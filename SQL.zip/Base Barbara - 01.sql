SELECT MT.CD_AVISO_CIRURGIA,
       MIN(MT.DT_INI_PED) AS DT_INI_PEND,
       MAX(MT.DT_FIM_PED) AS DT_FIM_PEND,
       TO_CHAR(SUM(DIAS)) || ' dias e ' ||
       TO_CHAR(TRUNC(SUM(MT.HORAS) * 24)) || ' horas' AS PERIO_TOTAL_PEND,
       MT.ESPECIALIDADE,
       MT.PRESTADOR
  FROM (
        SELECT DISTINCT 
               M.CD_GUIA,
               M.DT_MOVIMENTO AS DT_INI_PED,

               -- Data fim
               (SELECT MIN(P2.DT_MOVIMENTO)
                  FROM DBAMV.LOG_MOT_PEND P2
                     WHERE P2.CD_GUIA = M.CD_GUIA
                   AND P2.DT_MOVIMENTO > M.DT_MOVIMENTO
                   AND P2.CD_MOTIV_PEND_ANT = 2) AS DT_FIM_PED,

               -- Dias
               TRUNC( (SELECT NVL(MIN(P2.DT_MOVIMENTO), SYSDATE) - M.DT_MOVIMENTO
                         FROM DBAMV.LOG_MOT_PEND P2
                        WHERE P2.CD_GUIA = M.CD_GUIA
                          AND P2.DT_MOVIMENTO > M.DT_MOVIMENTO
                          AND P2.CD_MOTIV_PEND_ANT = 2) ) AS DIAS,

               -- Horas (parte decimal da diferen�a entre datas)
               MOD((SELECT NVL(MIN(P2.DT_MOVIMENTO), SYSDATE) - M.DT_MOVIMENTO
                      FROM DBAMV.LOG_MOT_PEND P2
                     WHERE P2.CD_GUIA = M.CD_GUIA
                       AND P2.DT_MOVIMENTO > M.DT_MOVIMENTO
                       AND P2.CD_MOTIV_PEND_ANT = 2),1) AS HORAS,

               T.ESP_MED   AS ESPECIALIDADE,
               T.PRESTADOR,
               T.CD_AVISO_CIRURGIA
          FROM DBAMV.LOG_MOT_PEND M
          JOIN GUIA G ON G.CD_GUIA = M.CD_GUIA
          JOIN ENKYO.TB_CIR_PENDENTES_NAC T ON T.CD_AVISO_CIRURGIA = G.CD_AVISO_CIRURGIA
         WHERE M.CD_MOTIV_PEND_ATU = 2
            OR M.CD_MOTIV_PEND_ANT = 2
           AND T.Dtgeracao_Avi_Cir BETWEEN TO_DATE('01/01/2025', 'DD/MM/RRRR') AND TO_DATE('30/06/2025', 'DD/MM/RRRR')
         GROUP BY M.CD_GUIA,
                  M.DT_MOVIMENTO,
                  T.ESP_MED,
                  T.PRESTADOR,
                  T.CD_MOT_PENDENCIA,
                  T.CD_AVISO_CIRURGIA
      ) MT
    
GROUP BY MT.CD_AVISO_CIRURGIA, MT.ESPECIALIDADE, MT.PRESTADOR,  MT.DT_INI_PED
ORDER BY MT.DT_INI_PED;
