---- INTEGRACAO DE EXAMES LABORATORIAIS -- FLEURY

UPDATE MVINTEGRA.IMV_SOLICITACAO_SADT
   SET TP_STATUS = 'A'
 WHERE CD_PEDIDO IN (2601153);
-----------------------------------------------------------------------------------------
SELECT IISS.CD_IMV_SOLICITACAO_SADT,
       IISS.TP_STATUS,
       IISS.CD_PEDIDO,
       IISS.CD_EXAME,
       IISS.CD_MATERIAL,
       
       IPL.CD_PED_LAB,
       IPL.CD_EXA_LAB,
       IPL.CD_MATERIAL,
       PL.NR_CONTROLE,
       
       EL.CD_CODIGO_EXTERNO,
       EL.SN_ATIVO,
       IISS.CD_SETOR

  FROM MVINTEGRA.IMV_SOLICITACAO_SADT IISS

  LEFT OUTER JOIN DBAMV.ITPED_LAB IPL
    ON IPL.CD_PED_LAB = IISS.CD_PEDIDO
   AND IISS.CD_EXAME = IPL.CD_EXA_LAB

  LEFT OUTER JOIN DBAMV.PED_LAB PL
    ON PL.CD_PED_LAB = IPL.CD_PED_LAB

  LEFT OUTER JOIN DBAMV.EXA_LAB EL
    ON EL.CD_EXA_LAB = IPL.CD_EXA_LAB

 WHERE IISS.CD_PEDIDO = 2614843 -- 2602050
----------------------------------------------------------------------------------------------------
  SELECT *
          FROM MVINTEGRA.IMV_SOLICITACAO_SADT
         WHERE CD_PEDIDO = 2601153
           AND CD_EXAME IN
               (1702, 1678, 811, 1688, 1707, 1700, 1659, 1709, 193)
        
--- VERIFICAR INTEGRACAO -----------------------------
        
          SELECT PL.CD_PED_LAB,
                 PL.HR_PED_LAB,
                 PL.CD_ATENDIMENTO,
                 
                 P.CD_PACIENTE,
                 P.NM_PACIENTE,
                 
                 PL.CD_SETOR,
                 S.NM_SETOR,
                 
                 PL.NR_CONTROLE,
                 
                 CASE
                 
                   WHEN PL.NR_CONTROLE > 0
                   
                    THEN
                    'SUCESSO'
                 
                   ELSE
                   
                    ISS.DS_ERRO
                 
                 END AS ERRO
                
                  FROM DBAMV.PED_LAB PL
                
                 INNER JOIN DBAMV.SETOR S
                    ON S.CD_SETOR = PL.CD_SETOR
                
                 INNER JOIN DBAMV.MULTI_EMPRESAS M
                    ON M.CD_MULTI_EMPRESA = S.CD_MULTI_EMPRESA
                
                 INNER JOIN DBAMV.ATENDIME A
                    ON A.CD_ATENDIMENTO = PL.CD_ATENDIMENTO
                
                 INNER JOIN DBAMV.PACIENTE P
                    ON P.CD_PACIENTE = A.CD_PACIENTE
                
                 INNER JOIN MVINTEGRA.IMV_SOLICITACAO_SADT ISS
                    ON ISS.CD_PEDIDO = PL.CD_PED_LAB
                
                 WHERE --( PL.DT_PEDIDO >=  ( SYSDATE -30 )) AND PL.NR_CONTROLE IS NULL AND ISS.DS_ERRO IS NULL
                
                --AND PL.CD_SETOR = 157
                
                 PL.CD_PED_LAB = 2614843
                
                 GROUP BY PL.CD_PED_LAB,
                    PL.HR_PED_LAB,
                    PL.CD_ATENDIMENTO,
                    
                    P.CD_PACIENTE,
                    P.NM_PACIENTE,
                    
                    PL.CD_SETOR,
                    S.NM_SETOR,
                    
                    PL.NR_CONTROLE,
                    
                    CASE
                    
                      WHEN PL.NR_CONTROLE > 0
                      
                       THEN
                       'SUCESSO'
                    
                      ELSE
                      
                       ISS.DS_ERRO
                    
                    END
                
                 ORDER BY PL.CD_PED_LAB DESC
   ----------------- verifica se exame em quest�o gera amostra--------------------------------------------------------------------                 
                     SELECT PL.CD_PED_LAB,
                            PL.NR_CONTROLE,
                            IPL.CD_EXA_LAB,
                            IPL.CD_MATERIAL,
                            AEL.CD_AMOSTRA
                       FROM DBAMV.PED_LAB PL
                      INNER JOIN DBAMV.ITPED_LAB IPL
                         ON IPL.CD_PED_LAB = PL.CD_PED_LAB
                       LEFT OUTER JOIN DBAMV.AMOSTRA_EXA_LAB AEL
                         ON AEL.CD_ITPED_LAB = IPL.CD_ITPED_LAB
                     --WHERE PL.CD_PED_LAB = 2614843
                      WHERE IPL.CD_EXA_LAB = 1849
                        AND PL.DT_PEDIDO >= '01/10/2025'
                        AND PL.CD_MULTI_EMPRESA = 2
