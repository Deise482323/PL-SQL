SELECT * FROM (
select
    pe.ano,
    pe.mes,
    pe.CD_ESTOQUE,
    ds_estoque,
    MB.DS_MOT_BAI,
    pe.vl_movimentacao,
    pe.vl_estoque_inicial,
   ((pe.vl_movimentacao / pe.vl_estoque_inicial)*100) perc_perda

  
from
  (
      select
            cc.cd_ano ano,
            cc.cd_mes mes,
            cc.CD_ESTOQUE,
            est.ds_estoque,
            SUM(vl_movimentacao) vl_movimentacao,

            --SUM(nvl(cc.vl_estoque_inicial,0)) vl_estoque_inicial
            SUM(((nvl(cc.vl_estoque_inicial,0)+ cc.vl_estoque_final)/ 2)) vl_estoque_inicial


      from dbamv.c_conest cc
      inner join dbamv.estoque est on est.cd_estoque = cc.cd_estoque
       inner join dbamv.mot_bai mb on mb.cd_mot_bai = me.cd_mot_bai
            
      left outer join
      (

              SELECT ppf.cd_produto,
                     ppf.CD_ESTOQUE,
                     ppf.ano,
                     ppf.mes,
                     ppf.DS_ESTOQUE,
                     sum (ppf.vl_movimentacao) vl_movimentacao 
                   


              FROM (SELECT
       mov.cd_produto,
       mov.ds_mot_bai,
       to_char(mov.dt_mvto_estoque, 'MM') mes,
       to_char(mov.dt_mvto_estoque, 'RRRR') ano,
       sum(qt_movimentacao) qt_movimentacao,
       sum((mov.qt_movimentacao * mov.vl_unitario)) vl_movimentacao,
       mov.DS_ESTOQUE,
       mov.CD_ESTOQUE
FROM (

        SELECT
               p.cd_produto,
               p.ds_produto,
               EST.DS_ESTOQUE,
               mb.ds_mot_bai,
               (ie.qt_movimentacao * up.vl_fator) qt_movimentacao,
               ME.HR_MVTO_ESTOQUE,
               ME.CD_ESTOQUE,
               me.dt_mvto_estoque,

               dbamv.fnc_mges_verif_vl_custo_ajuste(est.cd_multi_empresa, p.cd_produto,me.dt_mvto_estoque,me.hr_mvto_estoque) vl_unitario

        FROM dbamv.mvto_estoque me
        inner join dbamv.mot_bai mb on mb.cd_mot_bai = me.cd_mot_bai
        inner join dbamv.setor se on se.CD_SETOR = me.cd_setor
        inner join dbamv.itmvto_estoque ie on ie.cd_mvto_estoque = me.cd_mvto_estoque
        inner join dbamv.produto p on p.cd_produto = ie.cd_produto
        inner join dbamv.uni_pro up on up.cd_uni_pro = ie.cd_uni_pro
        inner join dbamv.estoque est on est.cd_estoque = me.cd_estoque

        where /*me.dt_mvto_estoque between '01/03/2016' and '31/03/2016'
        and */me.tp_mvto_estoque = 'X'
        and p.sn_consignado = 'N'
       

)mov
group by
       mov.cd_produto,
       mov.ds_mot_bai,
       to_char(mov.dt_mvto_estoque, 'MM'),
       to_char(mov.dt_mvto_estoque, 'RRRR'),
       mov.DS_ESTOQUE,
       mov.CD_ESTOQUE


ORDER BY
  DS_ESTOQUE) ppf
              group by
                     ppf.CD_ESTOQUE,
                     ppf.ano,
                     ppf.mes,
                     ppf.DS_ESTOQUE,
                     ppf.cd_produto


           ) mov
       on cc.cd_estoque = mov.cd_estoque
          and cc.cd_ano = mov.ano
          and cc.cd_mes =  mov.mes
          and cc.cd_produto = mov.cd_produto
      group by
           cc.cd_ano ,
            cc.cd_mes ,
            cc.CD_ESTOQUE,
            est.ds_estoque

  ) pe

) Q
WHERE Q.ANO = {ANO}
AND Q.MES = {MES}
AND (TRIM({CD_ESTOQUE}) IS NULL OR {CD_ESTOQUE} = 0 OR Q.CD_ESTOQUE = {CD_ESTOQUE})
