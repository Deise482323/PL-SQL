SELECT

 VW.DATA
 
,
 VW.CD_FILA_SENHA,
 VW.DS_FILA,
 TO_CHAR(VW.DH_REMOVIDO, 'HH24:MI'),
 VW.DS_SENHA
 
,
 COUNT(VW.CD_TRIAGEM_ATENDIMENTO) QTD_SENHA,
 COUNT(VW.TP_SEN_N) AS SEN_NORMAL,
 COUNT(VW.TP_SEN_P) AS SEN_PREFERENCIAL
 
,
 COUNT(VW.CD_ATENDIMENTO) AS CHECKIN,
 COUNT(VW.SEM_CHEKIN) AS SEM_CHECKIN

  FROM (SELECT TO_CHAR(DH_PRE_ATENDIMENTO, 'DD/MM/YYYY') AS DATA,
               TO_CHAR(DH_PRE_ATENDIMENTO, 'HH24') AS HORA,
               TA.CD_TRIAGEM_ATENDIMENTO,
               TA.CD_FILA_SENHA,
               FS.DS_FILA,
               TA.DS_SENHA,
               TA.DH_REMOVIDO
               
              ,
               CASE
                 WHEN TA.DS_SENHA LIKE '%P%' THEN
                  'PREFERENCIAL'
                 WHEN TA.DS_SENHA LIKE '%T%' THEN
                  'PREFERENCIAL'
                 ELSE
                  NULL
               END AS TP_SEN_P,
               CASE
                 WHEN TA.DS_SENHA NOT LIKE '%T%' THEN
                  'NORMAL'
                 ELSE
                  NULL
               END AS TP_SEN_N,
               TA.CD_ATENDIMENTO
               
              ,
               (SELECT TT.CD_TRIAGEM_ATENDIMENTO
                  FROM DBAMV.TRIAGEM_ATENDIMENTO TT
                 WHERE TT.CD_TRIAGEM_ATENDIMENTO = TA.CD_TRIAGEM_ATENDIMENTO
                   AND TT.CD_FILA_SENHA = TA.CD_FILA_SENHA
                   AND TA.CD_ATENDIMENTO IS NULL) AS SEM_CHEKIN
        
          FROM DBAMV.TRIAGEM_ATENDIMENTO TA, DBAMV.FILA_SENHA FS
         WHERE TA.CD_FILA_SENHA = FS.CD_FILA_SENHA
           AND TA.DH_PRE_ATENDIMENTO BETWEEN @P_DATA_INI AND @P_DATA_FIM
           AND TA.CD_FILA_SENHA IS NOT NULL
           AND TA.DH_REMOVIDO IS NOT NULL
           AND TA.CD_ATENDIMENTO IS NULL
           AND TO_CHAR(TA.DH_REMOVIDO, 'HH24') BETWEEN @HORA_IN AND
               @HORA_FIM 
               AND TA.CD_FILA_SENHA IN ({SET_01})
        
        -- ORDER BY HORA, 
        ) VW
-- WHERE VW.ds_fila in ({SET_01})
 GROUP BY VW.DATA,
          VW.HORA,
          VW.CD_FILA_SENHA,
          VW.DS_FILA,
          VW.DH_REMOVIDO,
          VW.DS_SENHA
 ORDER BY VW.CD_FILA_SENHA, VW.DATA, VW.HORA
