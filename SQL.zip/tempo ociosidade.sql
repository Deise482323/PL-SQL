SELECT SB2.CD_PRESTADOR,
       P.NM_PRESTADOR,
       SB2.CD_ESPECIALID,
       ESP.DS_ESPECIALID,
       -- Quantidade total de hor�rios esperados
       SUM(SB2.QTD_HORARIO_ESP) AS QTD_HORARIO_ESP,
       --SUM(SB2.HORAS_TOTAIS) AS HORAS_TOTAIS,
       LPAD(TRUNC(SUM(SB2.HORAS_TOTAIS)), 2, '0') || ':' ||
       LPAD(ROUND((SUM(SB2.HORAS_TOTAIS) - TRUNC(SUM(SB2.HORAS_TOTAIS))) * 60),
            2,
            '0') AS HORAS_TOTAIS_FORMATADO,
       -- Quantidade total de hor�rios ocupados
       SUM(SB2.QTD_HORARIOS_MARCADOS_NORM) AS QTD_HORARIOS_MARCADOS_NORM,
       --SUM(SB2.HORAS_OCUPADAS) AS HORAS_OCUPADAS,
       LPAD(TRUNC(SUM(SB2.HORAS_OCUPADAS)), 2, '0') || ':' ||
       LPAD(ROUND((SUM(SB2.HORAS_OCUPADAS) - TRUNC(SUM(SB2.HORAS_OCUPADAS))) * 60),
            2,
            '0') AS HORAS_OCUPADAS_FORMATADO,
       -- Quantidade total de hor�rios de encaixe
       SUM(SB2.QTD_HORARIOS_MARCADOS_ENC) AS QTD_HORARIOS_MARCADOS_ENC,
       --SUM(SB2.HORAS_ENCAIXE) AS HORAS_ENCAIXE,
       LPAD(TRUNC(SUM(SB2.HORAS_ENCAIXE)), 2, '0') || ':' ||
       LPAD(ROUND((SUM(SB2.HORAS_ENCAIXE) - TRUNC(SUM(SB2.HORAS_ENCAIXE))) * 60),
            2,
            '0') AS HORAS_ENCAIXE_FORMATADO,
       -- Quantidade total de hor�rios livres
       (SUM(SB2.QTD_HORARIO_ESP) - SUM(SB2.QTD_HORARIOS_MARCADOS_NORM)) AS QTD_HORARIOS_LIVRES,
       --(SUM(SB2.HORAS_TOTAIS) - SUM(SB2.HORAS_OCUPADAS)) AS HORAS_LIVRES,
       LPAD(TRUNC(SUM(SB2.HORAS_TOTAIS) - SUM(SB2.HORAS_OCUPADAS)), 2, '0') || ':' ||
       LPAD(ROUND(((SUM(SB2.HORAS_TOTAIS) - SUM(SB2.HORAS_OCUPADAS)) -
                  TRUNC(SUM(SB2.HORAS_TOTAIS) - SUM(SB2.HORAS_OCUPADAS))) * 60),
            2,
            '0') AS HORAS_LIVRES_FORMATADO

  FROM (
        -- Subquery para calcular m�tricas por agenda
        SELECT SB1.CD_AGENDA_CENTRAL,
                SB1.CD_PRESTADOR,
                SB1.CD_SER_DIS,
                SB1.CD_ESPECIALID,
                -- Quantidade de hor�rios esperados
                SB1.QTD_HORARIO_ESP,
                (SB1.QTD_HORARIO_ESP * SB1.TMP_MEDIO_AGENDA) / 60 AS HORAS_TOTAIS,
                -- Hor�rios normais marcados e tempo correspondente
                COALESCE(QT_MARCADOS_NORM, 0) AS QTD_HORARIOS_MARCADOS_NORM,
                (COALESCE(QT_MARCADOS_NORM, 0) * SB1.TMP_MEDIO_AGENDA) / 60 AS HORAS_OCUPADAS,
                -- Hor�rios de encaixe e tempo correspondente
                COALESCE(QT_MARCADOS_ENC, 0) AS QTD_HORARIOS_MARCADOS_ENC,
                (COALESCE(QT_MARCADOS_ENC, 0) * SB1.TMP_MEDIO_AGENDA) / 60 AS HORAS_ENCAIXE,
                -- Tempo m�dio da agenda
                SB1.TMP_MEDIO_AGENDA
        
          FROM (
                 -- C�lculo dos hor�rios esperados e tempo m�dio por agenda
                 SELECT AC.CD_AGENDA_CENTRAL,
                         AC.CD_PRESTADOR,
                         SD.CD_SER_DIS,
                         SD.CD_ESPECIALID,
                         MAX(AC.QT_ATENDIMENTO) -
                         SUM(NVL(ACST.QT_ATENDIMENTO, 0)) AS QTD_HORARIO_ESP,
                         AC.QT_TEMPO_MEDIO AS TMP_MEDIO_AGENDA
                   FROM DBAMV.AGENDA_CENTRAL AC
                   JOIN DBAMV.AGENDA_CENTRAL_SER_TIPO ACST
                     ON ACST.CD_AGENDA_CENTRAL = AC.CD_AGENDA_CENTRAL
                   JOIN DBAMV.SER_DIS SD
                     ON SD.CD_SER_DIS = ACST.CD_SER_DIS
                  WHERE AC.TP_AGENDA = 'A'
                    AND AC.SN_ATIVO = 'S'
                    AND AC.CD_MULTI_EMPRESA = 1
                    --AND AC.CD_PRESTADOR = 5314
                    AND AC.DT_AGENDA BETWEEN TO_DATE('&DT_INI', 'DD/MM/RRRR') AND
                        TO_DATE('&DT_FIM', 'DD/MM/RRRR')
                  GROUP BY AC.CD_AGENDA_CENTRAL,
                            AC.CD_PRESTADOR,
                            SD.CD_SER_DIS,
                            SD.CD_ESPECIALID,
                            AC.QT_TEMPO_MEDIO) SB1
          LEFT JOIN (
                     -- Conta hor�rios normais marcados
                     SELECT IAC.CD_AGENDA_CENTRAL,
                             IAC.CD_SER_DIS,
                             COUNT(*) AS QT_MARCADOS_NORM
                       FROM DBAMV.IT_AGENDA_CENTRAL IAC
                       JOIN DBAMV.AGENDA_CENTRAL AC1
                         ON AC1.CD_AGENDA_CENTRAL = IAC.CD_AGENDA_CENTRAL
                      WHERE IAC.SN_ENCAIXE = 'N'
                        AND IAC.NM_PACIENTE IS NOT NULL
                        AND IAC.CD_IT_AGENDA_PAI IS NULL
                        AND AC1.CD_MULTI_EMPRESA = 1
                        AND AC1.DT_AGENDA BETWEEN
                            TO_DATE('&DT_INI', 'DD/MM/RRRR') AND
                            TO_DATE('&DT_FIM', 'DD/MM/RRRR')
                      GROUP BY IAC.CD_AGENDA_CENTRAL, IAC.CD_SER_DIS) MARC_NORM
            ON SB1.CD_AGENDA_CENTRAL = MARC_NORM.CD_AGENDA_CENTRAL
           AND SB1.CD_SER_DIS = MARC_NORM.CD_SER_DIS
          LEFT JOIN (
                     -- Conta hor�rios marcados de encaixe
                     SELECT IAC.CD_AGENDA_CENTRAL,
                             IAC.CD_SER_DIS,
                             COUNT(*) AS QT_MARCADOS_ENC
                       FROM DBAMV.IT_AGENDA_CENTRAL IAC
                       JOIN DBAMV.AGENDA_CENTRAL AC1
                         ON AC1.CD_AGENDA_CENTRAL = IAC.CD_AGENDA_CENTRAL
                      WHERE IAC.SN_ENCAIXE = 'S'
                        AND IAC.NM_PACIENTE IS NOT NULL
                        AND IAC.CD_IT_AGENDA_PAI IS NULL
                        AND AC1.CD_MULTI_EMPRESA = 1
                        AND AC1.DT_AGENDA BETWEEN
                            TO_DATE('&DT_INI', 'DD/MM/RRRR') AND
                            TO_DATE('&DT_FIM', 'DD/MM/RRRR')
                      GROUP BY IAC.CD_AGENDA_CENTRAL, IAC.CD_SER_DIS) MARC_ENC
            ON SB1.CD_AGENDA_CENTRAL = MARC_ENC.CD_AGENDA_CENTRAL
           AND SB1.CD_SER_DIS = MARC_ENC.CD_SER_DIS
       
           
           ) SB2
  JOIN DBAMV.ESPECIALID ESP
    ON ESP.CD_ESPECIALID = SB2.CD_ESPECIALID
  JOIN DBAMV.PRESTADOR P
    ON P.CD_PRESTADOR = SB2.CD_PRESTADOR
 GROUP BY SB2.CD_PRESTADOR,
          P.NM_PRESTADOR,
          SB2.CD_ESPECIALID,
          ESP.DS_ESPECIALID
