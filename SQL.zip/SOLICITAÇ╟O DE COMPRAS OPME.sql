SELECT * FROM sol_com s
where s.cd_aviso_cirurgia = 196766



AVISO_CIRURGIA A
WHERE A.CD_AVISO_CIRURGIA = 196625
