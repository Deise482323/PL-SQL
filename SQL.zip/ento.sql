- obrigat�ria a informa��o >codigoDespesa< em Despesas Realizadas  no item 0000057142;
- obrigat�ria a informa��o >codigoDespesa< em Despesas Realizadas  no item 0000057142;

SELECT

                            SELECT cd_remessa FROM dbamv.tiss_guia WHERE cd_reg_fat = 2307
                            SELECT * FROM dbamv.tiss_guia WHERE cd_reg_fat = 2307

dbamv.pack_ffcv



  SELECT SUM(NVL(NVL(ITLAN_MED.VL_LIQUIDO, ITREG_FAT.VL_TOTAL_CONTA),
                       0))
          FROM DBAMV.ITLAN_MED,
               DBAMV.ITREG_FAT
         WHERE ITREG_FAT.CD_REG_FAT = ITLAN_MED.CD_REG_FAT(+)
           AND ITREG_FAT.CD_LANCAMENTO = ITLAN_MED.CD_LANCAMENTO(+)
           AND ITREG_FAT.CD_REG_FAT = 2307
           AND NVL(ITREG_FAT.SN_PERTENCE_PACOTE, 'N') = 'N'
           AND NVL(NVL(ITLAN_MED.TP_PAGAMENTO, ITREG_FAT.TP_PAGAMENTO), 'P') <> 'C'



      25421,41

      SELECT * FROM dbamv.tuss WHERE  cd_setor IS NOT null

      SELECT * FROM dbamv.tiss_itguia WHERE id_pai = 893794
      SELECT * FROM dbamv.tiss_itguia_out WHERE id_pai = 895368  AND tp_despesa IS null
      SELECT * FROM dbamv.tiss_itguia_OP WHERE id_pai = 893794
      SELECT vl_total_conta, cd_lancamento FROM dbamv.itreg_fat WHERE cd_lancamento IN (SELECT cd_lancamento FROM dbamv.itlan_med WHERE cd_reg_fat = 2307  AND tp_pagamento = 'P'  )
      AND cd_reg_fat =  2307


SELECT * FROM dbamv.itlan_med WHERE cd_reg_fat = 2307  AND tp_pagamento = 'P'  AND id_it_envio IS NULL

SELECT * FROM dbamv.itreg_fat WHERE cd_reg_fat = 2307   AND id_it_envio IS null  AND cd_lancamento IN (5450,5456,5462,5468)

SELECT * FROM dbamv.itreg_fat WHERE cd_reg_fat = 2307    AND cd_lancamento IN (5450,5456,5462,5468)


SELECT * FROM dbamv.tuss WHERE cd_pro_fat IN ('30730082', '30726158', '30727138', '30910129')

SELECT * FROM dbamv.reg_fat WHERE cd_reg_fat = 2307
SELECT cd_multi_empresa FROM dbamv.atendime WHERE cd_atendimento = 65486

DECLARE
  erro VARCHAR2(2000);  retorna varchar2(1000);
begin
  dbamv.pkg_mv2000.atribui_empresa(1);
--Tiss 3.0
  retorna := dbamv.pkg_ffcv_tiss_v3.f_gera_tiss(null,null,65486,2307,'R',erro,null);
  dbms_output.put_line(retorna|| ' ' || erro);
END;


