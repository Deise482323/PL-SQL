SELECT DECODE(A.TP_ATENDIMENTO,
              'U',
              'P.A',
              'E',
              'EXT',
              'A',
              'AMB',
              'I',
              'INT') TP_ATEND,
       OA.DS_ORI_ATE,
       A.CD_ATENDIMENTO,
       IRA.CD_REG_AMB,
       C.NM_CONVENIO,
       P.NM_PACIENTE,
       A.DT_ATENDIMENTO,
       A.DT_ALTA,
       IRA.DT_FECHAMENTO,
       A.SN_RETORNO,
       PR.NM_PRESTADOR,
       E.DS_ESPECIALID,
       0 SOMA_RECEBIDO,
       0 VL_RECEBER,
       SUM(IRA.VL_TOTAL_CONTA) VLR_TOTAL,
       DECODE(IRA.SN_FECHADA, 'S', 'FECHADA', 'N', 'ABERTA') SITUACAO_CONTA,
       C.CD_CONVENIO,
       U.NM_USUARIO
  FROM DBAMV.ATENDIME A
 INNER JOIN DBAMV.PACIENTE P
    ON P.CD_PACIENTE = A.CD_PACIENTE
 INNER JOIN DBAMV.PRESTADOR PR
    ON PR.CD_PRESTADOR = A.CD_PRESTADOR
 INNER JOIN DBAMV.ESPECIALID E
    ON E.CD_ESPECIALID = A.CD_ESPECIALID
 INNER JOIN DBAMV.ORI_ATE OA
    ON OA.CD_ORI_ATE = A.CD_ORI_ATE
 INNER JOIN DBAMV.ITREG_AMB IRA
    ON IRA.CD_ATENDIMENTO = A.CD_ATENDIMENTO
 INNER JOIN DBAMV.REG_AMB RA
    ON RA.CD_REG_AMB = IRA.CD_REG_AMB
 INNER JOIN DBAMV.CONVENIO C
    ON C.CD_CONVENIO = RA.CD_CONVENIO
  JOIN USUARIOS U
    ON U.CD_USUARIO = IRA.CD_USUARIO

 WHERE IRA.DT_FECHAMENTO >= TO_DATE(@P_ATEND_INI, 'dd/mm/RRRR')
   AND IRA.DT_FECHAMENTO < TO_DATE(@P_ATEND_FIM, 'dd/mm/RRRR')
   AND A.CD_MULTI_EMPRESA = 1
   AND RA.CD_CONVENIO IN (40, 148, 81, 82)
   AND A.TP_ATENDIMENTO IN ('A', 'E', 'U')
   AND IRA.SN_FECHADA = 'S'
   AND IRA.DT_FECHAMENTO IS NOT NULL
   AND {V_VAR}
 group by DECODE(a.TP_ATENDIMENTO,
                 'U',
                 'P.A',
                 'E',
                 'EXT',
                 'A',
                 'AMB',
                 'I',
                 'INT'),
          OA.DS_ORI_ATE,
          A.CD_ATENDIMENTO,
          IRA.CD_REG_AMB,
          C.NM_CONVENIO,
          p.nm_paciente,
          a.DT_ATENDIMENTO,
          A.DT_ALTA,
          A.SN_RETORNO,
          PR.NM_PRESTADOR,
          E.DS_ESPECIALID,
          DECODE(IRA.SN_FECHADA, 'S', 'FECHADA', 'N', 'ABERTA'),
          c.cd_convenio,
          U.NM_USUARIO,
          IRA.DT_FECHAMENTO
