select '<table height=30 width=auto bgcolor><tr><td align=left><font face = "Arial" size=1><b>' ||
       v.cd_atendimento || '</b></font></td></tr></table></font>' Atend,
       
       case
         when COUNT(*)
          OVER(PARTITION BY
                   substr(upper(nvl(v.nm_paciente, v.NM_PACIENTE)),
                          1,
                          instr(upper(nvl(v.nm_paciente, v.NM_PACIENTE)), ' '))) > 1 then
          decode(v.nm_paciente,
                 null,
                 '',
                 '<table height=30 width=auto><tr><td align=left><font face = "Arial" color = red size=1><b>' ||
                 v.nm_paciente || '</b></font></td></tr></table></font>')
         else
          decode(v.nm_paciente,
                 null,
                 '',
                 '<table height=30 width=auto><tr><td align=left><font face = "Arial" size=1><b>' ||
                 v.nm_paciente || '</b></font></td></tr></table></font>')
       end PACIENTE,
       
       CASE
         WHEN SUBSTR(v.ds_resumo, 1, 6) = 'UTI 1�' THEN
          '<table height=30 width=60 bgcolor><tr><td align=left><font face = "Arial" color = #008000 size=1><b>' ||
          v.ds_resumo || '</b></font></td></tr></table></font>'
         WHEN SUBSTR(v.ds_resumo, 1, 6) = 'UTI 1F' THEN
          '<table height=30 width=60 ><tr><td align=left><font face = "Arial" color = DarkOliveGreen size=1><b>' ||
          v.ds_resumo || '</b></font></td></tr></table></font>'
         WHEN SUBSTR(v.ds_resumo, 1, 6) = 'UTI 5�' THEN
          '<table height=30 width=60 ><tr><td align=left><font face = "Arial" color = #9400d3 size=1><b>' ||
          v.ds_resumo || '</b></font></td></tr></table></font>'
         WHEN SUBSTR(v.ds_resumo, 1, 3) = 'UCO' THEN
          '<table height=30 width=60 ><tr><td align=left><font face = "Arial" color = #ff8c00 size=1><b>' ||
          v.ds_resumo || '</b></font></td></tr></table></font>'
         WHEN V.CD_UNID_INT = 50 THEN
          '<table height=30 width=60 ><tr><td align=left><font face = "Arial Black" color = #B22222 size=1><b>' ||
          v.ds_resumo || '</b></font></td></tr></table></font>'
       END leito,
       
       '<table height=30 width=auto><tr><td align=left><font face = "Arial" size=1><b>' ||
       v.sexo || '</b></font></td></tr></table></font>' Sexo,
       
       /* EM 27/01/2020 ==incluido idade a pedido de marisol*/
       '<table height=30 width=auto><tr><td align=left><font face = "Arial" size=1><b>' ||
       v.Idade || '</b></font></td></tr></table></font>' Idade,
       
       CASE
         WHEN v.acomodacao = 'APTO' THEN
          '<table height=30 width=auto ><tr><td align=left><font face = "Arial" color = #0000ff size=1><b>' ||
          v.acomodacao || '</b></font></td></tr></table></font>'
         ELSE
          '<table height=30 width=auto ><tr><td align=left><font face = "Arial" color = #ff0000 size=1><b>' ||
          v.acomodacao || '</b></font></td></tr></table></font>'
       END acomo,
       
       '<table height=30 width=auto><tr><td align=left><font face = "Arial" size=1><b>' ||
       v.fugulin || '</b></font></td></tr></table></font>' fugulin,
       tipo_iso isolamento,/*
       decode(v.tipo_iso,
              'Isolamento De Contato',
              '<img width="25px" height="25px" align="center" src="/portal/bi/img/dash/avental_amarelo.png" border=0>',
              'Isolamento Respirat�rio Gotic�las',
              '<img width="25px" height="25px" align="center" src="/portal/bi/img/dash/avental_verde.png" border=0>',
              'Isolamento Respirat�rio Aeross�is',
              '<img width="25px" height="25px" align="center" src="/portal/bi/img/dash/avental_azul.png" border=0>',
              'Isolamento de Contato + Gotic�las',
              '<img width="25px" height="25px" align="center" src="/portal/bi/img/dash/avental_azul_amarelo.png" border=0>',
              'Isolamento de Contato + Aeross�is',
              '<img width="25px" height="25px" align="center" src="/portal/bi/img/dash/avental_verde_amarelo.png" border=0>',
              'Sem Isolamento',
              '<img width="25px" height="25px" align="center" src="/portal/bi/img/dash/avental_int.png" border=0>',
              'Isolamento de Prote��o Ambiental',
              '<img width="25px" height="25px" align="center" src="/portal/bi/img/dash/avental_cinza.png" border=0>'
              \* EM 27/01/2020 == INCLU�DA RESPOSTA "N�O" SE NENHUM TIPO DE ISOLAMENTO FOI ESCOLHIDA. a pedido de marisol*\,
              'N�O') isolamento2,*/
       CASE
         WHEN V.SN_SUIC = 'SIM' THEN
          '<table height=30 width=auto ><tr><td align=left><font face = "Arial" color = #00bfff size=1><b>' ||
          v.sn_suic || '</b></font></td></tr></table></font>'
         ELSE
          '<table height=30 width=auto><tr><td align=left><font face = "Arial" size=1><b>' ||
          v.sn_suic || '</b></font></td></tr></table></font>'
       END RISCO_SUICIDIO,
       '<table height=30 width=auto><tr><td align=center><font face = "Arial" size=1><b>' ||
       to_char(v.dt_score, 'dd/mm/rrrr hh24:mi:ss') ||
       '</b></font></td></tr></table></font>' Hr_Score,
       
       '<table height=30 width=auto><tr><td align=left><font face = "Arial" size=1><b>' ||
       v.LOCAL_ALTA || '</b></font></td></tr></table></font>' LOCAL_ALTA,
       
       v.observacao,
       '<table height=20 width=21><tr><td align=center><font size=1 font color=green><b>' ||
       V.LEITO_DESTINO || '</font></td></tr></table>' LEITO_DESTINO,
       
       V.NM_CONVENIO

  from (SELECT A.CD_ATENDIMENTO,
                P.NM_PACIENTE,
                DBAMV.FN_IDADE(P.DT_NASCIMENTO, 'a', A.DT_ATENDIMENTO) IDADE,
                P.TP_SEXO SEXO,
                UI.CD_UNID_INT,
                (CASE
                  WHEN UI.CD_UNID_INT IN (3, 47) THEN
                   'UTI 1�-' || SUBSTR(L.DS_RESUMO, 7, 2)
                  WHEN UI.CD_UNID_INT = 48 THEN
                   'UTI 1F-' || SUBSTR(L.DS_RESUMO, 7, 2)
                  WHEN UI.CD_UNID_INT = 15 THEN
                   'UTI 5�-' || SUBSTR(L.DS_RESUMO, 7, 2)
                  WHEN UI.CD_UNID_INT = 14 AND L.DS_RESUMO <> 'EX-UCO' THEN
                   'UCO -' || SUBSTR(L.DS_RESUMO, 7, 2)
                  WHEN UI.CD_UNID_INT = 14 AND L.DS_RESUMO = 'EX-UCO' THEN
                   'UCO -EX'
                  WHEN UI.CD_UNID_INT IN (50) THEN
                   'UPED -' || SUBSTR(DS_RESUMO, (INSTR(DS_RESUMO,'-')+1), 3)
                END) DS_RESUMO,
                C.DS_CID HD,
                DECODE(A.CD_TIP_ACOM_COBERTURA, 1, 'ENF', 2, 'APTO') ACOMODACAO,
                NULL DT_DOCUMENTO, /*COLOCAR DATA QUE FOI CRIADO O DOCUMENTO*/
                (SELECT SUBSTR(ER.LO_VALOR, 1, 150)
                   FROM EDITOR_REGISTRO_CAMPO ER
                   JOIN EDITOR_CAMPO EC1
                     ON EC1.CD_CAMPO = ER.CD_CAMPO
                  WHERE ER.CD_REGISTRO =
                        (SELECT MAX(EC.CD_EDITOR_REGISTRO)
                           FROM PW_DOCUMENTO_CLINICO DC
                           JOIN PW_EDITOR_CLINICO EC
                             ON EC.CD_DOCUMENTO_CLINICO =
                                DC.CD_DOCUMENTO_CLINICO
                          WHERE DC.TP_STATUS = 'FECHADO'
                            AND EC.CD_DOCUMENTO = 631
                            AND DC.CD_ATENDIMENTO = A.CD_ATENDIMENTO)
                    AND EC1.DS_IDENTIFICADOR = 'DS_SCORE_FUGULIN_1') FUGULIN,
                (SELECT DECODE(TO_CHAR(ER.LO_VALOR), 'true', 'SIM', 'N�O')
                   FROM EDITOR_REGISTRO_CAMPO ER
                   JOIN EDITOR_CAMPO EC1
                     ON EC1.CD_CAMPO = ER.CD_CAMPO
                  WHERE ER.CD_REGISTRO =
                        (SELECT MAX(EC.CD_EDITOR_REGISTRO)
                           FROM PW_DOCUMENTO_CLINICO DC
                           JOIN PW_EDITOR_CLINICO EC
                             ON EC.CD_DOCUMENTO_CLINICO =
                                DC.CD_DOCUMENTO_CLINICO
                          WHERE DC.TP_STATUS = 'FECHADO'
                            AND EC.CD_DOCUMENTO = 631
                            AND DC.CD_ATENDIMENTO = A.CD_ATENDIMENTO)
                    AND EC1.DS_IDENTIFICADOR = 'CK_ISOLA_SIM_1') TIPO_ISO,
                (SELECT SUBSTR(TO_CHAR(ER.LO_VALOR),
                               (INSTR(ER.LO_VALOR, '|') + 2),
                               40)
                   FROM EDITOR_REGISTRO_CAMPO ER
                   JOIN EDITOR_CAMPO EC1
                     ON EC1.CD_CAMPO = ER.CD_CAMPO
                  WHERE ER.CD_REGISTRO =
                        (SELECT MAX(EC.CD_EDITOR_REGISTRO)
                           FROM PW_DOCUMENTO_CLINICO DC
                           JOIN PW_EDITOR_CLINICO EC
                             ON EC.CD_DOCUMENTO_CLINICO =
                                DC.CD_DOCUMENTO_CLINICO
                          WHERE DC.TP_STATUS = 'FECHADO'
                            AND EC.CD_DOCUMENTO = 631
                            AND DC.CD_ATENDIMENTO = A.CD_ATENDIMENTO)
                    AND EC1.DS_IDENTIFICADOR = 'CK_SCORE_VAGAUTI_2') SN_SUIC,
                (SELECT SUBSTR(TO_CHAR(ER.LO_VALOR), 1, 3999)
                   FROM EDITOR_REGISTRO_CAMPO ER
                   JOIN EDITOR_CAMPO EC1
                     ON EC1.CD_CAMPO = ER.CD_CAMPO
                  WHERE ER.CD_REGISTRO =
                        (SELECT MAX(EC.CD_EDITOR_REGISTRO)
                           FROM PW_DOCUMENTO_CLINICO DC
                           JOIN PW_EDITOR_CLINICO EC
                             ON EC.CD_DOCUMENTO_CLINICO =
                                DC.CD_DOCUMENTO_CLINICO
                          WHERE DC.TP_STATUS = 'FECHADO'
                            AND EC.CD_DOCUMENTO = 631
                            AND DC.CD_ATENDIMENTO = A.CD_ATENDIMENTO)
                    AND EC1.DS_IDENTIFICADOR = 'DS_SCORE_OBSERVACOES_1') OBSERVACAO,
                (SELECT DC1.DH_CRIACAO
                   FROM PW_DOCUMENTO_CLINICO DC1
                  WHERE DC1.CD_DOCUMENTO_CLINICO =
                        (SELECT MAX(DC.CD_DOCUMENTO_CLINICO)
                           FROM PW_DOCUMENTO_CLINICO DC
                           JOIN PW_EDITOR_CLINICO EC
                             ON EC.CD_DOCUMENTO_CLINICO =
                                DC.CD_DOCUMENTO_CLINICO
                          WHERE DC.TP_STATUS = 'FECHADO'
                            AND EC.CD_DOCUMENTO = 631
                            AND DC.CD_ATENDIMENTO = A.CD_ATENDIMENTO)) DT_SCORE,
                (SELECT (CASE
                          WHEN EC1.DS_IDENTIFICADOR = 'RB_ALTA_CASA_1' THEN
                           'CASA'
                          WHEN EC1.DS_IDENTIFICADOR = 'RB_ALTA_UNID_INT_1' THEN
                           'UNIDADE INTERNA��O'
                          ELSE
                           NULL
                        END)
                   FROM EDITOR_REGISTRO_CAMPO ER
                   JOIN EDITOR_CAMPO EC1
                     ON EC1.CD_CAMPO = ER.CD_CAMPO
                  WHERE ER.CD_REGISTRO =
                        (SELECT MAX(EC.CD_EDITOR_REGISTRO)
                           FROM PW_DOCUMENTO_CLINICO DC
                           JOIN PW_EDITOR_CLINICO EC
                             ON EC.CD_DOCUMENTO_CLINICO =
                                DC.CD_DOCUMENTO_CLINICO
                          WHERE EC.CD_DOCUMENTO = 631
                            AND DC.TP_STATUS = 'FECHADO'
                            AND DC.CD_ATENDIMENTO = A.CD_ATENDIMENTO)
                    AND (EC1.DS_IDENTIFICADOR = 'RB_ALTA_CASA_1' or
                        EC1.DS_IDENTIFICADOR = 'RB_ALTA_UNID_INT_1')
                    AND to_char(ER.LO_VALOR) = 'true') LOCAL_ALTA,
                
                (SELECT LT.DS_ENFERMARIA
                   FROM MOV_INT MI
                  INNER JOIN ATENDIME AT1
                     ON AT1.CD_ATENDIMENTO = MI.CD_ATENDIMENTO
                  INNER JOIN LEITO LT
                     ON LT.CD_LEITO = MI.CD_LEITO
                  INNER JOIN UNID_INT UI
                     ON UI.CD_UNID_INT = LT.CD_UNID_INT
                  WHERE AT1.DT_ALTA IS NULL
                    AND MI.HR_LIB_MOV IS NULL
                    AND MI.TP_MOV IN ('R')
                    AND EXISTS
                  (SELECT *
                           FROM MOV_INT MI2
                          INNER JOIN LEITO LT2
                             ON MI2.CD_LEITO = LT2.CD_LEITO
                          INNER JOIN ATENDIME AT2
                             ON AT2.CD_ATENDIMENTO = MI2.CD_ATENDIMENTO
                          WHERE MI2.TP_MOV IN ('O', 'I')
                            AND MI2.HR_LIB_MOV IS NULL
                            AND LT2.CD_UNID_INT IN (3, 14, 15, 47, 50)
                            AND MI2.CD_ATENDIMENTO = MI.CD_ATENDIMENTO)
                    AND AT1.CD_ATENDIMENTO = A.CD_ATENDIMENTO ---6895256
                 ) LEITO_DESTINO,
                 
                 CV.NM_CONVENIO
         
           FROM DBAMV.ATENDIME A
          INNER JOIN DBAMV.PACIENTE P
             ON P.CD_PACIENTE = A.CD_PACIENTE
          INNER JOIN DBAMV.CONVENIO CV 
             ON CV.CD_CONVENIO = A.CD_CONVENIO
          INNER JOIN DBAMV.LEITO L
             ON L.CD_LEITO = A.CD_LEITO
          INNER JOIN DBAMV.UNID_INT UI
             ON UI.CD_UNID_INT = L.CD_UNID_INT
           LEFT JOIN DBAMV.CID C
             ON C.CD_CID = A.CD_CID
          INNER JOIN DBAMV.TIP_ACOM TP
             ON TP.CD_TIP_ACOM = A.CD_TIP_ACOM_COBERTURA
          WHERE A.DT_ALTA IS NULL
            AND EXISTS
          (SELECT 1
                   FROM PW_DOCUMENTO_CLINICO DC
                   JOIN PW_EDITOR_CLINICO EC
                     ON EC.CD_DOCUMENTO_CLINICO = DC.CD_DOCUMENTO_CLINICO
                  WHERE EC.CD_DOCUMENTO = 631
                    AND DC.TP_STATUS = 'FECHADO'
                    AND DC.CD_ATENDIMENTO = A.CD_ATENDIMENTO
                    AND TO_DATE(DC.DH_CRIACAO, 'DD/MM/RRRR') >=
                        (TO_DATE(SYSDATE, 'DD/MM/RRRR') - 2))
            AND EXISTS
          (SELECT MAX(MI.CD_MOV_INT)
                   FROM MOV_INT MI
                  INNER JOIN LEITO LT
                     ON MI.CD_LEITO = LT.CD_LEITO
                  INNER JOIN UNID_INT UI
                     ON LT.CD_UNID_INT = UI.CD_UNID_INT
                  WHERE MI.CD_ATENDIMENTO = A.CD_ATENDIMENTO
                    AND MI.DT_LIB_MOV IS NULL
                    AND UI.CD_SETOR NOT IN
                        (SELECT SE.CD_SETOR
                           FROM SETOR SE
                          WHERE SE.NM_SETOR LIKE 'UTI%'
                            AND SE.CD_MULTI_EMPRESA = 1
                            AND SE.SN_ATIVO = 'S'))
            AND A.TP_ATENDIMENTO = 'I'
            AND A.CD_MULTI_EMPRESA = 1
            AND UI.CD_SETOR IN (SELECT SE.CD_SETOR
                                  FROM SETOR SE
                                 WHERE SE.NM_SETOR LIKE 'UTI%'
                                   AND SE.CD_MULTI_EMPRESA = 1
                                   AND SE.SN_ATIVO = 'S') -- UNIDADES DE UTI'S E UCO;
        ) v
 ORDER BY v.CD_UNID_INT, to_char(v.dt_score, 'dd/mm/rrrr hh24:mi:ss')
