select DISTINCT me.Cd_Multi_Empresa,
                me.ds_multi_empresa,
                p.nr_cpf,
                p.nm_paciente DEVEDOR,
                p.nm_paciente,
                p.ds_endereco,
                c.nm_cidade,
                uf.nm_uf,
                p.nr_cep,
                p.nr_ddd_fone || p.nr_fone FONE,
                p.nr_ddd_celular || p.nr_celular CELULAR,
                p.email,
                cr.cd_nota_fiscal,
                a.cd_atendimento,
                --cr.nr_documento,
                itc.dt_vencimento,
                CR.CD_CON_REC,
                -- IRA.VL_TOTAL_CONTA,
                cr.vl_previsto SALDO,
                ITC.VL_DUPLICATA VALOR_CONTA,
                ITC.VL_SOMA_RECEBIDO VALOR_RECEBIDO,
                ROUND(cr.vl_previsto - ITC.vl_soma_recebido) SALDO_DEVEDOR,
                DECODE(ICR.TP_QUITACAO,
                       'Q',
                       'QUITADA',
                       'C',
                       'COMPROMETIDA',
                       'P',
                       'PARCIALMENTE RECEBIDA') SITUACAO_CONTA,
                CR.TP_QUITACAO,
                a.dt_atendimento,
                A.DT_ALTA,
                A.DS_OBS_ALTA MOTIVO_DA_ALTA,
                decode(a.tp_atendimento,
                       'I',
                       'INTERNACAO',
                       'A',
                       'AMBULATORIO',
                       'E',
                       'EXTERNO',
                       'U',
                       'URGENCIA') TIPO_ATENDIMENTO,
                co.nm_convenio,
                RRC.DT_RECEBIMENTO,
                 RRC.CD_RESPOSAVEL,
                R.NM_RESPONSAVEL
  from con_rec cr
 inner join itcon_rec itc
    on itc.cd_con_rec = cr.cd_con_rec
 INNER JOIN RECCON_REC RRC
    ON RRC.CD_ITCON_REC = ITC.CD_ITCON_REC
 inner join atendime a
    on a.cd_atendimento = cr.cd_atendimento
--INNER JOIN dbamv.itreg_amb ira
--on ira.cd_atendimento = a.CD_ATENDIMENTO*/
 inner join multi_empresas me
    on me.cd_multi_empresa = cr.cd_multi_empresa
 inner join paciente p
    on p.cd_paciente = a.cd_paciente
 inner join cidade c
    on p.cd_cidade = c.cd_cidade
 inner join uf
    on uf.cd_uf = c.cd_uf
 inner join convenio co
    on co.cd_convenio = a.cd_convenio
 INNER JOIN DBAMV.ITCON_REC ICR
    ON ICR.CD_CON_REC = CR.CD_CON_REC
 INNER JOIN RESPONSAVEL R
    ON R.CD_RESPOSAVEL = RRC.CD_RESPOSAVEL

 /*where a.cd_atendimento IN ({ATENDIM_AUX})
    OR to_date(a.dt_atendimento, 'dd/mm/rrrr') BETWEEN
       to_date(@P_ATEND_INI, 'dd/mm/rrrr') AND
       to_date(@P_ATEND_FIM, 'dd/mm/rrrr')
      
   AND ME.CD_MULTI_EMPRESA IN ({EMPRESA_AUX})
   AND {V_VAR}
   and cr.tp_con_rec = 'P'*/

where TO_DATE(itc.dt_vencimento, 'DD/MM/RRRR') BETWEEN '15/11/2023' AND
'21/11/2023'
AND ME.CD_MULTI_EMPRESA = 1
AND cr.tp_con_rec = 'P'
 AND ICR.TP_QUITACAO = 'P'

 GROUP BY me.Cd_Multi_Empresa,
          me.ds_multi_empresa,
          p.nr_cpf,
          p.nm_paciente,
          p.ds_endereco,
          c.nm_cidade,
          uf.nm_uf,
          p.nr_cep,
          p.nr_ddd_fone,
          p.nr_fone,
          p.nr_ddd_celular,
          p.nr_celular,
          p.email,
          cr.cd_nota_fiscal,
          a.cd_atendimento,
          --cr.nr_documento,
          itc.dt_vencimento,
          CR.CD_CON_REC,
          -- IRA.VL_TOTAL_CONTA,
          cr.vl_previsto,
          ITC.vl_duplicata,
          ITC.vl_soma_recebido,
          ICR.TP_QUITACAO,
          CR.TP_QUITACAO,
          a.dt_atendimento,
          A.DT_ALTA,
          A.DS_OBS_ALTA,
          a.tp_atendimento,
          co.nm_convenio,
          ICR.TP_QUITACAO,
          RRC.DT_RECEBIMENTO,
          RRC.CD_RESPOSAVEL,
          R.NM_RESPONSAVEL
