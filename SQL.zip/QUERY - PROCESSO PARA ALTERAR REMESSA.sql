-- PROCESSO PARA ALTERAR REMESSA

-- CONSULTAR A REMESSA
SELECT *
  FROM DBAMV.REMESSA_FATURA
 WHERE CD_REMESSA /*= 600901 */
       IN (605799 )

-- CONSULTAR A FATURA / LOCALIZAR O CONVENIO
  SELECT *
          FROM DBAMV.FATURA
         WHERE CD_FATURA /*= 21782*/
               IN (22231)
         ORDER BY 4 DESC
            
            -- CONSULTAR O CONVENIO / ONDE SER� VERIFICADO QUAL O N�MERO DA FATURA PARA SER ALTERADO
              SELECT *
                FROM DBAMV.FATURA
               WHERE CD_CONVENIO = 35
               ORDER BY 4 DESC 
                        
                        -- ABRIR O CADEADO PARA ALTERA��O
                          SELECT ROWID, RF.*
                            FROM DBAMV.REMESSA_FATURA RF
                           WHERE CD_REMESSA /*= 600901*/
                                IN (605799 )
                             FOR UPDATE
                          
                          -- CHECK 
                          -- FECHAR CADEADO
                          -- COMMIT
