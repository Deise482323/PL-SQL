SELECT MT.CD_AVISO_CIRURGIA,
       MT.DTGERACAO_AVI_CIR AS DT_CRIA_AVISO,
       MIN(MT.DT_MOVIMENTO) AS DT_INI_STATUS_P,
       MAX(MT.DT_FIM_STATUS) AS DT_FIM_STATUS,
       
       -- tempo m�dio em dias (decimais), transformado em dias e horas
       TO_CHAR(TRUNC(AVG(MT.TEMPO_TOTAL))) || ' dias e ' ||
       TO_CHAR(TRUNC(MOD(AVG(MT.TEMPO_TOTAL), 1) * 24)) || ' horas' AS TEMP_MEDIO_STATUS

  FROM (SELECT T.CD_AVISO_CIRURGIA,
               LG.DT_MOVIMENTO,
               T.DTGERACAO_AVI_CIR,
               
               -- pr�xima mudan�a para status 'S'
               (SELECT MIN(LG1.DT_MOVIMENTO)
                  FROM LOG_GUIA LG1
                 WHERE LG1.CD_GUIA = LG.CD_GUIA
                   AND LG1.DT_MOVIMENTO > LG.DT_MOVIMENTO
                   AND LG1.TP_SITUACAO_MOVIMENTO = 'S') AS DT_FIM_STATUS,
               
               -- tempo total em dias com fra��o
               (SELECT (MIN(LG1.DT_MOVIMENTO) - LG.DT_MOVIMENTO)
                  FROM LOG_GUIA LG1
                 WHERE LG1.CD_GUIA = LG.CD_GUIA
                   AND LG1.DT_MOVIMENTO > LG.DT_MOVIMENTO
                   AND LG1.TP_SITUACAO_MOVIMENTO = 'S') AS TEMPO_TOTAL
        
          FROM LOG_GUIA LG
          JOIN GUIA G
            ON G.CD_GUIA = LG.CD_GUIA
          JOIN ENKYO.TB_CIR_PENDENTES_NAC T
            ON T.CD_AVISO_CIRURGIA = G.CD_AVISO_CIRURGIA
         WHERE LG.TP_SITUACAO_MOVIMENTO = 'P'
           AND LG.DT_MOVIMENTO BETWEEN TO_DATE('01/01/2024', 'DD/MM/RRRR') AND
               TO_DATE('30/04/2024', 'DD/MM/RRRR')) MT
 WHERE MT.TEMPO_TOTAL IS NOT NULL
 GROUP BY MT.CD_AVISO_CIRURGIA, MT.DTGERACAO_AVI_CIR
 ORDER BY MIN(MT.DT_MOVIMENTO);
 ----------------------------------------------------------------
 SELECT MT.CD_AVISO_CIRURGIA,
       MT.DT_AVISO_CIRURGIA AS DT_CRIA_AVISO,
       MIN(MT.DT_MOVIMENTO) AS DT_INI_STATUS_P,
       MAX(MT.DT_FIM_STATUS) AS DT_FIM_STATUS,
       
       -- tempo m�dio em dias (decimais), transformado em dias e horas
       TO_CHAR(TRUNC(AVG(MT.TEMPO_TOTAL))) || ' dias e ' ||
       TO_CHAR(TRUNC(MOD(AVG(MT.TEMPO_TOTAL), 1) * 24)) || ' horas' AS TEMP_MEDIO_STATUS

  FROM (SELECT T.CD_AVISO_CIRURGIA,
               LG.DT_MOVIMENTO,
               T.DT_AVISO_CIRURGIA,
               
               -- pr�xima mudan�a para status 'S'
               (SELECT MIN(LG1.DT_MOVIMENTO)
                  FROM LOG_GUIA LG1
                 WHERE LG1.CD_GUIA = LG.CD_GUIA
                   AND LG1.DT_MOVIMENTO > LG.DT_MOVIMENTO
                   AND LG1.TP_SITUACAO_MOVIMENTO = 'S') AS DT_FIM_STATUS,
               
               -- tempo total em dias com fra��o
               (SELECT (MIN(LG1.DT_MOVIMENTO) - LG.DT_MOVIMENTO)
                  FROM LOG_GUIA LG1
                 WHERE LG1.CD_GUIA = LG.CD_GUIA
                   AND LG1.DT_MOVIMENTO > LG.DT_MOVIMENTO
                   AND LG1.TP_SITUACAO_MOVIMENTO = 'S') AS TEMPO_TOTAL
        
          FROM LOG_GUIA LG
          JOIN GUIA G
            ON G.CD_GUIA = LG.CD_GUIA
          JOIN AVISO_CIRURGIA T
            ON T.CD_AVISO_CIRURGIA = G.CD_AVISO_CIRURGIA
         WHERE LG.TP_SITUACAO_MOVIMENTO = 'P'
           AND LG.DT_MOVIMENTO BETWEEN TO_DATE('01/01/2024', 'DD/MM/RRRR') AND
               TO_DATE('30/04/2024', 'DD/MM/RRRR')) MT
 WHERE MT.TEMPO_TOTAL IS NOT NULL
 GROUP BY MT.CD_AVISO_CIRURGIA, MT.DT_AVISO_CIRURGIA
 ORDER BY MIN(MT.DT_MOVIMENTO);

