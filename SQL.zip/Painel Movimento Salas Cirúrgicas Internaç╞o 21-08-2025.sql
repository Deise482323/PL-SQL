select '<table height=50 width=60 bgcolor=' || cor.cor ||
       '><tr><td align=center><font size=2><b>' || row_number() over(order by v.tp_situacao, v.hora_cir) || '</b></font></td></tr></table></font>' Ordem,
       '<table height=50 width=60 bgcolor=' || cor.cor ||
       '><tr><td align=center><font size=2><b>' ||
       coalesce((SELECT TO_CHAR(MAX(rpa.dt_log_rpa), 'hh24:mi') 
                  FROM dbamv.mov_cc_rpa rpa
                 WHERE rpa.cd_atendimento = v.cd_atendimento),
                decode(Fnc_retorna_historico(V.cd_atendimento,
                                             'DOCUMENTO',
                                             'CK_ANOTENFSO_RPA_1',
                                             'A',
                                             'S',
                                             '719',
                                             'FECHADO',
                                             'N',
                                             '30',
                                             '1'),
                       NULL,
                       'N',
                       'S') || '</b></font></td></tr></table></font>') SN_RPA,
       
       (CASE
         WHEN V.SN_POS_BATEMAPA = 'N' THEN
          '<table height=50 width=60 bgcolor=' || cor.cor ||
          '><tr><td align=center><font size=2><b>' || v.CD_AVISO_CIRURGIA ||
          '</b></font></td></tr></table></font>'
         WHEN V.SN_POS_BATEMAPA = 'S' THEN
          '<table height=50 width=60 bgcolor= #0615b1><tr><td align=center><font size=2 color= white><b>' ||
          v.CD_AVISO_CIRURGIA || '</b></font></td></tr></table></font>'
         ELSE
          '<table height=50 width=60 bgcolor=' || cor.cor ||
          '><tr><td align=center><font size=2><b>' || v.CD_AVISO_CIRURGIA ||
          '</b></font></td></tr></table></font>'
       END) AVISO,
       
       (CASE
         WHEN V.TRANSF_DIA = 'N' THEN
          '<table height=50 width=60 bgcolor=' || cor.cor ||
          '><tr><td align=center><font size=2><b>' || v.hora_cir ||
          '</b></font></td></tr></table></font>'
         WHEN V.TRANSF_DIA = 'S' THEN
          '<table height=50 width=60 bgcolor= red><tr><td align=center><font size=2 color= white><b>' ||
          v.hora_cir || '</b></font></td></tr></table></font>'
         ELSE
          '<table height=50 width=60 bgcolor=' || cor.cor ||
          '><tr><td align=center><font size=2><b>' || v.hora_cir ||
          '</b></font></td></tr></table></font>'
       END) HORA_CIR,
       CASE
         WHEN V.CD_CEN_CIR = 1 THEN
          '<table height=50 width= 60 bgcolor="#1dff72"><tr><td align=center><font size=3 color = black><b>' ||
          DS_CEN_CIR || '</font></td></tr></table></font>'
         WHEN V.CD_CEN_CIR = 3 THEN
          '<table height=50 width= 60 bgcolor="#eb9132"><tr><td align=center><font size=3 color = black><b>' ||
          DS_CEN_CIR || '</font></td></tr></table></font>'
         WHEN V.CD_CEN_CIR = 7 THEN
          '<table height=50 width= 60 bgcolor="#ffb5df"><tr><td align=center><font size=3 color = black><b>' ||
          DS_CEN_CIR || '</font></td></tr></table></font>'
         WHEN V.CD_CEN_CIR = 11 THEN
          '<table height=50 width= 60 bgcolor="#a955eb"><tr><td align=center><font size=3 color = black><b>' ||
          DS_CEN_CIR || '</font></td></tr></table></font>'
         ELSE
          '<table height=50 width=60 bgcolor=' || cor.cor ||
          '><tr><td align=center><font size=2><b>' || DS_CEN_CIR ||
          '</b></font></td></tr></table></font>'
       END SETOR,
       case
         when v.categoria_leito = 'N' then
          '<table height=50 width= 100 bgcolor=' || cor.cor ||
          '><tr><td align=left><font size=2 color = Red><b>' || case
            when v.cd_grupo_cirurgia = 15 then
             v.leito || ' ORT.'
            ELSE
             v.leito
          end || '</br>' ||
          decode(dbamv.fnc_hnb_get_isolamento(v.cd_atendimento),
                 'IC',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_amarelo.png" border=0>',
                 'IG',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_verde.png" border=0>',
                 'IA',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_azul.png" border=0>',
                 'ICE',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_azul_amarelo.png" border=0>',
                 'ICG',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_verde_amarelo.png" border=0>',
                 'SUSP',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_susp_iso.png" border=0>',
                 'SI',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_int.png" border=0>') ||
          '</font></td></tr></table></font>'
         else
          '<table height=50 width=100 bgcolor=' || cor.cor ||
          '><tr><td align=left><font size=2><b>' || case
            when v.cd_grupo_cirurgia = 15 then
             v.leito || ' ORT.'
            ELSE
             v.leito
          end || '</br>' ||
          decode(dbamv.fnc_hnb_get_isolamento(v.cd_atendimento),
                 'IC',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_amarelo.png" border=0>',
                 'IG',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_verde.png" border=0>',
                 'IA',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_azul.png" border=0>',
                 'ICE',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_azul_amarelo.png" border=0>',
                 'ICG',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_verde_amarelo.png" border=0>',
                 'SUSP',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_susp_iso.png" border=0>',
                 'SI',
                 '<img width="20px" height="20px" align="center" src="/Painel/img/dash/avental_int.png" border=0>') ||
          '</b></font></td></tr></table></font>'
       end LEITO,
       CASE
         WHEN v.Sn_Urgencia_dia = 'Urgente' THEN
          '<table height=50 width= 100 bgcolor=' || cor.cor ||
          '><tr><td align=center><font size=3 color = Red><b>' ||
          v.Sn_Urgencia_dia || '</font></td></tr></table></font>'
         when v.Sn_Urgencia_dia = 'Urgenciada' then
          '<table height=50 width= 100 bgcolor=' || cor.cor ||
          '><tr><td align=center><font size=3 color = Green><b>' ||
          v.Sn_Urgencia_dia || '</font></td></tr></table></font>'
         WHEN V.SN_URGENCIA_DIA = 'Eletiva' AND
              (UPPER(V.DS_CIRURGIA) LIKE '%CESARIA%' OR
              UPPER(V.DS_CIRURGIA) LIKE '%PARTO%') then
          '<table height=50 width= 100 bgcolor=' || cor.cor ||
          '><tr><td align=center><font size=3 color ="#ff0084"><b>' ||
          v.Sn_Urgencia_dia || '</font></td></tr></table></font>'
         else
          '<table height=50 width= 100 bgcolor=' || cor.cor ||
          '><tr><td align=center><font size=3 ><b>' || v.Sn_Urgencia_dia ||
          '</font></td></tr></table></font>'
       END CARATER,
       
       '<table height=50 width= 90 bgcolor=' || cor.cor ||
       '><tr><td align=left><font size=2><b>' || v.cd_atendimento ||
       '</font></td></tr></table></font>' ATENDIMENTO,
       '<table height=50 width= 70 bgcolor=' || cor.cor ||
       '><tr><td align=center><font size=2><b>' || v.Hora_Chegada_Paciente ||
       '</font></td></tr></table></font>' Chegada_Paciente,
       '<table height=50 width=50 bgcolor=' || cor.cor ||
       '><tr><td align=center><font size=2><b>' || case
         when to_date(v.dh_cirurgia, 'dd/mm/rrrr') =
              to_date(v.dt_atendimento, 'dd/mm/rrrr') then
          decode(trunc((to_date(to_char(v.Dh_cirurgia, 'dd/mm/rrrr') || ' ' ||
                                v.HORA_CIR,
                                'dd/mm/rrrr hh24:mi:ss') -
                       v.dt_chegada_paciente) * 24) || ':' ||
                 lpad(replace(trunc(mod((to_date(to_char(v.Dh_cirurgia,
                                                         'dd/mm/rrrr') || ' ' ||
                                                 v.HORA_CIR,
                                                 'dd/mm/rrrr hh24:mi:ss') -
                                        v.dt_chegada_paciente) * 1440,
                                        60)),
                              '-',
                              ''),
                      2,
                      '00'),
                 ':',
                 null,
                 trunc((to_date(to_char(v.Dh_cirurgia, 'dd/mm/rrrr') || ' ' ||
                                v.HORA_CIR,
                                'dd/mm/rrrr hh24:mi:ss') -
                       v.dt_chegada_paciente) * 24) || ':' ||
                 lpad(replace(trunc(mod((to_date(to_char(v.Dh_cirurgia,
                                                         'dd/mm/rrrr') || ' ' ||
                                                 v.HORA_CIR,
                                                 'dd/mm/rrrr hh24:mi:ss') -
                                        v.dt_chegada_paciente) * 1440,
                                        60)),
                              '-',
                              ''),
                      2,
                      '00'))
         else
          null
       end || '</b></font></td></tr></table></font>' Tempo,
       case
         when v.SN_UTI = 'N' then
          '<table height=50 width= 90 bgcolor=' || cor.cor ||
          '><tr><td align=center><font color=' || (case
            when V.acomodacao2 = 'ENF.' then
             'red'
            when V.acomodacao2 = 'APTO' then
             'blue'
            else
             ''
          end) || ' size=2><b>' || V.acomodacao2 ||
          '</font></td></tr></table></font>'
         when v.SN_UTI = 'S' then
          '<table height=50 width= 90 bgcolor=' || cor.cor ||
          '><tr><td align=center><font color=' || (case
            when V.acomodacao2 = 'ENF.' then
             'red'
            when V.acomodacao2 = 'APTO' then
             'blue'
            else
             ''
          end) || ' size=2><b>' || V.acomodacao2 || (CASE
            WHEN V.UNID_RES_UTI = 'UTI' THEN
             '</font><font color = red size=2><b> / UTI </font></td></tr></table>'
            WHEN V.UNID_RES_UTI = 'UTIPED' THEN
             '</font><font color = red size=2><b> / UTIPED </font></td></tr></table>'
            WHEN V.UNID_RES_UTI = 'UCO' THEN
             '</font><font color = DarkMagenta size=2><b> / UCO </font></td></tr></table>'
            ELSE
             '</font></td></tr></table></font>' --NULL
          END)
       end acomodacao,
       
       CASE
         WHEN COUNT(*)
          OVER(PARTITION BY
                   SUBSTR(UPPER(NVL(V.NM_PACIENTE, V.NM_PACIENTE)),
                          1,
                          INSTR(UPPER(NVL(V.NM_PACIENTE, V.NM_PACIENTE)), ' ')),
                   TO_CHAR(V.DT_PREV_INTER, 'mm/yyyy')) > 1 THEN
          DECODE(V.NM_PACIENTE,
                 NULL,
                 '',
                 '<table height=50 width=400><tr><td align=left><font color="red" size=3><b>' ||
                 V.NM_PACIENTE || '</b></font><br />' || '<font size=1> (' ||
                 V.SEXO || ' - ' || V.DS_IDADE || ' - ' || 'Nasc: ' ||
                 V.DT_NASC || ')</font></td></tr></table></font>')
       
         WHEN V.SN_URGENCIA_DIA = 'Eletiva' AND
              (UPPER(V.DS_CIRURGIA) LIKE '%CESARIA%' OR
              UPPER(V.DS_CIRURGIA) LIKE '%PARTO%') THEN
          '<table height=50 width=400>
 <td align="left">
 <font color="red" size=3><b> <img width="30px" height="30px" src="/Painel/img/dash/gestante.png" border=0><br>' || ' ' ||
          V.NM_PACIENTE || '</b></font><br />
 <font size=1>(' || V.SEXO || ' - ' || V.DS_IDADE || ' - ' ||
          'Nasc: ' || V.DT_NASC || ')</font>
 </td>
 </tr>
 </table></font>'
       
         ELSE
          DECODE(V.NM_PACIENTE,
                 NULL,
                 '',
                 '<table height=50 width=400>
 <tr>
 <td align="left">
 <font size=3><b>' || V.NM_PACIENTE || '</b></font><br />
 <font size=1> (' || V.SEXO || ' - ' || V.DS_IDADE || ' - ' ||
                 'Nasc: ' || V.DT_NASC || ')</font>
 </td>
 </tr>
 </table></font>')
       END AS PACIENTE,
       
       '<font size=2><b>' || v.prest_cirurgiao || '</b></font>' CIRURGIAO,
       '<table height=50 width=300><tr><td align=left><font size=2><b>' ||
       v.ds_cirurgia || '</b></font></td></tr></table></font>' CIRURGIA,
       v.SN_ATER_UTI_DIACIR

  from dbamv.vdic_hnb_painel_cirurgias_int v

  left outer join (select '"#87ceeb"' cor, '1EC' tp_situacao
                     from dual --- Azul
                   union
                   select '"#deb887"' cor, '2ET' tp_situacao
                     from dual --- Marrom
                   union
                   select '"#f0e68c"' cor, '3AC' tp_situacao
                     from dual --- Amarelo
                   union
                   select '"#7fffd4"' cor, '4AI' tp_situacao
                     from dual --- Verde 
                   ) cor
    on cor.tp_situacao = v.tp_situacao

 where v.CD_CEN_CIR in #cdcir#
   and v.dt_cirurgia = to_date(#data#, 'dd/mm/rrrr')
      --and (v.cd_atendimento <> 7705567 or v.cd_atendimento is null)
   AND (v.TP_LEITO_OCUP is null OR v.TP_LEITO_OCUP = 'EX' or
       (v.TP_LEITO_OCUP NOT IN ('UCO', 'UTI') AND V.SN_UTI = 'S'))
 AND V.CD_AVISO_CIRURGIA <> 222406
 ORDER BY v.ORD_CC, v.tp_situacao, v.HORA_CIR, v.sala_Cir, V.CD_CEN_CIR
