EXPLAIN PLAN FOR
<cole aqui o bloco que � mais lento>;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);
