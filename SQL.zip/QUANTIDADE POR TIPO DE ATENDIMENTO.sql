SELECT COUNT(A.CD_ATENDIMENTO),
       DECODE(A.TP_ATENDIMENTO,
              'I',
              'INTERNACAO',
              'A',
              'AMBULATORIO',
              'E',
              'EXTERNO',
              'U',
              'URGENCIA') TIPO_ATENDIMENTO
  FROM ATENDIME A
 WHERE A.TP_ATENDIMENTO = 'A'
   AND TO_DATE(A.DT_ATENDIMENTO, 'DD/MM/RRRR') BETWEEN '01/01/2024' AND
       '31/01/2024'

GROUP BY
A.TP_ATENDIMENTO
