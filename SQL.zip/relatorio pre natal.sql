Select 
a.cd_atendimento,
a.cd_ori_ate,
a.cd_paciente,
a.tp_atendimento,
a.cd_atendimento_pai from atendime a where a.tp_atendimento = 'I' 
