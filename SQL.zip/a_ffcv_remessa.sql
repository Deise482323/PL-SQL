  select distinct  con_pla.cd_con_pla, con_pla.ds_con_pla,
                   sum(decode(nvl(itreg_amb.tp_pagamento, 'X'),'C',0,decode( nvl(itreg_amb.sn_pertence_pacote,'N'),'S',0,itreg_amb.vl_total_conta)))

vl_total_conta
            from itreg_amb,
                 reg_amb,
                 con_pla,
                 atendime
            where itreg_amb.cd_reg_amb     = 205733
              and itreg_amb.cd_convenio = 3
              and itreg_amb.cd_reg_amb     = reg_amb.cd_reg_amb
              and atendime.cd_atendimento  = itreg_amb.cd_atendimento
              and atendime.cd_con_pla      = con_pla.cd_con_pla(+)
              and atendime.cd_convenio     = con_pla.cd_convenio(+)
              and atendime.tp_atendimento in ('A','E','U')
              and reg_amb.cd_multi_empresa = atendime.cd_multi_empresa
              and reg_amb.cd_multi_empresa = 1
              and reg_amb.cd_remessa is null
            group by  con_pla.cd_con_pla, con_pla.ds_con_pla;


          select *           FROM
--            UPDATE

           dbamv.itreg_amb
--           SET cd_atendimento = 189587
           where cd_reg_amb = 205733
--             and cd_atendimento = 47
             and sn_fechada = 'N';



select * FROM

DELETE
dbamv.rmi_mensagem WHERE Upper(cd_modulo) like Upper('%TRANSFERE_CONTAS_FFCV%');
/


              SELECT atendime.dt_atendimento,
           atendime.cd_convenio,
           atendime.cd_con_pla,
           itreg_amb.cd_reg_amb,
           reg_amb.cd_remessa--204445
          ,atendime.tp_atendimento     -- OP 9140
          ,atendime.cd_guia            -- OP 9140
    FROM   dbamv.atendime,
           dbamv.itreg_amb,
           dbamv.reg_amb--204445
    WHERE  atendime.cd_atendimento = 186713
      and  itreg_amb.cd_convenio   = 3
      and  atendime.cd_atendimento = itreg_amb.cd_atendimento
      and  reg_amb.cd_reg_amb = itreg_amb.cd_reg_amb--204445
    GROUP BY atendime.dt_atendimento,
           atendime.cd_convenio,
           atendime.cd_con_pla,
           itreg_amb.cd_reg_amb,
           reg_amb.cd_remessa -- 209191
          ,atendime.tp_atendimento     -- OP 9140
          ,atendime.cd_guia            -- OP 9140
          ;

             SELECT * FROM dbamv.it_repasse WHERE cd_reg_amb = 205733
             SELECT * FROM dbamv.repasse_consolidado where cd_repasse IN (851,885)AND cd_reg_amb = 205733 AND cd_pro_fat = '40101010'

             SELECT distinct cd_reg_amb, cd_atendimento FROM dbamv.itreg_amb WHERE cd_atendimento = 47


             SELECT * FROM dbamv.reg_fat WHERE cd_atendimento = 47


             SELECT * FROM dbamv.itreg_fat
             WHERE cd_reg_fat IN (SELECT cd_reg_fat FROM dbamv.reg_fat WHERE cd_atendimento = 47)
             AND cd_pro_fat = '40101010'
             ORDER BY cd_lancamento




             SELECT tp_atendimento, dt_atendimento, dt_alta, cd_pro_int, cd_procedimento, cd_procedimento_alta FROM dbamv.atendime WHERE cd_atendimento = 47