SELECT DT_AGENDAMENTO,
       CD_AVISO_CIRURGIA,
       CD_PACIENTE,
       NM_PACIENTE,
       NR_TELEFONE_CONTATO,
       CIRURGIAO,
       ACOMODACAO,
       DT_GERACAO,
       DS_OBSERVACAO,
       ACOM_NULL,
       CONVENIO
FROM (
        SELECT TO_DATE(ACI.DT_INICIO_AGE_CIR, 'DD/MM/RRRR') DT_AGENDAMENTO,
               AC.CD_AVISO_CIRURGIA,
               AC.CD_PACIENTE,
               AC.NM_PACIENTE,
               AC.NR_TELEFONE_CONTATO,
               P.NM_PRESTADOR CIRURGIAO,
               TA.DS_TIP_ACOM ACOMODACAO,
               TO_DATE(AC.DT_AVISO_CIRURGIA, 'DD/MM/RRRR') DT_GERACAO,
               G.DS_OBSERVACAO,
               CASE WHEN TA.DS_TIP_ACOM IS NULL THEN 'S' ELSE 'N' END ACOM_NULL,
               CC.CD_CONVENIO || ' - ' || CC.NM_CONVENIO AS CONVENIO,
            ROW_NUMBER() OVER (
    PARTITION BY AC.CD_AVISO_CIRURGIA
    ORDER BY 
        CASE 
          WHEN CA.CD_CONVENIO IN (40,148,81,82) THEN 1  -- particular vem primeiro
          WHEN CA.SN_PRINCIPAL = 'S' THEN 2              -- depois o principal
          ELSE 3 
        END,
        CA.CD_CIRURGIA
) RN

          FROM DBAMV.AVISO_CIRURGIA AC 
          JOIN DBAMV.CIRURGIA_AVISO CA
            ON CA.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
          JOIN CONVENIO CC
            ON CC.CD_CONVENIO = CA.CD_CONVENIO
          JOIN DBAMV.AGE_CIR ACI
            ON ACI.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
          JOIN DBAMV.PRESTADOR_AVISO PA
            ON PA.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
           AND PA.CD_ATI_MED = 1
           AND PA.SN_PRINCIPAL = 'S'
          JOIN DBAMV.PRESTADOR P
            ON P.CD_PRESTADOR = PA.CD_PRESTADOR
          LEFT JOIN DBAMV.GUIA G
            ON G.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
           AND G.TP_GUIA = 'O'
          LEFT JOIN DBAMV.TIP_ACOM TA
            ON TA.CD_TIP_ACOM = G.CD_TIP_ACOM
          LEFT JOIN DBAMV.MOTIVO_PENDENCIA_GUIA MPG
            ON MPG.CD_MOTIVO_PENDENCIA_GUIA = G.CD_MOTIVO_PENDENCIA_GUIA
         WHERE TO_DATE(ACI.DT_INICIO_AGE_CIR, 'DD/MM/RRRR') > SYSDATE - 365
           AND AC.CD_CEN_CIR IN (1, 3)
           AND AC.TP_SITUACAO = 'G'
          --AND AC.CD_AVISO_CIRURGIA = 196326
           AND (
                 CA.CD_CONVENIO IN (40,148,81,82)
                 OR (
                     CA.SN_PRINCIPAL = 'N'
                     AND CA.CD_CONVENIO IN (40,148,81,82)
                     AND EXISTS (
                           SELECT 1
                             FROM DBAMV.CIRURGIA_AVISO CA1
                            WHERE CA1.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
                              AND CA1.SN_PRINCIPAL = 'S'
                              AND CA1.CD_CONVENIO NOT IN (40,148,81,82)
                          )
                   )
               )
       ) X
WHERE RN = 1
ORDER BY DT_AGENDAMENTO ASC
----------------------------------------------------------------------------------------
/*SELECT * FROM AVISO_CIRURGIA AC
JOIN CIRURGIA_AVISO CA
ON CA.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
JOIN AGE_CIR ACI
ON ACI.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
WHERE 
TO_DATE(ACI.DT_INICIO_AGE_CIR, 'DD/MM/RRRR') > SYSDATE - 365
AND (CA.SN_PRINCIPAL = 'N' AND CA.CD_CONVENIO IN (40, 148, 81, 82))
AND EXISTS (SELECT * FROM CIRURGIA_AVISO CA1
WHERE CA1.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
AND (CA1.SN_PRINCIPAL = 'S' AND CA1.CD_CONVENIO NOT IN (40, 148, 81, 82)) )
--AND AC.TP_SITUACAO = 'G'*/
