   --HNB_RESUMO_TOTAL

SELECT NVL(VL_CONTA, 0) VL_CONTA,
       NVL(VL_PAGO, 0) VL_PAGO,
       NVL(VL_ADIANTAMENTO, 0) VL_ADIANTAMENTO,
       NVL(DESCONTO, 0) DESCONTO,
       (NVL(VL_CONTA, 0) - NVL(VL_ADIANTAMENTO, 0) - NVL(DESCONTO, 0) - NVL(VL_PAGO, 0)) SALDO_CONTA,
       NVL(VL_CONTA_AGRUPADA, 0) VL_CONTA_AGRUPADA,
       NVL(VL_RECEB_AGRUP, 0) VL_RECEB_AGRUP,
       (NVL(VL_CONTA_AGRUPADA, 0) - NVL(VL_RECEB_AGRUP, 0)) SALDO_AGRUPADO
  FROM (SELECT
        
         SUM(NVL(RF.VL_TOTAL_CONTA, 0)) VL_CONTA,
         
         SUM(NVL(CASE
                   WHEN (SELECT NVL(ICR7.VL_DUPLICATA, 0)
                           FROM ITCON_REC ICR7
                          WHERE ICR7.CD_CON_REC = ICR.CD_CON_REC_AGRUP
                            AND ROWNUM = 1) <> 0 THEN
                    0
                   ELSE
                     NVL(ICR.VL_SOMA_RECEBIDO, 0)
                 END,
                 0)) VL_PAGO,
         
         (SELECT SUM(NVL(RCR.VL_RECEBIDO, 0))
            FROM RECCON_REC RCR
           WHERE RCR.CD_ITCON_REC IN
                 (SELECT ICR2.CD_ITCON_REC
                    FROM ITCON_REC ICR2
                   WHERE ICR2.CD_CON_REC_AGRUP = ICR.CD_CON_REC_AGRUP)
             AND RCR.CD_CONTRATO_ADIANT IS NOT NULL) VL_ADIANTAMENTO,
         
         (SELECT SUM(NVL(RCR1.VL_DESCONTO, 0))
            FROM RECCON_REC RCR1
           WHERE RCR1.CD_ITCON_REC IN
                 (SELECT ICR3.CD_ITCON_REC
                    FROM ITCON_REC ICR3
                   WHERE ICR3.CD_CON_REC_AGRUP = ICR.CD_CON_REC_AGRUP)) DESCONTO,
         
         (SELECT NVL(SUM(ICR7.VL_DUPLICATA), 0)
            FROM ITCON_REC ICR7
           WHERE ICR7.CD_CON_REC = ICR.CD_CON_REC_AGRUP) VL_CONTA_AGRUPADA,
         
         (SELECT NVL(SUM(ICR8.VL_SOMA_RECEBIDO), 0)
            FROM ITCON_REC ICR8
           WHERE ICR8.CD_CON_REC = ICR.CD_CON_REC_AGRUP) VL_RECEB_AGRUP
        
          FROM REG_FAT RF
          inner JOIN CON_REC CR
            ON CR.CD_REG_FAT = RF.CD_REG_FAT
          LEFT JOIN ITCON_REC ICR
            ON ICR.CD_CON_REC = CR.CD_CON_REC
             JOIN ATENDIME A
            ON A.CD_ATENDIMENTO = CR.CD_ATENDIMENTO
        
         WHERE A.CD_ATENDIMENTO = 11576048 --{V_ATENDIMENTO}
          --A.DT_ATENDIMENTO BETWEEN TO_DATE ('01/08/2025','DD/MM/RRRR') AND TO_DATE ('21/08/2025','DD/MM/RRRR')
           --AND {V_VAR}
        
         GROUP BY VL_RECEBIDO, CD_CON_REC_AGRUP
        
        UNION
        
        SELECT
        
         (NVL(RA.VL_TOTAL_CONTA, 0)) VL_CONTA,
         (NVL(CASE
                WHEN (SELECT NVL(SUM(CR1.VL_MOEDA), 0)
                        FROM CON_REC CR1
                       WHERE CR1.CD_CON_REC IN
                             (SELECT ICR1.CD_CON_REC_AGRUP
                                FROM ITCON_REC ICR1
                               WHERE ICR1.CD_CON_REC_AGRUP = ICR.CD_CON_REC_AGRUP)
                         AND ROWNUM = 1) <> 0 THEN
                 0
                ELSE
                 NVL(ICR.VL_SOMA_RECEBIDO, 0)
              END,
              0)) VL_PAGO,
         
         (SELECT SUM(NVL(RCR.VL_RECEBIDO, 0))
            FROM RECCON_REC RCR
           WHERE RCR.CD_ITCON_REC IN
                 (SELECT ICR2.CD_ITCON_REC
                    FROM ITCON_REC ICR2
                   WHERE ICR2.CD_CON_REC_AGRUP = ICR.CD_CON_REC_AGRUP)
             AND RCR.CD_CONTRATO_ADIANT IS NOT NULL) VL_ADIANTAMENTO,
         
         (SELECT SUM(NVL(RCR1.VL_DESCONTO, 0))
            FROM RECCON_REC RCR1
           WHERE RCR1.CD_ITCON_REC IN
                 (SELECT ICR3.CD_ITCON_REC
                    FROM ITCON_REC ICR3
                   WHERE ICR3.CD_CON_REC_AGRUP = ICR.CD_CON_REC_AGRUP)) DESCONTO,
         
         (SELECT NVL(SUM(CR2.VL_MOEDA), 0)
            FROM CON_REC CR2
           WHERE CR2.CD_CON_REC IN
                 (SELECT ICR4.CD_CON_REC_AGRUP
                    FROM ITCON_REC ICR4
                   WHERE ICR4.CD_CON_REC_AGRUP = ICR.CD_CON_REC_AGRUP)) VL_CONTA_AGRUPADA,
         
         (SELECT NVL(SUM(ICR8.VL_SOMA_RECEBIDO), 0)
            FROM ITCON_REC ICR8
           WHERE ICR8.CD_CON_REC = ICR.CD_CON_REC_AGRUP) VL_RECEB_AGRUP
        
          FROM REG_AMB RA
          JOIN ITREG_AMB IRA
            ON IRA.CD_REG_AMB = RA.CD_REG_AMB
          JOIN ATENDIME A
            ON A.CD_ATENDIMENTO = IRA.CD_ATENDIMENTO
          inner JOIN CON_REC CR
            ON CR.CD_REG_AMB = RA.CD_REG_AMB
          LEFT JOIN ITCON_REC ICR
            ON ICR.CD_CON_REC = CR.CD_CON_REC
        
         WHERE A.CD_ATENDIMENTO = 11576048  --{V_ATENDIMENTO}
         --A.DT_ATENDIMENTO BETWEEN TO_DATE ('01/08/2025','DD/MM/RRRR') AND TO_DATE ('21/08/2025','DD/MM/RRRR')
          -- AND {V_VAR}
         GROUP BY RA.VL_TOTAL_CONTA,
                  ICR.VL_SOMA_RECEBIDO,
                  VL_RECEBIDO,
                  CD_CON_REC_AGRUP)
