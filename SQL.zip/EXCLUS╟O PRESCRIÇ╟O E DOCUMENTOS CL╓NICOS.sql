/*
  ###### EXCLUS�O PRESCRI��O E DOCUMENTOS CL�NICOS######## 
*/

-- Tabela Atendimento
SELECT * FROM DBAMV.ATENDIME WHERE CD_ATENDIMENTO = 11704067
DELETE DBAMV.ATENDIME WHERE CD_ATENDIMENTO = 11704067

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Diagnostico m�dico
SELECT * FROM DIAGNOSTICO_ATENDIME WHERE CD_ATENDIMENTO = 11704067
DELETE DIAGNOSTICO_ATENDIME WHERE CD_ATENDIMENTO = 11704067

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Grupo Diagnostico m�dico
SELECT * FROM PW_GRUPO_DIAGNOSTICO_ATENDIME WHERE CD_DOCUMENTO_CLINICO_VALIDO IN (70164164)
DELETE PW_GRUPO_DIAGNOSTICO_ATENDIME WHERE CD_DOCUMENTO_CLINICO_VALIDO IN (70164372)

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Documento Clinico
SELECT * FROM PW_DOCUMENTO_CLINICO WHERE CD_ATENDIMENTO = 11704067 
DELETE PW_DOCUMENTO_CLINICO WHERE CD_ATENDIMENTO = 11704067

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Grupo Documento Clinico
SELECT * FROM PW_GRUPO_DIAGNOSTICO_ATENDIME WHERE CD_DOCUMENTO_CLINICO_VALIDO = 56654473
DELETE PW_GRUPO_DIAGNOSTICO_ATENDIME WHERE CD_DOCUMENTO_CLINICO_VALIDO = 56654473

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Tratamento
SELECT * FROM TRATAMENTO WHERE CD_DIAGNOSTICO_ATENDIME = 2512064
DELETE TRATAMENTO WHERE CD_DIAGNOSTICO_ATENDIME = 2512064

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Clico Tratamento 
SELECT * FROM CICLO_TRATAMENTO WHERE CD_TRATAMENTO = 2009
DELETE CICLO_TRATAMENTO WHERE CD_TRATAMENTO = 2009

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Sess�o Tratamento
SELECT * FROM SESSAO_TRATAMENTO WHERE CD_TRATAMENTO = 2009
DELETE SESSAO_TRATAMENTO WHERE CD_TRATAMENTO = 2009

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Prescri��o M�dica
SELECT * FROM PRE_MED WHERE CD_ATENDIMENTO = 11703965
DELETE PRE_MED WHERE CD_PRE_MED IN( 2079149)

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Itens Prescri��o M�dica 
SELECT * FROM ITPRE_MED WHERE CD_PRE_MED IN (12469142, 12469143)
DELETE ITPRE_MED WHERE CD_PRE_MED IN (12469142, 12469143)

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Aprazamento / Checagem
SELECT * FROM FECHAMENTO_PAGU WHERE CD_PRE_MED IN (927327)
DELETE FECHAMENTO_PAGU WHERE CD_FECHAMENTO = 19855565

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Item da Checagem
SELECT * FROM HRITPRE_CONS WHERE CD_ITPRE_MED IN (SELECT CD_ITPRE_MED FROM ITPRE_MED WHERE CD_PRE_MED IN (12469142, 12469143))
DELETE FROM HRITPRE_CONS WHERE CD_ITPRE_MED IN (SELECT CD_ITPRE_MED FROM ITPRE_MED WHERE CD_PRE_MED IN (12469142, 12469143))

----------------------------------------------------------------------------------------------------------------------------------------------------
SELECT * FROM PW_HRITPRE_MED_PRESCRICAO WHERE CD_ITPRE_MED IN (SELECT CD_ITPRE_MED FROM ITPRE_MED WHERE CD_PRE_MED IN (12469142, 12469143))
DELETE PW_HRITPRE_MED_PRESCRICAO WHERE CD_ITPRE_MED IN (SELECT CD_ITPRE_MED FROM ITPRE_MED WHERE CD_PRE_MED IN (12469142, 12469143))

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Checagem
SELECT * FROM PW_HORARIO_FECHADO_CHECAGEM WHERE CD_ITPRE_MED IN (SELECT CD_ITPRE_MED FROM ITPRE_MED WHERE CD_PRE_MED IN (12469142, 12469143))
DELETE PW_HORARIO_FECHADO_CHECAGEM WHERE CD_ITPRE_MED IN (SELECT CD_ITPRE_MED FROM ITPRE_MED WHERE CD_PRE_MED IN (12469142, 12469143))

----------------------------------------------------------------------------------------------------------------------------------------------------
SELECT * FROM PRE_MED_CICLO WHERE CD_PRE_MED IN (12469142, 12469143)
DELETE PRE_MED_CICLO WHERE CD_PRE_MED IN (12469142, 12469143)

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Status Prescri��o de Tratamento
SELECT * FROM ESTADO_PRE_MED WHERE CD_PRE_MED IN (12469142, 12469143)
DELETE ESTADO_PRE_MED WHERE CD_PRE_MED IN (12469142, 12469143)

----------------------------------------------------------------------------------------------------------------------------------------------------
SELECT * FROM PRE_MED_RESPOSTA_FORMULA WHERE CD_PRE_MED IN (12469142, 12469143)
DELETE PRE_MED_RESPOSTA_FORMULA WHERE CD_PRE_MED IN (12469142, 12469143) 

----------------------------------------------------------------------------------------------------------------------------------------------------
SELECT * FROM PW_AVALIACAO_PRE_MED WHERE CD_PRE_MED IN (12469142, 12469143)
DELETE PW_AVALIACAO_PRE_MED WHERE CD_PRE_MED IN (12469142, 12469143)

----------------------------------------------------------------------------------------------------------------------------------------------------
SELECT * FROM PW_AVALIACAO_ITPRE_MED WHERE CD_AVALIACAO_PRE_MED = 4992080
DELETE PW_AVALIACAO_ITPRE_MED WHERE CD_AVALIACAO_PRE_MED = 4992080

----------------------------------------------------------------------------------------------------------------------------------------------------
SELECT * FROM PW_PRE_MED_AVALIACAO_STATUS WHERE CD_PRE_MED IN (12469142, 12469143)
DELETE PW_PRE_MED_AVALIACAO_STATUS WHERE CD_PRE_MED IN (12469142, 12469143)

----------------------------------------------------------------------------------------------------------------------------------------------------
SELECT * FROM PW_MARCO_LINHA_TEMPO WHERE CD_PRE_MED IN (12469142, 12469143)
DELETE PW_MARCO_LINHA_TEMPO WHERE CD_PRE_MED IN (12469142, 12469143)

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Registro da Alta
SELECT * FROM PW_REGISTRO_ALTA WHERE CD_ATENDIMENTO = 11703965
DELETE PW_REGISTRO_ALTA WHERE CD_ATENDIMENTO = 11703965

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Vinculo Documento Clinico com o novo Editor
SELECT * FROM PW_EDITOR_CLINICO WHERE CD_DOCUMENTO_CLINICO IN (70163119,70163165,70163177)
DELETE PW_EDITOR_CLINICO WHERE CD_DOCUMENTO_CLINICO IN (70163177,70163119,70163165)

----------------------------------------------------------------------------------------------------------------------------------------------------
SELECT * FROM PW_FECHAMENTO_HORARIO_CHECAGEM WHERE CD_ATENDIMENTO = 10263952
DELETE PW_FECHAMENTO_HORARIO_CHECAGEM WHERE CD_ATENDIMENTO = 10263952

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Tabela Anota��o Enfermagem
SELECT * FROM EVO_ENF WHERE CD_DOCUMENTO_CLINICO = 
DELETE FROM EVO_ENF WHERE CD_EVO_ENF = 

----------------------------------------------------------------------------------------------------------------------------------------------------
-- FK apresentadas ap�s DELETE em alguma tabela acima - para identificar qual tabela tem o filho atrelado
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_DIAG_ATEND_ATENDIME_001_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_TRATAMENTO_DIAGATENDIME_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_CICLO_TRAT_TRATAMENTO_1_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_SESSAO_TRA_CICLO_TRAT_1_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_PRE_MED_SESSAO_TRTM_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'HRITPRE_CONS_ITPRE_MED_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_HRITPRE_PRESITPRE_MED_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_PW_HR_FECH_CHEC_ITP_MED_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_FECH_PAGU_PRE_MED_2_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_P_M_CICLO_PRE_MED_1_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_ESTADO_PRE_MED_PRE_MED_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_PRE_MED_RESP_FORM_PRE_M_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_AVAL_PRE_MED_PRE_MED_1_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_ITPRE_MD_AVL_AVL_PRE_MD_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_PRE_MED_AVAL_STTS_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_MARCO_PRE_MED_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_DOC_CLI_VALIDO_FK'
SELECT * FROM ALL_TAB_COLUMNS WHERE COLUMN_NAME =     'CD_GRUPO_DIAGNOSTICO_ATENDIME'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_PW_EDIT_CLIN_PW_DOC_CLI_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_PW_FEC_HR_CHEC_DOC_CLIN_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_PW_REG_ALTA_DOC_CLI_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_DOC_CLI_VALIDO_FK'
SELECT * FROM ALL_CONSTRAINTS WHERE CONSTRAINT_NAME = 'CNT_EVO_ENF_PW_DOCUM_CLINC_FK'
