SELECT DISTINCT ATE.CD_ATENDIMENTO,
                DECODE(ATE.TP_ATENDIMENTO,
                       'I',
                       'INTERNACAO',
                       'A',
                       'AMBULATORIO',
                       'E',
                       'EXTERNO',
                       'U',
                       'URGENCIA') TIPO_ATENDIMENTO,
                PAC.CD_PACIENTE,
                PAC.NM_PACIENTE,
                PLA.CD_PED_LAB PEDIDO,
                PLA.DT_PEDIDO,
                EL.CD_EXA_LAB,
                EL.NM_EXA_LAB EXAME,
                A.CD_USUARIO_COLETA,
                A.CD_AMOSTRA,
                S.CD_SETOR SETOR_SOLICITANTE,
                S.NM_SETOR,
                DECODE(A.DT_COLETA,
                       NULL,
                       'NAO', 'SIM') COLETADO
                       
  FROM DBAMV.ATENDIME ATE
  JOIN DBAMV.PACIENTE PAC
    ON PAC.CD_PACIENTE = ATE.CD_PACIENTE
  JOIN DBAMV.PED_LAB PLA
    ON PLA.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO
  JOIN DBAMV.ITPED_LAB IPLA
    ON IPLA.CD_PED_LAB = PLA.CD_PED_LAB
  JOIN DBAMV.EXA_LAB EL
    ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
  JOIN DBAMV.AMOSTRA_EXA_LAB  AEL
    ON  AEL.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
  JOIN AMOSTRA A
    ON A.CD_AMOSTRA =  AEL.CD_AMOSTRA
  JOIN SETOR S
    ON S.CD_SETOR = PLA.CD_SETOR

 WHERE ATE.DT_ATENDIMENTO = '10/01/2024'
   AND S.CD_SETOR = 145
