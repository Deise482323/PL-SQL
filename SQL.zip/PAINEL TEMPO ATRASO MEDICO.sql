SELECT M.NM_PRESTADOR, M.ATRASO

  FROM (SELECT ATE.HR_ATENDIMENTO,
               STP.DH_PROCESSO,
               IAC.HR_AGENDA,
               STP.CD_TIPO_TEMPO_PROCESSO,
               STTP.DS_TIPO_TEMPO_PROCESSO,
               TO_CHAR(ATE.HR_ATENDIMENTO, 'HH24:MI') HR_ATE,
               TO_CHAR(STP.DH_PROCESSO, 'HH24:MI') DH_PROCES,
               FNC_HNB_OBTER_DIFERENCA_HORAS(ATE.HR_ATENDIMENTO,
                                             STP.DH_PROCESSO),
               CASE
                 WHEN FNC_HNB_OBTER_DIFERENCA_HORAS(ATE.HR_ATENDIMENTO,
                                                    STP.DH_PROCESSO) >=
                      '0:15' AND
                      FNC_HNB_OBTER_DIFERENCA_HORAS(ATE.HR_ATENDIMENTO,
                                                    STP.DH_PROCESSO) < '0:30' THEN
                  'AMARELO'
                 WHEN FNC_HNB_OBTER_DIFERENCA_HORAS(ATE.HR_ATENDIMENTO,
                                                    STP.DH_PROCESSO) >=
                      '0:30' AND
                      FNC_HNB_OBTER_DIFERENCA_HORAS(ATE.HR_ATENDIMENTO,
                                                    STP.DH_PROCESSO) < '0:60' THEN
                  'LARANJA'
                 WHEN FNC_HNB_OBTER_DIFERENCA_HORAS(ATE.HR_ATENDIMENTO,
                                                    STP.DH_PROCESSO) >=
                      '0:60' THEN
                  'VERMELHO'
               END ATRASO,
               P.CD_PRESTADOR,
               P.NM_PRESTADOR,
               FNC_HNB_OBTER_DIFERENCA_HORAS(IAC.HR_AGENDA, STP.DH_PROCESSO) DIF,
               IAC.CD_AGENDA_CENTRAL,
               ATE.CD_ORI_ATE
          FROM ATENDIME ATE
         INNER JOIN SACR_TEMPO_PROCESSO STP
            ON STP.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO
         INNER JOIN SACR_TIPO_TEMPO_PROCESSO STTP
            ON STTP.CD_TIPO_TEMPO_PROCESSO = STP.CD_TIPO_TEMPO_PROCESSO
           AND STTP.CD_TIPO_TEMPO_PROCESSO = 30
         INNER JOIN PRESTADOR P
            ON P.CD_PRESTADOR = ATE.CD_PRESTADOR
         INNER JOIN IT_AGENDA_CENTRAL IAC
            ON IAC.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO
         WHERE ATE.TP_ATENDIMENTO = 'A'
              
           AND TO_DATE(ATE.DT_ATENDIMENTO, 'DD/MM/RRRR') =
               TO_DATE(SYSDATE, 'DD/MM/RRRR')) M
 WHERE M.CD_ORI_ATE = 15
   AND M.ATRASO IN ('AMARELO', 'LARANJA', 'VERMELHO')
   AND 
 GROUP BY M.NM_PRESTADOR, M.ATRASO
