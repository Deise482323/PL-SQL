SELECT 
       U.CD_UNID_INT       AS COD_UNID,
       U.DS_UNID_INT       AS UNIDADE_ORIGEM,
       A.CD_ATENDIMENTO    AS ATENDIMENTO,
       M.CD_MOV_INT        AS COD_MOV,
       M.CD_LEITO          AS COD_LEITO,
       L.DS_RESUMO         AS LEITO_DESTINO,
       M.DT_MOV_INT        AS DATA_TRANSFERENCIA
  FROM MOV_INT M
  JOIN ATENDIME A 
    ON A.CD_ATENDIMENTO = M.CD_ATENDIMENTO
  JOIN LEITO L 
    ON L.CD_LEITO = M.CD_LEITO
  JOIN UNID_INT U
    ON U.CD_UNID_INT = L.CD_UNID_INT
 WHERE M.DT_MOV_INT BETWEEN TO_DATE('01/01/2024','DD/MM/YYYY') 
                        AND TO_DATE('31/07/2025','DD/MM/YYYY')
   AND L.CD_LEITO IN (665, 668)      -- Leitos FLEX 05 e 08
   AND U.CD_UNID_INT IS NOT NULL     -- Garantir que veio de uma unidade de interna��o
 ORDER BY M.DT_MOV_INT,A.CD_ATENDIMENTO;
 ----------------------------------------
 SELECT 
       TO_CHAR(M.DT_MOV_INT, 'MM/YYYY') AS MES_ANO,
       L.DS_RESUMO                      AS LEITO,
       COUNT(*)                         AS QTD_MOVIMENTACOES
  FROM MOV_INT M
  JOIN ATENDIME A 
    ON A.CD_ATENDIMENTO = M.CD_ATENDIMENTO
  JOIN LEITO L 
    ON L.CD_LEITO = M.CD_LEITO
  JOIN UNID_INT U
    ON U.CD_UNID_INT = L.CD_UNID_INT
 WHERE M.DT_MOV_INT BETWEEN TO_DATE('01/01/2024','DD/MM/YYYY') 
                        AND TO_DATE('31/07/2025','DD/MM/YYYY')
   AND L.CD_LEITO IN (665, 668)      -- Leitos FLEX 05 e 08
   AND U.CD_UNID_INT IS NOT NULL     -- Garantir que veio de uma unidade de interna��o
 GROUP BY TO_CHAR(M.DT_MOV_INT, 'MM/YYYY'),
          L.CD_LEITO,
          L.DS_RESUMO
 ORDER BY TO_DATE(TO_CHAR(M.DT_MOV_INT, 'MM/YYYY'), 'MM/YYYY'),
          L.CD_LEITO;

