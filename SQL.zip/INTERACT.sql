SELECT * FROM ALL_SOURCE 
WHERE UPPER (TEXT) LIKE '%INTERACT%'
AND OWNER = 'DBAMV'

DBAMV.PKG_HNB_INDICADOR_QUALIDADE

sELECT * FROM HNB_INDICADOR_QUALIDADE_PM_SA
-*--------------------------------------
SELECT  * 
FROM  dbamv.HNB_INDICADOR_QUALIDADE_PM_SA p
WHERE   p.Dt_Referencia BETWEEN to_date ('01/06/2025', 'DD/MM/RRRR') AND to_date ('31/07/2025' , 'DD/MM/RRRR') 
and     p.grupo_indicador =  15
and     p.cd_setor = 141
--and     cod_indicador in   (626)
-----------------------------------------
select * from unid_int i
where i.ds_unid_int like '%HEMODI%'

SELECT * FROM LEITO L
WHERE L.CD_UNID_INT = 52
AND L.TP_SITUACAO = 'A'
-- VERIFICAR A CARGA QUE EST� ALIMENTANDO A TABELA DOS INDICADORES, ENTENDER O PORQUE OS INDICADORES DO 4�RJ N�O EST�O SENDO ALIMENTADOS COM OS DADOS AP�S OS AJUSTES NO LEITOS
