-- Tabela Cargas 
SELECT * FROM HNB_LOG_CARGAS

-- Tabela JOBS
SELECT * FROM DBA_JOBS

-- Pesquisar Trigger - PKG - Procede
SELECT * FROM ALL_SOURCE WHERE UPPER(TEXT) LIKE '%HNB_LOG_CARGAS%'

--Pesquisar View
SELECT * FROM ALL_VIEWS

-- Pesquisar Objeto
SELECT * FROM ALL_OBJECTS
