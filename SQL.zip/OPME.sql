select * -- 2476
  from ord_com o
 where cd_sol_com not in
       (
        
        select cd_sol_com --18179
          from sol_com
         where sn_opme = 'S'
           and cd_aviso_cirurgia is not null
          
           and dt_sol_com between to_date('01/01/2023', 'dd/mm/rrrr') and
               to_date('30/08/2024', 'dd/mm/rrrr')) and
               o.cd_consumo_paciente is not null
               and o.dt_cancelamento is null
               and o.dt_ord_com between to_date('01/01/2023', 'dd/mm/rrrr') and
               to_date('30/08/2024', 'dd/mm/rrrr')
---------------------------------------------------------------------------               
select * from dbamv.consumo_paciente c
where c.cd_consumo_paciente = 49818

select * from ent_pro ep
where ep.cd_ord_com = 414971

SELECT ME.CD_MVTO_ESTOQUE,ME.TP_MVTO_ESTOQUE , ME FROM MVTO_ESTOQUE ME
JOIN ITMVTO_ESTOQUE  IE
ON IE.CD_MVTO_ESTOQUE = ME.CD_MVTO_ESTOQUE

WHERE IE.CD_PRODUTO = 47571
 AND ME.CD_AVISO_CIRURGIA = 168492
 
 -----------------------------------------------------------
 SELECT ME.CD_MVTO_ESTOQUE,
       ME.TP_MVTO_ESTOQUE,
       ME.CD_ESTOQUE,
       E.DS_ESTOQUE,
       ME.DT_MVTO_ESTOQUE,
       ME.HR_MVTO_ESTOQUE,
       ME.CD_ATENDIMENTO,
       ME.CD_SETOR,
       S.NM_SETOR,
       ME.NR_DOCUMENTO,
       ME.CD_SOLSAI_PRO,
       ME.CD_AVISO_CIRURGIA,
       ME.CD_MOVIMENTACAO,
       IE.CD_PRODUTO,
       P.DS_PRODUTO,
       PF.CD_PRO_FAT,
       G.CD_GUIA,
       G.NR_GUIA,
       IG.CD_IT_GUIA,
       IG.CD_PRO_FAT,
       PF.DS_PRO_FAT,
       IG.DT_AUTORIZOU
  FROM MVTO_ESTOQUE ME
  JOIN ITMVTO_ESTOQUE IE
    ON IE.CD_MVTO_ESTOQUE = ME.CD_MVTO_ESTOQUE
    JOIN PRODUTO P
    ON P.CD_PRODUTO = IE.CD_PRODUTO
    JOIN PRO_FAT PF
    ON PF.CD_PRO_FAT = P.CD_PRO_FAT
    JOIN GUIA G
    ON G.CD_ATENDIMENTO = ME.CD_ATENDIMENTO
    JOIN IT_GUIA IG
    ON IG.CD_GUIA = G.CD_GUIA AND IG.CD_PRO_FAT = P.CD_PRO_FAT
    JOIN SETOR S
    ON S.CD_SETOR = ME.CD_SETOR
    JOIN ESTOQUE E
    ON E.CD_ESTOQUE = ME.CD_ESTOQUE
 WHERE --IE.CD_PRODUTO = 47571
    ME.CD_AVISO_CIRURGIA IN (198356)
   
----------------------------------------------------------------------------------------------------
  SELECT * FROM AUDIT_DBAMV.IT_GUIA WHERE CD_GUIA IN (3407863)
  
  SELECT * FROM IT_GUIA WHERE CD_AVISO_CIRURGIA = 198356
  
  SELECT * FROM USUARIOS WHERE CD_USUARIO = 'HC01866410'
  
  SELECT * FROM ORD_COM O WHERE O.CD_SOL_COM IS NULL AND O.CD
  --------------------------------------------------------------------------------------
  SELECT ME.CD_MVTO_ESTOQUE,
       ME.TP_MVTO_ESTOQUE,
       ME.CD_ESTOQUE,
       E.DS_ESTOQUE,
       ME.DT_MVTO_ESTOQUE,
       ME.HR_MVTO_ESTOQUE,
       ME.CD_ATENDIMENTO,
       ME.CD_SETOR,
       S.NM_SETOR,
       ME.NR_DOCUMENTO,
       ME.CD_SOLSAI_PRO,
       ME.CD_AVISO_CIRURGIA,
       ME.CD_MOVIMENTACAO,
       IE.CD_PRODUTO,
       P.DS_PRODUTO,
       PF.CD_PRO_FAT,
       G.CD_GUIA,
       G.NR_GUIA,
       IG.CD_IT_GUIA,
       IG.CD_PRO_FAT AS CD_PRO_FAT_GUIA,
       PF.DS_PRO_FAT,
       IG.DT_AUTORIZOU,
       CASE
         WHEN ME.TP_MVTO_ESTOQUE IN ('ALTERA��O', 'CANCELAMENTO') THEN
          'Diverg�ncia na Guia Inicial'
         ELSE
          NULL
       END AS DIVERGENCIA_GUIA,
       CASE
         WHEN G.CD<> IG.CD_PRO_FAT THEN
          'Produto Dispensado Diferente do Autorizado'
         ELSE
          NULL
       END AS PRODUTO_DIVERGENTE,
       CASE
         WHEN IG.DT_AUTORIZOU IS NULL THEN
          'Falta de Autoriza��o da Guia'
         ELSE
          NULL
       END AS FALTA_AUTORIZACAO,
       CASE
         WHEN ME.CD_AVISO_CIRURGIA IS NULL THEN
          'Cancelamento da Solicita��o Antes da Realiza��o da Cirurgia'
         ELSE
          NULL
       END AS CANCELAMENTO_SOLICITACAO
  FROM MVTO_ESTOQUE ME
  JOIN ITMVTO_ESTOQUE IE
    ON IE.CD_MVTO_ESTOQUE = ME.CD_MVTO_ESTOQUE
  JOIN PRODUTO P
    ON P.CD_PRODUTO = IE.CD_PRODUTO
  JOIN PRO_FAT PF
    ON PF.CD_PRO_FAT = P.CD_PRO_FAT
  JOIN GUIA G
    ON G.CD_ATENDIMENTO = ME.CD_ATENDIMENTO
  JOIN IT_GUIA IG
    ON IG.CD_GUIA = G.CD_GUIA
   AND IG.CD_PRO_FAT = PF.CD_PRO_FAT
  JOIN SETOR S
    ON S.CD_SETOR = ME.CD_SETOR
  JOIN ESTOQUE E
    ON E.CD_ESTOQUE = ME.CD_ESTOQUE
    JOIN SOL_COM SC
    ON SC.CD_AVISO_CIRURGIA = G.CD_AVISO_CIRURGIA
  JOIN ORD_COM O
ON  O.CD_SOL_COM = SC.CD_SOL_COM
 WHERE O.DT_ORD_COM >= '01/09/2024'
ORDER BY ME.CD_AVISO_CIRURGIA
-------------------------------------------------------
SELECT * FROM AUDIT_DBAMV.GUIA G
