-- DELETA  M�DULO/TELA DOS PAP�IS SELECIONADO ------

DELETE FROM dbasgu.papel_mod M
 WHERE M.CD_MODULO LIKE 'O_CONCBANC'
   AND M.CD_PAPEL IN (SELECT M.CD_PAPEL
                        FROM dbasgu.papel_mod M
                        LEFT JOIN DBAMV.HNB_LOG_PAPEL_MOD P
                          ON P.CD_PAPEL = M.CD_PAPEL
                       WHERE M.CD_MODULO LIKE 'M_EXALAB'
                         AND M.CD_PAPEL  IN (1,
                                            2,
                                            6,
                                            9,
                                            14,
                                            15,
                                            16,
                                            24,
                                            27,
                                            33,
                                            34,
                                            35,
                                            36,
                                            37,
                                            38,
                                            40,
                                            41,
                                            42,
                                            48,
                                            55,
                                            62,
                                            65,
                                            74,
                                            75,
                                            80,
                                            81,
                                            86,
                                            186,
                                            188,
                                            189,
                                            190,
                                            238,
                                            239,
                                            242,
                                            249,
                                            254,
                                            255,
                                            257,
                                            258,
                                            259,
                                            260,
                                            262,
                                            270,
                                            273,
                                            275,
                                            278,
                                            281,
                                            287,
                                            288,
                                            305,
                                            342));
-- DELETA DO PERFIL DO USUARIO O M�DULO/TELA QUE FOI LIBERADO POR FORA DE UM PAPEL - EXCETO OS USU�RIOS INSERIDOS A.CD_USUARIO :
DELETE FROM dbasgu.aut_mod A
 WHERE A.CD_MODULO IN ('M_REGRA','M_INDICE', 'M_CONVENIO', 'M_TABFAT')
   /*AND A.CD_USUARIO NOT IN
       ('NATALIA.JULIANE', 'KETHERINE.FORTES', 'LETICIA.SOMOGGI', 'DBAMV');*/

-- DELETA DE TODOS PERFIS DE USUARIOS, M�DULOS/TELA QUE FORAM LIBERADOS POR FORA DE UM PAPEL:
DELETE FROM dbasgu.aut_mod A
 WHERE A.CD_MODULO IN ('O_CONCBANC');

-- DELETA MODULOS/TELAS DE TODOS OS PAP�IS EXETO O DA TI: 309:
DELETE FROM dbasgu.papel_mod M
 WHERE M.CD_MODULO LIKE 'O_CONCBANC' --IN ('M_REGRA', 'M_INDICE', 'M_CONVENIO', 'M_TABFAT')
   AND M.CD_PAPEL <> 309
   AND M.CD_PAPEL <> 19
   AND M.CD_PAPEL <> 20
   AND M.CD_PAPEL <> 256
   AND M.CD_PAPEL <> 257
   AND M.CD_PAPEL <> 258
   AND M.CD_PAPEL <> 259

  -- AND M.CD_PAPEL <> 343 --CADASTRO
   ;
-- DELETA  M�DULO/TELA DOS PAP�IS SELECIONADO ------

DELETE FROM dbasgu.papel_mod M
 WHERE M.CD_MODULO LIKE 'M_EXALAB'
   AND M.CD_PAPEL IN (SELECT M.CD_PAPEL
                        FROM dbasgu.papel_mod M
                        LEFT JOIN DBAMV.HNB_LOG_PAPEL_MOD P
                          ON P.CD_PAPEL = M.CD_PAPEL
                       WHERE M.CD_MODULO LIKE 'M_EXALAB'
                         AND M.CD_PAPEL IN (1,
                                            2,
                                            6,
                                            9,
                                            14,
                                            15,
                                            16,
                                            24,
                                            27,
                                            33,
                                            34,
                                            35,
                                            36,
                                            37,
                                            38,
                                            40,
                                            41,
                                            42,
                                            48,
                                            55,
                                            62,
                                            65,
                                            74,
                                            75,
                                            80,
                                            81,
                                            86,
                                            186,
                                            188,
                                            189,
                                            190,
                                            238,
                                            239,
                                            242,
                                            249,
                                            254,
                                            255,
                                            257,
                                            258,
                                            259,
                                            260,
                                            262,
                                            270,
                                            273,
                                            275,
                                            278,
                                            281,
                                            287,
                                            288,
                                            305,
                                            342));
