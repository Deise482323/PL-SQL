SELECT MT.CD_AVISO_CIRURGIA,
       DECODE(MT.TP_GUIA, 'O', 'OPME', 'I', 'INTERNA��O') AS TIPO_DE_GUIA,
       MIN(MT.DT_INICIO) AS DT_INICIO,
       
       -- Formata DT_FIM apenas para OPME (somente data)
       CASE
         WHEN MT.TP_GUIA = 'O' THEN
          TO_DATE(TO_CHAR(MAX(MT.DT_FIM), 'DD/MM/YYYY'), 'DD/MM/YYYY')
         ELSE
          MAX(MT.DT_FIM)
       END AS DT_FIM,
       
       CASE
         WHEN MT.TP_GUIA = 'O' THEN
          TO_CHAR(SUM(MT.DIAS)) || ' dias'
         ELSE
          TO_CHAR(SUM(MT.DIAS)) || ' dias e ' ||
          TO_CHAR(TRUNC(SUM(MT.HORAS) * 24)) || ' horas'
       END AS TEMPO_SOLICITACAO

  FROM (
        -- OPME: dias entre S.DT_SOL_COM e status 'S'
        SELECT AC.CD_AVISO_CIRURGIA,
                G.TP_GUIA,
                S.DT_SOL_COM AS DT_INICIO,
                (SELECT MIN(L2.DT_MOVIMENTO)
                   FROM LOG_GUIA L2
                  WHERE L2.CD_GUIA = G.CD_GUIA
                    AND L2.TP_SITUACAO_MOVIMENTO = 'S') AS DT_FIM,
                TRUNC((SELECT MIN(L2.DT_MOVIMENTO) - S.DT_SOL_COM
                        FROM LOG_GUIA L2
                       WHERE L2.CD_GUIA = G.CD_GUIA
                         AND L2.TP_SITUACAO_MOVIMENTO = 'S')) AS DIAS,
                0 AS HORAS
        
          FROM GUIA G
          JOIN SOL_COM S
            ON S.CD_GUIA = G.CD_GUIA
          JOIN AVISO_CIRURGIA AC
            ON AC.CD_AVISO_CIRURGIA = G.CD_AVISO_CIRURGIA
         WHERE G.TP_GUIA = 'O'
           AND EXISTS (SELECT 1
                  FROM LOG_GUIA L
                 WHERE L.CD_GUIA = G.CD_GUIA
                   AND L.TP_SITUACAO_MOVIMENTO = 'S')
           AND AC.DT_AVISO_CIRURGIA BETWEEN
               TO_DATE('01/01/2025', 'DD/MM/YYYY') AND
               TO_DATE('30/06/2025', 'DD/MM/YYYY')
        
        UNION ALL
        
        -- Interna��o: dias + horas entre status 'P' e mudan�a para 'S'
        SELECT AC.CD_AVISO_CIRURGIA,
                G.TP_GUIA,
                L.DT_MOVIMENTO AS DT_INICIO,
                (SELECT MIN(L2.DT_MOVIMENTO)
                   FROM LOG_GUIA L2
                  WHERE L2.CD_GUIA = G.CD_GUIA
                    AND L2.DT_MOVIMENTO > L.DT_MOVIMENTO
                    AND L2.TP_SITUACAO_MOVIMENTO = 'S') AS DT_FIM,
                TRUNC((SELECT MIN(L2.DT_MOVIMENTO) - L.DT_MOVIMENTO
                        FROM LOG_GUIA L2
                       WHERE L2.CD_GUIA = G.CD_GUIA
                         AND L2.DT_MOVIMENTO > L.DT_MOVIMENTO
                         AND L2.TP_SITUACAO_MOVIMENTO = 'S')) AS DIAS,
                MOD((SELECT MIN(L2.DT_MOVIMENTO) - L.DT_MOVIMENTO
                      FROM LOG_GUIA L2
                     WHERE L2.CD_GUIA = G.CD_GUIA
                       AND L2.DT_MOVIMENTO > L.DT_MOVIMENTO
                       AND L2.TP_SITUACAO_MOVIMENTO = 'S'),
                    1) AS HORAS
        
          FROM GUIA G
          JOIN AVISO_CIRURGIA AC
            ON AC.CD_AVISO_CIRURGIA = G.CD_AVISO_CIRURGIA
          JOIN LOG_GUIA L
            ON L.CD_GUIA = G.CD_GUIA
         WHERE G.TP_GUIA = 'I'
           AND L.TP_SITUACAO_MOVIMENTO = 'P'
           AND EXISTS (SELECT 1
                  FROM LOG_GUIA L2
                 WHERE L2.CD_GUIA = G.CD_GUIA
                   AND L2.DT_MOVIMENTO > L.DT_MOVIMENTO
                   AND L2.TP_SITUACAO_MOVIMENTO = 'S')
           AND EXISTS
         (SELECT 1
                  FROM GUIA G_OPME
                 WHERE G_OPME.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
                   AND G_OPME.TP_GUIA = 'O')
           AND AC.DT_AVISO_CIRURGIA BETWEEN
               TO_DATE('01/01/2025', 'DD/MM/YYYY') AND
               TO_DATE('30/06/2025', 'DD/MM/YYYY')
        
        ) MT

 GROUP BY MT.CD_AVISO_CIRURGIA, MT.TP_GUIA
 ORDER BY MT.CD_AVISO_CIRURGIA, MT.TP_GUIA;
