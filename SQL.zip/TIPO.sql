SELECT owner,
       column_name,
       data_type,
       data_length,
       data_precision,
       data_scale
FROM all_tab_columns
WHERE table_name = 'HNB_INDICADOR_QUALIDADE_PM_SA'
ORDER BY owner, column_id;
------------------------------------------
SELECT
  TP_ATENDIMENTO,
  DUMP(TP_ATENDIMENTO) AS DUMP_TP
FROM DBAMV.HNB_INDICADOR_QUALIDADE_PM_SA
WHERE ROWNUM <= 10;


