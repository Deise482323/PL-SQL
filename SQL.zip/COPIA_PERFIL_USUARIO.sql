QUERY PARA ESPELHAR PERFIS 


begin
  
dbamv.prc_hnb_copia_perfil('HE38555985', 'HC01866410', 'S');

END;


/*
Usu�rio de origem: AGOSTINHO.LOPES
Usu�rio de destino: HC19847348812
N - N�o mant�m as configura��es anteriores do usu�rio de destino;
S - Mant�m as configura��es anteriores do usu�rio de destino;
*/
