---- SRIPT Para trazer os dados do raz�o contabil ( Gerar uma aba de planilha para M�s )

select lc.cd_multi_empresa,
       LC.CD_LOTE,
       lt.ds_lote,
       lc.dt_lcto,
       LT.DT_INICIAL_LCTO,
       LT.DT_FINAL_LCTO,
       LT.DT_CRIACAO,
       pc.cd_reduzido,
       pc.cd_reduzido_pai,
       pc.cd_contabil,
       pc.ds_conta,
       lc.ds_complemento,
       lc.cd_moeda,
       vl_lancado,
       'DEBITO' TP_LANCAMENTO,
       pc.tp_conta_contabil,
       pc.tp_natureza,
       LT.sn_importado,

       LC.CD_LCTO_CONTABIL,
       LC.CD_LCTO_MOVIMENTO

from lcto_contabil lc
inner join plano_contas pc on pc.CD_REDUZIDO = lc.CD_REDUZIDO_debito
inner join lote lt on lt.cd_lote = lc.cd_lote
--left outer  join lcto_setor ls on ls.cd_lcto_contabil = lc.cd_lcto_contabil
--left outer  join setor s on s.CD_SETOR = ls.cd_setor_DEBITO
where trunc(lc.dt_lcto) BETWEEN '01/09/2025' and '30/09/2025'
--and lc.cd_reduzido_DEBITO = 7
--and pc.cd_contabil = '3.3.15.20.0015.00005'
--and lc.cd_lote = 102655
--and lc.cd_multi_empresa = '1'
---AND LC.CD_LCTO_MOVIMENTO IN ( 24011000,26706679)

union all

select lc.cd_multi_empresa,
       LC.CD_LOTE,
       lt.ds_lote,
       lc.dt_lcto,
       LT.DT_INICIAL_LCTO,
       LT.DT_FINAL_LCTO,
       LT.DT_CRIACAO,

       pc.cd_reduzido,
       pc.cd_reduzido_pai,
       pc.cd_contabil,
       pc.ds_conta,
       lc.ds_complemento,
       lc.cd_moeda ,
       vl_lancado ,
       'CREDITO' TP_LANCAMENTO,
       pc.tp_conta_contabil,
       pc.tp_natureza,
       lt.sn_importado,
       LC.CD_LCTO_CONTABIL,
       LC.CD_LCTO_MOVIMENTO

from lcto_contabil lc
inner join plano_contas pc on pc.CD_REDUZIDO = lc.CD_REDUZIDO_CREDITO
inner join lote lt on lt.cd_lote = lc.cd_lote
--left outer join lcto_setor ls on ls.cd_lcto_contabil = lc.cd_lcto_contabil
--left outer join setor s on s.CD_SETOR = ls.cd_setor_credito
where trunc(lc.dt_lcto) BETWEEN '01/09/2025' and '30/09/2025'
--and lc.cd_reduzido_credito = 7
--and pc.cd_contabil = '3.3.15.20.0015.00005'
--and lc.cd_lote = 102655
--and lc.cd_multi_empresa = '1'
--order by nm_setor,ds_complemento""""""""""""""""
--AND LC.CD_LCTO_MOVIMENTO IN ( 24011000 ,26706679)
order by  dt_lcto,cd_lcto_movimento
