SELECT DISTINCT PAC.DS_TRABALHO CONTRATANTE_CHECKUP,
                PAC.NM_PACIENTE NOME,
                PAC.CD_PACIENTE SAME,
                PAC.EMAIL EMAIL,
                PAC.DT_NASCIMENTO DT_NASC,
                ATE.CD_ATENDIMENTO,
                ATE.DT_ATENDIMENTO,
                TO_NUMBER(FNC_HNB_OBTER_IDADE(PAC.DT_NASCIMENTO,
                                              PLA.DT_PEDIDO)) IDADE,
                (SELECT DISTINCT S.NM_SEXO
                   FROM DBAMV.TIPO_SEXO S
                  WHERE S.TP_SEXO = PAC.TP_SEXO) GENERO,
                TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATE.CD_ATENDIMENTO,
                                                          421,
                                                          'U')) IMC,
                TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATE.CD_ATENDIMENTO,
                                                          4,
                                                          'U')) PAS,
                TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATE.CD_ATENDIMENTO,
                                                          5,
                                                          'U')) PAD,
                TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATE.CD_ATENDIMENTO,
                                                          21,
                                                          'U')) PESO,
                TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATE.CD_ATENDIMENTO,
                                                          22,
                                                          'U')) ALTURA,
                TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATE.CD_ATENDIMENTO,
                                                          621,
                                                          'U')) CIRCU_ABDOMINAL,
                TO_NUMBER(REPLACE((SELECT DISTINCT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'GLI'
                                     AND UPPER(REX.NM_CAMPO) = 'GLICOSE'),
                                  '.',
                                  ',')) GLICOSE,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'TRI'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('TRIGLIC�RIDES', 'TRIGLICERIDES')),
                                  '.',
                                  ',')) TRIGLICERIDES,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'COL'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'COLESTEROL TOTAL'),
                                  '.',
                                  ',')) COLESTEROL_TOTAL,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'TGO'
                                     AND UPPER(REX.NM_CAMPO) = 'AST (TGO)'),
                                  '.',
                                  ',')) TGO,
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'TGP'
                                     AND UPPER(REX.NM_CAMPO) = 'ALT (TGP)')
                                      TGP,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'CR'
                                     AND UPPER(REX.NM_CAMPO) = 'CREATININA') 
                                     CREATININA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UR'
                                     AND UPPER(REX.NM_CAMPO) = 'UR�IA'),
                                  '.',
                                  ',')) UREIA,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'PSATL'
                                     AND UPPER(REX.NM_CAMPO) = 'PSA TOTAL')
                                      PSA_TOTAL,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'PSATL'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'PSA LIVRE/TOTAL')
                                          PSA_LIVRE_TOTAL,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'PSATL'
                                     AND UPPER(REX.NM_CAMPO) = 'PSA LIVRE')
                                      PSA_LIVREL,/*
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) = 'HEMACEAS'),
                                  '.',
                                  ',')) HEMACEAS,*/
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) = 'PLAQUETAS')
                                      PLAQUETAS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) = 'BAS�FILOS'),
                                  '.',
                                  ',')) BASOFILOS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) = 'LEUC�CITOS'),
                                  '.',
                                  ',')) LEUCOCITOS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'ERITR�CITOS'),
                                  '.',
                                  ',')) ERITROCITOS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('HEMAT�CRITO', 'HEMATOCRITO')),
                                  '.',
                                  ',')) HEMATOCRITO,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'HEMOGLOBINA'),
                                  '.',
                                  ',')) HEMOGLOBINA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'HEMOGLOBINA CORPUSCULAR M�DIA'),
                                  '.',
                                  ',')) HEMO_CORP_MEDIA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('MON�CITOS', 'MONOCITOS')),
                                  '.',
                                  ',')) MONOCITOS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('NEUTR�FILOS', 'NEUTROFILOS')),
                                  '.',
                                  ',')) NEUTROFILOS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('VOLUME PLAQUET�RIO M�DIO',
                                          'VOLUME PLAQUETARIO MEDIO')),
                                  '.',
                                  ',')) VOL_PLAQ_MEDIO,
                
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'AUR'
                                     AND UPPER(REX.NM_CAMPO) =
                                          '�CIDO �RICO, SORO'),
                                  '.',
                                  ',')) ACIDO_URICO,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'AFP'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'ALFA FETOPROTE�NA'),
                                  '.',
                                  ',')) ALFA_FETO_PROT,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'AMI'
                                     AND UPPER(REX.NM_CAMPO) = 'AMILASE'),
                                  '.',
                                  ',')) AMILASE,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'BTF'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'BILIRRUBINA TOTAL'),
                                  '.',
                                  ',')) BILI_TOT_E_FRACAO,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'CA'
                                     AND UPPER(REX.NM_CAMPO) = 'C�LCIO'),
                                  '.',
                                  ',')) CALCIO,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'CAI'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'C�LCIO IONIZADO'),
                                  '.',
                                  ',')) CALCIO_IONIZADO,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'CLF'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'FERRO - CAPAC TOTAL LIGA��O'),
                                  '.',
                                  ',')) CAP_DE_FIX_DO_FERRO,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HDL'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'HDL-COLESTEROL'),
                                  '.',
                                  ',')) HDL_COLESTEROL,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'DHL'
                                     AND UPPER(REX.NM_CAMPO) = 'DHL - IFCC'),
                                  '.',
                                  ',')) DHL_IFCC,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'FERR'
                                     AND UPPER(REX.NM_CAMPO) = 'FERRITINA'),
                                  '.',
                                  ',')) FERRITINA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'FAL'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'FOSFATASE ALCALINA'),
                                  '.',
                                  ',')) FOSFATASE_ALCALINA,/*
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'P'
                                     AND UPPER(REX.NM_CAMPO) = 'F�SFORO'),
                                  '.',
                                  ',')) FOSFORO,*/
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'GGT'
                                     AND UPPER(REX.NM_CAMPO) = 'GAMA-GT'),
                                  '.',
                                  ',')) GAMA_GT,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HBGLI'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'HEMOGLOBINA GLICADA'),
                                  '.',
                                  ',')) HEMOGLOBINA_GLICADA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'MG'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('MAGN�SIO', 'MAGNESIO')),
                                  '.',
                                  ',')) MAGNESIO,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'K'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('POT�SSIO', 'POTASSIO')),
                                  '.',
                                  ',')) POTASSIO,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'PTF'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('PROTEINAS', 'PROTE�NAS')),
                                  '.',
                                  ',')) PROTEINAS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'PTF'
                                     AND UPPER(REX.NM_CAMPO) = 'ALBUMINA'),
                                  '.',
                                  ',')) ALBUMINA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'PTF'
                                     AND UPPER(REX.NM_CAMPO) = 'GLOBULINAS'),
                                  '.',
                                  ',')) GLOBULINAS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'PTF'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'RELA��O ALBUMINA/GLOBULINA'),
                                  '.',
                                  ',')) RE_ALBU_GLOBULINA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'NA'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('SODIO', 'S�DIO')),
                                  '.',
                                  ',')) SODIO,
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'B12'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('VITAMINA B-12', 'VITAMINA B12'))
                                          VITAMINA_B_12,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'LDL'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('COLESTEROL LDL',
                                          'LDL-COLESTEROL')),
                                  '.',
                                  ',')) COLESTEROL_LDL,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'VLDL'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('COLESTEROL VLDL',
                                          'VLDL-COLESTEROL')),
                                  '.',
                                  ',')) COLESTEROL_VLDL,
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'PPF'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'PARASITOLOGICO DE FEZES') 
                                         PARASI_DE_FEZES,
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'SO'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'SANGUE OCULTO NAS FEZES')
                                          SANGUE_OCULTO,
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'ABORH'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'GRUPO SANGU�NEO')
                                          ABORH_GRUPO_SANG,
                /*TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) = 'HEMOGRAMA'),
                                  '.',
                                  ',')) HEMOGRAMA,*/
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'VHS'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'VHS'),
                                  '.',
                                  ',')) HEMOSSEDIMENTACAO,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HGH'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'HORM�NIO CRESCIMENTO') 
                                         HORMO_DE_CRESC,
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'E2'
                                     AND UPPER(REX.NM_CAMPO) = 'ESTRADIOL') 
                                     ESTRADIOL,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'FSH'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'FSH'),
                                  '.',
                                  ',')) FSH_HORM_FOLI_ESTIMU,
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'BHCG'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'BHCG GONADOTROFINA CORIONICA') 
                                         BHCG_GONAD_CORIONICA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'INSU'
                                     AND UPPER(REX.NM_CAMPO) = 'HOMA-IR'),
                                  '.',
                                  ',')) INSULINA,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'LH'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'LH')
                                          LH_HOR_LUTEINIZANTE,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'TESTO'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'TESTOSTERONA'),
                                  '.',
                                  ',')) TESTOSTE_TOTAL,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'TSH'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('HORM�NIO TIROESTIMULANTE',
                                          'HORMONIO TIROESTIMULANTE')) TSH_TIR_HORMONIO,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'T4L'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'T4 LIVRE - ELETROQUIMIOLUMINESCENCIA'),
                                  '.',
                                  ',')) T4_LIVRE,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'T3'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'TRIIODOTIRONINA (T3)'),
                                  '.',
                                  ',')) T3_HORMONIO_TRI,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'TESTOL'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'TESTOSTERONA LIVRE'),
                                  '.',
                                  ',')) TESTOSTERONA_LIVRE,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'IGF1'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'IGF-1'),
                                  '.',
                                  ',')) IGF1_SOMATOMEDINA_C,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'TRAB'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'TRAB')
                                          TRAB,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'VITD25OH'
                                     AND UPPER(REX.NM_CAMPO) =
                                         '25 HIDROXI - VITAMINA D'),
                                  '.',
                                  ',')) VITAMINA_D_25_OH,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'AHBCG'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'ANTI-HBC TOTAL')
                                          CON_ANT_CORE_DA_HEPA_B,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'ANTIHBS'
                                     AND UPPER(REX.NM_CAMPO) = 'ANTI-HBS')
                                      ANTI_HBS,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HVAG'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'ANTI-VHA TOTAL')
                                          ANTI_VHA_TOTAL,
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HVAM'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'ANTI-VHA, IGM')
                                          HVA_IGM_HEPATITE_A,
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HBSAG'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'AGHBS')
                                          HBSAG,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'CEA'
                                     AND UPPER(REX.NM_CAMPO) = 'CEA'),
                                  '.',
                                  ',')) CEA,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HBEAG'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'AGHBE')
                                         ANT_DA_HEPATITE_B,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'LATEX'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'FATOR REUMAT�IDE')
                                          FATOR_REUMA_LATEX,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'PCR'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'PCR'),
                                  '.',
                                  ',')) PCR_PROT_C_REATIVA,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'VDRL'
                    AND UPPER(REX.NM_CAMPO) IN
                        ('S�FILIS - FLOCULA��O')) VDRL,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'AHBCM'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'ANTI-HBC, IGM')
                                          HBC_IGM_ANTI_HEPATITE_B,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'CA199'
                                     AND UPPER(REX.NM_CAMPO) = 'CA19.9')
                                      CA19_9,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'CA125'
                                     AND UPPER(REX.NM_CAMPO) = 'CA 125'),
                                  '.',
                                  ',')) CA_125,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HCV'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'ANTI-HCV')
                                          HCV_HEPA_C,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'CA153'
                                     AND UPPER(REX.NM_CAMPO) = 'CA15.3'),
                                  '.',
                                  ',')) CA15_3,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HIV'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'HIV1/HIV2')
                                          ANTI_HIV_1_E_2,
                
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) IN ( 'ASPECTO',
                                         'ASPECTO, URINA'))
                                          ASPECTO, --------------------
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) =
                                         ' BILIRRUBINA, URINA')
                                          BILI_URINA,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         (' C�LULAS EPITELIAIS, URINA',
                                          'CELULAS EPITELIAIS, URINA'))
                                           CELULAS_EPIT_URINA,
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'CILINDROS, URINA')
                                         CILINDROS_URINA,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) = 'COR, URINA')
                                      COR_URINA,
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('CORPOS CET�NICOS, URINA',
                                          'CORPOS CETONICOS, URINA'))
                                           CORPOS_CETON_URINA,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'CRISTAIS, URINA')
                                          CRISTAIS_URINA,
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('ERITR�CITOS QUANTITATIVO, URINA',
                                          'ERITROCITOS QUANTITATIVO, URINA'))
                                           ERITR_QUANT_URINA,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'GLICOSE, URINA ISOLADA')
                                         GLI_URI_ISOLADA,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('LEUC�CITOS QUANTITATIVO, URINA',
                                          'LEUCOCITOS QUANTITATIVO, URINA'))
                                           LEUCO_QT_URINA,
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'NITRITO, URINA')
                                          NITRITO_URINA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) IN ( 'PH, URINA', 'PH' )),
                                  '.',
                                  ',')) PH_URINA,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('PROTE�NAS, URINA ISOLADA',
                                          'PROTEINAS, URINA ISOLADA', 'PROTE�NAS'))
                                           PROT_URINA_ISOLADA,
                (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('UROBILINOG�NIO, URINA',
                                          'UROBILINOGENIO, URINA'))
                                           UROBILI_URINA,
                
               (SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'PCRU'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'PROTEINA C ULTRA SENSIVEL')
                                          PROT_C_ULT_SENSIVEL,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'AUR'
                                     AND UPPER(REX.NM_CAMPO) IN (
                                         '�CIDO �RICO, SORO','�CIDO �RICO')),
                                  '.',
                                  ',')) AC_URI_SORO,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'BTF'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'BILIRRUBINA DIRETA'),
                                  '.',
                                  ',')) BILIRRUBINA_DIRETA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'BTF'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'BILIRRUBINA INDIRETA'),
                                  '.',
                                  ',')) BILIRRUBINA_INDIRETA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'BTF'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'BILIRRUBINA TOTAL'),
                                  '.',
                                  ',')) BILIRRUBINA_TOTAL

  FROM DBAMV.ATENDIME ATE
  JOIN DBAMV.PACIENTE PAC
    ON PAC.CD_PACIENTE = ATE.CD_PACIENTE
  JOIN DBAMV.PED_LAB PLA
    ON PLA.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO
 WHERE /*ATE.CD_CONVENIO IN (117, 166, 179, 111, 95, 83, 185, 131)*/
 ATE.CD_ORI_ATE = 7
 AND ATE.DT_ATENDIMENTO BETWEEN '08/11/2023' AND '12/12/2023'
/*AND ATE.CD_PACIENTE IN
(2132706, 2132708, 1643238, 2031749, 1578919, 1578918)*/
 ORDER BY PAC.NM_PACIENTE;
