select fs.ds_fila DESCR_FILA,
       oat.DS_ORI_ATE ORIGEM,
       ta.CD_PACIENTE PRONTUARIO,
       ta.CD_ATENDIMENTO ATENDIMENTO,
       ta.NM_PACIENTE PACIENTE,
       TO_CHAR(STP.DH_PROCESSO, 'dd/mm/rrrr HH24:MI:SS') HORA_TOTEM,
       TO_CHAR(STP2.DH_PROCESSO, 'dd/mm/rrrr HH24:MI:SS') HORA_INIC_ATEND,
       TO_CHAR(STP3.DH_PROCESSO, 'dd/mm/rrrr HH24:MI:SS') HORA_FIM_ATEND,
       fnc_hnb_obter_diferenca_horas(STP.DH_PROCESSO, STP2.DH_PROCESSO) tmp_totem_x_ini_atend,
       fnc_hnb_obter_diferenca_horas(STP2.DH_PROCESSO, STP3.DH_PROCESSO) tmp_ini_x_fim_atend
  from triagem_atendimento ta
  join fila_senha fs
    on fs.cd_fila_senha = ta.cd_fila_senha
  join sacr_tempo_processo stp -- totem
    on stp.cd_triagem_atendimento = ta.cd_triagem_atendimento
   and stp.cd_tipo_tempo_processo = 1
  join sacr_tempo_processo stp2 -- inicio atendimento administrativo
    on stp2.cd_triagem_atendimento = ta.cd_triagem_atendimento
   and stp2.cd_tipo_tempo_processo = 21
  join sacr_tempo_processo stp3 -- fim atendimento administrativo
    on stp3.cd_triagem_atendimento = ta.cd_triagem_atendimento
   and stp3.cd_tipo_tempo_processo = 22
  join atendime at
    on at.cd_atendimento = ta.cd_atendimento
  join ori_ate oat
    on oat.cd_ori_ate = at.cd_ori_ate
 where fs.cd_multi_empresa = 2
   and to_date(ta.dh_pre_atendimento, 'dd/mm/rrrr') between @DATA_INICIO and
       @DATA_FIM
   and ta.cd_multi_empresa = 2
   and ta.dh_removido is null
union all
select fs.ds_fila DESCR_FILA,
       null ORIGEM,
       null PRONTUARIO,
       null ATENDIMENTO,
       null PACIENTE,
       TO_CHAR(STP.DH_PROCESSO, 'dd/mm/rrrr HH24:MI:SS') HORA_TOTEM,
       TO_CHAR(STP2.DH_PROCESSO, 'dd/mm/rrrr HH24:MI:SS') HORA_INIC_ATEND,
       null HORA_FIM_ATEND,
       fnc_hnb_obter_diferenca_horas(STP.DH_PROCESSO, STP2.DH_PROCESSO) tmp_totem_x_ini_atend,
       null tmp_ini_x_fim_atend
  from triagem_atendimento ta
  join fila_senha fs
    on fs.cd_fila_senha = ta.cd_fila_senha
  join sacr_tempo_processo stp -- totem
    on stp.cd_triagem_atendimento = ta.cd_triagem_atendimento
   and stp.cd_tipo_tempo_processo = 1
  join sacr_tempo_processo stp2 -- inicio atendimento administrativo
    on stp2.cd_triagem_atendimento = ta.cd_triagem_atendimento
   and stp2.cd_tipo_tempo_processo = 21
 where fs.cd_multi_empresa = 2
   and to_date(ta.dh_pre_atendimento, 'dd/mm/rrrr') between @DATA_INICIO and
       @DATA_FIM
   and ta.cd_multi_empresa = 2
   and ta.dh_removido is null
   and ta.cd_paciente is null
