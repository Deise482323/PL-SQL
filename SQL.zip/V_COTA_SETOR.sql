CREATE OR REPLACE VIEW DBAMV.V_COTA_SETOR AS
SELECT	COTA_SETOR.CD_PRODUTO
	,COTA_SETOR.CD_SETOR
	,COTA_SETOR.CD_ESTOQUE
    ,COTA_SETOR.DT_VIGENCIA
    ,COTA_SETOR.CD_UNI_PRO
    ,COTA_SETOR.QT_COTA
    ,COTA_SETOR.NR_DIAS
    ,COTA_SETOR.SN_BLOQUEIA
    ,COTA_SETOR.cd_gabarito_cota  -- OP 12161
    FROM DBAMV.COTA_SETOR
 WHERE ( COTA_SETOR.CD_SETOR,
         COTA_SETOR.CD_PRODUTO,
         COTA_SETOR.CD_ESTOQUE,
         COTA_SETOR.DT_VIGENCIA ) IN (SELECT CD_SETOR,
                                             CD_PRODUTO,
                                             CD_ESTOQUE,
                                             MAX(DT_VIGENCIA ) DT_VIGENCIA
                                        FROM DBAMV.COTA_SETOR
                                       WHERE DT_VIGENCIA <= SYSDATE
                                         AND COTA_SETOR.SN_BLOQUEIA = 'N'  -- PDA 291072
                                         AND Cota_Setor.Cd_Estoque in ( Select Estoque.Cd_Estoque
		                                                                  From Dbamv.Estoque
                                                                         Where Estoque.Cd_Multi_Empresa = Pkg_Mv2000.Le_Empresa )
                                    GROUP BY CD_SETOR, CD_PRODUTO, CD_ESTOQUE )
;
