Atualiza��oo tabela :  TMP_MOVIMENTO_ESTOQUE;

----------------( TABELA TEMPORARIA MOVIMENTACAO DO ESTOQUE )------------------

---------( VERIFICAR MESES FECHADOS )----------

SELECT TO_CHAR(FM.DT_COMPETENCIA, 'MM/RRRR') COMPT, FM.SN_FECHAMENTO_DO_MES, FM.SN_CONSOLIDACAO
      --INTO vFECHAESTOQUE, vCONSOLIDAESTOQUE
      FROM DBAMV.FECHAMENTO_DO_MES FM
     WHERE TO_CHAR(FM.DT_COMPETENCIA, 'RRRR') >= '2025'
       AND FM.CD_MULTI_EMPRESA = 1
       ORDER BY 1 DESC;

-------------------------------------------------------------
--Movimenta��o : TMP_MOVIMENTO_ESTOQUE
-- Verificar quais s�o os meses que j� foram geradaos
SELECT TO_CHAR(ME.DT_MVTO_ESTOQUE,'YYYYMM') ANOMES,
COUNT(*) QTDE
FROM DBAMV.TMP_MOVIMENTO_ESTOQUE ME 
WHERE  TO_CHAR(ME.DT_MVTO_ESTOQUE,'YYYY') >= '2025'
GROUP BY to_char(ME.DT_MVTO_ESTOQUE,'YYYYMM') 
order by 1 desc

-- delete from dbamv.tmp_movimento_estoque tme where tme.dt_mvto_estoque between '01/02/2023' and '28/02/2023'
---- ATUALIZADO EM 15/02/2023 / 06/03/2023 / 10/04/2023


-- ATUALIZAR TABELA TMP_MOVIMENTO_ESTOQUE 

INSERT INTO DBAMV.TMP_MOVIMENTO_ESTOQUE
       (CD_MVTO_ESTOQUE,TP_MVTO_ESTOQUE,DESC_MVTO_ESTOQUE,CD_ESTOQUE,DT_MVTO_ESTOQUE,
       CD_ATENDIMENTO,CD_UNID_INT,CD_SETOR,CD_PRESTADOR,CD_ESTOQUE_DESTINO,
       CD_MOT_DEV,CD_SOLSAI_PRO,CD_AVISO_CIRURGIA,CD_ENT_PRO,CD_USUARIO,CD_MULTI_EMPRESA,
       TP_RETROATIVO,CD_ITMVTO_ESTOQUE,CD_PRODUTO,CD_UNI_PRO,QT_MOVIMENTACAO,CD_FORNECEDOR,
       CD_LOTE,DT_VALIDADE,NR_DOCUMENTO,DH_MVTO_ESTOQUE,CD_ITSOLSAI_PRO,
       TP_ESTOQUE,QT_KIT,TP_ORCAMENTO,SN_FATURA,DT_GRAVACAO,DS_ESTOQUE,
       SN_IMPRIME_DIRETO,CD_REDUZIDO_DEBITO,CD_REDUZIDO_CREDITO,CD_SUB_CLA,
       CD_CLASSE,CD_ESPECIE,DS_PRODUTO,DT_CADASTRO,TP_ATIVO,DT_ULTIMA_ENTRADA,
       SN_CONTROLE_VALIDADE,SN_PADRONIZADO,SN_PSCOTROPICO,HR_ULTIMA_ENTRADA,SN_MEDICAMENTO,
       CD_TIP_ATIV,SN_IMPRIME_ETIQUETA,SN_LOTE,CD_PRO_FAT,VL_FATOR_PRO_FAT,CD_DCB,CD_UNIDADE,
       DS_UNIDADE,VL_FATOR,TP_RELATORIOS,VL_CUSTO_MEDIO,CD_UNIDADERF1,DS_UNIDADERF1,VL_FATORRF1,
       TP_RELATORIOSRF1,CSTMEDIORF1,VL_ULTIMA_ENTRADA,CD_ULTIMO_FORNECEDOR,QT_ULTIMA_ENTRADA,
       DS_PRODUTO_RESUMIDO,VL_ULTIMA_CUSTO_REAL,SN_CONSIGNADO,CD_FORNECEDOR_PRINCIPAL,VL_ULTIMA_COMPRA_IPI,
       TP_HORAS_ESTERELIZAR,CD_USUARIO_INC,DT_INC_USUARIO,CD_USUARIO_ALT,DT_ALT_USUARIO )
  

Select 
    IME.CD_MVTO_ESTOQUE,  
    ME.TP_MVTO_ESTOQUE,  

    decode(ME.TP_MVTO_ESTOQUE,'B' ,'TOMBAMENTO','E','EMPRESTIMO','R','MOV. ENTRE EMPRESAS','S','SAIDA SETOR','P' ,'PACIENTE','X','BAIXA DE PRODUTO','C','DEVOLUCAO DE PACIENTE',
                                   'D','DEVOLUCAO DE SETOR','T','TRANSF ENTRE ESTOQUES') DESC_MVTO_ESTOQUE,       
    me.CD_ESTOQUE,
    DT_MVTO_ESTOQUE,
    CD_ATENDIMENTO,
    CD_UNID_INT,
    me.CD_SETOR,
    CD_PRESTADOR,
    CD_ESTOQUE_DESTINO,
    CD_MOT_DEV,
    CD_SOLSAI_PRO,
    CD_AVISO_CIRURGIA,
    CD_ENT_PRO,
    CD_USUARIO,
    me.CD_MULTI_EMPRESA,
    TP_RETROATIVO,
    CD_ITMVTO_ESTOQUE,
    ime.CD_PRODUTO,
    ime.CD_UNI_PRO,
    QT_MOVIMENTACAO,
    
    IME.CD_FORNECEDOR,
--    IME.CD_LOTE,
    substr(IME.CD_LOTE,1,20) cd_lote,
    IME.DT_VALIDADE,
    SUBSTR(ME.NR_DOCUMENTO,1,15)  NR_DOCUMENTO,
    DH_MVTO_ESTOQUE,
    CD_ITSOLSAI_PRO,
    e.TP_ESTOQUE,
    QT_KIT,
    TP_ORCAMENTO,
    SN_FATURA,
    DT_GRAVACAO,
    DS_ESTOQUE,
    SN_IMPRIME_DIRETO,
    CD_REDUZIDO_DEBITO,
    CD_REDUZIDO_CREDITO,
    CD_SUB_CLA,
    CD_CLASSE,
    CD_ESPECIE,
    DS_PRODUTO,
    DT_CADASTRO,
    TP_ATIVO,
    DT_ULTIMA_ENTRADA,
    SN_CONTROLE_VALIDADE,
    SN_PADRONIZADO,
    SN_PSCOTROPICO,
    HR_ULTIMA_ENTRADA,
    SN_MEDICAMENTO,
    CD_TIP_ATIV,
    SN_IMPRIME_ETIQUETA,
    SN_LOTE,
    pr.CD_PRO_FAT,
    VL_FATOR_PRO_FAT,
    CD_DCB,
    UP.CD_UNIDADE,
    UP.DS_UNIDADE,
    UP.VL_FATOR,
    UP.TP_RELATORIOS,
    VL_CUSTO_MEDIO,
    UP1.CD_UNIDADE CD_UNIDADERF1,
    UP1.DS_UNIDADE DS_UNIDADERF1,
    UP1.VL_FATOR VL_FATORRF1,
    UP1.TP_RELATORIOS TP_RELATORIOSRF1,
    (VL_ULTIMA_ENTRADA * up1.vl_fator) CSTMEDIORF1,
    VL_ULTIMA_ENTRADA,
    CD_ULTIMO_FORNECEDOR,
    QT_ULTIMA_ENTRADA,
    DS_PRODUTO_RESUMIDO,
    VL_ULTIMA_CUSTO_REAL,
    SN_CONSIGNADO,
    CD_FORNECEDOR_PRINCIPAL,
    VL_ULTIMA_COMPRA_IPI,
    TP_HORAS_ESTERELIZAR,
    CD_USUARIO_INC,
    DT_INC_USUARIO,
    CD_USUARIO_ALT,
    DT_ALT_USUARIO
fRom dbamv.mvto_estoque me
inner join dbamv.itmvto_estoque ime on ime.cd_mvto_estoque = me.cd_mvto_estoque
inner join dbamv.estoque e on e.cd_estoque = me.cd_estoque
inner join dbamv.produto pr on pr.cd_produto = ime.cd_produto
inner join dbamv.uni_pro up on up.cd_produto = pr.cd_produto and up.tp_relatorios = 'R' AND UP.SN_ATIVO = 'S'
LEFT OUTER join dbamv.uni_pro up1 on up1.cd_produto = pr.cd_produto and up1.tp_relatorios = '1' AND UP1.SN_ATIVO = 'S'
where me.dt_mvto_estoque between '01/07/2025' and '31/07/2025'-- Adicionar m�s que estiver faltando (Mes tem que estar fechado) Exemplo 01/04 a 30/04
and me.cd_solsai_pro not in ( 13414574499164)
--AND  ME.cd_estoque IN (4,5,6,7,8,2,9)
--AND E.TP_ESTOQUE = 'D'
AND ME.CD_MULTI_EMPRESA  = 1
--and IME.cd_produto = 115493 and ME.tp_mvto_estoque = 'S' AND IME.CD_MVTO_ESTOQUE = 12332452

select me.cd_mvto_estoque,me.* fRom dbamv.mvto_estoque me
where me.dt_mvto_estoque  between '01/07/2025' and '31/07/2025'
and me.cd_mvto_estoque >= 22184360
and me.cd_mvto_estoque <= 22184370
and me.cd_mvto_estoque in (22184364,22184367)
order by 1

select ime.cd_mvto_estoque,ime.cd_itsolsai_pro from itmvto_estoque ime where ime.cd_mvto_estoque in (22184364,22184367)
1	22184364	60289315
2	22184364	60289316
3	22184364	60289314
4	22184367	60287911
5	22184367	60287912

select * from dbamv.solsai_pro ssp where ssp.cd_solsai_pro in ( 13414574499164,13414131 ) 
select * from dbamv.itmvto_estoque ime  where ime.cd_ssp.cd_solsai_pro in ( 13414574499164,13414131 ) 

select * from dbamv.solsai_pro ssp where ssp.cd_solsai_pro >= 13414131 and ssp.hr_solsai_pro < '15/07/2025' order by 1

select * from dbamv.solsai_pro ssp where ssp.cd_solsai_pro in (13414154,13414155,13414156)

select * from dbamv.mvto_estoque me where me.cd_mvto_estoque in (22184364,22184367)
select * from dbamv.solsai_pro ssp where ssp.cd_solsai_pro in ( 13414574499164,13414131 ) 
select * from dbamv.itsolsai_pro issp where issp.cd_solsai_pro in ( 13414574499164,13414131 ) 


select * from dbamv.mvto_estoque me where me.cd_solsai_pro in ( 12997861 )for update   --1135777
select * from dbamv.solsai_pro ssp where ssp.cd_solsai_pro in ( 12997861 ) for update  --12997861
select * from dbamv.itsolsai_pro issp where issp.cd_solsai_pro in ( 12997861 ) for update  --12997861

Tabela TMP_ENTRADA_PRODUTO_ESTOQUE.

-- Verificar ultimo periodo gerado

SELECT to_char(epe.dt_entrada,'yyyymm') anomes,count(*) qtde
FROM DBAMV.TMP_ENTRADA_PRODUTO_ESTOQUE EPE 
WHERE to_char(epe.dt_entrada,'yyyy') >= '2025'
group by to_char(epe.dt_entrada,'yyyymm') 
order by 1


--------------------------------------------------------------
-----------( TMP_ENTRADA_PRODUTO_ESTOQUE )-------------------

INSERT INTO DBAMV.TMP_ENTRADA_PRODUTO_ESTOQUE
       (CD_ATENDIMENTO,
       CD_CUSTO_MEDIO,
       CD_ENT_PRO,
       CD_ESTOQUE,
       DT_ENTRADA,
       CD_FORNECEDOR,
       NR_DOCUMENTO,
       CD_CON_PAG,
       CD_ITENT_PRO,
       CD_ORD_COM,
       CD_PRODUTO,
       DS_PRODUTO,
       ds_especie,
       ds_classe,
       ds_sub_cla,
       cd_pro_fat,
       CD_TIP_ENT,
       CD_TIP_DOC,
       CD_UNI_PRO,
       CD_UNIDADE,
       DT_GRAVACAO,
       DT_EMISSAO,
       DS_UNIDADE,
       VL_TOTAL_ENTRADA,
       VL_DESCONTO,
       VL_CUSTO_REAL,
       VL_TOTAL,
       VL_UNITARIO,
       VL_DESCONTO_ITEM,
       VL_IMPOSTO,
       VL_PERCENTUAL_DESCONTO,
       VL_TOTAL_CUSTO_REAL,
       VL_FATOR,
       QT_ATENDIDA,
       QT_CONSUMO_ATUAL,
       QT_CONSUMO_MES,
       QT_DEVOLVIDA,
       QT_ENTRADA,
       QT_ESTOQUE_ATUAL,
       QT_ESTOQUE_MAXIMO,
       QT_ESTOQUE_MINIMO,
       QT_ESTOQUE_VIRTUAL,
       QT_ESTOQUE_DOADO,
       QT_ESTOQUE_RESERVADO,
       QT_ORDEM_DE_COMPRA,
       QT_PONTO_DE_PEDIDO,
       QT_SOLICITACAO_DE_COMPRA,
       SN_ATIVO,
       TP_RELATORIOS,
       TP_CLASSIFICACAO_ABC,
       CD_REG_FAT,
       CDPROFAT,
       HR_LANCAMENTO,
       QT_LANCAMENTO,
       VLR_UNIT_FAT,
       VL_TOTAL_CONTA
)
       
SELECT 
       IEP.CD_ATENDIMENTO,
       IEP.CD_CUSTO_MEDIO,
       EP.CD_ENT_PRO,
       EP.CD_ESTOQUE,
       EP.DT_ENTRADA,
       EP.CD_FORNECEDOR,
       EP.NR_DOCUMENTO,
       EP.CD_CON_PAG,
       IEP.CD_ITENT_PRO,
       EP.CD_ORD_COM,
       IEP.CD_PRODUTO,
       P.DS_PRODUTO,
       es.ds_especie,
       cl.ds_classe,
       sc.ds_sub_cla,
       p.cd_pro_fat,
       EP.CD_TIP_ENT,
       EP.CD_TIP_DOC,
       IEP.CD_UNI_PRO,
       UP.CD_UNIDADE,
       IEP.DT_GRAVACAO,
       EP.DT_EMISSAO,
       UP.DS_UNIDADE,
       EP.VL_TOTAL VL_TOTAL_ENTRADA,
       EP.VL_DESCONTO,
       IEP.VL_CUSTO_REAL,
       IEP.VL_TOTAL,
       IEP.VL_UNITARIO,
       IEP.VL_DESCONTO VL_DESCONTO_ITEM,
       IEP.VL_IMPOSTO,
       IEP.VL_PERCENTUAL_DESCONTO,
       IEP.VL_TOTAL_CUSTO_REAL,
       UP.VL_FATOR,
       IEP.QT_ATENDIDA,
       EPP.QT_CONSUMO_ATUAL,
       EPP.QT_CONSUMO_MES,
       IEP.QT_DEVOLVIDA,
       IEP.QT_ENTRADA,
       EPP.QT_ESTOQUE_ATUAL,
       EPP.QT_ESTOQUE_MAXIMO,
       EPP.QT_ESTOQUE_MINIMO,
       EPP.QT_ESTOQUE_VIRTUAL,
       EPP.QT_ESTOQUE_DOADO,
       EPP.QT_ESTOQUE_RESERVADO,
       EPP.QT_ORDEM_DE_COMPRA,
       EPP.QT_PONTO_DE_PEDIDO,
       EPP.QT_SOLICITACAO_DE_COMPRA,
       UP.SN_ATIVO,
       UP.TP_RELATORIOS,
       EPP.TP_CLASSIFICACAO_ABC,
       IRF.CD_REG_FAT,
       IRF.CD_PRO_FAT CDPROFAT,
       IRF.HR_LANCAMENTO,
       IRF.QT_LANCAMENTO,
       IRF.VL_UNITARIO VLR_UNIT_FAT,
       IRF.VL_TOTAL_CONTA

FROM DBAMV.ENT_PRO EP 
INNER JOIN DBAMV.ITENT_PRO IEP ON IEP.CD_ENT_PRO = EP.CD_ENT_PRO
LEFT OUTER JOIN DBAMV.UNI_PRO UP ON UP.CD_UNI_PRO = IEP.CD_UNI_PRO
LEFT OUTER JOIN DBAMV.EST_PRO EPP ON EPP.CD_PRODUTO = IEP.CD_PRODUTO AND EPP.CD_ESTOQUE = 4
inner join dbamv.produto p on p.cd_produto = iep.cd_produto
inner join dbamv.especie es on es.cd_especie = p.cd_especie
inner join dbamv.classe cl on cl.cd_especie = es.cd_especie and cl.cd_classe = p.cd_classe
inner join dbamv.sub_clas sc on sc.cd_classe = cl.cd_classe and es.cd_especie = cl.cd_especie 
and sc.cd_sub_cla = p.cd_sub_cla and sc.cd_classe = p.cd_classe and sc.cd_especie = p.cd_especie
LEFT OUTER JOIN DBAMV.REG_FAT RF ON RF.CD_ATENDIMENTO = EP.CD_ATENDIMENTO
LEFT OUTER JOIN DBAMV.ITREG_FAT IRF ON IRF.CD_PRO_FAT = P.CD_PRO_FAT AND IRF.CD_REG_FAT = RF.CD_REG_FAT
WHERE eP.cd_estoque IN (select E.CD_ESTOQUE from dbamv.estoque e WHERE E.tp_estoque = 'D' AND E.CD_MULTI_EMPRESA = 1)
AND EP.DT_ENTRADA  between '01/03/2025' and '31/03/2025'  -- Informar o periodo desejado



Tabela TMP_PRODUTO_SALDOMENSAL.

--Verificar o perido ja gerado

SELECT cd_ano,cd_mes, count(*) qtde
FROM DBAMV.TMP_PRODUTO_SALDOMENSAL C 
where to_number(c.cd_ano) >= '2025'
group by cd_ano,cd_mes
order by 1,2 

--dELETe FROM DBAMV.TMP_PRODUTO_SALDOMENSAL C WHERE C.CD_ANO = 2023 and c.cd_mes in (02)

--- ATUALIZADO EM 06/03/2023 - Dados FEV/2023 
--- ATUALIZADO EM 10/04/2023 - Dados MAR/2023 

-- ATUALIZAR TABELA TMP_PRODUTO_SALDOMENSAL

INSERT INTO DBAMV.TMP_PRODUTO_SALDOMENSAL
       (CD_PRODUTO,CD_ESTOQUE,CD_ANO,CD_MES,QT_ESTOQUE_INICIAL,VL_ESTOQUE_INICIAL,
       QT_ESTOQUE_FINAL,VL_ESTOQUE_FINAL,QT_ENTRADA,VL_ENTRADA,QT_SAIDA_SETOR,VL_SAIDA_SETOR,
       QT_SAIDA_PACIENTE,VL_SAIDA_PACIENTE,QT_DEVOLUCAO_SETOR,VL_DEVOLUCAO_SETOR,QT_DEVOLUCAO_PACIENTE,
       VL_DEVOLUCAO_PACIENTE,SN_IMPORTADO_MGES_FCCT)

select CD_PRODUTO,  
       CD_ESTOQUE,
       CD_ANO,
       CD_MES,
       QT_ESTOQUE_INICIAL,
       VL_ESTOQUE_INICIAL,
       QT_ESTOQUE_FINAL,
       VL_ESTOQUE_FINAL,
       QT_ENTRADA,  
       VL_ENTRADA,
       QT_SAIDA_SETOR,
       VL_SAIDA_SETOR,
       QT_SAIDA_PACIENTE,
       VL_SAIDA_PACIENTE,
       QT_DEVOLUCAO_SETOR,
       VL_DEVOLUCAO_SETOR,
       QT_DEVOLUCAO_PACIENTE,
       VL_DEVOLUCAO_PACIENTE,
       SN_IMPORTADO_MGES_FCCT
FROM DBAMV.C_CONEST C WHERE C.CD_ANO = 2025 and c.cd_mes in (3)  -- Alterar para o Mes desejado
