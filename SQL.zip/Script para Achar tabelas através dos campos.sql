SELECT OWNER, TABLE_NAME, COLUMN_NAME 
FROM ALL_TAB_COLUMNS 
WHERE COLUMN_NAME = 'TP_RECEBIMENTO'
AND OWNER = 'DBAMV';

/**no sqlTools vc DBAMV.RECCON_REC selecionando a tabela e teclado ctrl+F12 voc� ir� abrir a tabela e poder� ver os coment�rios dos campos, alguns ter�o l� a descri��o./
