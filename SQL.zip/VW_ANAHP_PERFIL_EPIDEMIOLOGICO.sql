--CREATE OR REPLACE VIEW ENKYO.VW_ANAHP_PERFIL_EPIDEMIOLOGICO AS
SELECT SB2.cd_paciente PRONTUARIO,
       SB2.cd_atendimento ATENDIMENTO,
       TO_CHAR(SB2.DT_NASCIMENTO, 'DD/MM/RRRR') NASCIMENTO,
       SB2.TP_SEXO SEXO,
       SB2.VL_PESO,
       SB2.VL_ALTURA,
       SB2.NR_CEP CEP,
       SB2.NM_BAIRRO BAIRRO,
       SB2.nm_cidade MUNICIPIO,
       SB2.cd_uf ESTADO,
       SB2.nr_registro_operadora_ans ANS_FONTE_PAGADORA,
       SB2.ds_ori_ate LOCAL_ATENDIMENTO,
       TO_CHAR(SB2.dt_atendimento, 'DD/MM/RRRR') DATA_INTERNACAO,
       TO_CHAR(SB2.dt_alta, 'DD/MM/RRRR') DATA_SAIDA,
       SB2.cd_cid_PRINCIPAL DIAGNOSTICO_PRINCIPAL,
       SB2.cd_cid_SECUNDARIO1 Diagnostico_secundario_1,
       SB2.CD_CID_SECUNDARIO2 Diagnostico_secundario_2,
       SB2.CD_PROCEDIMENTO Codigo_Procedimento_1,
       SB2.DATA_PROCEDIMENTO1 "DT_PROCEDIMENTO_1",
       SB2.COD_PROCEDIMENTO2 Codigo_Procedimento_2,
       SB2.DATA_PROCEDIMENTO2 "DT_PROCEDIMENTO_2",
       SB2.ds_mot_alt Tipo_Alta,
       SB2.Data_Admissao_UTI Admissao_UTI,
       SB2.Saida_UTI Alta_UTI,
       SB2.Passagens_UTI Passagens_pela_UTI,
       SB2.VENTILACAO_MECANICA,
       SB2.DIAS_VENTILACAO_MECANICA,
       SB2.VL_PESO_RN "Peso RN",
       SB2.Origem_paciente Origem_paciente,
       SB2.Valor_faturado_fechado "Valor Faturado"
  FROM (
         
         SELECT SB1.cd_paciente,
                 SB1.cd_atendimento,
                 SB1.nr_cpf,
                 SB1.dt_nascimento,
                 SB1.tp_sexo,
                 SB1.nr_cep,
                 SB1.nm_bairro,
                 SB1.nm_cidade,
                 SB1.cd_uf,
                 SB1.nm_convenio,
                 SB1.nr_registro_operadora_ans,
                 SB1.ds_ori_ate,
                 SB1.ds_codigo_conselho,
                 SB1.dt_atendimento,
                 SB1.dt_alta,
                 SB1.cd_cid_principal,
                 SB1.cd_cid_secundario1,
                 SB1.cd_cid_secundario2,
                 SB1.cd_procedimento,
                 SB1.procedimento,
                 SB1.data_procedimento1,
                 SB1.cod_procedimento2,
                 SB1.desc_procedimento2,
                 SB1.data_procedimento2,
                 SB1.vl_peso,
                 SB1.vl_altura,
                 SB1.vl_peso_rn,
                 SB1.ds_mot_alt,
                 SB1.data_admissao_uti,
                 (CASE
                   WHEN SB1.data_admissao_uti IS NOT NULL THEN
                    NVL(SB1.saida_uti, SB1.DT_ALTA)
                   ELSE
                    NULL
                 END) saida_uti,
                 SB1.passagens_uti,
                 (CASE
                   WHEN SB1.data_admissao_uti IS NOT NULL THEN
                    TO_DATE(NVL(SB1.saida_uti, SB1.DT_ALTA)) -
                    TO_DATE(SB1.data_admissao_uti)
                   ELSE
                    NULL
                 END) dias_uti,
                 (CASE
                   WHEN SB1.data_admissao_uti IS NOT NULL THEN
                    DBAMV.FNC_HNB_OBTER_DIFERENCA_HORAS(TO_DATE(SB1.data_admissao_uti),
                                                        TO_DATE(NVL(SB1.saida_uti,
                                                                    SB1.DT_ALTA)))
                   ELSE
                    NULL
                 END) horas_uti,
                 SB1.ventilacao_mecanica,
                 SB1.dias_ventilacao_mecanica,
                 SB1.origem_paciente,
                 SB1.valor_faturado_fechado,
                 SB1.valor_faturado_aberto,
                 SB1.ano_base,
                 SYSDATE dt_carga
           FROM (SELECT atd.cd_paciente              cd_paciente,
                          atd.cd_atendimento           cd_atendimento,
                          PAC.NR_CPF                   nr_cpf,
                          pac.DT_NASCIMENTO            dt_nascimento,
                          pac.TP_SEXO                  tp_sexo,
                          pac.NR_CEP                   nr_cep,
                          pac.NM_BAIRRO                nm_bairro,
                          cit.nm_cidade                nm_cidade,
                          cit.cd_uf                    cd_uf,
                          cv.nm_convenio               nm_convenio,
                          cv.nr_registro_operadora_ans nr_registro_operadora_ans,
                          ori.ds_ori_ate               ds_ori_ate,
                          pre.ds_codigo_conselho       ds_codigo_conselho,
                          atd.dt_atendimento           dt_atendimento,
                          atd.dt_alta                  dt_alta,
                          atd.cd_cid                   cd_cid_principal, ----- CID principal
                          
                          -------CID  SECUNDARIO 1 ------------------------
                          (select min(ca1.cd_cid)
                             from cid_ate ca1
                            where cd_atendimento = atd.cd_atendimento
                              AND EXISTS
                            (select cid1.tp_sexo
                                     from cid cid1
                                    Where (cid1.cd_cid = CA1.cd_cid AND
                                          cid1.tp_sexo = 'A')
                                       or (cid1.cd_cid = CA1.cd_cid and
                                          cid1.tp_sexo = pac.tp_sexo))) cd_cid_secundario1,
                          
                          -------CID  SECUNDARIO 2 ------------------------
                          (select min(ca2.cd_cid)
                             from cid_ate ca2
                            where cd_atendimento = atd.cd_atendimento
                              AND (ca2.cd_cid) >
                                  (SELECT min(ca3.cd_cid)
                                     from cid_ate ca3
                                    where cd_atendimento = atd.cd_atendimento)
                              AND EXISTS
                            (select cid2.tp_sexo
                                     from cid cid2
                                    where (cid2.cd_cid = CA2.cd_cid AND
                                          cid2.tp_sexo = 'A')
                                       or (cid2.cd_cid = CA2.cd_cid and
                                          cid2.tp_sexo = pac.tp_sexo))) cd_cid_secundario2,
                          
                          ---------------codigo procedimento principal
                          (select NVL((SELECT MAX(TUSS.CD_TUSS)
                                        FROM TUSS
                                       WHERE TUSS.CD_PRO_FAT = PF.CD_PRO_FAT),
                                      rf.CD_PRO_FAT_REALIZADO)
                             from reg_fat rf, pro_fat pf, GRU_PRO GP
                            where (atd.cd_atendimento = rf.cd_atendimento and
                                  rf.CD_PRO_FAT_REALIZADO = pf.cd_pro_fat and
                                  (pf.cd_gru_PRO = GP.CD_GRU_PRO) --AND GP.CD_GRU_FAT = 7)
                                  and rownum = 1)) cd_procedimento,
                          
                          ---------------descri��o procedimento principal
                          (select NVL((SELECT MAX(TUSS.DS_TUSS)
                                        FROM TUSS
                                       WHERE TUSS.CD_PRO_FAT = PF.CD_PRO_FAT),
                                      PF.DS_PRO_FAT)
                             from reg_fat rf, pro_fat pf
                           --      , GRU_PRO GP
                            where (atd.cd_atendimento = rf.cd_atendimento and
                                  rf.CD_PRO_FAT_REALIZADO = pf.cd_pro_fat
                                  --       and (pf.cd_gru_PRO = GP.CD_GRU_PRO  ) --AND GP.CD_GRU_FAT = 7)
                                  and rownum = 1)) procedimento,
                          
                          --------------------------DATA DO PROCEDIMENTO PRINCIPAL SE FOR CIRURGICO ---------------
                          (select ac.dt_inicio_cirurgia
                             from reg_fat rf
                           --      inner join pro_fat pf    on   rf.CD_PRO_FAT_REALIZADO = pf.cd_pro_fat
                           --                       and  (pf.DS_UNIDADE like '%ATO%' and pf.DS_pro_fat not like '%VISITA%')
                            inner join AVISO_CIRURGIA AC
                               ON AC.CD_ATENDIMENTO = rf.cd_atendimento
                            INNER JOIN CIRURGIA_AVISO CA
                               on ac.cd_aviso_cirurgia = ca.cd_aviso_cirurgia
                            inner join cirurgia ci
                               on ca.cd_cirurgia = ci.cd_cirurgia
                            where atd.cd_atendimento = rf.cd_atendimento
                              and ac.tp_situacao = 'R' ---- cirurgia realizada
                              and ca.sn_principal = 'S' ---- cirurgia principal
                              and ci.cd_pro_fat = rf.cd_pro_fat_realizado
                              AND ROWNUM = 1) data_procedimento1,
                          
                          '' cod_procedimento2,
                          '' desc_procedimento2,
                          '' data_procedimento2,
                          (CASE
                            WHEN NOT EXISTS
                             (SELECT 1
                                    FROM DBAMV.RECEM_NASCIDO RN
                                   WHERE RN.CD_ATENDIMENTO = ATD.CD_ATENDIMENTO) THEN
                             (CASE
                               WHEN DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATD.CD_ATENDIMENTO,
                                                                    21,
                                                                    'U') IS NOT NULL AND
                                    DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATD.CD_ATENDIMENTO,
                                                                    21,
                                                                    'U') NOT LIKE
                                    '%,%' THEN
                                (CASE
                                  WHEN LENGTH(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATD.CD_ATENDIMENTO,
                                                                              21,
                                                                              'U')) > 3 THEN
                                   ROUND(TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATD.CD_ATENDIMENTO,
                                                                                   21,
                                                                                   'U')) / 1000)
                                  ELSE
                                   TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATD.CD_ATENDIMENTO,
                                                                             21,
                                                                             'U'))
                                END)
                               ELSE
                                TRUNC(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATD.CD_ATENDIMENTO,
                                                                      21,
                                                                      'U'))
                             END)
                            ELSE
                             NULL
                          END) VL_PESO,
                          (CASE
                            WHEN NOT EXISTS
                             (SELECT 1
                                    FROM DBAMV.RECEM_NASCIDO RN
                                   WHERE RN.CD_ATENDIMENTO = ATD.CD_ATENDIMENTO) THEN
                             RPAD(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATD.CD_ATENDIMENTO,
                                                                  22,
                                                                  'U'),
                                  4,
                                  0)
                            ELSE
                             NULL
                          END) VL_ALTURA,
                          
                          (CASE
                            WHEN EXISTS
                             (SELECT 1
                                    FROM DBAMV.RECEM_NASCIDO RN
                                   WHERE RN.CD_ATENDIMENTO = ATD.CD_ATENDIMENTO) THEN
                             (SELECT CASE
                                       WHEN RN.VL_PESO NOT LIKE '%,%' THEN
                                        ROUND(RN.VL_PESO / 1000)
                                       ELSE
                                        RN.VL_PESO
                                     END
                                FROM DBAMV.RECEM_NASCIDO RN
                               WHERE RN.CD_ATENDIMENTO = ATD.CD_ATENDIMENTO)
                            ELSE
                             NULL
                          END) VL_PESO_RN,
                          /*(select
                              RN.vl_peso
                              from   recem_nascido rn
                              inner join atendime at1     on at1.cd_atendimento = rn.cd_atendimento
                              where
                              (
                                (at1.cd_atendimento_pai is not null AND ATD.CD_ATENDIMENTO_PAI IS NULL)
                              and  at1.cd_paciente = ATD.cd_paciente
                              and      AT1.tp_atendimento = 'I'
                              and      at1.CD_multi_empresa = 1
                              and
                                     trunc (
                                        round   (
                                               (
                                           ( to_number(to_date(SUBSTR(TO_CHAR (ATD.dt_atendimento, 'DD/MM/YYYY'),1,10) ||
                                                              SUBSTR(TO_CHAR (ATD.HR_atendimento, 'HH24:mi'),1,5) , 'DD/MM/YYYY HH24:MI')
                                                        -
                                                        to_date(SUBSTR(TO_CHAR (at1.HR_ALTA, 'DD/MM/YYYY'),1,10) ||
                                                SUBSTR(TO_CHAR (at1.HR_ALTA, 'HH24:mi'),1,5) , 'DD/MM/YYYY HH24:MI')
                                                        )
                                             ) * 1440) / 60 ,2), 0)       --) ,2), 0) / count(*),2), 0)   --- Soma das horas inteiras
                                     < 24  --- PARA RN INTERNADO AP�S VINCULA��O COM A M�E
                              AND  AT1.CD_ATENDIMENTO <> ATD.CD_ATENDIMENTO
                              )
                              OR
                              (
                                at1.cd_atendimento_pai is not null
                              and  at1.cd_paciente = ATD.cd_paciente
                              and      AT1.tp_atendimento = 'I'
                              and      at1.CD_multi_empresa = 1
                              AND  AT1.CD_ATENDIMENTO  =  ATD.CD_ATENDIMENTO
                              )
                          ) VL_PESO,*/ ------  PESO RN INTERNADO  AO NASCER
                          
                          motalta.ds_mot_alt ds_mot_alt,
                          
                          -----------------admiss�o UTI
                          (Select MIN(TO_DATE(TO_CHAR(mi.dt_mov_int, 'DD/MM/RRRR') ||
                                              TO_CHAR(MI.HR_MOV_INT, 'HH24:MI:SS'),
                                              'DD/MM/RRRR HH24:MI:SS'))
                             From mov_int mi
                            Inner join Leito lt
                               on mi.cd_leito = lt.cd_leito
                            Where mi.cd_atendimento = atd.cd_atendimento
                              And mi.cd_leito = lt.cd_leito
                              And lt.CD_TIP_ACOM in (3, 4, 5) -- 3=UTIadulto,  4=UTIsemi-Neo,  5=UTI-Neo
                              and (mi.cd_motivo_transf_leito <> 25 or
                                  mi.cd_motivo_transf_leito is null)
                           
                           ) data_admissao_uti,
                          -----------------sa�da UTI
                          (Select MAX(TO_DATE(TO_CHAR(mi.Dt_Lib_Mov, 'DD/MM/RRRR') ||
                                              TO_CHAR(MI.HR_LIB_MOV, 'HH24:MI:SS'),
                                              'DD/MM/RRRR HH24:MI:SS'))
                             From mov_int mi
                            Inner join Leito lt
                               on mi.cd_leito = lt.cd_leito
                            Where mi.cd_atendimento = atd.cd_atendimento
                              And mi.cd_leito = lt.cd_leito
                              And lt.CD_TIP_ACOM IN (3, 4, 5) -- 3=UTIadulto,  4=UTIsemi-Neo,  5=UTI-Neo
                              and (mi.cd_motivo_transf_leito <> 25 or
                                  mi.cd_motivo_transf_leito is null)) saida_uti,
                          (select count(*)
                             from mov_int mi
                            inner join leito lt1
                               on mi.cd_leito = lt1.cd_leito
                             left outer join leito lt2
                               on mi.cd_leito_anterior = lt2.cd_leito
                            where mi.cd_atendimento = ATD.cd_atendimento
                              and lt1.cd_tip_acom in (3, 4, 5)
                              and (mi.cd_motivo_transf_leito <> 25 or
                                  mi.cd_motivo_transf_leito is null)
                              and (lt2.cd_tip_acom not in (3, 4, 5) or
                                  mi.cd_leito_anterior is null)) passagens_uti, --- numero de passagens pela UTI
                          0 dias_uti, --- DIAS NA UTI
                          0 horas_uti, --- HORAS NA UTI
                          
                          (CASE
                            WHEN (SELECT COUNT(1)
                                    FROM PRE_MED PRE
                                    JOIN ITPRE_MED IPRE
                                      ON IPRE.CD_PRE_MED = PRE.CD_PRE_MED
                                    JOIN TIP_PRESC TP
                                      ON TP.CD_TIP_PRESC = IPRE.CD_TIP_PRESC
                                   WHERE TP.SN_ATIVO = 'S'
                                     AND TP.CD_TIP_PRESC IN
                                         (29290, /*VENTILACAO MECANICA - CPAP*/
                                          29291, /*VENTILACAO MECANICA - INTERMITENTE*/
                                          29293) /*VENTILACAO NAO INVASIVA*/
                                     AND PRE.CD_ATENDIMENTO = ATD.CD_ATENDIMENTO) >= 1 THEN
                             'S'
                            ELSE
                             'N'
                          END) ventilacao_mecanica, -- VENTILA�AO MECANICA (S/N)
                          '' dias_ventilacao_mecanica, -- DIAS DE USO DE VENTILA��O MECANICA
                          '' origem_paciente, ---Origem do  paciente --->> n�o tem informa��o
                          
                          ---------------CONTA FECHADA
                          (select sum(FAT.VL_TOTAL_CONTA)
                             from reg_fat FAT
                            where FAT.cd_atendimento = ATD.CD_ATENDIMENTO
                              AND SN_FECHADA = 'S') valor_faturado_fechado,
                          ---------------CONTA ABERTA
                          (select sum(FAT.VL_TOTAL_CONTA)
                             from reg_fat FAT
                            where FAT.cd_atendimento = ATD.CD_ATENDIMENTO
                              AND SN_FECHADA = 'N') valor_faturado_aberto,
                          TO_CHAR(ATD.DT_ALTA, 'RRRR') ANO_BASE
                   
                   ----- identifica RN vinculado INATIVADO PARA 2017 -------------------------------------
                   --  (select 'S'  from recem_nascido RN1
                   --     inner join atendime at2     on at2.cd_atendimento = rn1.cd_atendimento
                   --        where
                   --          at2.cd_atendimento_pai is not null
                   --      and  at2.cd_paciente = ATD.cd_paciente
                   --      and      AT2.tp_atendimento = 'I'
                   --      and      at2.CD_multi_empresa = 1
                   --      AND  AT2.CD_ATENDIMENTO  =  ATD.CD_ATENDIMENTO
                   --  )
                   
                     from atendime atd
                     left outer join paciente pac
                       on atd.cd_paciente = pac.cd_paciente
                     left outer join cidade cit
                       on pac.CD_CIDADE = cit.cd_cidade
                     left outer join convenio cv
                       on atd.cd_convenio = cv.cd_convenio
                     left outer join ori_ate ori
                       on atd.CD_ORI_ATE = ori.cd_ori_ate
                     left outer join prestador pre
                       on atd.cd_prestador = pre.CD_PRESTADOR
                     left outer join mot_alt motalta
                       on atd.cd_mot_alt = motalta.cd_mot_alt
                    INNER JOIN CID CID
                       ON atd.cd_cid = CID.CD_CID ---
                    where atd.CD_MULTI_EMPRESA = 1
                      and atd.TP_ATENDIMENTO = 'I'
                      AND to_date(ATD.DT_ALTA, 'dd/mm/rrrr') >= '01/01/2025'
                      AND to_date(ATD.DT_ALTA, 'dd/mm/rrrr') <= '31/12/2025'
                         --AND ATD.CD_ATENDIMENTO = 9787590
                         ----- (n�o inclui Rn's vinculados)  ---   executado para 2012 e 2013
                       ---    AND     atd.CD_ATENDIMENTO_PAI IS NULL
                       
                       ----- ( checa sexo paciente /sexo CID principal)
                    AND (pac.TP_SEXO = CID.TP_SEXO or cid.TP_SEXO = 'A')
                       ----- ( checa sexo paciente / sexo procedimento realizado principal
                    and (exists
                         (select *
                            from reg_fat rf, pro_fat pf, GRU_PRO GP
                           where (atd.cd_atendimento = rf.cd_atendimento and
                                 rf.CD_PRO_FAT_REALIZADO = pf.cd_pro_fat and
                                 (pf.cd_gru_PRO = GP.CD_GRU_PRO) --AND GP.CD_GRU_FAT = 7)   ---- 7 = HONORARIOS
                                 and rownum = 1 and
                                 (pac.TP_SEXO = pf.TP_SEXO or pf.TP_SEXO = 'A'))) or
                         (atd.cd_atendimento_pai is NOT NULL))
                    and not exists
                  (select *
                           from --recem_nascido rn
                                atendime atd3 --on at3.cd_atendimento = rn.cd_atendimento
                          where ATD3.CD_ATENDIMENTO_PAI IS NULL
                            and atd3.cd_paciente = ATD.cd_paciente
                            and ATd3.tp_atendimento = 'I'
                            and atd3.CD_multi_empresa = 1
                            and trunc(round(((to_number(to_date(SUBSTR(TO_CHAR(ATD3.dt_atendimento,
                                                                               'DD/MM/YYYY'),
                                                                       1,
                                                                       10) ||
                                                                SUBSTR(TO_CHAR(ATD3.HR_atendimento,
                                                                               'HH24:mi'),
                                                                       1,
                                                                       5),
                                                                'DD/MM/YYYY HH24:MI') -
                                                        to_date(SUBSTR(TO_CHAR(atd.HR_ALTA,
                                                                               'DD/MM/YYYY'),
                                                                       1,
                                                                       10) ||
                                                                SUBSTR(TO_CHAR(atd.HR_ALTA,
                                                                               'HH24:mi'),
                                                                       1,
                                                                       5),
                                                                'DD/MM/YYYY HH24:MI'))) * 1440) / 60,
                                            2),
                                      0) --- Soma das horas inteiras
                                < 24 --- PARA RN INTERNADO AP�S VINCULA��O COM A M�E
                            AND ATd3.CD_ATENDIMENTO <> ATD.CD_ATENDIMENTO
                            and atd.cd_atendimento_pai is not null)) SB1) SB2;
