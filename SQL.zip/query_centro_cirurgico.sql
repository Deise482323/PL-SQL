select ac.dt_inicio_age_cir, ac.dt_final_age_cir, ac.cd_sal_cir
  from age_cir ac
 where ac.cd_sal_cir = 2
   and to_date(ac.dt_inicio_age_cir, 'dd/mm/rrrr') between
       to_date('01/06/2023', 'dd/mm/rrrr') and
       to_date('30/07/2023', 'dd/mm/rrrr')


select ac.dt_inicio_age_cir, ac.dt_final_age_cir, ac.cd_sal_cir
  from age_cir ac
 where ac.cd_sal_cir = 2
   and to_date(ac.dt_inicio_age_cir, 'dd/mm/rrrr') =
       to_date('21/07/2023', 'dd/mm/rrrr') 
