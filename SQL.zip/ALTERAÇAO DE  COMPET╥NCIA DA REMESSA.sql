---------------------------------ALTERAR COMPET�NCIA REMESSA------------------------------------------
----1� LOCALIZAR CD_FATURA -----
SELECT A.CD_REMESSA,
       A.CD_FATURA,
       A.DT_ENTREGA_DA_FATURA,
       A.DT_PREVISTA_PARA_PGTO
  FROM REMESSA_FATURA A
WHERE A.CD_REMESSA IN (710773);
-- 2� CONSULTAR O CD_FATURA EM QUAL COMPETENCIA SE ENCONTRA -----
SELECT B.CD_CONVENIO, B.DS_FATURA, B.DT_COMPETENCIA, B.CD_MULTI_EMPRESA
  FROM FATURA B
WHERE B.CD_FATURA IN (23922);
-- 3� LOCALIZAR  CD_FATURA QUE CONSTA NA COMPETENCIA SOLICITADA -----
SELECT *
  FROM FATURA B1
WHERE B1.CD_CONVENIO = 125
   AND B1.CD_MULTI_EMPRESA = 1
   AND to_date (B1.DT_COMPETENCIA , 'dd/mm/rrrr') = to_date('01/07/2025', 'dd/mm/rrrr');
 
-- 4� ALTERAR PARA O CD_FATURA DA COMPETENCIA SOLICITADA -----
UPDATE REMESSA_FATURA C2
   SET C2.CD_FATURA = 25177
WHERE C2.CD_REMESSA IN (710773);
 
/*---------- ALTERAR DATA DE ENTREGA E PAGAMENTO DA REMESSA  -----------------
----- 1� LOCALIZAR DADOS -----
SELECT a.cd_remessa,
       A.CD_FATURA,
       A.DT_ENTREGA_DA_FATURA,
       A.DT_PREVISTA_PARA_PGTO ---
  FROM REMESSA_FATURA A
WHERE A.CD_REMESSA IN (521178);
------ 2� ALTERAR DADOS -------
UPDATE REMESSA_FATURA A
   SET A.DT_ENTREGA_DA_FATURA  = '10/10/2022',
       A.DT_PREVISTA_PARA_PGTO = '21/11/2022'
WHERE A.CD_REMESSA IN (521178);
 
------- CORRIGIR DA DATA VENCIMENTO  NA ITCON_REC ( CONTA A RECEBER ) -------
----- 1� LOCALIZAR DADOS -----
select rowid, icr.*
  from dbamv.itcon_rec icr
where icr.cd_con_rec in
       (select distinct (cr.cd_con_rec) --,cr.cd_nota_fiscal,cr.dt_emissao 
          from dbamv.con_rec cr
         inner join dbamv.itfat_nota_fiscal ifnf
            on ifnf.cd_nota_fiscal = cr.cd_nota_fiscal
         where ifnf.cd_remessa in (521178));
------ 2� ALTERAR DADOS -------
Update dbamv.itcon_rec icr
   set icr.dt_prevista_recebimento = '11/07/2022',
       icr.dt_vencimento           = '11/07/2022'
where icr.cd_con_rec in
       (select distinct (cr.cd_con_rec) --,cr.cd_nota_fiscal,cr.dt_emissao 
          from dbamv.con_rec cr
         inner join dbamv.itfat_nota_fiscal ifnf
            on ifnf.cd_nota_fiscal = cr.cd_nota_fiscal
         where ifnf.cd_remessa in (521178));*/
