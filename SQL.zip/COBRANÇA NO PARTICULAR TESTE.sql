SELECT DISTINCT  ME.CD_MULTI_EMPRESA,
                ME.DS_MULTI_EMPRESA,
                P.NR_CPF,
                P.NM_PACIENTE DEVEDOR,
                P.DS_ENDERECO,
                C.NM_CIDADE,
                UF.NM_UF,
                P.NR_CEP,
                P.NR_DDD_FONE || P.NR_FONE FONE,
                P.NR_DDD_CELULAR || P.NR_CELULAR CELULAR,
                P.EMAIL,
                A.CD_ATENDIMENTO,
                ITC.DT_VENCIMENTO,
                CR.CD_CON_REC,
                CR.VL_PREVISTO SALDO,
                ITC.VL_DUPLICATA VALOR_CONTA,
                RRC.VL_RECEBIDO VALOR_RECEBIDO,
                 (ITC.VL_DUPLICATA - NVL ( ITC.VL_SOMA_RECEBIDO, 0)) SALDO_DEVEDOR,
                DECODE(ICR.TP_QUITACAO,
                       'Q',
                       'QUITADA',
                       'C',
                       'COMPROMETIDA',
                       'P',
                       'PARCIALMENTE RECEBIDA') SITUACAO_CONTA,
                A.DT_ATENDIMENTO,
                A.DT_ALTA,
                NVL (TR.DS_TIP_RES,M.DS_MOT_ALT),
                
                DECODE(A.TP_ATENDIMENTO,
                       'I',
                       'INTERNACAO',
                       'A',
                       'AMBULATORIO',
                       'E',
                       'EXTERNO',
                       'U',
                       'URGENCIA') TIPO_ATENDIMENTO,
                CO.NM_CONVENIO,
                RRC.DT_RECEBIMENTO,
               NVL (R.NM_RESPONSAVEL, RPS.NM_RESPONSAVEL)
  FROM CON_REC CR
 INNER JOIN ITCON_REC ITC
    ON ITC.CD_CON_REC = CR.CD_CON_REC
 LEFT JOIN RECCON_REC RRC
    ON RRC.CD_ITCON_REC = ITC.CD_ITCON_REC
 INNER JOIN ATENDIME A
    ON A.CD_ATENDIMENTO = CR.CD_ATENDIMENTO
   LEFT JOIN MOT_ALT M
    ON M.CD_MOT_ALT = A.CD_MOT_ALT
    LEFT JOIN TIP_RES TR
    ON TR.CD_TIP_RES = A.CD_TIP_RES
 INNER JOIN MULTI_EMPRESAS ME
    ON ME.CD_MULTI_EMPRESA = CR.CD_MULTI_EMPRESA
 INNER JOIN PACIENTE P
    ON P.CD_PACIENTE = A.CD_PACIENTE
 INNER JOIN CIDADE C
    ON P.CD_CIDADE = C.CD_CIDADE
 INNER JOIN UF
    ON UF.CD_UF = C.CD_UF
 INNER JOIN CONVENIO CO
    ON CO.CD_CONVENIO = A.CD_CONVENIO
 INNER JOIN DBAMV.ITCON_REC ICR
    ON ICR.CD_CON_REC = CR.CD_CON_REC
 LEFT JOIN RESPONSAVEL R
    ON R.CD_RESPOSAVEL = RRC.CD_RESPOSAVEL 
    LEFT JOIN RESPONSA RPS
    ON RPS.CD_ATENDIMENTO = A.CD_ATENDIMENTO

WHERE A.CD_ATENDIMENTO = 10025968


AND ME.CD_MULTI_EMPRESA IN (1,2) 

GROUP BY ME.CD_MULTI_EMPRESA,
          ME.DS_MULTI_EMPRESA,
          P.NR_CPF,
          P.NM_PACIENTE,
          P.DS_ENDERECO,
          C.NM_CIDADE,
          UF.NM_UF,
          P.NR_CEP,
          P.NR_DDD_FONE,
          P.NR_FONE,
          P.NR_DDD_CELULAR,
          P.NR_CELULAR,
          P.EMAIL,
          A.CD_ATENDIMENTO,
          ITC.DT_VENCIMENTO,
           CR.CD_CON_REC,
          CR.VL_PREVISTO,
          ITC.VL_DUPLICATA,
          ITC.VL_SOMA_RECEBIDO,
          RRC.VL_RECEBIDO,
          ICR.TP_QUITACAO,
          A.DT_ATENDIMENTO,
          A.DT_ALTA,
          M.DS_MOT_ALT,
          TR.DS_TIP_RES,
          A.TP_ATENDIMENTO,
          CO.NM_CONVENIO,
          RRC.DT_RECEBIMENTO,
          R.NM_RESPONSAVEL,
          RPS.NM_RESPONSAVEL
