create or replace view vdic_hnb_prest_enf as
select
cd_prestador,
cracha,
conselho,
nome,
cpf,
setor,
turno,
cargo,
chefe,
dt_nascimento,
dt_admissao,
--case when tp_situacao = 'I' then dt_inativacao else null  end dt_inativacao, Quando se baseia pela data de inativac?o
dt_inativacao,
case when dt_inativacao is null then 'N' else 'S' end Sn_Desligado,
--dt_inativacao,
email,
replace(string_agg(/*chr(42)||chr(160)||*/decode(cd_tip_comun ,'3','Celular: ','2','Residencia: ')||fone||''||chr(10)),',','') fone,
sn_foto,
cd_usuario
from
(
select
p.tp_situacao,
p.cd_prestador cd_prestador,
p.cd_identificacao cracha,
p.ds_codigo_conselho conselho,
p.nr_cpf_cgc cpf,
p.nm_prestador Nome,
      (select IP.DS_IT_PREFERENCIA from dbamv.preferencia p
         inner join dbamv.it_preferencia ip on ip.cd_preferencia = p.cd_preferencia
         inner join dbamv.prestador_preferencia pp on pp.cd_it_preferencia = ip.cd_it_preferencia
         where pp.cd_prestador = p.cd_prestador and p.cd_preferencia = 2
       ) setor ,
(select IP.DS_IT_PREFERENCIA from dbamv.preferencia p
         inner join dbamv.it_preferencia ip on ip.cd_preferencia = p.cd_preferencia
         inner join dbamv.prestador_preferencia pp on pp.cd_it_preferencia = ip.cd_it_preferencia
         where pp.cd_prestador = p.cd_prestador and p.cd_preferencia = 1
) turno,

         (select IP.DS_IT_PREFERENCIA from dbamv.preferencia p
         inner join dbamv.it_preferencia ip on ip.cd_preferencia = p.cd_preferencia
         inner join dbamv.prestador_preferencia pp on pp.cd_it_preferencia = ip.cd_it_preferencia
         where pp.cd_prestador = p.cd_prestador and p.cd_preferencia = 3
) cargo ,
p1.nm_prestador chefe,
p.dt_nascimento,
LOWER (CASE WHEN ptc.DS_TIP_COMUN_PREST IS NULL THEN P.DS_EMAIL ELSE Ptc.DS_TIP_COMUN_PREST END) EMAIL,
pc.ds_tip_comun_presT Fone,
pc.cd_tip_comun,
p.dt_inicio_contrato Dt_admissao,
p.dt_final_contrato Dt_Inativacao,
--p.dt_inativacao dt_inativacao,
case when pf.cd_prestador = p.cd_prestador then 'S' else 'N' end sn_foto,
u.cd_usuario

from dbamv.prestador p
     left outer join dbamv.prestador_foto pf on pf.cd_prestador = p.cd_prestador
     left outer join dbamv.prestador p1 on p1.cd_prestador= p.cd_prestador_muitos
     left outer join dbamv.prestador_tip_comun ptc on ptc.cd_prestador = p.cd_prestador and ptc.cd_tip_comun = 7
     left outer join dbamv.prestador_tip_comun pc on pc.cd_prestador = p.cd_prestador and pc.cd_tip_comun in (2,3,10)
     left outer join dbasgu.usuarios u on u.cd_prestador = p.cd_prestador  or u.nm_usuario = p.nm_prestador
     where p.cd_tip_presta in (4,14,31,49) --Auxiliar de Enfermagem, Tecnico de Enfermagem, Enfermeiro e Escriturario
     --and p.cd_identificacao = 6160 --5237

     )--where cracha is not null

      group by
    cd_prestador,
    cracha,
    conselho,
    nome,
    setor,
    turno,
    cargo,
    chefe,
    dt_nascimento,
    email,
    dt_admissao,
    dt_inativacao,
    sn_foto,
    tp_situacao,
    cd_usuario,
    cpf
;
