SELECT ATE.CD_ORI_ATE,
       OA.DS_ORI_ATE,
       ES.DS_ESPECIALID,
       EL.NM_EXA_LAB,
      
       COUNT(IPL.CD_EXA_LAB) QTD_SOLICITADO,
       
       SUM(CASE
             WHEN EXISTS (select 1
                     from dbamv.amostra_exa_lab ael
                    inner join amostra am
                       on am.cd_amostra = ael.cd_amostra
                    where ael.cd_itped_lab = IPL.cd_itped_lab
                      and am.dt_coleta IS NOT NULL) OR EXISTS
              (SELECT 1
                     FROM DBAMV.RES_EXA RE
                    WHERE RE.CD_ITPED_LAB = IPL.cd_itped_lab
                      AND RE.CD_PED_LAB = PL.CD_PED_LAB) OR EXISTS
              (select 1
                     from dbamv.cultura c
                    where c.cd_ped_lab = IPL.cd_ped_lab
                      and c.cd_exa_lab = IPL.cd_exa_lab
                      and c.cd_itped_lab = IPL.cd_itped_lab) THEN
              '1'
             ELSE
              '0'
           END) QTD_EXECUTADO

  FROM ITPED_LAB IPL
 INNER JOIN PED_LAB PL
    ON PL.CD_PED_LAB = IPL.CD_PED_LAB
 INNER JOIN ATENDIME ATE
    ON ATE.CD_ATENDIMENTO = PL.CD_ATENDIMENTO
 INNER JOIN EXA_LAB EL
    ON EL.CD_EXA_LAB = IPL.CD_EXA_LAB
 INNER JOIN ORI_ATE OA
    ON OA.CD_ORI_ATE = ATE.CD_ORI_ATE
 INNER JOIN ESPECIALID ES
    ON ES.CD_ESPECIALID = ATE.CD_ESPECIALID

 WHERE PL.DT_PEDIDO BETWEEN TO_DATE('01/01/2023', 'DD/MM/YYYY') AND
       TO_DATE('30/06/2024', 'DD/MM/YYYY')
   AND OA.CD_ORI_ATE = 35

 GROUP BY ATE.CD_ORI_ATE, OA.DS_ORI_ATE, EL.NM_EXA_LAB,ES.DS_ESPECIALID
