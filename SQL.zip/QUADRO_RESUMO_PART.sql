SELECT COUNT(*) AS QTD_CONTAS_FECHADAS,
       
       ROUND(AVG(IRA.DT_FECHAMENTO - A.DT_ATENDIMENTO), 2) AS MEDIA_DIAS_FECHAMENTO,
       
       ROUND((SUM(CASE
                    WHEN (IRA.DT_FECHAMENTO - A.DT_ATENDIMENTO) <= 3 THEN
                     1
                    ELSE
                     0
                  END) / COUNT(*)) * 100,
             2) AS PERCENTUAL_ATE_3_DIAS,
       
       ROUND((SUM(CASE
                    WHEN (IRA.DT_FECHAMENTO - A.DT_ATENDIMENTO) BETWEEN 4 AND 10 THEN
                     1
                    ELSE
                     0
                  END) / COUNT(*)) * 100,
             2) AS PERCENTUAL_ENTRE_4_10_DIAS,
       
       ROUND((SUM(CASE
                    WHEN (IRA.DT_FECHAMENTO - A.DT_ATENDIMENTO) > 10 THEN
                     1
                    ELSE
                     0
                  END) / COUNT(*)) * 100,
             2) AS PERCENTUAL_ACIMA_10_DIAS

  FROM DBAMV.ATENDIME A
 INNER JOIN DBAMV.ITREG_AMB IRA
    ON IRA.CD_ATENDIMENTO = A.CD_ATENDIMENTO
 INNER JOIN DBAMV.REG_AMB RA
    ON RA.CD_REG_AMB = IRA.CD_REG_AMB
 WHERE IRA.DT_FECHAMENTO >= TO_DATE('17/06/2025', 'dd/mm/RRRR')
   AND IRA.DT_FECHAMENTO < TO_DATE('25/06/2025', 'dd/mm/RRRR')
   AND A.CD_MULTI_EMPRESA = 1
   AND RA.CD_CONVENIO IN (40, 148, 81, 82)
   AND A.TP_ATENDIMENTO IN ( 'E', 'U')
   AND IRA.SN_FECHADA = 'S'
   AND IRA.DT_FECHAMENTO IS NOT NULL
   --AND {V_VAR}
   AND (IRA.DT_FECHAMENTO - A.DT_ATENDIMENTO) >= 0
