SELECT DISTINCT A.DT_ATENDIMENTO AS DATA_ATEND,
                A.CD_ATENDIMENTO AS ATENDIMENTO,
                P.CD_PACIENTE AS SAME,
                P.NM_PACIENTE AS PACIENTE,
                IT.HR_AGENDA AS HORARIO_AGEN,
                PR.CD_PED_RX AS PEDIDO,
                ER.CD_EXA_RX AS COD_EXAME,
                ER.DS_EXA_RX AS DESC_EXAME,
                S.CD_SETOR AS SETOR,
                S.NM_SETOR,
                TO_CHAR((SELECT MIN(STP.DH_PROCESSO)
                          FROM SACR_TEMPO_PROCESSO STP
                         WHERE STP.CD_ATENDIMENTO = A.CD_ATENDIMENTO
                           AND STP.CD_TIPO_TEMPO_PROCESSO = 1),
                        'HH24:MI:SS') HR_SENHA_TOTEM,
                TO_CHAR((SELECT MIN(STP.DH_PROCESSO)
                          FROM SACR_TEMPO_PROCESSO STP
                         WHERE STP.CD_ATENDIMENTO = A.CD_ATENDIMENTO
                           AND STP.CD_TIPO_TEMPO_PROCESSO = 21),
                        'HH24:MI:SS') HR_INI_FICHA,
                TO_CHAR((SELECT MIN(STP.DH_PROCESSO)
                          FROM SACR_TEMPO_PROCESSO STP
                         WHERE STP.CD_ATENDIMENTO = A.CD_ATENDIMENTO
                           AND STP.CD_TIPO_TEMPO_PROCESSO = 22),
                        'HH24:MI:SS') HR_FIM_FICHA
                
                /*SUM((SELECT COUNT(DISTINCT A1.CD_ATENDIMENTO)
                      FROM ATENDIME A1
                     INNER JOIN PED_RX PR1
                        ON PR1.CD_ATENDIMENTO = A1.CD_ATENDIMENTO
                     INNER JOIN SETOR S1
                        ON S1.CD_SETOR = PR1.CD_SETOR
                     WHERE TO_DATE(A1.DT_ATENDIMENTO, 'DD/MM/RRRR') BETWEEN
                           TO_DATE('01/05/2024', 'DD/MM/RRRR') AND
                           TO_DATE('10/05/2024', 'DD/MM/RRRR')
                       AND A1.TP_ATENDIMENTO = 'E'
                       AND S1.CD_SETOR = 347
                       AND FS.CD_FILA_SENHA = 24)) AS QTD_ATEND_CARDIO,
                
                SUM((SELECT COUNT(DISTINCT A1.CD_ATENDIMENTO)
                      FROM ATENDIME A1
                     INNER JOIN PED_RX PR1
                        ON PR1.CD_ATENDIMENTO = A1.CD_ATENDIMENTO
                     INNER JOIN SETOR S1
                        ON S1.CD_SETOR = PR1.CD_SETOR
                     WHERE TO_DATE(A1.DT_ATENDIMENTO, 'DD/MM/RRRR') BETWEEN
                           TO_DATE('01/05/2024', 'DD/MM/RRRR') AND
                           TO_DATE('10/05/2024', 'DD/MM/RRRR')
                       AND A1.TP_ATENDIMENTO = 'E'
                       AND S1.CD_SETOR = 117
                       AND FS.CD_FILA_SENHA = 21)) AS QTD_ATEND_ULTRA,
                
                SUM((SELECT COUNT(DISTINCT A1.CD_ATENDIMENTO)
                      FROM ATENDIME A1
                     INNER JOIN PED_RX PR1
                        ON PR1.CD_ATENDIMENTO = A1.CD_ATENDIMENTO
                     INNER JOIN SETOR S1
                        ON S1.CD_SETOR = PR1.CD_SETOR
                     WHERE TO_DATE(A1.DT_ATENDIMENTO, 'DD/MM/RRRR') BETWEEN
                           TO_DATE('01/05/2024', 'DD/MM/RRRR') AND
                           TO_DATE('10/05/2024', 'DD/MM/RRRR')
                       AND A1.TP_ATENDIMENTO = 'E'
                       AND S1.CD_SETOR = 107
                       AND FS.CD_FILA_SENHA = 28)) AS QTD_ATEND_ENDOS
*/
  FROM ATENDIME A
 INNER JOIN PACIENTE P
    ON P.CD_PACIENTE = A.CD_PACIENTE
 INNER JOIN PED_RX PR
    ON PR.CD_ATENDIMENTO = A.CD_ATENDIMENTO
  LEFT JOIN IT_AGENDA_CENTRAL IT
    ON IT.CD_ATENDIMENTO = A.CD_ATENDIMENTO
 INNER JOIN SETOR S
    ON S.CD_SETOR = PR.CD_SETOR
 INNER JOIN SET_EXA SE
    ON SE.CD_SET_EXA = PR.CD_SET_EXA
 INNER JOIN ITPED_RX ITPR
    ON ITPR.CD_PED_RX = PR.CD_PED_RX
 INNER JOIN EXA_RX ER
    ON ER.CD_EXA_RX = ITPR.CD_EXA_RX
 INNER JOIN MULTI_EMPRESAS ME
    ON ME.CD_MULTI_EMPRESA = A.CD_MULTI_EMPRESA
 INNER JOIN FILA_SENHA FS
    ON FS.CD_MULTI_EMPRESA = ME.CD_MULTI_EMPRESA
 INNER JOIN SACR_TEMPO_PROCESSO STP
    ON STP.CD_ATENDIMENTO = A.CD_ATENDIMENTO
 INNER JOIN SACR_TIPO_TEMPO_PROCESSO STTP
    ON STTP.CD_TIPO_TEMPO_PROCESSO = STP.CD_TIPO_TEMPO_PROCESSO

 WHERE TO_DATE(A.DT_ATENDIMENTO, 'DD/MM/RRRR') BETWEEN
       TO_DATE('01/05/2023', 'DD/MM/RRRR') AND
       TO_DATE('30/04/2024', 'DD/MM/RRRR')
   AND A.TP_ATENDIMENTO = 'E'
   AND S.CD_SETOR IN (347, 117, 107)
   AND FS.CD_FILA_SENHA IN (21, 24, 28)

 GROUP BY A.DT_ATENDIMENTO,
          A.CD_ATENDIMENTO,
          P.CD_PACIENTE,
          P.NM_PACIENTE,
          IT.HR_AGENDA,
          PR.CD_PED_RX,
          ER.CD_EXA_RX,
          ER.DS_EXA_RX,
          S.CD_SETOR,
          S.NM_SETOR

 ORDER BY S.CD_SETOR;

-- 21 ULTRASSONOGRAFIA / 24 CARDIOLOGIA (CD) / 28 EXAMES AGENDADOS (ED)/ 29 MARCA��O DE EXAMES (ED)
-- 117 ULTRASSONOGRAFIA / 347 CARDIOLOGIA / 107 ENDOSCOPIA - SADT 6.o CD
