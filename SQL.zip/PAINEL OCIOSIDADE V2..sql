SELECT AC.CD_PRESTADOR || ' - ' || P.NM_PRESTADOR AS MEDICO,
       AC.CD_AGENDA_CENTRAL AS COD_AG,
       AC.DT_AGENDA AS DATA_AG,
       TO_CHAR(ESC.HR_INICIO, 'HH24:MI') AS HR_INI,
       TO_CHAR(ESC.HR_FIM, 'HH24:MI') AS HR_FIM,
       EP.DS_ESPECIALID AS ESPECIALIDADE,
       IA.CD_ITEM_AGENDAMENTO || ' - ' || IA.DS_ITEM_AGENDAMENTO AS ITEM_AG,
       ------------------------------------------------------------------------------------
       
       TO_CHAR(TRUNC((SELECT DISTINCT (COUNT(IAC1.CD_ITEM_AGENDAMENTO) *
                                      AC.QT_TEMPO_MEDIO / 24) *
                                      NVL(AC.QT_TEMPO_MEDIO, 0)
                        FROM DBAMV.IT_AGENDA_CENTRAL IAC1
                       WHERE IAC1.CD_AGENDA_CENTRAL = AC.CD_AGENDA_CENTRAL
                         AND IAC1.CD_ITEM_AGENDAMENTO =
                             O.CD_ITEM_AGENDAMENTO) / 60),
               'FM9900') || ':' ||
       TO_CHAR(MOD((SELECT DISTINCT (COUNT(IAC1.CD_ITEM_AGENDAMENTO) *
                                   AC.QT_TEMPO_MEDIO / 60) *
                                   NVL(AC.QT_TEMPO_MEDIO, 0)
                     FROM DBAMV.IT_AGENDA_CENTRAL IAC1
                    WHERE IAC1.CD_AGENDA_CENTRAL = AC.CD_AGENDA_CENTRAL
                      AND IAC1.CD_ITEM_AGENDAMENTO = O.CD_ITEM_AGENDAMENTO),
                   60),
               'FM00') AS HORAS_TRAB_ITEM,
       ---------------------------------------------------------------------------------------    
       LPAD(FLOOR((ESC.HR_FIM - ESC.HR_INICIO) * 24), 2, '0') || ':' ||
       LPAD(FLOOR(MOD((ESC.HR_FIM - ESC.HR_INICIO) * 24 * 60, 60)), 2, '0') || ':' ||
       LPAD(FLOOR(MOD((ESC.HR_FIM - ESC.HR_INICIO) * 24 * 60 * 60, 60)),
            2,
            '0') AS TOTAL_HRS_TRAB
-------------------------------------------------------------------------------------------------
  FROM DBAMV.AGENDA_CENTRAL AC
  JOIN DBAMV.IT_AGENDA_CENTRAL IAC
    ON AC.CD_AGENDA_CENTRAL = IAC.CD_AGENDA_CENTRAL
  JOIN AGENDA_CENTRAL_ITEM_AGENDA O --
    ON O.CD_AGENDA_CENTRAL = AC.CD_AGENDA_CENTRAL
  JOIN DBAMV.PRESTADOR P
    ON P.CD_PRESTADOR = AC.CD_PRESTADOR
  JOIN DBAMV.ESCALA_CENTRAL ESC
    ON ESC.CD_ESCALA_CENTRAL = AC.CD_ESCALA_CENTRAL
  JOIN DBAMV.ESP_MED E
    ON E.CD_PRESTADOR = AC.CD_PRESTADOR
   AND E.SN_ESPECIAL_PRINCIPAL = 'S'
  JOIN DBAMV.ESPECIALID EP
    ON EP.CD_ESPECIALID = E.CD_ESPECIALID
  JOIN DBAMV.ITEM_AGENDAMENTO IA
    ON IA.CD_ITEM_AGENDAMENTO = O.CD_ITEM_AGENDAMENTO
   AND IA.TP_ITEM = 'A'
  JOIN DBAMV.ITEM_AGENDAMENTO_PRESTADOR IAP
    ON IAP.CD_ITEM_AGENDAMENTO = IAC.CD_ITEM_AGENDAMENTO
 WHERE AC.CD_AGENDA_CENTRAL = 1594999

/*IAC.HR_AGENDA BETWEEN TO_DATE('01/02/2025', 'DD/MM/YYYY') AND
    TO_DATE('04/02/2025', 'DD/MM/RRRR')
    
AND AC.CD_PRESTADOR = 249
AND AC.TP_AGENDA = 'A'*/

 GROUP BY AC.CD_PRESTADOR,
          P.NM_PRESTADOR,
          AC.CD_AGENDA_CENTRAL,
          AC.DT_AGENDA,
          ESC.HR_INICIO,
          ESC.HR_FIM,
          EP.DS_ESPECIALID,
          IA.CD_ITEM_AGENDAMENTO,
          IA.DS_ITEM_AGENDAMENTO,
          AC.QT_TEMPO_MEDIO,
          O.CD_ITEM_AGENDAMENTO
 ORDER BY MEDICO, AC.DT_AGENDA, ESC.HR_INICIO ASC
