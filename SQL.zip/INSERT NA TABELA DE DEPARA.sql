
--STEP 1: PROCESSO INICIAL DE INSERT NA TABELA DE DEPARA

BEGIN
  FOR X IN (SELECT SB1.TP_DEPARA,
                   SB1.CD_MULTI_EMPRESA,
                   SB1.CD_DEPARA_MV,
                   SB1.CD_DEPARA_INTEGRA,
                   SB1.CD_SISTEMA_INTEGRA,
                   SB1.SN_AUTOMATICO
              FROM (SELECT TP_DEPARA,
                           1 CD_MULTI_EMPRESA,
                           EL.CD_EXA_LAB CD_DEPARA_MV,
                           EL.CD_CODIGO_EXTERNO CD_DEPARA_INTEGRA,
                           IMV.CD_SISTEMA_INTEGRA,
                           'S' SN_AUTOMATICO
                      FROM EXA_LAB EL
                     CROSS JOIN (SELECT 'EXAME_FLEURY' TP_DEPARA,
                                       'FLEURY' CD_SISTEMA_INTEGRA
                                  FROM DUAL
                                UNION ALL
                                SELECT 'EXAME_FLEURY_PRODUTO' TP_DEPARA,
                                       'FLEURY' CD_SISTEMA_INTEGRA
                                  FROM DUAL) IMV
                     WHERE EL.CD_EXA_LAB IN (2001,
                                             2002,
                                             2003,
                                             2004,
                                             2005,
                                             2006,
                                             2007,
                                             2008,
                                             2009,
                                             2010,
                                             2011,
                                             2012,
                                             2013,
                                             2014,
                                             2015,
                                             2016,
                                             2017,
                                             2018) /*LISTA DE EXAMES PARA CRIAR DEPARA*/
                       AND LENGTH(EL.CD_CODIGO_EXTERNO) <= 10
                       AND EL.CD_CODIGO_EXTERNO IS NOT NULL) SB1
             WHERE NOT EXISTS
             (SELECT 1
                      FROM MVINTEGRA.DEPARA IMV2
                     WHERE IMV2.TP_DEPARA = SB1.TP_DEPARA
                       AND IMV2.CD_DEPARA_MV = TO_CHAR(SB1.CD_DEPARA_MV)
                       AND IMV2.CD_DEPARA_INTEGRA = SB1.CD_DEPARA_INTEGRA)) LOOP
    INSERT INTO MVINTEGRA.DEPARA
      (TP_DEPARA,
       CD_MULTI_EMPRESA,
       CD_DEPARA_MV,
       CD_DEPARA_INTEGRA,
       CD_SISTEMA_INTEGRA,
       SN_AUTOMATICO)
    VALUES
      (X.TP_DEPARA,
       X.CD_MULTI_EMPRESA,
       X.CD_DEPARA_MV,
       X.CD_DEPARA_INTEGRA,
       X.CD_SISTEMA_INTEGRA,
       X.SN_AUTOMATICO);
    COMMIT;
  END LOOP;

END;

/*
STEP 2: VERIFICA SE FICOU ALGUM EXAME FORA DO DEPARA
*/

SELECT SB1.TP_DEPARA,
       SB1.CD_MULTI_EMPRESA,
       SB1.CD_DEPARA_MV,
       SB1.CD_DEPARA_INTEGRA,
       SB1.CD_SISTEMA_INTEGRA,
       SB1.SN_AUTOMATICO
  FROM (SELECT TP_DEPARA,
               1 CD_MULTI_EMPRESA,
               EL.CD_EXA_LAB CD_DEPARA_MV,
               EL.CD_CODIGO_EXTERNO CD_DEPARA_INTEGRA,
               IMV.CD_SISTEMA_INTEGRA,
               'S' SN_AUTOMATICO
          FROM EXA_LAB EL
         CROSS JOIN (SELECT 'EXAME_FLEURY' TP_DEPARA,
                           'FLEURY' CD_SISTEMA_INTEGRA
                      FROM DUAL
                    UNION ALL
                    SELECT 'EXAME_FLEURY_PRODUTO' TP_DEPARA,
                           'FLEURY' CD_SISTEMA_INTEGRA
                      FROM DUAL) IMV
         WHERE EL.CD_EXA_LAB IN (2001,
                                 2002,
                                 2003,
                                 2004,
                                 2005,
                                 2006,
                                 2007,
                                 2008,
                                 2009,
                                 2010,
                                 2011,
                                 2012,
                                 2013,
                                 2014,
                                 2015,
                                 2016,
                                 2017,
                                 2018) /*LISTA DE EXAMES PARA VERIRICAR SE N�O FOI CRIADO O DEPARA*/
        ) SB1
 WHERE NOT EXISTS
 (SELECT 1
          FROM MVINTEGRA.DEPARA IMV2
         WHERE IMV2.TP_DEPARA = SB1.TP_DEPARA
           AND IMV2.CD_DEPARA_MV = TO_CHAR(SB1.CD_DEPARA_MV)
           AND IMV2.CD_DEPARA_INTEGRA = SB1.CD_DEPARA_INTEGRA);
