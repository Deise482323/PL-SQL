-- QUANTIDADE DE HORAS TRABALHADAS X HORAS DE OCIOSIDADE
-- ANALITICO: M�S E ANO, NOME DO M�DICO, ESPECIALIDADE, QUANTAS HORAS TRABALHADAS, QUANTAS HORAS OCIOSAS - POR M�DICO E ESPECIALIDADE.  
-- SINTETICO: TOTAL DE HORAS TRABALHADOS X TOTAL DE HORAS OCIOSAS - POR ESPECIALIDADE 

(SELECT AC.CD_PRESTADOR,
         ACIA.CD_ITEM_AGENDAMENTO,
         AC.CD_AGENDA_CENTRAL,
         AC.CD_SETOR,
         
         COUNT(IAC.CD_IT_AGENDA_CENTRAL) TOTAL_HORARIOS,
         
         COUNT(CASE
                 WHEN IAC.NM_PACIENTE IS NOT NULL THEN
                  IAC.CD_IT_AGENDA_CENTRAL
               END)QT_MARCADOS,
               
         ACIA.QT_MAX_ITEM_AGENDAMENTO,
         
         COUNT(CASE
                 WHEN ACIA.CD_ITEM_AGENDAMENTO = IAC.CD_ITEM_AGENDAMENTO AND IAC.NM_PACIENTE IS NOT NULL THEN
                  IAC.CD_IT_AGENDA_CENTRAL
               END) HORARIOS_OCUPADOS_ITEM
               
    FROM DBAMV.AGENDA_CENTRAL AC
    JOIN DBAMV.AGENDA_CENTRAL_ITEM_AGENDA ACIA
      ON AC.CD_AGENDA_CENTRAL = ACIA.CD_AGENDA_CENTRAL
    JOIN DBAMV.IT_AGENDA_CENTRAL IAC
      ON AC.CD_AGENDA_CENTRAL = IAC.CD_AGENDA_CENTRAL
      
   WHERE AC.DT_AGENDA >= TO_DATE(SYSDATE, 'DD/MM/RRRR')
     AND AC.CD_MULTI_EMPRESA = 1
     AND AC.TP_AGENDA = 'A'
     AND AC.SN_ATIVO = 'S'
     AND IAC.SN_ENCAIXE = 'N'
     AND IAC.SN_BLOQUEADO = 'N'
     AND IAC.CD_IT_AGENDA_PAI IS NULL
     AND AC.CD_SETOR NOT IN (200) /*UNIDADE AMBULATORIAL-ITAQUERA*/
     
   GROUP BY AC.CD_PRESTADOR,
            ACIA.CD_ITEM_AGENDAMENTO,
            AC.CD_AGENDA_CENTRAL,
            AC.CD_SETOR,
            AC.QT_MARCADOS,
            ACIA.QT_MAX_ITEM_AGENDAMENTO), HORARIOSCALCULADOS AS
            
            
 (SELECT CD_PRESTADOR,
         CD_ITEM_AGENDAMENTO,
         CD_SETOR,
         SUM(TOTAL_HORARIOS) TOTAL_HORARIOS,--
         SUM(CASE
               WHEN QT_MAX_ITEM_AGENDAMENTO IS NOT NULL THEN
                LEAST(QT_MAX_ITEM_AGENDAMENTO - HORARIOS_OCUPADOS_ITEM,
                      TOTAL_HORARIOS - QT_MARCADOS)
               ELSE
                TOTAL_HORARIOS - QT_MARCADOS
             END) HORARIOS_LIVRES,--
             
             
         SUM(CASE
               WHEN QT_MAX_ITEM_AGENDAMENTO IS NOT NULL THEN
                LEAST(HORARIOS_OCUPADOS_ITEM, QT_MAX_ITEM_AGENDAMENTO)
               ELSE
                HORARIOS_OCUPADOS_ITEM
             END) HORARIOS_OCUPADOS --
             
    FROM HORARIOSTOTAIS
   GROUP BY CD_PRESTADOR, CD_ITEM_AGENDAMENTO, CD_SETOR)
SELECT HC.CD_PRESTADOR,
       P.NM_PRESTADOR,
       HC.CD_ITEM_AGENDAMENTO,
       IA.DS_ITEM_AGENDAMENTO,
       HC.CD_SETOR,
       S.NM_SETOR,
       HC.TOTAL_HORARIOS,
       HC.HORARIOS_LIVRES,
       HC.HORARIOS_OCUPADOS,
       ROUND((HC.HORARIOS_LIVRES / HC.TOTAL_HORARIOS) * 100, 2) PERC_DISPONIVEL
  FROM HORARIOSCALCULADOS HC
  JOIN DBAMV.ITEM_AGENDAMENTO IA
    ON IA.CD_ITEM_AGENDAMENTO = HC.CD_ITEM_AGENDAMENTO
  JOIN DBAMV.SETOR S
    ON S.CD_SETOR = HC.CD_SETOR
  JOIN DBAMV.PRESTADOR P
    ON P.CD_PRESTADOR = HC.CD_PRESTADOR
 ORDER BY CD_PRESTADOR, CD_ITEM_AGENDAMENTO;
 ----------------------------------------------------------------------------------------------------------------------------------
 SELECT TO_DATE(IG.DATA, 'dd/mm/rrrr') AS data,
       IG.DS_ITEM_AGENDAMENTO,
       IG.QT_TOTAL_HORARIO * 60 AS QT_TL_HRS,
       IG.QT_TOTAL_AGENDADO * 60 AS QT_TL_HRS_AGENDADAS,
       IG.QT_TOTAL_NAO_AGENDADO * 60 AS QT_TL_NAO_AGENDADO_HRS,
       IG.QT_TOTAL_BLOQUEADO * 60 AS QT_TOTAL_BLOQUEADO_HRS,
       IG.QT_ATENDIDO_NORMAL * 60 AS QT_HRS_ATEND,
       IG.QT_ATENDIDO_ENCAIXE * 60 AS QT_HRS_ATEND_ENC,
       IG.QT_FALTA_NORMAL * 60 AS QT_HRS_FALTA_NORMAL,
       IG.QT_FALTA_ENCAIXE * 60 AS QT_HRS_FALTA_ENC,
       IG.QT_ATEND_SEM_AGENDA * 60 AS QT_HRS_ATEND_SEM_AGEND,
       
       -- C�lculo do percentual de absente�smo--
       CASE
         WHEN IG.QT_TOTAL_AGENDADO > 0 THEN
          ROUND(((IG.QT_FALTA_NORMAL / IG.QT_TOTAL_AGENDADO) * 24), 2)
         ELSE
          0
       END AS PERCENTUAL_ABSENTEISMO,
       
       -- C�lculo do percentual de encaixe--
       CASE
         WHEN IG.QT_ATENDIDO_ENCAIXE > 0 THEN
          ROUND(((IG.QT_ATENDIDO_ENCAIXE / IG.QT_TOTAL_AGENDADO) * 24), 2)
         ELSE
          0
       END AS PERCENTUAL_ENCAIXE,
       
       -- Percentual de ociosidade-
       ROUND((((IG.QT_TOTAL_AGENDADO / IG.QT_TOTAL_HORARIO) * 24) - 100),
             2) AS PERCENTUAL_OCIOSIDADE
             
             
      

  FROM (SELECT DATA,
               IMG.DS_ITEM_AGENDAMENTO,
               
               
               -- Quantidade de hor�rio
               ROUND(SUM(IMG.QT_HORARIO), 2) AS QT_TOTAL_HORARIO,
               
              
              
               -- Quantidade de agendamento--
               ROUND(SUM(IMG.QT_AGENDADO), 2) AS QT_TOTAL_AGENDADO,
               
               -- Quantidade n�o agendado e bloqueado
               ROUND(SUM(IMG.QT_NAO_AGENDADO), 2) AS QT_TOTAL_NAO_AGENDADO,
               
               ROUND(SUM(IMG.QT_BLOQUEADO) + SUM(IMG.QT_BLOQUEADO_SIT), 2) AS QT_TOTAL_BLOQUEADO,
               
               -- Quantidade de atendido e faltas
               ROUND(SUM(IMG.QT_ATENDIDO_NORMAL), 2) AS QT_ATENDIDO_NORMAL,
               ROUND(SUM(IMG.QT_ATENDIDO_ENCAIXE), 2) AS QT_ATENDIDO_ENCAIXE,
               ROUND(SUM(IMG.QT_FALTA_NORMAL), 2) AS QT_FALTA_NORMAL,
               ROUND(SUM(IMG.QT_FALTA_ENCAIXE), 2) AS QT_FALTA_ENCAIXE,
               ROUND(SUM(IMG.QT_ATEND_SEM_AGENDA), 2) AS QT_ATEND_SEM_AGENDA
               
        
          FROM (SELECT TO_DATE(AC.DT_AGENDA, 'DD/MM/RRRR') AS DATA,
                       IA.DS_ITEM_AGENDAMENTO,
                       
                       
                       (1 / ((IAP.HR_REALIZACAO - TRUNC(IAP.HR_REALIZACAO)) /
                       NVL(AC.QT_TEMPO_MEDIO / 1440, 1))) / 60 AS QT_HORARIO,
                       
                       
                       DECODE(IAC.CD_ITEM_AGENDAMENTO, NULL, 0, 1) / 60 AS QT_AGENDADO,
                       
                       
                       DECODE(IAC.CD_ITEM_AGENDAMENTO,
                              NULL,
                              DECODE(IAC.SN_BLOQUEADO, 'N', 1, 0),
                              0) / 60 AS QT_NAO_AGENDADO,
                              
                              
                       DECODE(SN_BLOQUEADO,
                              'S',
                              (1 /
                              ((IAP.HR_REALIZACAO - TRUNC(IAP.HR_REALIZACAO)) /
                              NVL(AC.QT_TEMPO_MEDIO / 1440, 1))) / 60,
                              0) AS QT_BLOQUEADO,
                              
                       DECODE(TP_SITUACAO,
                              'C',
                              (1 /
                              ((IAP.HR_REALIZACAO - TRUNC(IAP.HR_REALIZACAO)) /
                              NVL(AC.QT_TEMPO_MEDIO / 1440, 1))) / 60,
                              0) AS QT_BLOQUEADO_SIT,
                       
                       
                       DECODE(IAC.CD_ATENDIMENTO,
                              NULL,
                              0,
                              DECODE(SN_ENCAIXE, 'S', 0, 1)) / 60 AS QT_ATENDIDO_NORMAL,
                              
                              
                              
                       DECODE(IAC.CD_ATENDIMENTO,
                              NULL,
                              0,
                              DECODE(SN_ENCAIXE, 'S', 1, 0)) / 60 AS QT_ATENDIDO_ENCAIXE,
                              
                              
                       DECODE(IAC.CD_ITEM_AGENDAMENTO,
                              NULL,
                              0,
                              DECODE(SIGN(SYSDATE - HR_AGENDA),
                                     1,
                                     DECODE(IAC.CD_ATENDIMENTO,
                                            NULL,
                                            DECODE(SN_ENCAIXE, 'N', 1),
                                            0),
                                     0)) / 60 AS QT_FALTA_NORMAL,
                                     
                                     
                                     
                       DECODE(IAC.CD_ITEM_AGENDAMENTO,
                              NULL,
                              0,
                              DECODE(SIGN(SYSDATE - HR_AGENDA),
                                     1,
                                     DECODE(CD_ATENDIMENTO,
                                            NULL,
                                            DECODE(SN_ENCAIXE, 'S', 1, 0),
                                            0),
                                     0)) / 60 AS QT_FALTA_ENCAIXE,
                                     
                                     
                                     
                       0 / 60 AS QT_ATEND_SEM_AGENDA
                
                  FROM IT_AGENDA_CENTRAL IAC
                 INNER JOIN AGENDA_CENTRAL AC
                    ON IAC.CD_AGENDA_CENTRAL = AC.CD_AGENDA_CENTRAL
                   AND AC.TP_AGENDA = 'A'
                 INNER JOIN DBAMV.ITEM_AGENDAMENTO IA
                    ON IA.CD_ITEM_AGENDAMENTO = IAC.CD_ITEM_AGENDAMENTO
                   AND IA.TP_ITEM = 'A'
                   JOIN DBAMV.ESCALA_CENTRAL ESC
                    ON ESC.CD_ESCALA_CENTRAL = AC.CD_ESCALA_CENTRAL
    
                  LEFT OUTER JOIN (SELECT IAP.CD_PRESTADOR,
                                         AC.CD_AGENDA_CENTRAL,
                                         MIN(IAP.HR_REALIZACAO) AS HR_REALIZACAO
                                    FROM DBAMV.AGENDA_CENTRAL AC
                                   INNER JOIN DBAMV.AGENDA_CENTRAL_ITEM_AGENDA AGI
                                      ON AC.CD_AGENDA_CENTRAL =
                                         AGI.CD_AGENDA_CENTRAL
                                   INNER JOIN DBAMV.ITEM_AGENDAMENTO_PRESTADOR IAP
                                      ON IAP.CD_ITEM_AGENDAMENTO =
                                         AGI.CD_ITEM_AGENDAMENTO
                                     AND AC.CD_PRESTADOR = IAP.CD_PRESTADOR
                                      JOIN DBAMV.ESCALA_CENTRAL ESC
                                     ON ESC.CD_ESCALA_CENTRAL = AC.CD_ESCALA_CENTRAL
                                   WHERE AC.CD_MULTI_EMPRESA = 1
                                   GROUP BY IAP.CD_PRESTADOR,
                                            AC.CD_AGENDA_CENTRAL) IAP
                    ON IAP.CD_PRESTADOR = AC.CD_PRESTADOR
                   AND AC.CD_AGENDA_CENTRAL = IAP.CD_AGENDA_CENTRAL
                 WHERE IAC.CD_IT_AGENDA_PAI IS NULL
                   AND AC.CD_MULTI_EMPRESA = 1) IMG
        
         GROUP BY DATA, IMG.DS_ITEM_AGENDAMENTO) IG
         
          WHERE TO_DATE(IG.DATA, 'DD/MM/RRRR') BETWEEN
       TO_DATE('04/02/2025', 'DD/MM/RRRR') AND
       TO_DATE('05/02/2025', 'DD/MM/RRRR')
----------------------------------------------------------------------------------------------
SELECT * FROM dbamv.item_agendamento_prestador iap
----------------------------------------------------------------------------
SELECT * FROM DBAMV.ITEM_AGENDAMENTO IA
WHERE IA.CD_ITEM_AGENDAMENTO = 20
-----------------------------------------------------------------------------         
SELECT * FROM DBAMV.ESCALA_CENTRAL ESC
WHERE 
 TO_DATE (ESC.HR_INICIO, 'DD/MM/RRRR') = TO_DATE ('04/02/2025', 'DD/MM/RRRR')
 AND ESC.CD_PRESTADOR = 11137 
---------------------------------------------
SELECT *FROM DBAMV.IT_AGENDA_CENTRAL IAC
/*JOIN DBAMV.AGENDA_CENTRAL AC 
ON AC.CD_AGENDA_CENTRAL = IAC.CD_AGENDA_CENTRAL
WHERE TO_DATE (IAC.HR_AGENDA, 'DD/MM/RRRR') = TO_DATE ('04/02/2025', 'DD/MM/RRRR') 
AND AC.CD_PRESTADOR = 11137  
--AND IAC.SN_BLOQUEADO = 'S'*/
------------------------------------------------------
SELECT * FROM AGENDA_CENTRAL AC
WHERE AC.DT_AGENDA = '11/02/2025'
AND AC.CD_SETOR = 126
/*WHERE 
TO_DATE (AC.DT_AGENDA, 'DD/MM/RRRR') = TO_DATE ('04/02/2025', 'DD/MM/RRRR')
AND AC.CD_PRESTADOR = 11137 */

--------------------------------------------------------
SELECT CD_PRESTADOR, HR_AGENDA, COUNT(*) 
FROM DBAMV.IT_AGENDA_CENTRAL
WHERE HR_AGENDA = TO_DATE('04/02/2025', 'DD/MM/RRRR')
GROUP BY CD_PRESTADOR, HR_AGENDA
--------------------------------------------
SELECT * FROM 


