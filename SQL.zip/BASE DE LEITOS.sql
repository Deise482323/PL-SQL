SELECT U.CD_UNID_INT AS CODIGO_UNID,
       U.DS_UNID_INT AS UNIDADE,
       L.CD_LEITO AS CODIGO_LEITO,
       L.DS_RESUMO AS LEITO,
       CASE
         WHEN L.TP_OCUPACAO = 'O' THEN
          'Ocup. por paciente'
         WHEN L.TP_OCUPACAO = 'V' THEN
          'Vago'
         WHEN L.TP_OCUPACAO = 'L' THEN
          'Em Limpeza'
         WHEN L.TP_OCUPACAO = 'I' THEN
          'Ocup. por infec��o'
         WHEN L.TP_OCUPACAO = 'R' THEN
          'Ocup. por reserva'
         WHEN L.TP_OCUPACAO = 'A' THEN
          'Acompanhante'
         WHEN L.TP_OCUPACAO = 'E' THEN
          'Reforma'
         WHEN L.TP_OCUPACAO = 'M' THEN
          'Manuten��o'
         WHEN L.TP_OCUPACAO = 'N' THEN
          'Interdi��o'
         WHEN L.TP_OCUPACAO = 'C' THEN
          'Interditado por Infec��o'
         WHEN L.TP_OCUPACAO = 'T' THEN
          'Interditado Temporariamente'
         ELSE
          'Desconhecido'
       END AS TP_OCUPACAO,
       
       (CASE
         WHEN L.DT_DESATIVACAO IS NULL THEN
          'ATIVO'
         ELSE
          'DESATIVADO'
       END) AS SITUACAO,
       L.DT_DESATIVACAO,
       L.SN_EXTRA,
       L.DS_ENFERMARIA
  FROM LEITO L
  JOIN UNID_INT U
    ON U.CD_UNID_INT = L.CD_UNID_INT
  JOIN SETOR S
    ON S.CD_SETOR = U.CD_SETOR
 WHERE L.SN_EXTRA = 'N'
   AND U.CD_UNID_INT <> 42
   AND S.CD_MULTI_EMPRESA = 1
 ORDER BY U.CD_UNID_INT,
          L.CD_LEITO,
          SITUACAO
          
          
          
