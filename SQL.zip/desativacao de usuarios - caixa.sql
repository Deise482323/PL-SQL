--- 1 validar os usu�rios
SELECT *
  FROM USUARIO_CAIXA UC
 WHERE UC.CD_CAIXA = 1
   AND UC.CD_USUARIO IN ('JOAO.PAULO',
                         'HC42228827',
                         'DAIANA.NOVAIS',
                         'FABIANA.VALESINI',
                         'MARIA.MONTEIRO',
                         'HC09452464',
                         'HC31511130',
                         'HC35823350',
                         'HC50247061',
                         'HC42956479',
                         'HC23989356',
                         'HC43323425');
-------validar os registros a serem excluidos ------------------
SELECT *
  FROM USUARIO_CAIXA
 WHERE CD_CAIXA = 1
   AND CD_USUARIO NOT IN ('JOAO.PAULO',
                          'HC42228827',
                          'DAIANA.NOVAIS',
                          'FABIANA.VALESINI',
                          'MARIA.MONTEIRO',
                          'HC09452464',
                          'HC31511130',
                          'HC35823350',
                          'HC50247061',
                          'HC42956479',
                          'HC23989356',
                          'HC43323425');
----------desativa��o--------------

UPDATE USUARIO_CAIXA
SET DT_DESATIVACAO = SYSDATE
WHERE CD_CAIXA = 1
  AND CD_USUARIO NOT IN (
      'JOAO.PAULO',
      'HC42228827',
      'DAIANA.NOVAIS',
      'FABIANA.VALESINI',
      'MARIA.MONTEIRO',
      'HC09452464',
      'HC31511130',
      'HC35823350',
      'HC50247061',
      'HC42956479',
      'HC23989356',
      'HC43323425',
      'HE38555985'
  )
  AND DT_DESATIVACAO IS NULL;
