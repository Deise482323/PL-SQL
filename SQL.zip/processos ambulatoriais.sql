SELECT 

  SB1.SAME,
  SB1.PACIENTE,
  SB1.IDADE,
  SB1.CD_ATENDIMENTO,
  SB1.DATA_ATENDIMENTO,
  SB1.HR_SOLICITACAO,
  SB1.AMBULATORIO,
  SB1.PRESTADOR,
  SB1.ESPECIALIDADE_ATEND,
  SB1.GUIA_TISS,
  SB1.PROC_PRINCIPAL,
  SB1.SN_UTI,
  SB1.SN_SANGUE,
  SB1.EXAMES_LAB,
  SB1.EXAMES_IMAGEM,
  SB1.AVAL_ESPECIALISTA,
  SB1.DOC_ENTREGUE,
  SB1.CD_AVISO_CIRURGIA,
  SB1.DT_CIRURGIA,
  SB1.SN_CONCLUIDO,
  SB1.DIAS_PASSADOS,
  SB1.DIF_UTI,
  SB1.DIF_SANGUE

FROM (

  SELECT 
       SOLINT.SAME,
       SOLINT.PACIENTE,
       SOLINT.IDADE,
       SOLINT.CD_ATENDIMENTO,
       SOLINT.DATA_ATENDIMENTO,
       SOLINT.HR_SOLICITACAO,
       SOLINT.AMBULATORIO,
       SOLINT.PRESTADOR,
       SOLINT.ESPECIALIDADE_ATEND,
       SOLINT.GUIA_TISS,
       NVL(SUBSTR(SUBSTR(SOLINT.PROC_PRINCIPAL,
                         (INSTR(SOLINT.PROC_PRINCIPAL, '-') + 2),
                         200),
                  1,
                  (INSTR(SUBSTR(SOLINT.PROC_PRINCIPAL,
                                (INSTR(SOLINT.PROC_PRINCIPAL, '-') + 2),
                                200),
                         '|') - 2)),
           SUBSTR(SOLINT.PROC_PRINCIPAL,
                  (INSTR(SOLINT.PROC_PRINCIPAL, '-') + 2),
                  200)) PROC_PRINCIPAL,
       SOLINT.SN_UTI,
       SOLINT.SN_SANGUE,
       SOLINT.SN_EXAMES_LAB EXAMES_LAB,
       SOLINT.SN_EXAMES_IMAGEM EXAMES_IMAGEM,
       CASE
         WHEN SOLINT.AVAL_ESPECIALISTA = 'N' THEN
          NULL
         ELSE
          '<img width="24px" height="24px" src="/Painel/img/dash/aval med.jpg" border=0>'
       END || (CASE
         WHEN TO_DATE(TISS2.DT_CIRURGIA, 'DD/MM/RRRR') -
              (SELECT MAX(TO_DATE(PCAE.DT_AGENDADA, 'DD/MM/RRRR')) DT_AGENDADA
                 FROM ENKYO.TB_PROC_CIR_AVAL_ESPECIALISTA PCAE
                WHERE PCAE.CD_ATENDIMENTO = SOLINT.CD_ATENDIMENTO) > 15 THEN
          '<img width="24px" height="24px" src="/Painel/img/dash/bullet_ball_glass_green.png" border=0>'
       
         WHEN TO_DATE(TISS2.DT_CIRURGIA, 'DD/MM/RRRR') -
              (SELECT MAX(TO_DATE(PCAE.DT_AGENDADA, 'DD/MM/RRRR')) DT_AGENDADA
                 FROM ENKYO.TB_PROC_CIR_AVAL_ESPECIALISTA PCAE
                WHERE PCAE.CD_ATENDIMENTO = SOLINT.CD_ATENDIMENTO) BETWEEN 10 AND 15 THEN
          '<img width="24px" height="24px" src="/Painel/img/dash/bullet_ball_glass_yellow.png" border=0>'
       
         WHEN TO_DATE(TISS2.DT_CIRURGIA, 'DD/MM/RRRR') -
              (SELECT MAX(TO_DATE(PCAE.DT_AGENDADA, 'DD/MM/RRRR')) DT_AGENDADA
                 FROM ENKYO.TB_PROC_CIR_AVAL_ESPECIALISTA PCAE
                WHERE PCAE.CD_ATENDIMENTO = SOLINT.CD_ATENDIMENTO) < 10 THEN
          '<img width="24px" height="24px" src="/Painel/img/dash/bullet_ball_glass_red.png" border=0>'
       
         ELSE
          NULL
       END) || (CASE
         WHEN (SELECT MAX(TO_DATE(PCAE.DT_AGENDADA, 'DD/MM/RRRR'))
                 FROM ENKYO.TB_PROC_CIR_AVAL_ESPECIALISTA PCAE
                WHERE PCAE.CD_ATENDIMENTO = SOLINT.CD_ATENDIMENTO
                  AND PCAE.REALIZADA = 'NAO') < TO_DATE(SYSDATE, 'DD/MM/RRRR') THEN
          '<img width="24px" height="24px" src="/Painel/img/dash/Slide3.png" border=0>'
         ELSE
          NULL
       END) AVAL_ESPECIALISTA,
       SOLINT.SN_DOC_ENTREGUE DOC_ENTREGUE,
       
       CASE
         WHEN (SELECT AC.CD_CEN_CIR
                   FROM AVISO_CIRURGIA AC
                   WHERE AC.CD_AVISO_CIRURGIA = TISS2.CD_AVISO_CIRURGIA) = 9 
           THEN 'EM DATA VIRTUAL'
                ELSE TO_CHAR(TISS2.DT_CIRURGIA, 'DD/MM/RRRR HH24:MI:SS')
                  END DT_CIRURGIA,
       
       TISS2.SN_CONCLUIDO,
       SOLINT.DIAS_PASSADOS,
       (CASE
         WHEN SOLINT.SN_UTI =
              (SELECT DECODE(AC.SN_UTI, 'S', 'SIM', 'N', 'N�O')
                 FROM DBAMV.AVISO_CIRURGIA AC
                WHERE AC.CD_AVISO_CIRURGIA = TISS2.CD_AVISO_CIRURGIA) THEN
          'N'
         ELSE
          'S'
       END) DIF_UTI,
       (CASE
         WHEN SOLINT.SN_SANGUE =
              (CASE WHEN EXISTS (SELECT 1 FROM DBAMV.SANGUE_AVISO SA WHERE SA.CD_AVISO_CIRURGIA = TISS2.CD_AVISO_CIRURGIA) THEN 'SIM' ELSE 'N�O' END) THEN
          'N'
         ELSE
          'S'
       END) DIF_SANGUE,
       TISS2.CD_AVISO_CIRURGIA

  FROM ENKYO.TB_SOLINT_PROCCIR_AMB SOLINT
  JOIN ENKYO.TB_TISS_AVISO_CIRURGIA TISS2
    ON TISS2.TISS_FORMAT = SOLINT.GUIA_TISS
   JOIN ENKYO.TB_PROC_CIR_AVAL_ESPECIALISTA PCAE 
   ON PCAE.CD_ATENDIMENTO = SOLINT.CD_ATENDIMENTO
 WHERE TISS2.SN_CONCLUIDO = 'N'
   AND SOLINT.DIAS_PASSADOS BETWEEN 0 AND 300
   AND PCAE.CD_ESPECIALIDADE IN (6)
   AND TO_DATE(TISS2.DT_CIRURGIA, 'DD/MM/RRRR') >=
       TO_DATE(SYSDATE, 'DD/MM/RRRR')

UNION ALL

SELECT SOLINT.SAME,
       SOLINT.PACIENTE,
       SOLINT.IDADE,
       SOLINT.CD_ATENDIMENTO,
       SOLINT.DATA_ATENDIMENTO,
       SOLINT.HR_SOLICITACAO,
       SOLINT.AMBULATORIO,
       SOLINT.PRESTADOR,
       SOLINT.ESPECIALIDADE_ATEND,
       SOLINT.GUIA_TISS,
       NVL(SUBSTR(SUBSTR(SOLINT.PROC_PRINCIPAL,
                         (INSTR(SOLINT.PROC_PRINCIPAL, '-') + 2),
                         200),
                  1,
                  (INSTR(SUBSTR(SOLINT.PROC_PRINCIPAL,
                                (INSTR(SOLINT.PROC_PRINCIPAL, '-') + 2),
                                200),
                         '|') - 2)),
           SUBSTR(SOLINT.PROC_PRINCIPAL,
                  (INSTR(SOLINT.PROC_PRINCIPAL, '-') + 2),
                  200)) PROC_PRINCIPAL,
       SOLINT.SN_UTI,
       SOLINT.SN_SANGUE,
       SOLINT.SN_EXAMES_LAB EXAMES_LAB,
       SOLINT.SN_EXAMES_IMAGEM EXAMES_IMAGEM,
       CASE
         WHEN SOLINT.AVAL_ESPECIALISTA = 'N' THEN
          NULL
         ELSE
          '<img width="24px" height="24px" src="/Painel/img/dash/aval med.jpg" border=0>'
       END || (CASE
         WHEN TO_DATE(TISS2.DT_CIRURGIA, 'DD/MM/RRRR') -
              (SELECT MAX(TO_DATE(PCAE.DT_AGENDADA, 'DD/MM/RRRR')) DT_AGENDADA
                 FROM ENKYO.TB_PROC_CIR_AVAL_ESPECIALISTA PCAE
                WHERE PCAE.CD_ATENDIMENTO = SOLINT.CD_ATENDIMENTO) > 15 THEN
          '<img width="24px" height="24px" src="/Painel/img/dash/bullet_ball_glass_green.png" border=0>'
       
         WHEN TO_DATE(TISS2.DT_CIRURGIA, 'DD/MM/RRRR') -
              (SELECT MAX(TO_DATE(PCAE.DT_AGENDADA, 'DD/MM/RRRR')) DT_AGENDADA
                 FROM ENKYO.TB_PROC_CIR_AVAL_ESPECIALISTA PCAE
                WHERE PCAE.CD_ATENDIMENTO = SOLINT.CD_ATENDIMENTO) BETWEEN 10 AND 15 THEN
          '<img width="24px" height="24px" src="/Painel/img/dash/bullet_ball_glass_yellow.png" border=0>'
       
         WHEN TO_DATE(TISS2.DT_CIRURGIA, 'DD/MM/RRRR') -
              (SELECT MAX(TO_DATE(PCAE.DT_AGENDADA, 'DD/MM/RRRR')) DT_AGENDADA
                 FROM ENKYO.TB_PROC_CIR_AVAL_ESPECIALISTA PCAE
                WHERE PCAE.CD_ATENDIMENTO = SOLINT.CD_ATENDIMENTO) < 10 THEN
          '<img width="24px" height="24px" src="/Painel/img/dash/bullet_ball_glass_red.png" border=0>'
       
         ELSE
          NULL
       END) || (CASE
         WHEN (SELECT MAX(TO_DATE(PCAE.DT_AGENDADA, 'DD/MM/RRRR'))
                 FROM ENKYO.TB_PROC_CIR_AVAL_ESPECIALISTA PCAE
                WHERE PCAE.CD_ATENDIMENTO = SOLINT.CD_ATENDIMENTO
                  AND PCAE.REALIZADA = 'NAO') < TO_DATE(SYSDATE, 'DD/MM/RRRR') THEN
          '<img width="24px" height="24px" src="/Painel/img/dash/Slide3.png" border=0>'
         ELSE
          NULL
       END) AVAL_ESPECIALISTA,
       SOLINT.SN_DOC_ENTREGUE DOC_ENTREGUE,
       
       CASE
         WHEN (SELECT AC.CD_CEN_CIR
           FROM AVISO_CIRURGIA AC
           WHERE AC.CD_AVISO_CIRURGIA = TISS2.CD_AVISO_CIRURGIA) = 9 THEN 'EM DATA VIRTUAL'
           ELSE TO_CHAR(TISS2.DT_CIRURGIA, 'DD/MM/RRRR HH24:MI:SS') 
             END DT_CIRURGIA,
       
       TISS2.SN_CONCLUIDO,
       SOLINT.DIAS_PASSADOS,
       (CASE
         WHEN SOLINT.SN_UTI =
              (SELECT DECODE(AC.SN_UTI, 'S', 'SIM', 'N', 'N�O')
                 FROM DBAMV.AVISO_CIRURGIA AC
                WHERE AC.CD_AVISO_CIRURGIA = TISS2.CD_AVISO_CIRURGIA) THEN
          'N'
         ELSE
          'S'
       END) DIF_UTI,
       (CASE
         WHEN SOLINT.SN_SANGUE =
              (CASE WHEN EXISTS (SELECT 1 FROM DBAMV.SANGUE_AVISO SA WHERE SA.CD_AVISO_CIRURGIA = TISS2.CD_AVISO_CIRURGIA) THEN 'SIM' ELSE 'N�O' END) THEN
          'N'
         ELSE
          'S'
       END) DIF_SANGUE,
       TISS2.CD_AVISO_CIRURGIA

  FROM ENKYO.TB_SOLINT_PROCCIR_AMB SOLINT
  JOIN ENKYO.TB_TISS_AVISO_CIRURGIA TISS2
    ON TISS2.TISS2_FORMAT = SOLINT.GUIA_TISS
    JOIN ENKYO.TB_PROC_CIR_AVAL_ESPECIALISTA PCAE 
   ON PCAE.CD_ATENDIMENTO = SOLINT.CD_ATENDIMENTO
 WHERE TISS2.SN_CONCLUIDO = 'N'
   AND SOLINT.DIAS_PASSADOS BETWEEN 0 AND 300
   AND PCAE.CD_ESPECIALIDADE IN (6)
   AND TO_DATE(TISS2.DT_CIRURGIA, 'DD/MM/RRRR') >=
       TO_DATE(SYSDATE, 'DD/MM/RRRR')
       
      ) SB1

       ORDER BY 
  (SELECT CASE WHEN AC.CD_CEN_CIR = 9 THEN 1 ELSE 0 END 
   FROM AVISO_CIRURGIA AC 
   WHERE AC.CD_AVISO_CIRURGIA = SB1.CD_AVISO_CIRURGIA) ASC, 
  DT_CIRURGIA ASC
