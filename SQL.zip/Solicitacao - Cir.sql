select * from ENKYO.TB_SOLINT_PROCCIR_AMB SOLINT
where  TO_DATE(solint.data_atendimento, 'DD/MM/RRRR') BETWEEN
      TO_DATE('01/08/2025', 'DD/MM/RRRR') AND
               TO_DATE('02/08/2025', 'DD/MM/RRRR')
    
               
