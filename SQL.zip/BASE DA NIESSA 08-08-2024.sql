SELECT DISTINCT A.DT_ATENDIMENTO AS DATA_ATEND,
                A.CD_ATENDIMENTO AS ATENDIMENTO,
                DECODE(A.TP_ATENDIMENTO,
                       'I',
                       'INTERNACAO',
                       'A',
                       'AMBULATORIO',
                       'E',
                       'EXTERNO',
                       'U',
                       'URGENCIA') AS TIPO_ATENDIMENTO,
                P.CD_PACIENTE AS SAME,
                P.NM_PACIENTE AS PACIENTE,
                TO_CHAR(FNC_HNB_OBTER_IDADE(P.DT_NASCIMENTO,
                                            A.DT_ATENDIMENTO)) AS IDADE,
                CO.CD_CONVENIO AS COD_CONVENIO,
                CO.NM_CONVENIO AS CONVENIO,
                NVL(TO_CHAR(IT.HR_AGENDA, 'HH24:MI:SS'), 'N�O AGENDADO') AS HORARIO_AGEN,
                PR.CD_PED_RX AS PEDIDO,
                ER.CD_EXA_RX AS COD_EXAME,
                ER.DS_EXA_RX AS DESC_EXAME,
                S.CD_SETOR AS SETOR,
                S.NM_SETOR,
                PRES.NM_PRESTADOR AS PRESTADOR,
                TO_CHAR((SELECT MIN(STP.DH_PROCESSO)
                          FROM SACR_TEMPO_PROCESSO STP
                         WHERE STP.CD_ATENDIMENTO = A.CD_ATENDIMENTO
                           AND STP.CD_TIPO_TEMPO_PROCESSO = 1),
                        'HH24:MI:SS') AS HR_SENHA_TOTEM,
                TO_CHAR((SELECT MIN(STP.DH_PROCESSO)
                          FROM SACR_TEMPO_PROCESSO STP
                         WHERE STP.CD_ATENDIMENTO = A.CD_ATENDIMENTO
                           AND STP.CD_TIPO_TEMPO_PROCESSO = 21),
                        'HH24:MI:SS') AS HR_INI_FICHA,
                TO_CHAR((SELECT MIN(STP.DH_PROCESSO)
                          FROM SACR_TEMPO_PROCESSO STP
                         WHERE STP.CD_ATENDIMENTO = A.CD_ATENDIMENTO
                           AND STP.CD_TIPO_TEMPO_PROCESSO = 22),
                        'HH24:MI:SS') AS HR_FIM_FICHA
  FROM IT_AGENDA_CENTRAL IT
  LEFT JOIN ATENDIME A
    ON IT.CD_ATENDIMENTO = A.CD_ATENDIMENTO
  LEFT JOIN PACIENTE P
    ON IT.CD_PACIENTE = P.CD_PACIENTE
  LEFT JOIN PED_RX PR
    ON PR.CD_ATENDIMENTO = A.CD_ATENDIMENTO
  LEFT JOIN SETOR S
    ON S.CD_SETOR = PR.CD_SETOR
  LEFT JOIN SET_EXA SE
    ON SE.CD_SET_EXA = PR.CD_SET_EXA
  LEFT JOIN ITPED_RX ITPR
    ON ITPR.CD_PED_RX = PR.CD_PED_RX
  LEFT JOIN EXA_RX ER
    ON ER.CD_EXA_RX = ITPR.CD_EXA_RX
  LEFT JOIN MULTI_EMPRESAS ME
    ON ME.CD_MULTI_EMPRESA = A.CD_MULTI_EMPRESA
  LEFT JOIN FILA_SENHA FS
    ON FS.CD_MULTI_EMPRESA = ME.CD_MULTI_EMPRESA
  LEFT JOIN SACR_TEMPO_PROCESSO STP
    ON STP.CD_ATENDIMENTO = A.CD_ATENDIMENTO
  LEFT JOIN SACR_TIPO_TEMPO_PROCESSO STTP
    ON STTP.CD_TIPO_TEMPO_PROCESSO = STP.CD_TIPO_TEMPO_PROCESSO
  LEFT JOIN CONVENIO CO
    ON CO.CD_CONVENIO = IT.CD_CONVENIO
  LEFT JOIN PRESTADOR PRES
    ON PRES.CD_PRESTADOR = A.CD_PRESTADOR

 WHERE TO_DATE(A.DT_ATENDIMENTO, 'DD/MM/RRRR') BETWEEN
       TO_DATE('01/05/2024', 'DD/MM/RRRR') AND
       TO_DATE('31/07/2024', 'DD/MM/RRRR')
   AND S.CD_SETOR IN (347, 117, 107)
   AND FS.CD_FILA_SENHA IN (21, 24, 28)

 GROUP BY A.DT_ATENDIMENTO,
          A.CD_ATENDIMENTO,
          DECODE(A.TP_ATENDIMENTO,
                 'I',
                 'INTERNACAO',
                 'A',
                 'AMBULATORIO',
                 'E',
                 'EXTERNO',
                 'U',
                 'URGENCIA'),
          P.CD_PACIENTE,
          P.NM_PACIENTE,
          TO_CHAR(FNC_HNB_OBTER_IDADE(P.DT_NASCIMENTO, A.DT_ATENDIMENTO)),
          CO.CD_CONVENIO,
          CO.NM_CONVENIO,
          NVL(TO_CHAR(IT.HR_AGENDA, 'HH24:MI:SS'), 'N�O AGENDADO'),
          PR.CD_PED_RX,
          ER.CD_EXA_RX,
          ER.DS_EXA_RX,
          S.CD_SETOR,
          S.NM_SETOR,
          PRES.NM_PRESTADOR,
          IT.CD_ATENDIMENTO
 ORDER BY A.DT_ATENDIMENTO;
