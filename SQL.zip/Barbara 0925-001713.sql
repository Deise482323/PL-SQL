WITH SOL_COM_AGG AS
 (SELECT CD_GUIA, NVL(MIN(DT_INTEGRA), MIN(DT_SOL_COM)) AS DT_SOL_COMPRAS
    FROM SOL_COM
   WHERE DT_CANCELAMENTO IS NULL
   GROUP BY CD_GUIA),
LOG_SOL AS
 (SELECT CD_GUIA, MIN(DT_MOVIMENTO) AS DT_SOLIC_OPME
    FROM LOG_GUIA
   WHERE TP_SITUACAO_MOVIMENTO = 'S'
   GROUP BY CD_GUIA)
SELECT G.CD_AVISO_CIRURGIA,
       G.CD_GUIA,
       AC.DT_AVISO_CIRURGIA,
       SCA.DT_SOL_COMPRAS,
       LS.DT_SOLIC_OPME,
       CASE
         WHEN LS.DT_SOLIC_OPME IS NULL THEN
          'Aguardando solicita��o'
         ELSE
          TRUNC(LS.DT_SOLIC_OPME - SCA.DT_SOL_COMPRAS) || ' dia(s) ' ||
          TRUNC(MOD((LS.DT_SOLIC_OPME - SCA.DT_SOL_COMPRAS) * 24, 24)) ||
          ' hora(s) ' ||
          TRUNC(MOD((LS.DT_SOLIC_OPME - SCA.DT_SOL_COMPRAS) * 24 * 60, 60)) ||
          ' minuto(s)'
       END AS TEMPO_DECORRIDO
  FROM DBAMV.AVISO_CIRURGIA AC
  JOIN DBAMV.GUIA G
    ON G.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
  JOIN SOL_COM_AGG SCA
    ON SCA.CD_GUIA = G.CD_GUIA
  LEFT JOIN LOG_SOL LS
    ON LS.CD_GUIA = G.CD_GUIA
 WHERE G.TP_GUIA = 'O'
   AND G.TP_SITUACAO <> 'C'
   AND SCA.DT_SOL_COMPRAS IS NOT NULL
   AND AC.DT_AVISO_CIRURGIA BETWEEN TO_DATE('01/01/2025', 'DD/MM/RRRR') AND
       TO_DATE('15/01/2025', 'DD/MM/RRRR');
------------------------------------------------
(SELECT DBMS_LOB.substr(ERC.LO_VALOR, 30)
                      FROM EDITOR_REGISTRO_CAMPO ERC
                      JOIN EDITOR_CAMPO EDC
                        ON EDC.CD_CAMPO = ERC.CD_CAMPO
                     WHERE ERC.CD_REGISTRO =
                           (SELECT MAX(EC1.CD_EDITOR_REGISTRO)
                              FROM PW_DOCUMENTO_CLINICO DC1
                              JOIN PW_EDITOR_CLINICO EC1
                                ON EC1.CD_DOCUMENTO_CLINICO =
                                   DC1.CD_DOCUMENTO_CLINICO
                             WHERE EC1.CD_DOCUMENTO = 971
                               AND DC1.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO
                               AND DC1.TP_STATUS = 'FECHADO')
                       AND EDC.DS_IDENTIFICADOR = 'Metadado_P_177025_1') GUIA_TISS
