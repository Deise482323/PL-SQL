SELECT O.CD_ORD_COM AS ORDEM_COMPRA,
       TO_DATE(O.DT_ORD_COM, 'DD/MM/RRRR') AS DT_ORDEM,
       DECODE(O.TP_SITUACAO,
              'A',
              'ABERTA',
              'L',
              'LIBERADA',
              'U',
              'AUTORIZADA') AS SITUACAO,
       O.CD_FORNECEDOR || ' - ' || F.NM_FORNECEDOR AS FORNECEDOR,
       O.DT_PREV_ENTREGA AS DT_PREVISTA,
       O.VL_TOTAL AS VL_TOTAL,
       C.DS_COTADOR AS COMPRADOR,
       SC.CD_SETOR || ' - ' || S.NM_SETOR AS SETOR,
       ITO.CD_PRODUTO || ' - ' || P.DS_PRODUTO AS ITENS,
       -- Dias de atraso: apenas se data prevista j� passou e situa��o n�o for C, T, N
       CASE
         WHEN O.DT_PREV_ENTREGA < SYSDATE AND
              O.TP_SITUACAO NOT IN ('C', 'T', 'N') THEN
          TRUNC(SYSDATE - O.DT_PREV_ENTREGA)
         ELSE
          0
       END AS DIAS_ATRASO
  FROM ORD_COM O
  JOIN ITORD_PRO ITO
    ON ITO.CD_ORD_COM = O.CD_ORD_COM
  JOIN SOL_COM SC
    ON SC.CD_SOL_COM = O.CD_SOL_COM
  JOIN SETOR S
    ON S.CD_SETOR = SC.CD_SETOR
  LEFT JOIN COTADOR C
    ON C.CD_COTADOR = SC.CD_COTADOR
  JOIN DBAMV.FORNECEDOR F
    ON F.CD_FORNECEDOR = O.CD_FORNECEDOR
  JOIN ITORD_PRO ITP
    ON ITP.CD_ORD_COM = O.CD_ORD_COM
  JOIN PRODUTO P
    ON P.CD_PRODUTO = ITO.CD_PRODUTO

 WHERE TO_DATE(O.DT_ORD_COM, 'DD/MM/RRRR') BETWEEN
       TO_DATE('01/01/2023', 'DD/MM/RRRR') and
       TO_DATE('18/06/2025', 'DD/MM/RRRR')
   AND SC.SN_OPME = 'N'
   AND O.TP_SITUACAO IN ('A', 'L', 'U')
  
  -- AND {V_VAR}
 GROUP BY O.CD_ORD_COM,
          O.DT_ORD_COM,
          O.TP_SITUACAO,
          O.CD_FORNECEDOR,
          F.NM_FORNECEDOR,
          O.DT_PREV_ENTREGA,
          O.VL_TOTAL,
          C.DS_COTADOR,
          SC.CD_SETOR,
          ITO.CD_PRODUTO,
          P.DS_PRODUTO,
          S.NM_SETOR
 ORDER BY O.CD_ORD_COM
