SELECT
      t.cd_registro_auditoria,
      t.nm_maquina_registro_auditoria,
      t.ds_modulo_auditoria,
      t.cd_usuario_registro_auditoria,
      TO_CHAR(t.tz_registro_auditoria, 'DD-MM-YYYY HH24:MI:SS') AS tz_registro_auditoria
FROM
      REGISTRO_AUDITORIA t
WHERE 
     TO_CHAR(t.tz_registro_auditoria, 'MM/YYYY') = '05/2024'
      --AND cd_usuario_registro_auditoria = 'INGRID'
      --AND t.TP_REGISTRO_AUDITORIA = 'ACE'
ORDER BY 5 DESC

SELECT * FROM REGISTRO_AUDITORIA T
