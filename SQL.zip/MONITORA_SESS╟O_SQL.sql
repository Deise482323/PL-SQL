SELECT S.SID,
       S.SERIAL#,
       S.USERNAME,
       S.PROGRAM,
       S.MACHINE,
       ROUND(S.LAST_CALL_ET / 3600, 2) AS HOURS_INACTIVE,
       ROUND(P.PGA_USED_MEM / 1024 / 1024, 2) AS PGA_MB,
       ROUND(P.PGA_ALLOC_MEM / 1024 / 1024, 2) AS LUGA_MB,
       ROUND(P.PGA_USED_MEM / 1024 / 1024 + P.PGA_ALLOC_MEM / 1024 / 1024,
             2) AS TOTAL_MEMORY_MB,
       (SELECT VALUE
          FROM V$PGASTAT
         WHERE NAME = 'aggregate PGA target parameter') AS PGA_LIMIT_MB,
       CASE
         WHEN (P.PGA_USED_MEM * 100 /
              (SELECT VALUE
                  FROM V$PGASTAT
                 WHERE NAME = 'aggregate PGA target parameter')) < 70 THEN
          'OK - abaixo de 70% da PGA'
         ELSE
          'ALERTA - acima de 70%'
       END AS MEMORY_STATUS,
       S.SQL_ID,
       S.PREV_SQL_ID,
       S.STATUS AS KILLED
  FROM V$SESSION S
  JOIN V$PROCESS P
    ON S.PADDR = P.ADDR
 WHERE S.USERNAME IS NOT NULL;
