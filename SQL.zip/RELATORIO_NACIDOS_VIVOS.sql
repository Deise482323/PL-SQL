create or replace view dbamv.vdic_dnv_same_hnb as
select distinct
	   af.cd_atendimento_pai  Atendimento_da_mae,
	   ap.dt_atendimento dt_internacao_mae,
	   af.dt_atendimento data_nascimento,
	   ap.dt_alta  alta_mae,
	   ap.cd_paciente  cd_paciente_mae,
	   p.nm_paciente  mae ,
	   tp.ds_tip_parto tipo_de_parto,
	   to_char(rn.cd_declaracao_nascido_vivo) dnv ,
	   RN.nm_recem_nascido nome_recem_nasc
from dbamv.recem_nascido rn
	 ,dbamv.atendime af
	 ,dbamv.atendime ap
	 ,dbamv.paciente p
	 ,dbamv.admissao_co ad
	 ,dbamv.tip_parto tp
where rn.cd_atendimento = af.cd_atendimento
and af.cd_atendimento_pai = ap.cd_atendimento
and p.cd_paciente = ap.cd_paciente
and rn.cd_admissao_co   = ad.cd_admissao_co
and ad.cd_tip_parto  = tp.cd_tip_parto (+);
