CREATE OR REPLACE VIEW DBAMV.VDIC_HNB_ALTAS_MED_INTER AS
SELECT SB1.ATENDIMENTO,
       '<b><font face = "Arial" color = #000000 size=2>' ||
       Initcap(SB1.NOME_PACIENTE) || '</font></b>' NOME_PACIENTE,
       (CASE
         WHEN TP_ACOM = 'APT' THEN
          '<b><font face = "Arial" color = #002db3 size=1>' || SB1.LEITO ||
          '</font></b>'
         WHEN TP_ACOM = 'ENF' THEN
          '<b><font face = "Arial" color = #e60000 size=1>' || SB1.LEITO ||
          '</font></b>'
         ELSE
          '<b><font face = "Arial" color = #000000 size=1>' || SB1.LEITO ||
          '</font></b>'
       END) LEITO,
       '<b><font face = "Arial" color = #000000 size=1>' ||
       Initcap(SB1.OBSERVACAO) || '</font></b>' OBSERVACAO,
       '<b><font face = "Arial" color = #000000 size=1>' ||
       Initcap(SB1.JUSTIFICATIVA) || '</font></b>' JUSTIFICATIVA,
       '<b><font face = "Arial" color = #000000 size=1>' ||
       SB1.DIAS_INTERNACAO || '</font></b>' DIAS_INTERNACAO,
       '<b><font face = "Arial" color = #000000 size=1>' || SB1.DH_NASC ||
       '</font></b>' DH_NASC,
       '<b><font face = "Arial" color = #000000 size=1>' ||
       SB1.DT_ALTA_PRESC || '</font></b>' DT_ALTA_PRESC,
       '<b><font face = "Arial" color = #000000 size=1>' ||
       SB1.HR_ALTA_PRESC || '</font></b>' HR_ALTA_PRESC,
       '<b><font face = "Arial" color = #000000 size=1>' ||
       SB1.HR_ALTA_MEDICA || '</font></b>' HR_ALTA_MEDICA,
       '<b><font face = "Arial" color = #000000 size=1>' ||
       SB1.HR_ALTA_HOSPITALAR || '</font></b>' HR_ALTA_HOSPITALAR,
       SB1.CD_UNID_INT,
       SB1.DS_UNID_INT,
       SB1.ALTA_HOSPITALAR,
       SB1.COND_MATER,
       SB1.ORDEM
  FROM (SELECT ATE.CD_ATENDIMENTO ATENDIMENTO,
                PAC.NM_PACIENTE NOME_PACIENTE,
                (SELECT CASE
                          WHEN LT.SN_EXTRA = 'S' THEN
                           'EXTRA'
                          WHEN TA.DS_TIP_ACOM LIKE 'APARTA%' THEN
                           'APT'
                          WHEN TA.DS_TIP_ACOM LIKE 'ENFERM%' THEN
                           'ENF'
                          WHEN TA.DS_TIP_ACOM LIKE '%ISOLA%APAR%' THEN
                           'APT'
                          WHEN TA.DS_TIP_ACOM LIKE '%ISOLA%ENF%' THEN
                           'ENF'
                          WHEN TA.DS_TIP_ACOM LIKE 'HOSPITAL DIA' THEN
                           'HD'
                          ELSE
                           TA.DS_TIP_ACOM
                        END TP_ACOM
                   FROM TIP_ACOM TA
                  WHERE TA.CD_TIP_ACOM = LT.CD_TIP_ACOM) TP_ACOM,
                LT.DS_ENFERMARIA LEITO,
                SUBSTR(IPM.DS_ITPRE_MED, 0, 100) OBSERVACAO,
                TP.DS_TIP_PRESC || CHR(10) || '-' || IPM.DS_JUSTIFICATIVA JUSTIFICATIVA,
                TO_DATE(SYSDATE, 'DD/MM/YYYY') -
                TO_DATE(ATE.DT_ATENDIMENTO, 'DD/MM/YYYY') DIAS_INTERNACAO,
                (SELECT TO_CHAR(ERC.LO_VALOR) DS_RESPOSTA
                   FROM DBAMV.EDITOR_REGISTRO_CAMPO ERC
                  INNER JOIN DBAMV.EDITOR_CAMPO EC
                     ON EC.CD_CAMPO = ERC.CD_CAMPO
                  WHERE ERC.CD_REGISTRO IN
                        (SELECT MAX(PE.CD_EDITOR_REGISTRO)
                           FROM DBAMV.PW_EDITOR_CLINICO PE
                          INNER JOIN DBAMV.PW_DOCUMENTO_CLINICO PE1
                             ON PE1.CD_DOCUMENTO_CLINICO =
                                PE.CD_DOCUMENTO_CLINICO
                          WHERE PE1. CD_ATENDIMENTO IN
                                (SELECT ATM.CD_ATENDIMENTO
                                   FROM ATENDIME ATM
                                  WHERE ATM.CD_PACIENTE IN
                                        (SELECT ATM_P.CD_PACIENTE
                                           FROM ATENDIME ATM_P
                                          WHERE ATM_P.CD_ATENDIMENTO =
                                                (SELECT DBAMV.FNC_HNB_RET_DADOS_MAE(ATE.CD_ATENDIMENTO)
                                                   FROM DUAL)))
                            AND PE.CD_DOCUMENTO IN (651)
                            AND PE1.TP_STATUS = 'FECHADO')
                    AND UPPER(EC.DS_IDENTIFICADOR) IN ('DT_DATA_PARTO_1')) DH_NASC,
                TO_CHAR(PM.DH_IMPRESSAO, 'DD/MM/YYYY') DT_ALTA_PRESC,
                TO_CHAR(PM.DH_IMPRESSAO, 'HH24:MI:SS') HR_ALTA_PRESC,
                TO_CHAR(ATE.HR_ALTA_MEDICA, 'HH24:MI:SS') HR_ALTA_MEDICA,
                TO_CHAR(ATE.HR_ALTA, 'HH24:MI:SS') HR_ALTA_HOSPITALAR,
                UI.CD_UNID_INT CD_UNID_INT,
                UI.DS_UNID_INT DS_UNID_INT,
                ATE.DT_ALTA ALTA_HOSPITALAR,
                (CASE
                  WHEN UI.DS_UNID_INT LIKE '%MATERN%' THEN
                   'MATER'
                  ELSE
                   'OUTRA'
                END) COND_MATER,
                ATE.CD_ATENDIMENTO ORDEM
           FROM ATENDIME ATE
           JOIN PRE_MED PM
             ON PM.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO
           JOIN ITPRE_MED IPM
             ON IPM.CD_PRE_MED = PM.CD_PRE_MED
           JOIN TIP_PRESC TP
             ON TP.CD_TIP_PRESC = IPM.CD_TIP_PRESC
           JOIN PACIENTE PAC
             ON PAC.CD_PACIENTE = ATE.CD_PACIENTE
           JOIN LEITO LT
             ON LT.CD_LEITO = ATE.CD_LEITO
           JOIN UNID_INT UI
             ON UI.CD_UNID_INT = LT.CD_UNID_INT
          WHERE ATE.TP_ATENDIMENTO = 'I'
            AND LT.CD_TIP_ACOM NOT IN (3, 4, 5, 19, 20) /*UTI'S*/
           AND ATE.CD_MULTI_EMPRESA = 1
           AND ATE.DT_ALTA IS NULL
           AND IPM.CD_TIP_PRESC = 28847
           AND IPM.DH_CANCELADO IS NULL
           AND UI.DS_UNID_INT NOT LIKE 'MATER%' /*DESCARTA UNIDADE DE MATERNIDADE*/
           AND ATE.CD_ATENDIMENTO_PAI IS NULL /*SEM RN VINCULADO A M?E*/
              /*AND TO_DATE(PM.DT_PRE_MED, 'DD/MM/RRRR') =
              TO_DATE(SYSDATE, 'DD/MM/RRRR')*/
           AND PM.CD_PRE_MED =
               (SELECT MAX(PM1.CD_PRE_MED)
                  FROM PRE_MED PM1
                  JOIN ITPRE_MED IPM1
                    ON IPM1.CD_PRE_MED = PM1.CD_PRE_MED
                  JOIN PW_DOCUMENTO_CLINICO DC
                    ON DC.CD_DOCUMENTO_CLINICO = PM1.CD_DOCUMENTO_CLINICO
                 WHERE PM1.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO
                   AND IPM1.CD_TIP_PRESC = 28847
                   AND IPM1.DH_CANCELADO IS NULL
                   AND DC.TP_STATUS = 'FECHADO')

        UNION ALL

        SELECT ATE.CD_ATENDIMENTO,
               PAC.NM_PACIENTE NOME_PACIENTE,
               (SELECT CASE
                         WHEN LT.SN_EXTRA = 'S' THEN
                          'EXTRA'
                         WHEN TA.DS_TIP_ACOM LIKE 'APARTA%' THEN
                          'APT'
                         WHEN TA.DS_TIP_ACOM LIKE 'ENFERM%' THEN
                          'ENF'
                         WHEN TA.DS_TIP_ACOM LIKE '%ISOLA%APAR%' THEN
                          'APT'
                         WHEN TA.DS_TIP_ACOM LIKE '%ISOLA%ENF%' THEN
                          'ENF'
                         WHEN TA.DS_TIP_ACOM LIKE 'HOSPITAL DIA' THEN
                          'HD'
                         ELSE
                          TA.DS_TIP_ACOM
                       END TP_ACOM
                  FROM TIP_ACOM TA
                 WHERE TA.CD_TIP_ACOM = LT.CD_TIP_ACOM) TP_ACOM,
               LT.DS_ENFERMARIA LEITO,
               SUBSTR(IPM.DS_ITPRE_MED, 0, 100) OBSERVACAO,
               TP.DS_TIP_PRESC || CHR(10) || '-' || IPM.DS_JUSTIFICATIVA JUSTIFICATIVA,
               TO_DATE(SYSDATE, 'DD/MM/YYYY') -
               TO_DATE(ATE.DT_ATENDIMENTO, 'DD/MM/YYYY') DIAS_INTERNACAO,
               (SELECT TO_CHAR(ERC.LO_VALOR) DS_RESPOSTA
                  FROM DBAMV.EDITOR_REGISTRO_CAMPO ERC
                 INNER JOIN DBAMV.EDITOR_CAMPO EC
                    ON EC.CD_CAMPO = ERC.CD_CAMPO
                 WHERE ERC.CD_REGISTRO IN
                       (SELECT MAX(PE.CD_EDITOR_REGISTRO)
                          FROM DBAMV.PW_EDITOR_CLINICO PE
                         INNER JOIN DBAMV.PW_DOCUMENTO_CLINICO PE1
                            ON PE1.CD_DOCUMENTO_CLINICO =
                               PE.CD_DOCUMENTO_CLINICO
                         WHERE PE1. CD_ATENDIMENTO IN
                               (SELECT ATM.CD_ATENDIMENTO
                                  FROM ATENDIME ATM
                                 WHERE ATM.CD_PACIENTE IN
                                       (SELECT ATM_P.CD_PACIENTE
                                          FROM ATENDIME ATM_P
                                         WHERE ATM_P.CD_ATENDIMENTO =
                                               (SELECT DBAMV.FNC_HNB_RET_DADOS_MAE(ATE.CD_ATENDIMENTO)
                                                  FROM DUAL)))
                           AND PE.CD_DOCUMENTO IN (651)
                           AND PE1.TP_STATUS = 'FECHADO')
                   AND UPPER(EC.DS_IDENTIFICADOR) IN ('DT_DATA_PARTO_1')) DH_NASC,
               TO_CHAR(PM.DH_IMPRESSAO, 'DD/MM/YYYY') DT_ALTA_PRESC,
               TO_CHAR(PM.DH_IMPRESSAO, 'HH24:MI:SS') HR_ALTA_PRESC,
               TO_CHAR(ATE.HR_ALTA_MEDICA, 'HH24:MI:SS') HR_ALTA_MEDICA,
               TO_CHAR(ATE.HR_ALTA, 'HH24:MI:SS') HR_ALTA_HOSPITALAR,
               NVL((SELECT UI2.CD_UNID_INT
                     FROM ATENDIME ATE2
                     JOIN LEITO LT2
                       ON LT2.CD_LEITO = ATE2.CD_LEITO
                     JOIN UNID_INT UI2
                       ON UI2.CD_UNID_INT = LT2.CD_UNID_INT
                    WHERE ATE2.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO_PAI),
                   UI.CD_UNID_INT) CD_UNIDADE,
               NVL((SELECT UI2.DS_UNID_INT
                     FROM ATENDIME ATE2
                     JOIN LEITO LT2
                       ON LT2.CD_LEITO = ATE2.CD_LEITO
                     JOIN UNID_INT UI2
                       ON UI2.CD_UNID_INT = LT2.CD_UNID_INT
                    WHERE ATE2.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO_PAI),
                   UI.DS_UNID_INT) DS_UNI_INT,
               ATE.DT_ALTA ALTA_HOSPITALAR,
               (CASE
                 WHEN NVL((SELECT UI2.DS_UNID_INT
                            FROM ATENDIME ATE2
                            JOIN LEITO LT2
                              ON LT2.CD_LEITO = ATE2.CD_LEITO
                            JOIN UNID_INT UI2
                              ON UI2.CD_UNID_INT = LT2.CD_UNID_INT
                           WHERE ATE2.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO_PAI),
                          UI.DS_UNID_INT) LIKE '%MATERN%' THEN
                  'MATER'
                 ELSE
                  'OUTRA'
               END) COND_MATER,
               NVL(ATE.CD_ATENDIMENTO_PAI, ATE.CD_ATENDIMENTO) ORDEM
          FROM ATENDIME ATE
          JOIN PRE_MED PM
            ON PM.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO
          JOIN ITPRE_MED IPM
            ON IPM.CD_PRE_MED = PM.CD_PRE_MED
          JOIN TIP_PRESC TP
            ON TP.CD_TIP_PRESC = IPM.CD_TIP_PRESC
          JOIN PACIENTE PAC
            ON PAC.CD_PACIENTE = ATE.CD_PACIENTE
          JOIN LEITO LT
            ON LT.CD_LEITO = ATE.CD_LEITO
          JOIN UNID_INT UI
            ON UI.CD_UNID_INT = LT.CD_UNID_INT
         WHERE ATE.TP_ATENDIMENTO = 'I'
           AND LT.CD_TIP_ACOM NOT IN (3, 4, 5, 19, 20) /*UTI'S*/
            AND ATE.CD_MULTI_EMPRESA = 1
            AND ATE.DT_ALTA IS NULL
            AND IPM.CD_TIP_PRESC = 28847
            AND IPM.DH_CANCELADO IS NULL
            AND (UI.DS_UNID_INT LIKE 'MATER%' /*UNIDADE DE MATERNIDADE*/
                OR (UI.DS_UNID_INT LIKE 'BER%' AND
                ATE.CD_ATENDIMENTO_PAI IS NOT NULL)) /*RN VINCULADO A M?E*/
               /*AND TO_DATE(PM.DT_PRE_MED, 'DD/MM/RRRR') =
               TO_DATE(SYSDATE, 'DD/MM/RRRR')*/
            AND PM.CD_PRE_MED =
                (SELECT MAX(PM1.CD_PRE_MED)
                   FROM PRE_MED PM1
                   JOIN ITPRE_MED IPM1
                     ON IPM1.CD_PRE_MED = PM1.CD_PRE_MED
                   JOIN PW_DOCUMENTO_CLINICO DC
                     ON DC.CD_DOCUMENTO_CLINICO = PM1.CD_DOCUMENTO_CLINICO
                  WHERE PM1.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO
                    AND IPM1.CD_TIP_PRESC = 28847
                    AND IPM1.DH_CANCELADO IS NULL
                    AND DC.TP_STATUS = 'FECHADO')

         UNION ALL

         SELECT DISTINCT NULL ATENDIMENTO,
                         NULL NOME_PACIENTE,
                         NULL TP_ACOM,
                         NULL LEITO,
                         NULL OBSERVACAO,
                         NULL JUSTIFICATIVA,
                         NULL DIAS_INTERNACAO,
                         NULL DH_NASC,
                         NULL DT_ALTA_PRESC,
                         NULL HR_ALTA_PRESC,
                         NULL HR_ALTA_MEDICA,
                         NULL HR_ALTA_HOSPITALAR,
                         NVL((SELECT UI2.CD_UNID_INT
                               FROM ATENDIME ATE2
                               JOIN LEITO LT2
                                 ON LT2.CD_LEITO = ATE2.CD_LEITO
                               JOIN UNID_INT UI2
                                 ON UI2.CD_UNID_INT = LT2.CD_UNID_INT
                              WHERE ATE2.CD_ATENDIMENTO =
                                    ATE.CD_ATENDIMENTO_PAI),
                             UI.CD_UNID_INT) CD_UNIDADE,
                         NVL((SELECT UI2.DS_UNID_INT
                               FROM ATENDIME ATE2
                               JOIN LEITO LT2
                                 ON LT2.CD_LEITO = ATE2.CD_LEITO
                               JOIN UNID_INT UI2
                                 ON UI2.CD_UNID_INT = LT2.CD_UNID_INT
                              WHERE ATE2.CD_ATENDIMENTO =
                                    ATE.CD_ATENDIMENTO_PAI),
                             UI.DS_UNID_INT) DS_UNI_INT,
                         NULL ALTA_HOSPITALAR,
                         (CASE
                           WHEN NVL((SELECT UI2.DS_UNID_INT
                                      FROM ATENDIME ATE2
                                      JOIN LEITO LT2
                                        ON LT2.CD_LEITO = ATE2.CD_LEITO
                                      JOIN UNID_INT UI2
                                        ON UI2.CD_UNID_INT = LT2.CD_UNID_INT
                                     WHERE ATE2.CD_ATENDIMENTO =
                                           ATE.CD_ATENDIMENTO_PAI),
                                    UI.DS_UNID_INT) LIKE '%MATERN%' THEN
                            'MATER'
                           ELSE
                            'OUTRA'
                         END) COND_MATER,
                         1 ORDEM
           FROM ATENDIME ATE
           JOIN PRE_MED PM
             ON PM.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO
           JOIN ITPRE_MED IPM
             ON IPM.CD_PRE_MED = PM.CD_PRE_MED
           JOIN TIP_PRESC TP
             ON TP.CD_TIP_PRESC = IPM.CD_TIP_PRESC
           JOIN PACIENTE PAC
             ON PAC.CD_PACIENTE = ATE.CD_PACIENTE
           JOIN LEITO LT
             ON LT.CD_LEITO = ATE.CD_LEITO
           JOIN UNID_INT UI
             ON UI.CD_UNID_INT = LT.CD_UNID_INT
          WHERE ATE.TP_ATENDIMENTO = 'I'
            AND LT.CD_TIP_ACOM NOT IN (3, 4, 5, 19, 20) /*UTI'S*/
           AND ATE.CD_MULTI_EMPRESA = 1
           AND ATE.DT_ALTA IS NULL
           AND IPM.CD_TIP_PRESC = 28847 /*RN VINCULADO A M?E*/
           AND IPM.DH_CANCELADO IS NULL
              /*AND TO_DATE(PM.DT_PRE_MED, 'DD/MM/RRRR') =
              TO_DATE(SYSDATE, 'DD/MM/RRRR')*/
           AND PM.CD_PRE_MED =
               (SELECT MAX(PM1.CD_PRE_MED)
                  FROM PRE_MED PM1
                  JOIN ITPRE_MED IPM1
                    ON IPM1.CD_PRE_MED = PM1.CD_PRE_MED
                  JOIN PW_DOCUMENTO_CLINICO DC
                    ON DC.CD_DOCUMENTO_CLINICO = PM1.CD_DOCUMENTO_CLINICO
                 WHERE PM1.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO
                   AND IPM1.CD_TIP_PRESC = 28847
                   AND IPM1.DH_CANCELADO IS NULL
                   AND DC.TP_STATUS = 'FECHADO')

        ) SB1
 WHERE NOT EXISTS
 (SELECT 1
          FROM DBAMV.PW_DOCUMENTO_CLINICO DC3
          JOIN DBAMV.PW_EDITOR_CLINICO EC3
            ON EC3.CD_DOCUMENTO_CLINICO = DC3.CD_DOCUMENTO_CLINICO
         WHERE EC3.CD_DOCUMENTO = 673
           AND DC3.TP_STATUS = 'FECHADO'
           AND DC3.CD_ATENDIMENTO = SB1.ATENDIMENTO)

 ORDER BY DS_UNID_INT, ORDEM, ATENDIMENTO;
