SELECT TO_CHAR((SELECT MIN(STP.DH_PROCESSO) FROM SACR_TEMPO_PROCESSO STP 
WHERE STP.CD_ATENDIMENTO =  PL.CD_ATENDIMENTO AND STP.CD_TIPO_TEMPO_PROCESSO = 50),'DD-MM-RRRR HH24:MI:SS') DT_CHAMA_COLETA
      ,TO_CHAR(MIN(A.DT_COLETA),'DD-MM-RRRR HH24:MI:SS') DT_COLETA
      
      
     from dbamv.ped_lab pl
     inner join dbamv.itped_lab it on it.cd_ped_lab = pl.cd_ped_lab
     inner join dbamv.amostra_exa_lab axl on axl.cd_itped_lab = it.cd_itped_lab
     inner join dbamv.amostra a on a.cd_amostra = axl.cd_amostra     
     WHERE A.DT_COLETA BETWEEN TO_DATE ('09/10/2023', 'DD/MM/RRRR') AND TO_DATE('10/10/2023', 'DD/MM/RRRR') 
     GROUP BY A.DT_COLETA,
     PL.CD_ATENDIMENTO
