SELECT * FROM ADMISSAO_CO C
WHERE c.cd_atendimento = 11694428
AND C.CD_ADMISSAO_CO = 31827
-------------DELETE---------------------------
DELETE FROM ADMISSAO_CO C
WHERE c.cd_atendimento = 11694428
AND C.CD_ADMISSAO_CO = 31827
--C.CD_ADMISSAO_CO IN (31757,31758)
-------------UPDATE-------------------------------------------------
SELECT ROWID, C.* FROM ADMISSAO_CO C 
WHERE C.CD_ATENDIMENTO = 11694428
AND C.CD_ADMISSAO_CO = 31827
 ----------------------------------------------------------------
SELECT * FROM RECEM_NASCIDO CC
WHERE cc.cd_atendimento = 11694875

--CC.CD_ADMISSAO_CO IN (31757,31758)
