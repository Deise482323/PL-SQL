Select ue.cd_estoque, e.ds_estoque, u.nm_usuario, u.sn_ativo,e.cd_multi_empresa
  from usu_estoque ue
  join estoque e
    on e.cd_estoque = ue.cd_estoque
  join dbasgu.usuarios u
    on u.cd_usuario = ue.cd_id_do_usuario
    where u.sn_ativo = 'S' 
