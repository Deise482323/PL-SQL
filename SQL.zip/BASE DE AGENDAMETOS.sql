SELECT DISTINCT IT.DT_GRAVACAO AS DATA_AGENDAMENTO,
                
                CASE
                  WHEN IT.CD_ATENDIMENTO IS NOT NULL THEN
                   TO_CHAR(IT.CD_ATENDIMENTO)
                  ELSE
                   'N�o Compareceu'
                END AS ATENDIMENTO,
                
                DECODE(NVL(A.TP_ATENDIMENTO, 'A'),
                       'A',
                       'CONSULTA',
                       'E',
                       'EXAME') AS TIPO_ATENDIMENTO,
                
                P.CD_PACIENTE  AS SAME,
                IT.NM_PACIENTE AS PACIENTE,
                
                CASE
                  WHEN IT.CD_ATENDIMENTO IS NOT NULL THEN
                   'Agendado e executado'
                  ELSE
                   'S� agendado'
                END AS STATUS_COMPARECIMENTO

  FROM IT_AGENDA_CENTRAL IT
  LEFT JOIN ATENDIME A
    ON IT.CD_ATENDIMENTO = A.CD_ATENDIMENTO
  LEFT JOIN PACIENTE P
    ON IT.CD_PACIENTE = P.CD_PACIENTE

   WHERE TRUNC(IT.DT_GRAVACAO) BETWEEN ADD_MONTHS(TRUNC(SYSDATE), -6) AND TRUNC(SYSDATE)
   AND NVL(A.TP_ATENDIMENTO, 'A') IN ('A', 'E')
   

 
