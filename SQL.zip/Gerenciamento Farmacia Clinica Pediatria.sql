Select '<table><tr><td><font color=black size=1>' || cd_unid_int ||
       '</font></td></tr></table>' Unidade,
       '<table><tr><td><font color=black size=1>' || cd_atendimento ||
       '</font></td></tr></table>' ATENDIMENTO,
       case
         when prioridade = '1' then
          '<table><tr><td><font color=black size=1>' || nm_paciente ||
          '</font></td></tr></table>'
         when prioridade = '0' then
          '<table><tr><td><b><font color=black size=1>' || nm_paciente ||
          '</font></b></td></tr></table>'
       end nm_paciente,
       '<table><tr><td><font color=black size=1>' || medico_resp ||
       '</font></td></tr></table>' MEDICO,
       '<table><tr><td><font color=black size=1>' || ds_leito ||
       '</font></td></tr></table>' LEITO,
       '<table><tr><td><font color=black size=1>' || dias_leito ||
       '</font></td></tr></table>' DIAS_LEITO,
       '<table><tr><td><font color=black size=1>' || dias_int ||
       '</font></td></tr></table>' DIAS_INT,
       case
         when dt_recon_admissao is null and hr >= '24' and hr <= '48' then
          '<table bgcolor=yellow   width=60 height=20><tr><td align=center><font color=yellow size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when dt_recon_admissao is null and hr >= '48' then
          '<table bgcolor=red          width=20 height=20><tr><td align=center><font color=red size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when dt_recon_admissao is not null then
          '<table bgcolor=green        width=20 height=20><tr><td align=center><font color=green size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when dt_recon_admissao is null and hr < '24' then
          '<table bgcolor=white   width=60 height=20><tr><td align=center><font color=white size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
       END RECONCILIACAO_ADMISSAO,
       '<table bgcolor=gray width=20 height=20><tr><td align=center>' ||
       result_avaliacao ||
       '<font color=black size=1><b></font></td></tr></table></font>' SCORE,
       CASE
         when result_avaliacao >= 8 and result_avaliacao <= 10 and
              hr_evo > 24 and hr_evo <= 48 and result_avaliacao is not null and
              dt_ult_evo is not null then
          '<table bgcolor=yellow    width=20 height=20><tr><td align=center><font color=yellow size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when result_avaliacao >= 8 and result_avaliacao <= 10 and
              hr_leito_atual > 24 and hr_leito_atual <= 48 and
              result_avaliacao is not null and dt_ult_evo is null then
          '<table bgcolor=yellow    width=20 height=20><tr><td align=center><font color=yellow size=1>' ||
          'TESTE' || '<b></font></td></tr></table></font>'
         when result_avaliacao >= 8 and result_avaliacao <= 10 and
              dt_ult_evo is null and hr_leito_atual > 24 and
              hr_leito_atual <= 48 then
          '<table bgcolor=yellow    width=20 height=20><tr><td align=center><font color=yellow size=1>' ||
          'TESTE' || '<b></font></td></tr></table></font>'
         when result_avaliacao >= 11 and hr_evo > 24 and
              dt_ult_evo is not null then
          '<table bgcolor=red   width=20 height=20><tr><td align=center><font color=red size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when result_avaliacao >= 8 and result_avaliacao <= 10 and
              hr_evo > 48 and result_avaliacao is not null and
              dt_ult_evo is not null then
          '<table bgcolor=red   width=20 height=20><tr><td align=center><font color=red size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when result_avaliacao >= 11 and dt_ult_evo is null and
              hr_leito_atual > 24 then
          '<table bgcolor=red   width=20 height=20><tr><td align=center><font color=red size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when hr_evo >= 0 and hr_evo <= 24 and dt_ult_evo is not null and
              result_avaliacao is not null then
          '<table bgcolor=green   width=20 height=20><tr><td align=center><font color=green size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when hr_leito_atual >= 0 and hr_leito_atual <= 24 and
              dt_ult_evo is null and result_avaliacao is not null then
          '<table bgcolor=green   width=20 height=20><tr><td align=center><font color=green size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when result_avaliacao >= 0 and result_avaliacao <= 7 then
          '<table><tr><td><font color=black size=1>' || 'NSA' ||
          '</font></td></tr></table>'
       END evolucao,
       '<table><tr><td><font color=black size=1>' || leito_anterior ||
       '</font></td></tr></table>' LEITO_ANTERIOR,
       CASE
         when dt_recon_transf is null THEN
          '<table bgcolor=white          width=20 height=20><tr><td align=center><font color=white size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when dt_recon_transf is not null and
              cd_unid_int_transf = cd_unid_int THEN
          '<table bgcolor=green        width=20 height=20><tr><td align=center><font color=green size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when dt_recon_transf is not null and
              cd_unid_int_transf <> cd_unid_int THEN
          '<table bgcolor=red          width=20 height=20><tr><td align=center><font color=red size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when cd_leito = cd_leito_anterior then
          '<table bgcolor=white          width=20 height=20><tr><td align=center><font color=white size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
       END RECONCILIACAO_TRANSF,
       
       CASE
         when Beira_leito is null or Beira_leito = '' THEN
          '<table bgcolor=white          width=20 height=20><tr><td align=center><font color=black size=1><b>' || ' ' ||
          '</font></td></tr></table></font>'
         when Beira_leito = 'SIM' THEN
          '<table bgcolor=white        width=20 height=20><tr><td align=center><font color=black size=1><b>' ||
          'SIM' || '</font></td></tr></table></font>'
         when Beira_leito = 'NAO' THEN
          '<table bgcolor=white          width=20 height=20><tr><td align=center><font color=black size=1><b>' ||
          'NAO' || '</font></td></tr></table></font>'
       END Visita_Beira_Leito,
       
       CASE
         when ALTA_DOC is null and result_avaliacao > 7 THEN
          '<table bgcolor=red          width=20 height=20><tr><td align=center><font color=red size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when ALTA_DOC is not null and result_avaliacao > 7 then
          '<table bgcolor=green        width=20 height=20><tr><td align=center><font color=green size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         when ALTA_DOC is null and result_avaliacao < 8 then
          '<table bgcolor=white          width=20 height=20><tr><td align=center><font color=white size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
         else
          '<table bgcolor=white          width=20 height=20><tr><td align=center><font color=white size=1><b>' ||
          'TESTE' || '</font></td></tr></table></font>'
       
       END status_ori_alta

  from (select nm_paciente,
               ds_leito,
               cd_leito,
               to_number(trunc(tempo_registro * 24)) hr,
               trunc(tempo_registro * 24) || ':' ||
               lpad(replace(trunc(mod(tempo_registro * 1440, 60)), '-', ''),
                    2,
                    '00') hr_no_leito_adm, -- tempo que o paciente tem desde a mov_int de admissao 
               dh_mov_int,
               to_number(trunc(temp_hr_leito * 24)) hr_leito_atual,
               temp_hr_leito,
               to_char(sysdate, 'dd/mm/rrrr hh24:mi') data_atual,
               cd_unid_int,
               ds_unid_int,
               nm_setor,
               cd_atendimento,
               dias_int,
               medico_resp,
               dt_recon_admissao,
               result_avaliacao,
               dias_leito,
               leito_anterior,
               cd_leito_anterior,
               ent_leito,
               (SELECT CD_UNID_INT
                  FROM LEITO
                 WHERE DS_LEITO IN (R_LEITO_TRANSF)) CD_UNID_INT_TRANSF,
               dt_recon_transf,
               Beira_leito,
               data_alta_presc,
               dt_ult_evo,
               temp_evo,
               trunc(temp_evo * 24) || ':' ||
               lpad(replace(trunc(mod(temp_evo * 1440, 60)), '-', ''),
                    2,
                    '00') hr_temp_evo,
               to_number(trunc(temp_evo * 24)) hr_evo,
               justificativa,
               --dt_recon_alta,
               CASE
                 when data_alta_presc is null THEN
                  '1'
                 when data_alta_presc is not null then
                  '0'
               END prioridade,
               ALTA_DOC
        
          from (select p.nm_paciente,
                       l.ds_leito,
                       l.cd_leito,
                       (to_date(to_char(sysdate, 'dd/mm/rrrr hh24:mi'),
                                'dd/mm/rrrr hh24:mi')) -
                       (select to_date(to_char(dt_mov_int, 'dd/mm/rrrr') || ' ' ||
                                       to_char(hr_mov_int, 'hh24:mi'),
                                       'dd/mm/rrrr hh24:mi')
                          from mov_int
                         where mov_int.cd_mov_int in
                               (select max(cd_mov_int)
                                  from mov_int mx
                                 where mx.cd_atendimento = a.CD_ATENDIMENTO
                                   and mx.tp_mov = 'I')) tempo_registro,
                       (select to_date(to_char(dt_mov_int, 'dd/mm/rrrr') || ' ' ||
                                       to_char(hr_mov_int, 'hh24:mi'),
                                       'dd/mm/rrrr hh24:mi')
                          from mov_int
                         where mov_int.cd_mov_int in
                               (select max(cd_mov_int)
                                  from mov_int mx
                                 where mx.cd_atendimento = a.CD_ATENDIMENTO
                                   and mx.tp_mov = 'I')) dh_mov_int,
                       
                       (to_date(to_char(sysdate, 'dd/mm/rrrr hh24:mi'),
                                'dd/mm/rrrr hh24:mi')) -
                       (select to_date(to_char(dt_mov_int, 'dd/mm/rrrr') || ' ' ||
                                       to_char(hr_mov_int, 'hh24:mi'),
                                       'dd/mm/rrrr hh24:mi')
                          from mov_int
                         where mov_int.cd_mov_int in
                               (select max(cd_mov_int)
                                  from mov_int mx
                                 where mx.cd_atendimento = a.CD_ATENDIMENTO
                                   and mx.tp_mov = 'I')) temp_hr_leito,
                       l.cd_unid_int,
                       u.DS_UNID_INT,
                       s.NM_SETOR,
                       a.CD_ATENDIMENTO,
                       trunc(sysdate) - trunc(a.DT_ATENDIMENTO) dias_int,
                       pr.nm_prestador medico_resp,
                       (SELECT pdc1.dh_criacao
                          FROM dbamv.editor_registro_campo erc
                         inner join dbamv.pw_editor_clinico pe2
                            on erc.cd_registro = pe2.cd_editor_registro
                         inner join dbamv.pw_documento_clinico pdc1
                            on pe2.cd_documento_clinico =
                               pdc1.cd_documento_clinico
                         INNER JOIN dbamv.editor_campo ec
                            ON ec.cd_campo = erc.cd_campo
                         where erc.cd_registro IN
                               (SELECT min(pe.cd_editor_registro)
                                  FROM dbamv.pw_editor_clinico pe
                                 iNNER JOIN dbamv.pw_documento_clinico pe1
                                    ON pe1.cd_documento_clinico =
                                       pe.cd_documento_clinico
                                 where pe1. cd_atendimento = a.CD_ATENDIMENTO
                                   and pe.cd_documento = 610
                                   AND PE1.TP_STATUS = 'FECHADO')
                           AND (upper(ec.ds_identificador) =
                               upper('DS_ATO_RECONCILIACAO_1_1'))
                           and to_char(erc.lo_valor) = to_char('AD||Admiss�o')) dt_recon_admissao,
                       
                       (SELECT pdc1.dh_criacao
                          FROM dbamv.editor_registro_campo erc
                         inner join dbamv.pw_editor_clinico pe2
                            on erc.cd_registro = pe2.cd_editor_registro
                         inner join dbamv.pw_documento_clinico pdc1
                            on pe2.cd_documento_clinico =
                               pdc1.cd_documento_clinico
                         INNER JOIN dbamv.editor_campo ec
                            ON ec.cd_campo = erc.cd_campo
                         where erc.cd_registro IN
                               (SELECT MAX(pe.cd_editor_registro)
                                  FROM dbamv.pw_editor_clinico pe
                                 iNNER JOIN dbamv.pw_documento_clinico pe1
                                    ON pe1.cd_documento_clinico =
                                       pe.cd_documento_clinico
                                 where pe1. cd_atendimento = a.CD_ATENDIMENTO
                                   and pe.cd_documento = 610)
                           AND (upper(ec.ds_identificador) =
                               upper('DS_ATO_RECONCILIACAO_1_1'))
                           and to_char(erc.lo_valor) =
                               to_char('TR||Tranfesr�ncia entre unidades')) dt_recon_transf,
                       
                       (SELECT dbms_lob.substr(LO_VALOR)
                          FROM dbamv.editor_registro_campo erc2
                         INNER JOIN dbamv.editor_campo ec2
                            ON ec2.cd_campo = erc2.cd_campo
                         WHERE ERC2.CD_REGISTRO = (SELECT erc.cd_registro
                          FROM dbamv.editor_registro_campo erc
                         inner join dbamv.pw_editor_clinico pe2
                            on erc.cd_registro = pe2.cd_editor_registro
                         inner join dbamv.pw_documento_clinico pdc1
                            on pe2.cd_documento_clinico =
                               pdc1.cd_documento_clinico
                         INNER JOIN dbamv.editor_campo ec
                            ON ec.cd_campo = erc.cd_campo
                         where erc.cd_registro IN
                               (SELECT MAX(pe.cd_editor_registro)
                                  FROM dbamv.pw_editor_clinico pe
                                 iNNER JOIN dbamv.pw_documento_clinico pe1
                                    ON pe1.cd_documento_clinico =
                                       pe.cd_documento_clinico
                                 where pe1. cd_atendimento = a.CD_ATENDIMENTO
                                   and pe.cd_documento = 610)
                           AND (upper(ec.ds_identificador) =
                               upper('DS_ATO_RECONCILIACAO_1_1'))
                           and to_char(erc.lo_valor) =
                               to_char('TR||Tranfesr�ncia entre unidades'))
                           and ec2.ds_identificador =  'DS_ATO_RECONC_1') R_LEITO_TRANSF,
                               
                       (SELECT pa.vl_resultado
                          FROM dbamv.pagu_avaliacao pa
                         WHERE pa.cd_atendimento = a.cd_atendimento
                           AND pa.cd_formula = 33
                           AND pa.dh_avaliacao =
                               (select max(pa1.dh_avaliacao) dh_avaliacao
                                  from dbamv.pagu_avaliacao pa1
                                 where pa.cd_formula = pa1.cd_formula
                                   and pa1.cd_atendimento = pa.cd_atendimento)) result_avaliacao,
                       (SELECT CASE
                                 WHEN to_char(erc.lo_valor) = 'true' THEN
                                  'SIM'
                                 ELSE
                                  'N�O'
                               END BEIRA_LITO
                          FROM dbamv.editor_registro_campo erc
                         inner join dbamv.pw_editor_clinico pe2
                            on erc.cd_registro = pe2.cd_editor_registro
                         inner join dbamv.pw_documento_clinico pdc1
                            on pe2.cd_documento_clinico =
                               pdc1.cd_documento_clinico
                         INNER JOIN dbamv.editor_campo ec
                            ON ec.cd_campo = erc.cd_campo
                         where erc.cd_registro IN
                               (SELECT MAX(pe.cd_editor_registro)
                                  FROM dbamv.pw_editor_clinico pe
                                 iNNER JOIN dbamv.pw_documento_clinico pe1
                                    ON pe1.cd_documento_clinico =
                                       pe.cd_documento_clinico
                                 where pe1. cd_atendimento = a.CD_ATENDIMENTO
                                   and pe.cd_documento = 802)
                           AND upper(ec.ds_identificador) =
                               upper('TXT_VISITA_BEIRA_LEITO_SIM_1')) Beira_leito,
                       dbamv.pkg_hnb_painel_assistencial.get_dias_leito(a.cd_atendimento) dias_leito,
                       (select ds_leito
                          from dbamv.leito ll
                         where ll.cd_leito =
                               dbamv.hnb_leito_anterior(a.cd_atendimento)) leito_anterior,
                       (select cd_leito
                          from dbamv.leito ll
                         where ll.cd_leito =
                               dbamv.hnb_leito_anterior(a.cd_atendimento)) cd_leito_anterior,
                       dbamv.pkg_hnb_painel_assistencial.get_data_entr_no_leito(a.CD_ATENDIMENTO) ent_leito,
                       presc_alta.data_alta_presc,
                       presc_alta.justificativa,
                       (SELECT pdc1.dh_criacao
                          FROM dbamv.editor_registro_campo erc
                         inner join dbamv.pw_editor_clinico pe2
                            on erc.cd_registro = pe2.cd_editor_registro
                         inner join dbamv.pw_documento_clinico pdc1
                            on pe2.cd_documento_clinico =
                               pdc1.cd_documento_clinico
                         INNER JOIN dbamv.editor_campo ec
                            ON ec.cd_campo = erc.cd_campo
                         where erc.cd_registro IN
                               (SELECT min(pe.cd_editor_registro)
                                  FROM dbamv.pw_editor_clinico pe
                                 iNNER JOIN dbamv.pw_documento_clinico pe1
                                    ON pe1.cd_documento_clinico =
                                       pe.cd_documento_clinico
                                 where pe1. cd_atendimento = a.CD_ATENDIMENTO
                                   and pe.cd_documento = 610)
                           AND (upper(ec.ds_identificador) =
                               upper('DS_ATO_RECONCILIACAO_1_1'))
                           and to_char(erc.lo_valor) = to_char('A||Alta')) dt_recon_alta,
                       
                       (SELECT CASE
                                 WHEN to_char(erc.lo_valor) = 'true' THEN
                                  pdc1.Dh_Criacao
                                 ELSE
                                  TO_DATE(TO_CHAR(''))
                               END DT_ULT_EVO
                          FROM dbamv.editor_registro_campo erc
                         inner join dbamv.pw_editor_clinico pe2
                            on erc.cd_registro = pe2.cd_editor_registro
                         inner join dbamv.pw_documento_clinico pdc1
                            on pe2.cd_documento_clinico =
                               pdc1.cd_documento_clinico
                         INNER JOIN dbamv.editor_campo ec
                            ON ec.cd_campo = erc.cd_campo
                         where erc.cd_registro IN
                               (SELECT MAX(pe.cd_editor_registro)
                                  FROM dbamv.pw_editor_clinico pe
                                 iNNER JOIN dbamv.pw_documento_clinico pe1
                                    ON pe1.cd_documento_clinico =
                                       pe.cd_documento_clinico
                                 where pe1. cd_atendimento = a.CD_ATENDIMENTO
                                   and pe.cd_documento = 802)
                           AND upper(ec.ds_identificador) =
                               upper('RB_EVO_FARMA_SIM_1')) dt_ult_evo,
                       
                       (SELECT to_date(to_char(sysdate, 'dd/mm/rrrr') || ' ' ||
                                       to_char(sysdate, 'hh24:mi'),
                                       'dd/mm/rrrr hh24:mi') -
                               (SELECT CASE
                                         WHEN to_char(erc.lo_valor) = 'true' THEN
                                          pdc1.Dh_Criacao
                                         ELSE
                                          TO_DATE(TO_CHAR(''))
                                       END TEMP_EVO
                                  FROM dbamv.editor_registro_campo erc
                                 inner join dbamv.pw_editor_clinico pe2
                                    on erc.cd_registro = pe2.cd_editor_registro
                                 inner join dbamv.pw_documento_clinico pdc1
                                    on pe2.cd_documento_clinico =
                                       pdc1.cd_documento_clinico
                                 INNER JOIN dbamv.editor_campo ec
                                    ON ec.cd_campo = erc.cd_campo
                                 where erc.cd_registro IN
                                       (SELECT MAX(pe.cd_editor_registro)
                                          FROM dbamv.pw_editor_clinico pe
                                         iNNER JOIN dbamv.pw_documento_clinico pe1
                                            ON pe1.cd_documento_clinico =
                                               pe.cd_documento_clinico
                                         where pe1.
                                         cd_atendimento = a.CD_ATENDIMENTO
                                           and pe.cd_documento = 802)
                                   AND upper(ec.ds_identificador) =
                                       upper('RB_EVO_FARMA_SIM_1'))
                          from atendime a2
                         where a.CD_ATENDIMENTO = a2.CD_ATENDIMENTO) temp_evo,
                       
                       (SELECT SUBSTR(to_char(erc.lo_valor), 6, 3)
                          FROM dbamv.editor_registro_campo erc
                         inner join dbamv.pw_editor_clinico pe2
                            on erc.cd_registro = pe2.cd_editor_registro
                         inner join dbamv.pw_documento_clinico pdc1
                            on pe2.cd_documento_clinico =
                               pdc1.cd_documento_clinico
                         INNER JOIN dbamv.editor_campo ec
                            ON ec.cd_campo = erc.cd_campo
                         where erc.cd_registro IN
                               (SELECT MAX(pe.cd_editor_registro)
                                  FROM dbamv.pw_editor_clinico pe
                                 iNNER JOIN dbamv.pw_documento_clinico pe1
                                    ON pe1.cd_documento_clinico =
                                       pe.cd_documento_clinico
                                 where pe1. cd_atendimento = a.CD_ATENDIMENTO
                                   and pe.cd_documento = 802)
                           AND upper(ec.ds_identificador) =
                               upper('SN_ORI_ALTA_1_1')) ALTA_DOC
                
                  from atendime a,
                       leito l,
                       unid_int u,
                       setor s,
                       prestador pr,
                       paciente p,
                       (select distinct b.cd_atendimento cd_atendimento,
                                        h.ds_tip_presc || ' - ' ||
                                        a.ds_justificativa Justificativa,
                                        TO_CHAR(C.DT_ATENDIMENTO, 'DD/MM/YYYY') Interna��o,
                                        TO_CHAR(b.dh_impressao, 'DD/MM/YYYY') alta,
                                        to_char(b.dh_impressao, 'HH24:MI:SS') data_alta_presc,
                                        TO_CHAR(c.hr_alta_medica, 'HH24:MI:SS') alta_medica,
                                        TO_CHAR(c.hr_alta, 'HH24:MI:SS') alta_hospitalar
                        
                          from itpre_med a, pre_med b, atendime c, tip_presc h
                         where a.cd_pre_med = b.cd_pre_med
                           and b.cd_atendimento = c.cd_atendimento
                           and a.cd_tip_presc = h.cd_tip_presc
                           and a.cd_tip_presc = 28847
                           AND C.CD_MULTI_EMPRESA = 1
                           and b.dt_pre_med between
                               to_date(sysdate - 1, 'dd/mm/rrrr') and
                               to_date(sysdate, 'dd/mm/rrrr')) presc_alta
                
                 where a.cd_paciente = p.cd_paciente
                   and a.CD_LEITO = l.cd_leito
                   and l.cd_unid_int = u.CD_UNID_INT
                   and u.CD_SETOR = s.CD_SETOR
                   and a.CD_PRESTADOR = pr.cd_prestador
                   and a.CD_ATENDIMENTO = presc_alta.cd_atendimento(+)
                   and a.TP_ATENDIMENTO = 'I'
                   and u.CD_UNID_INT in ('12','52')
                   and a.DT_ALTA is null))

 order by prioridade, cd_unid_int, nm_paciente
