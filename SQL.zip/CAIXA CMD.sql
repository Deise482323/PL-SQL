
SELECT MC.CD_MOV_CAIXA,
       MC.CD_LOTE_CAIXA,
       NVL(MC.CD_PAGCON_PAG,
           (SELECT DC1.CD_PAGCON_PAG
              FROM DOC_CAIXA DC1
              JOIN PAGCON_PAG PCP1
                ON PCP1.CD_PAGCON_PAG = DC1.CD_PAGCON_PAG
             WHERE DC1.CD_DOC_CAIXA = MC.CD_DOC_CAIXA)) CD_PAGCON_PAG,
       NVL(MC.CD_RECCON_REC,
           NVL((SELECT DC1.CD_RECCON_REC
                 FROM DOC_CAIXA DC1
                 JOIN RECCON_REC RCR1
                   ON RCR1.CD_RECCON_REC = DC1.CD_RECCON_REC
                WHERE DC1.CD_DOC_CAIXA = MC.CD_DOC_CAIXA),
               (SELECT RCR1.CD_RECCON_REC
                  FROM RECCON_REC RCR1
                 WHERE RCR1.CD_MOV_CAIXA = MC.CD_MOV_CAIXA))) CD_RECCON_REC,
       MC.CD_DOC_CAIXA,
       C.CD_CAIXA,
       C.DS_CAIXA,
       MC.DS_MOV_CAIXA,
       MC.DT_MOVIMENTACAO,
       MC.VL_MOVIMENTACAO,
       NVL((SELECT PC.DS_CONTA
             FROM PLANO_CONTAS PC
            WHERE PC.CD_REDUZIDO = MC.CD_REDUZIDO),
           IR.DS_ITEM_RES) DS_CONTA,
       NVL((SELECT S.NM_SETOR FROM SETOR S WHERE S.CD_SETOR = MC.CD_SETOR),
           S.NM_SETOR) NM_SETOR,
       MC.DT_LANCAMENTO,
       MC.DS_MOVIMENTACAO_PADRAO,
       MC.TP_ORIGEM_MOV,
       DECODE(MC.TP_ORIGEM_MOV,
              'RE',
              'Recebimento',
              'ER',
              'Estorno de Recebimento',
              'PA',
              'Pagamento',
              'TR',
              'Transfer�ncia',
              'DE',
              'Dep�sito',
              'RF',
              'Refor�o de caixa',
              'CA',
              'Dep. Antecipado',
              'RD',
              'Receita Direta',
              'DD',
              'Despesa Direta',
              'DV',
              'Devolu��o',
              'RN',
              'Renegocia��o',
              'TE',
              'Troca de Esp�cie',
              'CN',
              'Cancelamento de Esp�cia') ORIGEM_MOV
           
  FROM LOTE_CAIXA LC
  JOIN MOV_CAIXA MC
    ON MC.CD_LOTE_CAIXA = LC.CD_LOTE_CAIXA
  JOIN CAIXA C
    ON C.CD_CAIXA = LC.CD_CAIXA
  LEFT OUTER JOIN DBAMV.PAGCON_PAG PCP
    ON PCP.CD_PAGCON_PAG = MC.CD_PAGCON_PAG
  LEFT OUTER JOIN DBAMV.ITCON_PAG ICP
    ON ICP.CD_ITCON_PAG = PCP.CD_ITCON_PAG
  LEFT OUTER JOIN DBAMV.CON_PAG CP
    ON CP.CD_CON_PAG = ICP.CD_CON_PAG
  LEFT OUTER JOIN DBAMV.RATCON_PAG RCP
    ON RCP.CD_CON_PAG = CP.CD_CON_PAG
  LEFT OUTER JOIN DBAMV.SETOR S
    ON S.CD_SETOR = RCP.CD_SETOR
  LEFT OUTER JOIN DBAMV.ITEM_RES IR
    ON IR.CD_ITEM_RES = RCP.CD_ITEM_RES

 WHERE C.CD_MULTI_EMPRESA IN (2)
   AND MC.CD_MOTIVO_CANC IS NULL
      --AND MC.CD_SETOR IS NOT NULL
  -- AND C.CD_CAIXA = {CAIXA}
  /* AND (CASE
         WHEN '{TPDATA}' = 'M' THEN
          TO_DATE(MC.DT_MOVIMENTACAO, 'DD/MM/RRRR')
         WHEN '{TPDATA}' = 'L' THEN*/
          AND TO_DATE(MC.DT_LANCAMENTO, 'DD/MM/RRRR')
        BETWEEN TO_DATE('24/09/2024', 'DD/MM/RRRR') AND
       TO_DATE('01/10/2024', 'DD/MM/RRRR')
