select dc.cd_paciente,
       dc.cd_atendimento,
       dc.cd_usuario,
       dc.cd_prestador,
       p.nm_prestador,
       dc.dh_criacao,
       dc.dh_fechamento,
       dc.nm_documento,
       c.ds_campo,
       TO_CHAR(erc.lo_valor) Pre_Natal
  from dbamv.pw_documento_clinico  dc,
       dbamv.pw_editor_clinico     ec,
       dbamv.editor_registro_campo erc,
       dbamv.editor_campo          c,
       dbamv.prestador             p
 where dc.cd_documento_clinico = ec.cd_documento_clinico
   and erc.cd_campo = c.cd_campo
   and ec.cd_editor_registro = erc.cd_registro
   and p.cd_prestador = dc.cd_prestador
   and ec.cd_documento = 742
   and dc.dh_criacao >=  TO_DATE ('01/08/2023','DD/MM/RRRR') 
   and c.ds_identificador = 'CB_PRE_NATAL_1'
   and dc.tp_status = 'FECHADO'
