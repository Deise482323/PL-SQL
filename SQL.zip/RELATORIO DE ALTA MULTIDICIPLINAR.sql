select
  case when cd_tip_presta = 49 then 1 else 0 end ordem
 ,cd_tip_presta teste
 ,cd_registro_documento
 ,dt_registro
 ,dt_equivalente
 ,cd_atendimento
 ,USER_REL
 ,Alta_Domicilio
 ,Alta_Outros
 ,Resumo_Sim
 ,Resumo_Nao
 ,Receita_Sim
 ,Receita_Nao
 ,Atestado_Sim
 ,Atestado_Nao
 ,Curativo_Sim
 ,Curativo_Nao
 ,Curativo_Desc
,CVD_Sim
,CVD_Nao
,CVD_Desc
,CNE_Sim
,CNE_Nao
,CNE_Desc
,OSTOMIA_Sim
,OSTOMIA_Nao
,OSTOMIA_Desc
,DRENOS_Sim
,DRENOS_Nao
,DRENOS_Desc
,Gesso_Sim
,Gesso_Nao
,Gesso_Desc
,Enfaixamento_Sim
,Enfaixamento_Nao
,Enfaixamento_Desc
,Outros_Sim
,Outros_Nao
,Outros_Desc
,Varizes_Sim
,Varizes_Nao
,Varizes_Desc
,Maternidade_Sim
,Maternidade_Nao
,Maternidade_Desc
,VL_M
,OXI
,DESC_1
,DESC_2
,DESC_3
 ,Resumo
 ,case when Usuario_Resumo is null then Usuario_resumo1 else Usuario_Resumo end Usuario_Resumo
 --,Usuario_Resumo
 --,Usuario_resumo1
 ,Data_Extenso
 ,same
 ,nome
 ,nome_civil
 ,nacto
 ,idade
 ,sexo
 ,convenio
 ,inscr
 ,medico
 ,servico
 ,origem
 ,unidade
 ,leito
 ,dt_ate
 ,hr_ate
 ,(select user from dual)usuario
 ,USER_3
 ,doc_res
 ,CD_DOCUMENTO
 ,null RESUMO_646
from(
/*PEP 2*/
select  tpp.cd_tip_presta
       ,pe.cd_editor_registro cd_registro_documento
       ,pe1.dh_criacao dt_registro
       ,to_char(pe1.dh_criacao,'dd/mm/rrrr') dt_equivalente
       ,pe1.cd_atendimento cd_atendimento
       ,(SELECT
         tp.nm_tip_presta ||': '||
         case when tp.cd_tip_presta = 49 then u.nm_usuario else p.nm_prestador end ||''||CHR(10)||
         case when tp.cd_tip_presta = 49 then '' else  c.ds_conselho ||': '|| P.DS_CODIGO_CONSELHO end USER_LOG
         from sys.dual
         --left outer JOIN DBASGU.USUARIOS U ON U.CD_USUARIO = USER
         left outer JOIN PRESTADOR P ON P.CD_PRESTADOR = U.CD_PRESTADOR
         left outer JOIN DBAMV.TIP_PRESTA TP ON TP.CD_TIP_PRESTA = P.CD_TIP_PRESTA
         left outer JOIN DBAMV.CONSELHO C ON C.CD_CONSELHO = P.CD_CONSELHO) USER_REL

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_SN_ALTA_P_DOMICIO_1','A','S','646','FECHADO','N','200','1'),
         'true',1, null) Alta_Domicilio --usado resultado = P, DEVIDO UTILIZA��O NO RELAT 1414

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_SN_ALTA_OUT_SERV_1','A','S','646','FECHADO','N','200','1'),
         'true',1, null) Alta_Outros

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_RESUMO_ALTA_SIM_1','A','S','646','FECHADO','N','200','1'),
          'true',1, null) Resumo_Sim

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_RESUMO_ALTA_NAO_1','A','S','646','FECHADO','N','200','1'),
          'true',1, null) Resumo_Nao

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_RECEITA_MEDICA_SIM_1','A','S','646','FECHADO','N','200','1'),
           'true',1, null) Receita_Sim

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_RECEITA_MEDICA_NAO_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Receita_Nao

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_ATEST_MEDICO_SIM_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Atestado_Sim

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_ATEST_MEDICO_NAO_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Atestado_Nao

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_CURATIVO_SIM_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Curativo_Sim

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_CURATIVO_NAO_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Curativo_Nao--O

     ,nvl(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','CTXT_CURATIVOS_1','A','S','646','FECHADO','N','200','1'),
          fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','CTXT_CURATIVOS_1','A','S','646','FECHADO','N','200','1')) Curativo_Desc

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_CVD_SIM_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) CVD_Sim

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_CVD_NAO_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) CVD_Nao --O

     ,nvl(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_CVD_1','A','S','646','FECHADO','N','200','1'),
          fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','CTXT_CVD_1','A','S','646','FECHADO','N','200','1')) CVD_Desc

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_CNE_GTT_SIM_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) CNE_Sim

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_CNE_GTT_NAO_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) CNE_Nao--O

     ,nvl(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_CNE_GTT_1','A','S','646','FECHADO','N','200','1'),
          fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','CTXT_CNE_GTT_1','A','S','646','FECHADO','N','200','1')) CNE_Desc

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_OSTOMIA_SIM_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) OSTOMIA_Sim

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_OSTOMIA_NAO_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) OSTOMIA_Nao --O

     ,nvl(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_OSTOMIA_1','A','S','646','FECHADO','N','200','1'),
          fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','CTXT_OSTOMIA_1','A','S','646','FECHADO','N','200','1')) OSTOMIA_Desc

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_DRENOS_SIM_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) DRENOS_Sim

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_DRENOS_NAO_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) DRENOS_Nao --O

     ,nvl(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_DRENOS_1','A','S','646','FECHADO','N','200','1'),
          fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','CTXT_DRENOS_1','A','S','646','FECHADO','N','200','1')) DRENOS_Desc

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_GESSO_TALA_SIM_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Gesso_Sim

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_GESSO_TALA_NAO_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Gesso_Nao --o

     ,nvl(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_GESSO_TALA_1','A','S','646','FECHADO','N','200','1'),
          fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','CTXT_GESSO_TALA_1','A','S','646','FECHADO','N','200','1')) Gesso_Desc

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_ENFAIXAMENTO_SIM_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Enfaixamento_Sim

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_ENFAIXAMENTO_NAO_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Enfaixamento_Nao --O

     ,nvl(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_ENFAIXAMENTO_1','A','S','646','FECHADO','N','200','1'),
          fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','CTXT_ENFAIXAMENTO_1','A','S','646','FECHADO','N','200','1')) Enfaixamento_Desc

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_OUTROS_SIM_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Outros_Sim

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_OUTROS_NAO_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Outros_Nao --O

     ,nvl(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_OUTROS_ORI_1','A','S','646','FECHADO','N','200','1'),
          fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','CTXT_OUTROS_ORI_1','A','S','646','FECHADO','N','200','1')) Outros_Desc


     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_SIM_VARIZES_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Varizes_Sim

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_NAO_VARIZES_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Varizes_Nao --O

     ,nvl(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','CXTX_VARIZES_1','A','S','646','FECHADO','N','200','1'),
          fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','CXTX_VARIZES_1','A','S','646','FECHADO','N','200','1')) Varizes_Desc

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_SIM_MATERNIDADE_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Maternidade_Sim

     ,DECODE(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','RB_NAO_MATERNIDADE_1','A','S','646','FECHADO','N','200','1'),
            'true',1, null) Maternidade_Nao --O

     ,nvl(fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','CXTX_MATERNIDADE_1','A','S','646','FECHADO','N','200','1'),
          fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','CXTX_MATERNIDADE_1','A','S','646','FECHADO','N','200','1')) Maternidade_Desc

     ,fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_MEWS_EVO_1','A','S','646','FECHADO','N','200','1') VL_M

     ,fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_OXI_EVO_1','A','S','646','FECHADO','N','200','1') OXI

     ,fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_DESC1_EVO_1','A','S','646','FECHADO','N','200','1') DESC_1

     ,fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_DESC2_EVO_1','A','S','646','FECHADO','N','200','1') DESC_2

     ,fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_EVOL_ALTA_1','A','S','646','FECHADO','N','200','1') DESC_3

     ,fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_NM_PRESTADORDS_NM_PRESTADOR_DOC_1','A','S','646','FECHADO','N','200','1') USER_3


     ,(SELECT to_char(erc.lo_valor) ds_resposta FROM dbamv.editor_registro_campo erc INNER JOIN dbamv.editor_campo ec ON ec.cd_campo = erc.cd_campo
        where erc.cd_registro = pe.cd_editor_registro
          AND upper(ec.ds_identificador) in ('DS_RESUMO_ALTA_MULTIDISCIPLINAR_1','DS_RIA_ORIENTAPOSALTA_1')) Resumo

     ,(SELECT to_char(erc.lo_valor) ds_resposta FROM dbamv.editor_registro_campo erc INNER JOIN dbamv.editor_campo ec ON ec.cd_campo = erc.cd_campo
        where erc.cd_registro = pe.cd_editor_registro
          AND upper(ec.ds_identificador) in ('DS_RESUMOALTA_MEDICOCRM_1'/*,'DS_RIA_PRESTADOR_1'*/)) Usuario_Resumo

     /*,'MEDICO(A): '||(SELECT to_char(erc.lo_valor) ds_resposta FROM dbamv.editor_registro_campo erc INNER JOIN dbamv.editor_campo ec
        ON ec.cd_campo = erc.cd_campo where erc.cd_registro = pe.cd_editor_registro
        AND (upper(ec.ds_identificador) in ('DS_RIA_PRESTADOR_1'))) Usuario_Resumo1*/

     ,'MEDICO(A): '|| fnc_retorna_historico(a.Cd_Atendimento,'DOCUMENTO','DS_RIA_PRESTADOR_1','A','S','620','FECHADO','N','200','1') Usuario_Resumo1

     ,TO_CHAR(sysdate, '"S�o Paulo," DD "de" fmMonth "de" YYYY.','NLS_DATE_LANGUAGE=PORTUGUESE')Data_Extenso

     ,pa.cd_paciente same

     ,pa.nm_paciente nome
     
     ,case
      when pa.sn_utiliza_nome_social = 'S' 
           and pa.nm_social_paciente is not null
           then 'NOME SOCIAL: ' || pa.nm_social_paciente || ' ' || chr(10) || 'NOME CIVIL: ' || pa.nm_paciente
             else 
               'NOME CIVIL: ' || pa.nm_paciente
               end                
              nome_civil

     ,pa.dt_nascimento nacto

     ,fn_idade(pa.dt_nascimento, 'a A', sysdate) idade

     ,decode(pa.tp_sexo,'M', 'MASC', 'F', 'FEM', '')sexo

     ,c.nm_convenio convenio

     ,a.NR_CARTEIRA inscr

     ,prr.nm_prestador medico

     ,s.ds_servico servico

     ,oa.ds_ori_ate origem

     ,ui.DS_UNID_INT unidade

     ,l.ds_resumo leito

     ,to_char(a.DT_ATENDIMENTO,'dd/mm/rrrr') dt_ate

     ,to_char(a.DT_ATENDIMENTO,'hh24:mi:ss') hr_ate

     ,DECODE(pe.cd_documento, 619,'ALTA_MULTI',620,'RES_INT',646,'ALTA_ENF') doc_res

     ,PE.CD_DOCUMENTO

FROM DBAMV.ATENDIME A
              LEFT OUTER JOIN DBAMV.PACIENTE PA  ON  PA.CD_PACIENTE = A.CD_PACIENTE
              LEFT OUTER JOIN DBAMV.PW_DOCUMENTO_CLINICO PE1 ON PE1.CD_ATENDIMENTO = A.CD_ATENDIMENTO
              INNER JOIN DBAMV.PW_EDITOR_CLINICO PE ON PE.CD_DOCUMENTO_CLINICO = PE1.CD_DOCUMENTO_CLINICO
              INNER JOIN DBAMV.ORI_ATE OA ON OA.CD_ORI_ATE = A.CD_ORI_ATE
              INNER JOIN DBAMV.SERVICO S ON S.CD_SERVICO = A.CD_SERVICO
              INNER JOIN DBAMV.CONVENIO C ON C.CD_CONVENIO = A.CD_CONVENIO
              LEFT OUTER JOIN DBAMV.PRESTADOR PRR ON PRR.CD_PRESTADOR = A.CD_PRESTADOR
              LEFT OUTER JOIN DBASGU.USUARIOS U ON U.CD_USUARIO = pe1.cd_usuario --RD.NM_USUARIO
              LEFT OUTER JOIN DBAMV.PRESTADOR P1 ON P1.CD_PRESTADOR = U.CD_PRESTADOR
              LEFT OUTER JOIN DBAMV.TIP_PRESTA TPP ON TPP.CD_TIP_PRESTA = P1.CD_TIP_PRESTA
              LEFT OUTER JOIN DBAMV.LEITO L ON L.CD_LEITO = A.CD_LEITO
              LEFT OUTER JOIN DBAMV.UNID_INT UI ON UI.CD_UNID_INT =  L.CD_UNID_INT
     where pe.cd_documento = 620
     and a.CD_ATENDIMENTO = 10262264


     and pe.cd_editor_registro in ( select
                                                        max(pe.cd_editor_registro) cd_registro_documento
                                                        from DBAMV.PW_DOCUMENTO_CLINICO PE1, DBAMV.PW_EDITOR_CLINICO PE
                                                        where PE.CD_DOCUMENTO_CLINICO = PE1.CD_DOCUMENTO_CLINICO
                                                        and PE1.CD_ATENDIMENTO = A.CD_ATENDIMENTO
                                                        and pe1.tp_status = 'FECHADO'
                                                        and pe.cd_documento in(620)))
