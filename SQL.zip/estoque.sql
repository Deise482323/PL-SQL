select * from estoque where cd_multi_empresa = 2
