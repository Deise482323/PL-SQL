
SELECT TDP.CD_CON_PAG_PAI,
       TDP.CD_CON_PAG_FILHO,
       TDP.CD_DETALHAMENTO,
       TD.DS_DETALHAMENTO,
       ICP.DT_VENCIMENTO,
       CP.DT_EMISSAO,
       CP.DS_CON_PAG,
       (SELECT DISTINCT F1.NR_CGC_CPF
          FROM DBAMV.CON_PAG CP1
         INNER JOIN DBAMV.TIP_DETCON_PAG TDP1
            ON CP1.CD_CON_PAG = TDP1.CD_CON_PAG_PAI
         INNER JOIN DBAMV.FORNECEDOR F1
            ON CP1.CD_FORNECEDOR = F1.CD_FORNECEDOR
         WHERE CP1.CD_CON_PAG = TDP.CD_CON_PAG_PAI) AS CNPJ,
       CP.NR_DOCUMENTO,
       TDP.VL_DETALHAMENTO,
       PC.CD_CON_COR,
       CC.DS_CON_COR
  FROM DBAMV.CON_PAG CP
 INNER JOIN DBAMV.ITCON_PAG ICP
    ON CP.CD_CON_PAG = ICP.CD_CON_PAG
 INNER JOIN DBAMV.PAGCON_PAG PC
    ON ICP.CD_ITCON_PAG = PC.CD_ITCON_PAG
 INNER JOIN DBAMV.CON_COR CC
    ON PC.CD_CON_COR = CC.CD_CON_COR
 INNER JOIN DBAMV.TIP_DETCON_PAG TDP
    ON CP.CD_CON_PAG = TDP.CD_CON_PAG_PAI
 INNER JOIN DBAMV.TIP_DETALHE TD
    ON TD.CD_DETALHAMENTO = TDP.CD_DETALHAMENTO 
 WHERE ICP.DT_VENCIMENTO BETWEEN TO_DATE('01/01/2024', 'DD/MM/YYYY') AND
       TO_DATE('29/02/2024', 'DD/MM/YYYY')
  AND CP.CD_MULTI_EMPRESA IN (1,2)
AND TD.CD_DETALHAMENTO IN (2,36)
--------------------------

SELECT TDP.CD_CON_PAG_PAI,
       TDP.CD_CON_PAG_FILHO,
       TD.CD_DETALHAMENTO,
       TD.DS_DETALHAMENTO,
       ICP.DT_VENCIMENTO,
       CP.DT_EMISSAO,
       CP.DS_CON_PAG,
       (SELECT DISTINCT F1.NR_CGC_CPF
          FROM DBAMV.CON_PAG CP1
         INNER JOIN DBAMV.TIP_DETCON_PAG TDP1
            ON CP1.CD_CON_PAG = TDP1.CD_CON_PAG_PAI
         INNER JOIN DBAMV.FORNECEDOR F1
            ON CP1.CD_FORNECEDOR = F1.CD_FORNECEDOR
         WHERE CP1.CD_CON_PAG = TDP.CD_CON_PAG_PAI) AS CNPJ,
       CP.NR_DOCUMENTO,
       TDP.VL_DETALHAMENTO,
       PC.CD_CON_COR,
       CC.DS_CON_COR
  FROM DBAMV.CON_PAG CP
 INNER JOIN DBAMV.ITCON_PAG ICP
    ON CP.CD_CON_PAG = ICP.CD_CON_PAG
 INNER JOIN DBAMV.PAGCON_PAG PC
    ON ICP.CD_ITCON_PAG = PC.CD_ITCON_PAG
 INNER JOIN DBAMV.CON_COR CC
    ON PC.CD_CON_COR = CC.CD_CON_COR
 INNER JOIN DBAMV.TIP_DETCON_PAG TDP
    ON CP.CD_CON_PAG = TDP.CD_CON_PAG_PAI
  INNER JOIN DBAMV.TIP_DETALHE TD
    ON TD.CD_DETALHAMENTO = TDP.CD_DETALHAMENTO 
 WHERE ICP.DT_VENCIMENTO 
 
 
  AND CP.CD_MULTI_EMPRESA 
AND TD.CD_DETALHAMENTO IN ({DETALHAMENTO_AUX})
---------------------------------------------------------------

SELECT I.CD_CON_PAG_PAI,
       
       LISTAGG(I.CD_CON_PAG_FILHO, ' / ') WITHIN GROUP(ORDER BY I.CD_DETALHAMENTO) COD_FILHOS,
       
       SUM(I.VL_IMPOSTO_IRRF) I,
       
       SUM(I.VL_IMPOSTO_PCC) P,
       
       SUM(I.VL_IMPOSTO_IRRF) + SUM(I.VL_IMPOSTO_PCC) VL_IMPOSTO,
       
       I.CD_CON_COR,
       
       I.DS_CON_COR BENEFICIARIO,
       
       I.VL_NOTA VALOR_NOTA,
       
       LISTAGG(I.DT_EMISSAO, ' / ') WITHIN GROUP(ORDER BY I.CD_DETALHAMENTO) DT_EMISSAO,
       
       LISTAGG(I.DS_CON_PAG, ' / ') WITHIN GROUP(ORDER BY I.CD_DETALHAMENTO) DESCRICAO,
       
       I.DT_VCTO_IMPOSTO VENCIMENTO,
       
       I.CNPJ,
       
       I.CD_CGC,
       
       I.NR_DOCUMENTO,
       
       I.DT_PAGAMENTO,
  FROM (
        
        SELECT TDP.CD_CON_PAG_PAI,
                
                TDP.CD_CON_PAG_FILHO,
                
                TDP.CD_DETALHAMENTO,
                
                TD.DS_DETALHAMENTO,
                
                ICP.DT_VENCIMENTO AS DT_VCTO_NOTA,
                
                (SELECT DISTINCT ICP2.DT_VENCIMENTO
                 
                   FROM CON_PAG CP2
                 
                  INNER JOIN ITCON_PAG ICP2
                 
                     ON CP2.CD_CON_PAG = ICP2.CD_CON_PAG
                 
                  WHERE CP2.CD_CON_PAG = TDP.CD_CON_PAG_FILHO) AS DT_VCTO_IMPOSTO,
                
                CP.DT_EMISSAO,
                
                CP.DS_CON_PAG,
                
                (SELECT DISTINCT F1.NR_CGC_CPF
                 
                   FROM DBAMV.CON_PAG CP1
                 
                  INNER JOIN DBAMV.TIP_DETCON_PAG TDP1
                 
                     ON CP1.CD_CON_PAG = TDP1.CD_CON_PAG_PAI
                 
                  INNER JOIN DBAMV.FORNECEDOR F1
                 
                     ON CP1.CD_FORNECEDOR = F1.CD_FORNECEDOR
                 
                  WHERE CP1.CD_CON_PAG = TDP.CD_CON_PAG_PAI) AS CNPJ,
                
                CP.NR_DOCUMENTO,
                
                CP.VL_MOEDA AS VL_NOTA,
                
                TDP.VL_DETALHAMENTO VL_IMPOSTO_IRRF,
                
                0 VL_IMPOSTO_PCC,
                
                PC.CD_CON_COR,
                
                CC.DS_CON_COR,
                
                ME.CD_CGC,
                
                ME.CD_MULTI_EMPRESA,
                
                ICP.TP_QUITACAO
        
          FROM DBAMV.CON_PAG CP
        
         INNER JOIN DBAMV.ITCON_PAG ICP
        
            ON CP.CD_CON_PAG = ICP.CD_CON_PAG
        
         INNER JOIN DBAMV.PAGCON_PAG PC
        
            ON ICP.CD_ITCON_PAG = PC.CD_ITCON_PAG
        
         INNER JOIN DBAMV.CON_COR CC
        
            ON PC.CD_CON_COR = CC.CD_CON_COR
        
         INNER JOIN DBAMV.TIP_DETCON_PAG TDP
        
            ON CP.CD_CON_PAG = TDP.CD_CON_PAG_PAI
        
         INNER JOIN DBAMV.TIP_DETALHE TD
        
            ON TD.CD_DETALHAMENTO = TDP.CD_DETALHAMENTO
        
         INNER JOIN DBAMV.MULTI_EMPRESAS ME
        
            ON ME.CD_MULTI_EMPRESA = CP.CD_MULTI_EMPRESA
        
         WHERE TDP.CD_DETALHAMENTO = 2
        
         GROUP BY TDP.CD_CON_PAG_PAI,
                   
                   TDP.CD_CON_PAG_FILHO,
                   
                   TDP.CD_DETALHAMENTO,
                   
                   TD.DS_DETALHAMENTO,
                   
                   ICP.DT_VENCIMENTO,
                   
                   CP.DT_EMISSAO,
                   
                   CP.DS_CON_PAG,
                   
                   CP.NR_DOCUMENTO,
                   
                   CP.VL_MOEDA,
                   
                   TDP.VL_DETALHAMENTO,
                   
                   PC.CD_CON_COR,
                   
                   CC.DS_CON_COR,
                   
                   ME.CD_CGC,
                   
                   ME.CD_MULTI_EMPRESA,
                   
                    ICP.TP_QUITACAO
        
        UNION ALL
        
        SELECT TDP.CD_CON_PAG_PAI,
                
                TDP.CD_CON_PAG_FILHO,
                
                TDP.CD_DETALHAMENTO,
                
                TD.DS_DETALHAMENTO,
                
                ICP.DT_VENCIMENTO AS DT_VCTO_NOTA,
                
                (SELECT DISTINCT ICP2.DT_VENCIMENTO
                 
                   FROM CON_PAG CP2
                 
                  INNER JOIN ITCON_PAG ICP2
                 
                     ON CP2.CD_CON_PAG = ICP2.CD_CON_PAG
                 
                  WHERE CP2.CD_CON_PAG = TDP.CD_CON_PAG_FILHO) AS DT_VCTO_IMPOSTO,
                
                CP.DT_EMISSAO,
                
                CP.DS_CON_PAG,
                
                (SELECT DISTINCT F1.NR_CGC_CPF
                 
                   FROM DBAMV.CON_PAG CP1
                 
                  INNER JOIN DBAMV.TIP_DETCON_PAG TDP1
                 
                     ON CP1.CD_CON_PAG = TDP1.CD_CON_PAG_PAI
                 
                  INNER JOIN DBAMV.FORNECEDOR F1
                 
                     ON CP1.CD_FORNECEDOR = F1.CD_FORNECEDOR
                 
                  WHERE CP1.CD_CON_PAG = TDP.CD_CON_PAG_PAI) AS CNPJ,
                
                CP.NR_DOCUMENTO,
                
                CP.VL_MOEDA AS VL_NOTA,
                
                0 VL_IMPOSTO_IRR,
                
                TDP.VL_DETALHAMENTO VL_IMPOSTO_PCC,
                
                PC.CD_CON_COR,
                
                CC.DS_CON_COR,
                
                ME.CD_CGC,
                
                ME.CD_MULTI_EMPRESA,
                
                CP.CD_TIP_DOC,
                
                ICP.TP_QUITACAO
        
          FROM DBAMV.CON_PAG CP
        
         INNER JOIN DBAMV.ITCON_PAG ICP
        
            ON CP.CD_CON_PAG = ICP.CD_CON_PAG
        
         INNER JOIN DBAMV.PAGCON_PAG PC
        
            ON ICP.CD_ITCON_PAG = PC.CD_ITCON_PAG
        
         INNER JOIN DBAMV.CON_COR CC
        
            ON PC.CD_CON_COR = CC.CD_CON_COR
        
         INNER JOIN DBAMV.TIP_DETCON_PAG TDP
        
            ON CP.CD_CON_PAG = TDP.CD_CON_PAG_PAI
        
         INNER JOIN DBAMV.TIP_DETALHE TD
        
            ON TD.CD_DETALHAMENTO = TDP.CD_DETALHAMENTO
        
         INNER JOIN MULTI_EMPRESAS ME
        
            ON ME.CD_MULTI_EMPRESA = CP.CD_MULTI_EMPRESA
        
         WHERE TDP.CD_DETALHAMENTO = 36
        
         GROUP BY TDP.CD_CON_PAG_PAI,
                   TDP.CD_CON_PAG_FILHO,
                   TDP.CD_DETALHAMENTO,
                   TD.DS_DETALHAMENTO,
                   ICP.DT_VENCIMENTO,
                   CP.DT_EMISSAO,
                   CP.DS_CON_PAG,
                   CP.NR_DOCUMENTO,
                   CP.VL_MOEDA,
                   TDP.VL_DETALHAMENTO,
                   PC.CD_CON_COR,
                   CC.DS_CON_COR,
                   ME.CD_CGC,
                   ME.CD_MULTI_EMPRESA,
                    ICP.TP_QUITACAO
                   ) I

 WHERE TO_DATE(I.DT_VCTO_NOTA, 'DD/MM/RRRR') BETWEEN
       TO_DATE('01/01/2024', 'DD/MM/RRRR') AND
       TO_DATE('29/06/2024', 'DD/MM/RRRR')
   AND I.CD_MULTI_EMPRESA IN (1, 2)
   AND I.CD_DETALHAMENTO IN (2, 36)
/*   AND I.DT_PAGAMENTO >= SYSDATE*/
   
/*AND NOT EXISTS (
    SELECT PC.DT_PAGAMENTO 
    FROM DBAMV.PAGCON_PAG PC
    WHERE PC.DT_PAGAMENTO = I.DT_PAGAMENTO 
      AND PC.DT_PAGAMENTO  IS NOT NULL)*/
     
 GROUP BY I.CD_CON_PAG_PAI,
          I.CD_CON_COR,
          I.DS_CON_COR,
          I.VL_NOTA,
          I.DT_VCTO_IMPOSTO,
          I.CNPJ,
          I.CD_CGC,
          I.NR_DOCUMENTO,
          I.DT_PAGAMENTO

