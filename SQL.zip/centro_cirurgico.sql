SELECT C.CD_CIRURGIA,
       C.DS_CIRURGIA,
       DECODE(C.TP_CIRURGIA,
              'P',
              'PEQUENO',
              'M',
              'M�DIO',
              'G',
              'GRANDE',
              'E',
              'ESPECIAL') PORTE,
       PF.CD_PRO_FAT,
       PF.DS_PRO_FAT,
       C.NR_HORAS_PADRAO TEMPO_CIRURGIA
  FROM DBAMV.CIRURGIA C
  JOIN DBAMV.PRO_FAT PF
    ON PF.CD_PRO_FAT = C.CD_PRO_FAT
 WHERE C.SN_ATIVO = 'S'
   AND C.NR_HORAS_PADRAO IS NULL
 ORDER BY 1
