SELECT * FROM PRODUTO P 


/*
select pr.cd_produto,pr.ds_produto,c.cd_classe,c.ds_classe,
        sc.cd_sub_cla,sc.ds_sub_cla,e.cd_especie,e.ds_especie
from dbamv.produto pr 

inner join dbamv.sub_clas sc on sc.cd_sub_cla = pr.cd_sub_cla 
        and sc.cd_classe = pr.cd_classe and sc.cd_especie = pr.cd_especie
      
inner join dbamv.classe c on c.cd_classe = pr.cd_classe and c.cd_classe = sc.cd_classe
      and c.cd_especie = sc.cd_especie
inner join dbamv.especie e on e.cd_especie = pr.cd_especie 
        where pr.cd_especie = 1
*/
