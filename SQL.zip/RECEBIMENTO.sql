SELECT * FROM NOTA_FISCAL F
WHERE F.NR_ID_NOTA_FISCAL = 1041428

SELECT * FROM CON_REC C WHERE C.CD_ATENDIMENTO = 11738858 

SELECT * FROM ITCON_REC CC WHERE CC.CD_CON_REC IN (1488012,1487852)

/* tipo de quita��o:
V	previsto
C	comprometido
P	parcialmente pago
Q	quitado
N	cancelado
T	liquidacao total devolu��o
L	liquidacao parcial devolu��o
*\
