SELECT UNIDADE, "% OCUPA��O", ORDEM
  FROM (
        
        SELECT '<b><span style="  color: #00B388;"><b>TAXA DE OCUPA��O ' || ' ' ||
                TRUNC(SYSDATE) || '</b>' UNIDADE,
                NULL,
                NULL,
                NULL,
                ' ' "% OCUPA��O",
                NULL,
                1 ORDEM
          FROM DUAL
  
       /*SELECT '<b><span style="  color: #00B388;font-family: Arial Black;"><b>TAXA DE OCUPA��O ' || ' ' ||
               TRUNC(SYSDATE) || '</b>' UNIDADE,
               NULL,
               NULL,
               NULL,
               ' ' "% OCUPA��O",
               NULL,
               1 ORDEM
          FROM DUAL*/
        
        UNION ALL
        
        -- 1 ABERTURA
        SELECT '<b><span style="  color: #001A70;font-family: Arial Black;"><b>- PEDIATRIA' UNIDADE,
               SUM(PACDIA) QTD,
               SUM(QUINZE) "de 15 a 30 dias",
               SUM(TRINTA) " + 30",
               '<b><span style="color: #001A70; font-family: Arial Black;">' ||
               TO_CHAR(ROUND(SUM(PACDIA) / SUM(LEITO) * 100, 0) || '%') ||
               '</span></b>' "% OCUPA��O",
               SUM(LEITO) LEITO,
               3 ORDEM
          FROM (SELECT COUNT(CD_ATENDIMENTO) "PACDIA",
                       SUM(QUINZE) QUINZE,
                       SUM(TRINTA) TRINTA,
                       NULL,
                       NULL LEITO
                       
                  FROM ( -----------------------------OCUPA��O
                        SELECT DS_UNID_INT,
                                CD_ATENDIMENTO,
                                CASE
                                  WHEN QTD_DIAS >= 15 AND QTD_DIAS < 30 THEN
                                   1
                                END "QUINZE",
                                CASE
                                  WHEN QTD_DIAS >= 30 THEN
                                   1
                                END "TRINTA"
                          FROM (SELECT DS_UNID_INT,
                                        CD_ATENDIMENTO,
                                        TRUNC(SYSDATE) - DT_ATENDIMENTO QTD_DIAS
                                   FROM ATENDIME, LEITO, UNID_INT
                                  WHERE TP_ATENDIMENTO = 'I'
                                    AND CD_ATENDIMENTO_PAI IS NULL
                                    AND DT_ALTA IS NULL
                                    AND CD_MULTI_EMPRESA = 1
                                    AND ATENDIME.CD_LEITO = LEITO.CD_LEITO
                                    AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
                                    AND LEITO.CD_UNID_INT IN (12))) -------------------------------FIM OCUPACAO
                UNION ALL
                ---------------------------QUANTIDADE DE LEITOS ATIVOS
                SELECT NULL, NULL, NULL, NULL, COUNT(1) QTD
                  FROM LEITO, UNID_INT
                 WHERE LEITO.TP_SITUACAO = 'A'
                   AND LEITO.SN_EXTRA = 'N'
                   AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
                   AND LEITO.CD_UNID_INT IN
                       (SELECT CD_UNID_INT
                          FROM UNID_INT
                         WHERE CD_SETOR IN
                               (SELECT CD_SETOR
                                  FROM SETOR
                                 WHERE CD_MULTI_EMPRESA = 1))
                   AND LEITO.CD_UNID_INT IN (12))
           -- 1 FECHAMENTO 
           
        UNION ALL
        
        -- 2 ABERTURA
        SELECT '<b><span style="  color: #001A70;font-family: Arial Black;"><b>- SEM PEDIATRIA' UNIDADE,
               SUM(PACDIA) QTD,
               SUM(QUINZE) "de 15 a 30 dias",
               SUM(TRINTA) " + 30",
               '<b><span style="color: #001A70; font-family: Arial Black;">' ||
               TO_CHAR(ROUND(SUM(PACDIA) / SUM(LEITO) * 100, 0) || '%') ||
               '</span></b>' "% OCUPA��O",
               SUM(LEITO) LEITO,
               2 ORDEM
          FROM (SELECT COUNT(CD_ATENDIMENTO) "PACDIA",
                       SUM(QUINZE) QUINZE,
                       SUM(TRINTA) TRINTA,
                       NULL,
                       NULL LEITO
                  FROM ( -----------------------------OCUPA��O
                        SELECT DS_UNID_INT,
                                CD_ATENDIMENTO,
                                CASE
                                  WHEN QTD_DIAS >= 15 AND QTD_DIAS < 30 THEN
                                   1
                                END "QUINZE",
                                CASE
                                  WHEN QTD_DIAS >= 30 THEN
                                   1
                                END "TRINTA"
                          FROM (SELECT DS_UNID_INT,
                                        CD_ATENDIMENTO,
                                        TRUNC(SYSDATE) - DT_ATENDIMENTO QTD_DIAS
                                   FROM ATENDIME, LEITO, UNID_INT
                                  WHERE TP_ATENDIMENTO = 'I'
                                    AND CD_ATENDIMENTO_PAI IS NULL
                                    AND DT_ALTA IS NULL
                                    AND CD_MULTI_EMPRESA = 1
                                    AND ATENDIME.CD_LEITO = LEITO.CD_LEITO
                                    AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
                                    AND LEITO.CD_UNID_INT NOT IN (12))) -------------------------------FIM OCUPACAO
                UNION ALL
                ---------------------------QUANTIDADE DE LEITOS ATIVOS
                SELECT NULL, NULL, NULL, NULL, COUNT(1) QTD
                  FROM LEITO, UNID_INT
                 WHERE LEITO.TP_SITUACAO = 'A'
                   AND LEITO.SN_EXTRA = 'N'
                   AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
                   AND LEITO.CD_UNID_INT IN
                       (SELECT CD_UNID_INT
                          FROM UNID_INT
                         WHERE CD_SETOR IN
                               (SELECT CD_SETOR
                                  FROM SETOR
                                 WHERE CD_MULTI_EMPRESA = 1))
                   AND LEITO.CD_UNID_INT NOT IN (12)
                
                -------------------------FIM LEITOS ATIVOS        
                
                )
        
        UNION ALL
        
        --------------OCUPACAO UTI
        SELECT '- ' ||
               
               CASE
                 WHEN DS_UNID_INT = 'UTI GERAL 1 ANDAR' THEN
                  '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI 1�'
                 WHEN DS_UNID_INT = 'UTI GERAL 5 ANDAR' THEN
                  '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI 5�'
                 WHEN DS_UNID_INT = 'UTI CORONARIANA' THEN
                  '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UCO'
                 WHEN DS_UNID_INT = 'UTI PEDIATRICA' THEN
                  '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI PED'
               END UNIDADE,
               SUM(PACDIA) QTD,
               SUM(QUINZE) "de 15 a 30 dias",
               SUM(TRINTA) " + 30",
               '<b><span style="color: #001A70; font-family: Arial Black;">' ||
               TO_CHAR(ROUND(SUM(PACDIA) / SUM(LEITO) * 100, 0) || '%') ||
               '</span></b>' "% OCUPA��O",
               SUM(LEITO) LEITO,
               CASE
                 WHEN DS_UNID_INT = 'UTI GERAL 1 ANDAR' THEN
                  4
                 WHEN DS_UNID_INT = 'UTI GERAL 5 ANDAR' THEN
                  5
                 WHEN DS_UNID_INT = 'UTI CORONARIANA' THEN
                  6
                 WHEN DS_UNID_INT = 'UTI PEDIATRICA' THEN
                  7
               END ORDEM
          FROM (SELECT DS_UNID_INT,
                       COUNT(CD_ATENDIMENTO) "PACDIA",
                       SUM(QUINZE) QUINZE,
                       SUM(TRINTA) TRINTA,
                       NULL,
                       NULL LEITO
                  FROM ( -----------------------------OCUPA��O
                        SELECT DS_UNID_INT,
                                CD_ATENDIMENTO,
                                CASE
                                  WHEN QTD_DIAS >= 15 AND QTD_DIAS < 30 THEN
                                   1
                                END "QUINZE",
                                CASE
                                  WHEN QTD_DIAS >= 30 THEN
                                   1
                                END "TRINTA"
                          FROM (SELECT DS_UNID_INT,
                                        CD_ATENDIMENTO,
                                        TRUNC(SYSDATE) - DT_ATENDIMENTO QTD_DIAS
                                   FROM ATENDIME, LEITO, UNID_INT
                                  WHERE TP_ATENDIMENTO = 'I'
                                    AND DT_ALTA IS NULL
                                    AND CD_MULTI_EMPRESA = 1
                                    AND ATENDIME.CD_LEITO = LEITO.CD_LEITO
                                    AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
                                    AND LEITO.CD_UNID_INT IN (3, 14, 15, 50)))
                 GROUP BY DS_UNID_INT ------------------------------FIM OCUPACAO
                UNION ALL
                ---------------------------QUANTIDADE DE LEITOS ATIVOS
                SELECT DS_UNID_INT, NULL, NULL, NULL, NULL, COUNT(1) QTD
                  FROM LEITO, UNID_INT
                 WHERE LEITO.TP_SITUACAO = 'A'
                   AND LEITO.SN_EXTRA = 'N'
                   AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
                   AND LEITO.CD_UNID_INT IN
                       (SELECT CD_UNID_INT
                          FROM UNID_INT
                         WHERE CD_SETOR IN
                               (SELECT CD_SETOR
                                  FROM SETOR
                                 WHERE CD_MULTI_EMPRESA = 1))
                   AND LEITO.CD_UNID_INT IN (3, 14, 15, 50)
                 GROUP BY DS_UNID_INT --3, GERAL 1 ANDAR 14 CORONARIANA,15 GERAL 5 ANDAR 
                -------------------------FIM LEITOS ATIVOS        
                )
         GROUP BY DS_UNID_INT
        -- 2 FECHAMENTO
        
        --------------FIM OCUPACAO UTI      
        UNION ALL
        
        SELECT '<b><span style="  color: #00B388;font-family: Arial Black;">INTERNA��ES' || ' ' ||
               TO_CHAR(TRUNC(SYSDATE) - 1, 'DD/MM/YYYY') || '</b>' UNIDADE,
               NULL,
               NULL,
               NULL,
               ' ' "% OCUPA��O",
               NULL,
               8 ORDEM
          FROM DUAL
   ----------------------------------------------------
          
        
        UNION ALL
        --------------INTERNA��ES DIA ANTERIOR
        SELECT '<b><span style="  color: #001A70;font-family: Arial Black;">- VIA PAA''</span></b>',
               NULL,
               NULL,
               NULL,
               '<b><span style="color: #001A70; font-family: Arial Black;">' ||
               TO_CHAR(COUNT(CD_ATENDIMENTO)) || '</span></b>' TESTE,
               NULL,
               9 ORDEM
          FROM ATENDIME, ORI_ATE
         WHERE DT_ATENDIMENTO = TRUNC(SYSDATE) - 1
           AND TP_ATENDIMENTO = 'I'
           AND ATENDIME.CD_MULTI_EMPRESA = 1
           AND ATENDIME.CD_ORI_ATE = ORI_ATE.CD_ORI_ATE
           AND ATENDIME.CD_ATENDIMENTO_PAI IS NULL
           AND ATENDIME.CD_ORI_ATE IN (52, 63, 50)
        
        --------------FIM INTERNA��ES DIA ANTERIOR
        
        UNION ALL
        --------------INTERNA��ES DIA ANTERIOR
        SELECT '<b><span style="  color: #001A70;font-family: Arial Black;"><b>- VIA PAP',
               NULL,
               NULL,
               NULL,
               '<b><span style="color: #001A70; font-family: Arial Black;">' ||
               TO_CHAR(COUNT(CD_ATENDIMENTO)) || '</span></b>',
               NULL,
               10 ORDEM
          FROM ATENDIME, ORI_ATE
         WHERE DT_ATENDIMENTO = TRUNC(SYSDATE) - 1
           AND TP_ATENDIMENTO = 'I'
           AND ATENDIME.CD_MULTI_EMPRESA = 1
           AND ATENDIME.CD_ORI_ATE = ORI_ATE.CD_ORI_ATE
           AND ATENDIME.CD_ATENDIMENTO_PAI IS NULL
           AND ATENDIME.CD_ORI_ATE IN (64)
        
        UNION ALL
        --------------INTERNA��ES DIA ANTERIOR
        SELECT '<b><span style="  color: #001A70;font-family: Arial Black;"><b>- TRAUMA',
               NULL,
               NULL,
               NULL,
               '<b><span style="color: #001A70; font-family: Arial Black;">' ||
               TO_CHAR(COUNT(CD_ATENDIMENTO)) || '</span></b>',
               NULL,
               13 ORDEM
          FROM ATENDIME, ORI_ATE
         WHERE DT_ATENDIMENTO = TRUNC(SYSDATE) - 1
           AND TP_ATENDIMENTO = 'I'
           AND ATENDIME.CD_MULTI_EMPRESA = 1
           AND ATENDIME.CD_ORI_ATE = ORI_ATE.CD_ORI_ATE
           AND ATENDIME.CD_ATENDIMENTO_PAI IS NULL
           AND ATENDIME.CD_ORI_ATE IN (37)
         GROUP BY DS_ORI_ATE
        --------------FIM INTERNA��ES DIA ANTERIOR
        
        UNION ALL
        --------------INTERNA��ES DIA ANTERIOR SEM PA
        SELECT '<b><span style="  color: #001A70;font-family: Arial Black;"><b>- ELETIVA' DS_ORI_ATE,
               NULL,
               NULL,
               NULL,
               '<b><span style="color: #001A70; font-family: Arial Black;">' ||
               TO_CHAR(COUNT(CD_ATENDIMENTO)) || '</span></b>',
               NULL,
               14 ORDEM
          FROM ATENDIME, ORI_ATE
         WHERE DT_ATENDIMENTO = TRUNC(SYSDATE) - 1
           AND TP_ATENDIMENTO = 'I'
           AND ATENDIME.CD_MULTI_EMPRESA = 1
           AND ATENDIME.CD_ORI_ATE = ORI_ATE.CD_ORI_ATE
           AND ATENDIME.CD_ATENDIMENTO_PAI IS NULL
           AND ORI_ATE.CD_ORI_ATE IN (39, 36)
        
        --------------FIM INTERNA��ES DIA ANTERIOR
        UNION ALL
        --------------ALTAS DIA ANTERIOR
        SELECT '<b><span style="  color: #001A70;font-family: Arial Black;"><b>- ALTAS' TIPO,
               NULL,
               NULL,
               NULL,
               '<b><span style="color: #001A70; font-family: Arial Black;">' ||
               TO_CHAR(COUNT(CD_ATENDIMENTO)) || '</span></b>',
               NULL,
               15 ORDEM
          FROM ATENDIME, ORI_ATE
         WHERE DT_ALTA = TRUNC(SYSDATE) - 1
           AND TP_ATENDIMENTO = 'I'
           AND ATENDIME.CD_MULTI_EMPRESA = 1
           AND ATENDIME.CD_ORI_ATE = ORI_ATE.CD_ORI_ATE
           AND ATENDIME.CD_LEITO NOT IN
               (SELECT CD_LEITO
                  FROM LEITO
                 WHERE CD_UNID_INT IN (20, 52, 16, 17))
           AND ATENDIME.CD_LEITO NOT IN
               (SELECT CD_LEITO FROM LEITO WHERE LEITO.SN_EXTRA = 'S')
        
        --------------FIM ALTAS INTERNA��ES DIA ANTERIOR
        
        UNION ALL
        
        SELECT '<b><span style="  color: #00B388;font-family: Arial Black;">MAPA CIR�RGICO' || ' ' ||
               TRUNC(SYSDATE) || '</b>' UNIDADE,
               NULL,
               NULL,
               NULL,
               ' ' "% OCUPA��O",
               NULL,
               16 ORDEM
          FROM DUAL
        
        UNION ALL
        -------MAPA CIRURGICO
        SELECT '- ' ||
               
               CASE
                 WHEN CEN_CIR.DS_CEN_CIR = 'CENTRO CIRURGICO - HNB' THEN
                  '<b><span style="  color: #001A70;font-family: Arial Black;"><b>C.C'
                 WHEN CEN_CIR.DS_CEN_CIR = 'CENTRO OBSTETRICO' THEN
                  '<b><span style="  color: #001A70;font-family: Arial Black;"><b>C.O'
                 WHEN CEN_CIR.DS_CEN_CIR = 'HEMODINAMICA' THEN
                  '<b><span style="  color: #001A70;font-family: Arial Black;"><b>HEMO'
               END
               
              ,
               NULL,
               NULL,
               NULL,
               '<b><span style="color: #001A70; font-family: Arial Black;">' ||
               TO_CHAR(COUNT(AVISO_CIRURGIA.CD_AVISO_CIRURGIA)) ||
               '</span></b>',
               NULL,
               
               CASE
                 WHEN CEN_CIR.DS_CEN_CIR = 'CENTRO CIRURGICO - HNB' THEN
                  17
                 WHEN CEN_CIR.DS_CEN_CIR = 'CENTRO OBSTETRICO' THEN
                  18
                 WHEN CEN_CIR.DS_CEN_CIR = 'HEMODINAMICA' THEN
                  19
               END ORDEM
        
          FROM AVISO_CIRURGIA, CEN_CIR, AGE_CIR
         WHERE TRUNC(DT_INICIO_AGE_CIR) = TRUNC(SYSDATE)
           AND AVISO_CIRURGIA.CD_CEN_CIR = CEN_CIR.CD_CEN_CIR
           AND AGE_CIR.CD_AVISO_CIRURGIA = AVISO_CIRURGIA.CD_AVISO_CIRURGIA
           AND AVISO_CIRURGIA.CD_CEN_CIR IN (1, 7, 3)
           AND AVISO_CIRURGIA.TP_SITUACAO <> 'C'
         GROUP BY CEN_CIR.DS_CEN_CIR
        -------FIM MAPA CIRURGICO
        UNION ALL
        
        SELECT '<b><span style="  color: #00B388;font-family: Arial Black;">RESERVAS UTI</span></b>' UNIDADE,
               NULL,
               NULL,
               NULL,
               ' ' "% OCUPA��O",
               NULL,
               20 ORDEM
          FROM DUAL
        
        UNION ALL
        
        -------RESERVA UTI
        
        SELECT UNIDADE,
               QTD,
               "de 15 a 30 dias",
               " + 30",
               "% OCUPA��O",
               LEITO,
               ORDEM
          FROM (SELECT '- ' || CASE
                         WHEN DS_UNID_INT = 'UTI GERAL 1 ANDAR' THEN
                          '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI 1�'
                         WHEN DS_UNID_INT = 'UTI GERAL 5 ANDAR' THEN
                          '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI 5�'
                         WHEN DS_UNID_INT = 'UTI CORONARIANA' THEN
                          '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UCO'
                         WHEN DS_UNID_INT = 'UTI PEDIATRICA' THEN
                          '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI PED'
                       END UNIDADE,
                       NULL QTD,
                       NULL "de 15 a 30 dias",
                       NULL " + 30",
                       '<b><span style="color: #001A70; font-family: Arial Black;">' ||
                       TO_CHAR(COUNT(CD_AVISO_CIRURGIA)) || '</span></b>' "% OCUPA��O",
                       NULL LEITO,
                       21 ORDEM,
                       (SELECT DECODE(LT1.CD_UNID_INT,
                                      14,
                                      '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UCO',
                                      15,
                                      '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI 5�',
                                      3,
                                      '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI 1�',
                                      50,
                                      '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI PED',
                                      NULL)
                          FROM ATENDIME AT1, LEITO LT1
                         WHERE AT1.CD_LEITO = LT1.CD_LEITO
                           AND AT1.CD_ATENDIMENTO =
                               AVISO_CIRURGIA.CD_ATENDIMENTO
                           AND LT1.CD_UNID_INT IN (3, 14, 15, 52)) LEITO_OCUP
                  FROM AVISO_CIRURGIA, CEN_CIR, UNID_INT
                 WHERE TRUNC(DT_PREV_INTER) = TRUNC(SYSDATE)
                   AND AVISO_CIRURGIA.CD_CEN_CIR = CEN_CIR.CD_CEN_CIR
                   AND AVISO_CIRURGIA.CD_UNID_INT = UNID_INT.CD_UNID_INT
                   AND SN_UTI = 'S'
                   AND CEN_CIR.CD_CEN_CIR IN (1, 7, 3)
                 GROUP BY '- ' || CASE
                            WHEN DS_UNID_INT = 'UTI GERAL 1 ANDAR' THEN
                             '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI 1�'
                            WHEN DS_UNID_INT = 'UTI GERAL 5 ANDAR' THEN
                             '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI 5�'
                            WHEN DS_UNID_INT = 'UTI CORONARIANA' THEN
                             '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UCO'
                            WHEN DS_UNID_INT = 'UTI PEDIATRICA' THEN
                             '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI PED'
                          END)
         WHERE LEITO_OCUP IS NULL
        
        --------FIM RESERVA UTI
        UNION ALL
        SELECT '<b><span style="  color: #00B388;font-family: Arial Black;">LEITOS VAGOS UTI</span></b>' UNIDADE,
               NULL,
               NULL,
               NULL,
               ' ' "% OCUPA��O",
               NULL,
               22 ORDEM
          FROM DUAL
        UNION ALL
        -------LEITOS VAGOS UTI
        SELECT '- ' || CASE
                 WHEN DS_UNID_INT = 'UTI GERAL 1 ANDAR' THEN
                  '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI 1�'
                 WHEN DS_UNID_INT = 'UTI GERAL 5 ANDAR' THEN
                  '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI 5�'
                 WHEN DS_UNID_INT = 'UTI CORONARIANA' THEN
                  '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UCO'
                 WHEN DS_UNID_INT = 'UTI PEDIATRICA' THEN
                  '<b><span style="  color: #001A70;font-family: Arial Black;"><b>UTI PED'
               END UNIDADE,
               NULL,
               NULL,
               NULL,
               '<b><span style="color: #001A70; font-family: Arial Black;">' ||
               TO_CHAR(COUNT(1)) || '</span></b>',
               NULL QTD,
               
               CASE
                 WHEN DS_UNID_INT = 'UTI GERAL 1 ANDAR' THEN
                  23
                 WHEN DS_UNID_INT = 'UTI GERAL 5 ANDAR' THEN
                  24
                 WHEN DS_UNID_INT = 'UTI CORONARIANA' THEN
                  25
                 WHEN DS_UNID_INT = 'UTI PEDIATRICA' THEN
                  26
               END ORDEM
        
          FROM LEITO, UNID_INT
         WHERE LEITO.TP_SITUACAO = 'A'
           AND LEITO.SN_EXTRA = 'N'
           AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
           AND LEITO.CD_UNID_INT IN
               (SELECT CD_UNID_INT
                  FROM UNID_INT
                 WHERE CD_SETOR IN
                       (SELECT CD_SETOR FROM SETOR WHERE CD_MULTI_EMPRESA = 1))
           AND LEITO.CD_UNID_INT IN (3, 14, 15, 50)
           AND TP_OCUPACAO = 'V'
         GROUP BY DS_UNID_INT --3, GERAL 1 ANDAR 14 CORONARIANA,15 GERAL 5 ANDAR ,42 UTI NEO
        
        UNION ALL
        
        SELECT '<b><span style="  color: #00B388;font-family: Arial Black;">PRONTO ATENDIMENTO' || ' ' ||
               TO_CHAR(TRUNC(SYSDATE) - 1, 'DD/MM/YYYY') || '</b>' UNIDADE,
               NULL,
               NULL,
               NULL,
               ' ' "% OCUPA��O",
               NULL,
               27 ORDEM
          FROM DUAL
        
        UNION ALL
        
        SELECT '<b><span style="  color: #001A70;font-family: Arial Black;"><b>- PAA' TIPO,
               NULL,
               NULL,
               NULL,
               '<b><span style="color: #001A70; font-family: Arial Black;">' ||
               TO_CHAR(COUNT(CD_ATENDIMENTO)) || '</span></b>',
               NULL,
               28 ORDEM
          FROM ATENDIME, ORI_ATE
         WHERE TRUNC(DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1
           AND TP_ATENDIMENTO = 'U'
           AND ATENDIME.CD_MULTI_EMPRESA = 1
           AND ATENDIME.CD_ORI_ATE = ORI_ATE.CD_ORI_ATE
           AND ATENDIME.CD_ORI_ATE IN (13, 47)
        
        UNION ALL
        
        SELECT '<b><span style="  color: #001A70;font-family: Arial Black;"><b>- PAP' TIPO,
               NULL,
               NULL,
               NULL,
               '<b><span style="color: #001A70; font-family: Arial Black;">' ||
               TO_CHAR(COUNT(CD_ATENDIMENTO)) || '</span></b>',
               NULL,
               29 ORDEM
          FROM ATENDIME, ORI_ATE
         WHERE TRUNC(DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1
           AND TP_ATENDIMENTO = 'U'
           AND ATENDIME.CD_MULTI_EMPRESA = 1
           AND ATENDIME.CD_ORI_ATE = ORI_ATE.CD_ORI_ATE
           AND ATENDIME.CD_ORI_ATE IN (14)
        
        UNION ALL
        
        SELECT '<b><span style="  color: #001A70;font-family: Arial Black;"><b>- PA EXTERNO' TIPO,
               NULL,
               NULL,
               NULL,
               '<b><span style="color: #001A70; font-family: Arial Black;">' ||
               TO_CHAR(COUNT(CD_ATENDIMENTO)) || '</span></b>',
               NULL,
               30 ORDEM
          FROM ATENDIME, ORI_ATE
         WHERE TRUNC(DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1
           AND TP_ATENDIMENTO = 'U'
           AND ATENDIME.CD_MULTI_EMPRESA = 1
           AND ATENDIME.CD_ORI_ATE = ORI_ATE.CD_ORI_ATE
           AND ATENDIME.CD_ORI_ATE IN (66)
        
        --)*/
        )
 ORDER BY ORDEM
