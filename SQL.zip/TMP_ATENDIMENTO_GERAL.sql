------------- ( TMP_ATENDIMENTO_GERAL ) -------------

------------ Gera��o Tabela : TMP_ATENDIMENTO_GERAL ------------

Insert INTO DBAMV.TMP_ATENDIMENTO_GERAL
  (TP_ATENDIMENTO,
   CD_ATENDIMENTO,
   CD_CONVENIO,
   CD_CON_PLA,
   ds_con_pla,
   CD_PACIENTE,
   nm_paciente,
   dt_nascimento,
   TP_SEXO,
   CD_ORI_ATE,
   DT_ATENDIMENTO,
   CD_MULTI_EMPRESA,
   CD_PRO_INT,
   CD_TIPO_INTERNACAO,
   cd_carteira,
   nr_carteira,
   NM_EMPRESA)

  select A.TP_ATENDIMENTO,
         a.CD_ATENDIMENTO,
         a.CD_CONVENIO,
         a.CD_CON_PLA,
         cp.ds_con_pla,
         a.CD_PACIENTE,
         p.nm_paciente,
         p.dt_nascimento,
         P.TP_SEXO,
         a.CD_ORI_ATE,
         a.DT_ATENDIMENTO,
         a.CD_MULTI_EMPRESA,
         a.CD_PRO_INT,
         a.CD_TIPO_INTERNACAO,
         thc.cd_carteira,
         c.nr_carteira,
         nvl(NVL(c.nm_empresa, A.NM_EMPRESA), c2.nm_empresa) NM_EMPRESA
    from dbamv.atendime a
   inner join dbamv.paciente p
      on p.cd_paciente = a.CD_PACIENTE
   inner join dbamv.con_pla cp
      on cp.cd_convenio = a.CD_CONVENIO
     and cp.cd_con_pla = a.CD_CON_PLA
    left outer join dbamv.tb_hnb_carteira thc
      on thc.cd_atendimento = a.CD_ATENDIMENTO
    left outer join dbamv.carteira c
      on c.cd_carteira = thc.cd_carteira
    left outer join dbamv.carteira c2
      on c2.cd_paciente = p.cd_paciente
     and c2.cd_convenio = a.CD_CONVENIO
     and c2.cd_con_pla = a.CD_CON_PLA
     and c2.nm_empresa is not null
     AND C2.DT_VALIDADE > A.DT_ATENDIMENTO
     and c2.nr_carteira = a.NR_CARTEIRA
   where a.cd_atendimento not in
         (select aa.cd_atendimento from dbamv.tmp_atendimento_geral aa)
   group by A.TP_ATENDIMENTO,
            a.CD_ATENDIMENTO,
            a.CD_CONVENIO,
            a.CD_CON_PLA,
            cp.ds_con_pla,
            a.CD_PACIENTE,
            p.nm_paciente,
            p.dt_nascimento,
            P.TP_SEXO,
            a.CD_ORI_ATE,
            a.DT_ATENDIMENTO,
            a.CD_MULTI_EMPRESA,
            a.CD_PRO_INT,
            a.CD_TIPO_INTERNACAO,
            thc.cd_carteira,
            c.nr_carteira,
            nvl(NVL(c.nm_empresa, A.NM_EMPRESA), c2.nm_empresa)
            
            ---------------( VERIFICA REGISTROS DUPLICADOS 2 CADASTROS EMPRESAS )------
              select cd_atendimento
                from (select tg.cd_atendimento, count(*)
                         from dbamv.tmp_atendimento_geral tg
                        where tg.dt_atendimento >= '01/01/2024'
                        group by tg.cd_atendimento
                       having count(*) > 1 --and count(*) > 1
                       )
                     
                     ----------------( EXCLUS�O DE REGISTROS DUPLICADOS )----------
                     
                      delete
                from dbamv.tmp_atendimento_geral tg
               where tg.cd_atendimento = 9970174
                 and tg.nm_empresa = 'HOSPITAL NIPO BRASILEIRO';


---------------- ( GERACAO DADOS DO PACIENTE )----------------------------

-- drop table dbamv.tmp_paciente

create table dbamv.TMP_PACIENTE as

  select CD_PACIENTE,
         NM_PACIENTE,
         DT_NASCIMENTO,
         
         TP_SITUACAO,
         TP_SEXO,
         TP_ESTADO_CIVIL,
         
         NR_CEP,
         p.CD_TIPO_LOGRADOURO,
         l.ds_tipo_logradouro,
         DS_ENDERECO,
         NR_ENDERECO,
         NM_BAIRRO,
         C.CD_CIDADE,
         C.NM_CIDADE,
         CD_CIDADANIA,
         
         DT_CADASTRO,
         CD_PACIENTE_ANTIGO,
         DT_ULTIMA_ATUALIZACAO,
         CD_MULTI_EMPRESA
  
    from dbamv.paciente p -- 943.468
    left outer join dbamv.tipo_logradouro l
      on p.cd_tipo_logradouro = l.cd_tipo_logradouro
    LEFT OUTER JOIN DBAMV.CIDADE C
      ON C.CD_CIDADE = P.CD_CIDADE
  --where p.dt_cadastro >= '01/01/2017'
  
  ----------------( Listagem para Fernando ( Toad))-----------
  
    SELECT *
            FROM dbamv.tmp_paciente
           ORDER BY cd_paciente -- 1.229.647 -- (Jun/20222)
               SELECT *
                 FROM dbamv.tmp_atendimento_geral
                WHERE dt_atendimento >= '01/01/2023'
                ORDER BY cd_atendimento -- 8.568.542 (Jun/2022)
                         
                          SELECT to_char(dt_atendimento, 'yyyy') ano,
                                 count(*)
                            FROM dbamv.tmp_atendimento_geral
                           WHERE dt_atendimento >= '01/01/2012'
                             and dt_atendimento < '01/01/2016' --RDER BY cd_atendimento-- 8.568.542 (Jun/2022)
                           group by to_char(dt_atendimento, 'yyyy')
                                    
                                     SELECT *
                                       FROM dbamv.tmp_atendimento_geral
                                      WHERE dt_atendimento >=
                                            '01/01/2012'
                                        and dt_atendimento <
                                            '01/02/2012'
                                      ORDER BY cd_atendimento -- 8.568.542 (Jun/2022)
                                               
                                               ------------------------------------( SCRIPT PARA J� SALVAR NA ESTRUTURA COM DELIMITADOR "|" )-----------------
                                               /*
                                               select 'CD_LANCAMENTO'||'|'||'CD_ATENDIMENTO'||'|'||'NR_CONTA'||'|'||'TIPO_ATD'||'|'||'CD_CONVENIO'||'|'||'CD_CON_PLA'||'|'||'CD_ORI_ATE'||'|'||'CD_TIPO_INTERNACAO'||'|'||
                                                      'CD_CID'||'|'||'PROCEDIMENTO'||'|'||'CD_ESPECIALID'||'|'||'CD_SETOR'||'|'||'CD_SETOR_PRODUZIU'||'|'||'PREST_EXC'||'|'||'PREST_ATD'||'|'||'DT_ATENDIMENTO'||'|'||'DT_ALTA'||'|'||
                                                      'CD_TIP_RES'||'|'||'CD_MOT_ALT'||'|'||'DT_LANCAMENTO'||'|'||'MES_LANCAMENTO'||'|'||'CD_TIP_ACOM'||'|'||'CD_GRU_FAT'||'|'||'CD_GRU_PRO'||'|'||'CD_PRO_FAT'||'|'||
                                                      'SN_PERTENCE_PACOTE'||'|'||'TP_MVTO'||'|'||'CD_ITMVTO'||'|'||'CD_MVTO'||'|'||'CD_REMESSA'||'|'||'DS_UNIDADE'||'|'||'QT_LANCAMENTO'||'|'||'VL_ULTIMA_ENTRADA'||'|'||
                                                      'VL_CUSTO_MEDIO'||'|'||'VL_CUSTOIDEAL'||'|'||'REPASSE'||'|'||'VL_UNITARIO'||'|'||'VL_FILME_UNITARIO'||'|'||'VL_TOTAL_LANC'||'|'||'VALOR_NFISCAL'||'|'||'NUM_NFISCAL'||'|'||
                                                      'VLR_CH'||'|'||'EMISSAO_NF'||'|'||'SN_CIRURGICO'||'|'||'COMPETENCIA'||'|'||'TABELAORIGEM'||'|'||'CD_MOTIVO_AUDITORIA'||'|'||'VLR_FATURADO'||'|'||'VL_RECEBIDO'||'|'||
                                                      'VL_GLOSA_INIC'||'|'||'VL_GLOSA_ACEITA'||'|'||'VL_RECURSO_GLOSA'||'|'||'VL_RECEBIDO_GLOSA'||'|'||'VL_SALDO_FATURA'||'|'||'CD_PRODUTO'||'|'||'VL_FATOR_PRO_FAT'||'|'||
                                                      'CD_PACIENTE'||'|'||'DT_CARGA'
                                                       FROM DUAL  
                                               
                                               UNION ALL
                                               */
                                               
                                               -------------------- TMP_PACIENTE-----------------------
                                                 SELECT CD_PACIENTE || '|' ||
                                                        NM_PACIENTE || '|' ||
                                                        DT_NASCIMENTO || '|' ||
                                                        TP_SITUACAO || '|' ||
                                                        TP_SEXO || '|' ||
                                                        TP_ESTADO_CIVIL || '|' ||
                                                        NR_CEP || '|' ||
                                                        CD_TIPO_LOGRADOURO || '|' ||
                                                        DS_TIPO_LOGRADOURO || '|' ||
                                                        DS_ENDERECO || '|' ||
                                                        NR_ENDERECO || '|' ||
                                                        NM_BAIRRO || '|' ||
                                                        CD_CIDADE || '|' ||
                                                        NM_CIDADE || '|' ||
                                                        CD_CIDADANIA || '|' ||
                                                        DT_CADASTRO || '|' ||
                                                        CD_PACIENTE_ANTIGO || '|' ||
                                                        DT_ULTIMA_ATUALIZACAO || '|' ||
                                                        CD_MULTI_EMPRESA
                                                   FROM dbamv.tmp_paciente
                                                  ORDER BY cd_paciente -- 1.229.647 -- (Jun/20222)
                                                           
                                                           ------------------ TMP_ATENDIMENTO_GERAL ---------------------
                                                             SELECT TP_ATENDIMENTO || '|' ||
                                                                    CD_ATENDIMENTO || '|' ||
                                                                    CD_CONVENIO || '|' ||
                                                                    CD_CON_PLA || '|' ||
                                                                    DS_CON_PLA || '|' ||
                                                                    CD_PACIENTE || '|' ||
                                                                    NM_PACIENTE || '|' ||
                                                                    DT_NASCIMENTO || '|' ||
                                                                    TP_SEXO || '|' ||
                                                                    CD_ORI_ATE || '|' ||
                                                                    DT_ATENDIMENTO || '|' ||
                                                                    CD_MULTI_EMPRESA || '|' ||
                                                                    CD_PRO_INT || '|' ||
                                                                    CD_TIPO_INTERNACAO || '|' ||
                                                                    CD_CARTEIRA || '|' ||
                                                                    NR_CARTEIRA || '|' ||
                                                                    NM_EMPRESA
                                                               FROM dbamv.tmp_atendimento_geral
                                                              WHERE dt_atendimento >=
                                                                    '01/01/2023'
                                                              ORDER BY cd_atendimento -- 8.568.542 (Jun/2022)
                                                             
                                                             ---------------------------------------------
