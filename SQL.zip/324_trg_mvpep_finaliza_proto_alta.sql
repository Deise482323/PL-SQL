CREATE OR REPLACE TRIGGER dbamv.trg_mvpep_finaliza_proto_alta
AFTER UPDATE OF DT_ALTA ON dbamv.atendime
REFERENCING NEW AS NEW OLD AS OLD
            FOR EACH ROW
DECLARE
  CURSOR cProtocolos(P_CD_PACIENTE NUMBER) IS
    SELECT  CD_CASO_PROTOCOLO
      FROM  DBAMV.PW_CASO_PROTOCOLO CASO_PROTOCOLO  
          , DBAMV.PW_ALERTA_PROTOCOLO  ALERTA_PROTOCOLO
      WHERE CASO_PROTOCOLO.CD_ALERTA_PROTOCOLO  =   ALERTA_PROTOCOLO.CD_ALERTA_PROTOCOLO
        AND ALERTA_PROTOCOLO.SN_REMOVE_STATUS_ALTA = 'S'
        AND CASO_PROTOCOLO.DT_FIM IS NULL
        AND CASO_PROTOCOLO.CD_PACIENTE = P_CD_PACIENTE;

  CURSOR cEtapa IS
    SELECT CD_ETAPA_PROTOCOLO
         , TP_ETAPA 
      FROM PW_ETAPA_PROTOCOLO 
     WHERE TP_ETAPA = 'FINALIZADO';

  vcEtapa cEtapa%ROWTYPE;
  nCD_ETAPA_PROTOCOLO NUMBER;
  vTextoPadrao VARCHAR2(100) :=  pkg_rmi_traducao.extrair_proc_msg('MSG_1'
                                                                 , 'TRG_MVPEP_FINALIZAR_PROTO_ALTA'
                                                                 , 'PROTOCOLO FINALIZADO EM VIRTUDE DA ALTA MEDICA DO PACIENTE, CONFORME CONFIGURAÇÃO DO PROTOCOLO'
                                                                 ,NULL); 
BEGIN
IF Nvl(:NEW.DT_ALTA, :OLD.DT_ALTA) IS NOT NULL THEN

     OPEN cEtapa;
    FETCH cEtapa INTO vcEtapa;
      if cEtapa%NOTFOUND THEN
        CLOSE cEtapa;
        RETURN;
      end if;
    CLOSE cEtapa;
    
  FOR i IN cProtocolos(Nvl(:NEW.CD_PACIENTE, :OLD.CD_PACIENTE)) LOOP  
   
    pkg_mvpep_protocolo_clinico.prc_mvpep_inserir_evolucao( i.CD_CASO_PROTOCOLO
                                                          , vcEtapa.TP_ETAPA
                                                          , vcEtapa.CD_ETAPA_PROTOCOLO
                                                          , SYSDATE
                                                          , SYSDATE
                                                          , SYSDATE
                                                          , NULL
                                                          , dbamv.pkg_mv_variaveis.fnc_get_usuario()
                                                          , vTextoPadrao
                                                          , NULL);

    
  END LOOP;
END IF;
END;
/