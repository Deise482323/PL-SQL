---------( VERIFICAR MESES FECHADOS )----------
SELECT *
  FROM DBAMV.FECHAMENTO_DO_MES FM
 WHERE FM.CD_MULTI_EMPRESA = 1
   AND FM.DT_COMPETENCIA >= '01/10/2024'
 ORDER BY FM.DT_COMPETENCIA
-- ACRESCENTAR NO SCRIPT O PERIODO QUE DESEJAR DAR CARGA.
          
          --( USAR INSERT )
           INSERT
  INTO DBAMV.TMP_MOVIMENTO_ESTOQUE(CD_MVTO_ESTOQUE,
                                   TP_MVTO_ESTOQUE,
                                   DESC_MVTO_ESTOQUE,
                                   CD_ESTOQUE,
                                   DT_MVTO_ESTOQUE,
                                   CD_ATENDIMENTO,
                                   CD_UNID_INT,
                                   CD_SETOR,
                                   CD_PRESTADOR,
                                   CD_ESTOQUE_DESTINO,
                                   CD_MOT_DEV,
                                   CD_SOLSAI_PRO,
                                   CD_AVISO_CIRURGIA,
                                   CD_ENT_PRO,
                                   CD_USUARIO,
                                   CD_MULTI_EMPRESA,
                                   TP_RETROATIVO,
                                   CD_ITMVTO_ESTOQUE,
                                   CD_PRODUTO,
                                   CD_UNI_PRO,
                                   QT_MOVIMENTACAO,
                                   CD_FORNECEDOR,
                                   CD_LOTE,
                                   DT_VALIDADE,
                                   NR_DOCUMENTO,
                                   DH_MVTO_ESTOQUE,
                                   CD_ITSOLSAI_PRO,
                                   TP_ESTOQUE,
                                   QT_KIT,
                                   TP_ORCAMENTO,
                                   SN_FATURA,
                                   DT_GRAVACAO,
                                   DS_ESTOQUE,
                                   SN_IMPRIME_DIRETO,
                                   CD_REDUZIDO_DEBITO,
                                   CD_REDUZIDO_CREDITO,
                                   CD_SUB_CLA,
                                   CD_CLASSE,
                                   CD_ESPECIE,
                                   DS_PRODUTO,
                                   DT_CADASTRO,
                                   TP_ATIVO,
                                   DT_ULTIMA_ENTRADA,
                                   SN_CONTROLE_VALIDADE,
                                   SN_PADRONIZADO,
                                   SN_PSCOTROPICO,
                                   HR_ULTIMA_ENTRADA,
                                   SN_MEDICAMENTO,
                                   CD_TIP_ATIV,
                                   SN_IMPRIME_ETIQUETA,
                                   SN_LOTE,
                                   CD_PRO_FAT,
                                   VL_FATOR_PRO_FAT,
                                   CD_DCB,
                                   CD_UNIDADE,
                                   DS_UNIDADE,
                                   VL_FATOR,
                                   TP_RELATORIOS,
                                   VL_CUSTO_MEDIO,
                                   CD_UNIDADERF1,
                                   DS_UNIDADERF1,
                                   VL_FATORRF1,
                                   TP_RELATORIOSRF1,
                                   CSTMEDIORF1,
                                   VL_ULTIMA_ENTRADA,
                                   CD_ULTIMO_FORNECEDOR,
                                   QT_ULTIMA_ENTRADA,
                                   DS_PRODUTO_RESUMIDO,
                                   VL_ULTIMA_CUSTO_REAL,
                                   SN_CONSIGNADO,
                                   CD_FORNECEDOR_PRINCIPAL,
                                   VL_ULTIMA_COMPRA_IPI,
                                   TP_HORAS_ESTERELIZAR,
                                   CD_USUARIO_INC,
                                   DT_INC_USUARIO,
                                   CD_USUARIO_ALT,
                                   DT_ALT_USUARIO)
       
        SELECT IME.CD_MVTO_ESTOQUE,
               ME.TP_MVTO_ESTOQUE,
               DECODE(ME.TP_MVTO_ESTOQUE,
                      'B',
                      'TOMBAMENTO',
                      'E',
                      'EMPRESTIMO',
                      'R',
                      'MOV. ENTRE EMPRESAS',
                      'S',
                      'SAIDA SETOR',
                      'P',
                      'PACIENTE',
                      'X',
                      'BAIXA DE PRODUTO',
                      'C',
                      'DEVOLUCAO DE PACIENTE',
                      'D',
                      'DEVOLUCAO DE SETOR',
                      'T',
                      'TRANSF ENTRE ESTOQUES') DESC_MVTO_ESTOQUE,
               
               ME.CD_ESTOQUE,
               DT_MVTO_ESTOQUE,
               CD_ATENDIMENTO,
               CD_UNID_INT,
               ME.CD_SETOR,
               CD_PRESTADOR,
               CD_ESTOQUE_DESTINO,
               CD_MOT_DEV,
               CD_SOLSAI_PRO,
               CD_AVISO_CIRURGIA,
               CD_ENT_PRO,
               CD_USUARIO,
               ME.CD_MULTI_EMPRESA,
               TP_RETROATIVO,
               CD_ITMVTO_ESTOQUE,
               IME.CD_PRODUTO,
               IME.CD_UNI_PRO,
               QT_MOVIMENTACAO,
               IME.CD_FORNECEDOR,
               SUBSTR(IME.CD_LOTE, 1, 20) CD_LOTE,
               IME.DT_VALIDADE,
               SUBSTR(ME.NR_DOCUMENTO, 1, 15) NR_DOCUMENTO,
               DH_MVTO_ESTOQUE,
               CD_ITSOLSAI_PRO,
               E.TP_ESTOQUE,
               QT_KIT,
               TP_ORCAMENTO,
               SN_FATURA,
               DT_GRAVACAO,
               DS_ESTOQUE,
               SN_IMPRIME_DIRETO,
               CD_REDUZIDO_DEBITO,
               CD_REDUZIDO_CREDITO,
               CD_SUB_CLA,
               CD_CLASSE,
               CD_ESPECIE,
               DS_PRODUTO,
               DT_CADASTRO,
               TP_ATIVO,
               DT_ULTIMA_ENTRADA,
               SN_CONTROLE_VALIDADE,
               SN_PADRONIZADO,
               SN_PSCOTROPICO,
               
               HR_ULTIMA_ENTRADA,
               SN_MEDICAMENTO,
               CD_TIP_ATIV,
               SN_IMPRIME_ETIQUETA,
               SN_LOTE,
               PR.CD_PRO_FAT,
               VL_FATOR_PRO_FAT,
               CD_DCB,
               
               UP.CD_UNIDADE,
               UP.DS_UNIDADE,
               UP.VL_FATOR,
               UP.TP_RELATORIOS,
               VL_CUSTO_MEDIO,
               
               UP1.CD_UNIDADE CD_UNIDADERF1,
               UP1.DS_UNIDADE DS_UNIDADERF1,
               UP1.VL_FATOR VL_FATORRF1,
               UP1.TP_RELATORIOS TP_RELATORIOSRF1,
               (VL_ULTIMA_ENTRADA * UP1.VL_FATOR) CSTMEDIORF1,
               
               VL_ULTIMA_ENTRADA,
               CD_ULTIMO_FORNECEDOR,
               QT_ULTIMA_ENTRADA,
               DS_PRODUTO_RESUMIDO,
               VL_ULTIMA_CUSTO_REAL,
               SN_CONSIGNADO,
               CD_FORNECEDOR_PRINCIPAL,
               VL_ULTIMA_COMPRA_IPI,
               TP_HORAS_ESTERELIZAR,
               CD_USUARIO_INC,
               DT_INC_USUARIO,
               CD_USUARIO_ALT,
               DT_ALT_USUARIO
        
          FROM DBAMV.MVTO_ESTOQUE ME
         INNER JOIN DBAMV.ITMVTO_ESTOQUE IME
            ON IME.CD_MVTO_ESTOQUE = ME.CD_MVTO_ESTOQUE
         INNER JOIN DBAMV.ESTOQUE E
            ON E.CD_ESTOQUE = ME.CD_ESTOQUE
         INNER JOIN DBAMV.PRODUTO PR
            ON PR.CD_PRODUTO = IME.CD_PRODUTO
         INNER JOIN DBAMV.UNI_PRO UP
            ON UP.CD_PRODUTO = PR.CD_PRODUTO
           AND UP.TP_RELATORIOS = 'R'
           AND UP.SN_ATIVO = 'S'
          LEFT OUTER JOIN DBAMV.UNI_PRO UP1
            ON UP1.CD_PRODUTO = PR.CD_PRODUTO
           AND UP1.TP_RELATORIOS = '1'
           AND UP1.SN_ATIVO = 'S'
         WHERE ME.DT_MVTO_ESTOQUE BETWEEN '01/10/2024' AND '30/10/2024'
           AND ME.CD_MULTI_EMPRESA = 1
-- FIM---------------------------------------------------------------------------------------------------------------------------------------------
-----------( TABELA ENTRADA DE PRODUTO NO ESTOQUE )------------------

SELECT TO_CHAR(EPE.DT_ENTRADA, 'yyyymm') ANOMES, COUNT(*) QTDE
  FROM DBAMV.TMP_ENTRADA_PRODUTO_ESTOQUE EPE
 WHERE TO_CHAR(EPE.DT_ENTRADA, 'yyyy') = '2024'
 GROUP BY TO_CHAR(EPE.DT_ENTRADA, 'yyyymm')
 ORDER BY 1
          
          --( USAR INSERT )
           INSERT
  INTO DBAMV.TMP_ENTRADA_PRODUTO_ESTOQUE(CD_ATENDIMENTO,
                                         CD_CUSTO_MEDIO,
                                         CD_ENT_PRO,
                                         CD_ESTOQUE,
                                         DT_ENTRADA,
                                         CD_FORNECEDOR,
                                         NR_DOCUMENTO,
                                         CD_CON_PAG,
                                         CD_ITENT_PRO,
                                         CD_ORD_COM,
                                         CD_PRODUTO,
                                         DS_PRODUTO,
                                         DS_ESPECIE,
                                         DS_CLASSE,
                                         DS_SUB_CLA,
                                         CD_PRO_FAT,
                                         CD_TIP_ENT,
                                         CD_TIP_DOC,
                                         CD_UNI_PRO,
                                         CD_UNIDADE,
                                         DT_GRAVACAO,
                                         DT_EMISSAO,
                                         DS_UNIDADE,
                                         VL_TOTAL_ENTRADA,
                                         VL_DESCONTO,
                                         VL_CUSTO_REAL,
                                         VL_TOTAL,
                                         VL_UNITARIO,
                                         VL_DESCONTO_ITEM,
                                         VL_IMPOSTO,
                                         VL_PERCENTUAL_DESCONTO,
                                         VL_TOTAL_CUSTO_REAL,
                                         VL_FATOR,
                                         QT_ATENDIDA,
                                         QT_CONSUMO_ATUAL,
                                         QT_CONSUMO_MES,
                                         QT_DEVOLVIDA,
                                         QT_ENTRADA,
                                         QT_ESTOQUE_ATUAL,
                                         QT_ESTOQUE_MAXIMO,
                                         QT_ESTOQUE_MINIMO,
                                         QT_ESTOQUE_VIRTUAL,
                                         QT_ESTOQUE_DOADO,
                                         QT_ESTOQUE_RESERVADO,
                                         QT_ORDEM_DE_COMPRA,
                                         QT_PONTO_DE_PEDIDO,
                                         QT_SOLICITACAO_DE_COMPRA,
                                         SN_ATIVO,
                                         TP_RELATORIOS,
                                         TP_CLASSIFICACAO_ABC,
                                         CD_REG_FAT,
                                         CDPROFAT,
                                         HR_LANCAMENTO,
                                         QT_LANCAMENTO,
                                         VLR_UNIT_FAT,
                                         VL_TOTAL_CONTA)
       
        SELECT IEP.CD_ATENDIMENTO,
               IEP.CD_CUSTO_MEDIO,
               EP.CD_ENT_PRO,
               EP.CD_ESTOQUE,
               EP.DT_ENTRADA,
               EP.CD_FORNECEDOR,
               EP.NR_DOCUMENTO,
               EP.CD_CON_PAG,
               IEP.CD_ITENT_PRO,
               EP.CD_ORD_COM,
               IEP.CD_PRODUTO,
               P.DS_PRODUTO,
               ES.DS_ESPECIE,
               CL.DS_CLASSE,
               SC.DS_SUB_CLA,
               P.CD_PRO_FAT,
               EP.CD_TIP_ENT,
               EP.CD_TIP_DOC,
               IEP.CD_UNI_PRO,
               UP.CD_UNIDADE,
               IEP.DT_GRAVACAO,
               EP.DT_EMISSAO,
               UP.DS_UNIDADE,
               EP.VL_TOTAL                  VL_TOTAL_ENTRADA,
               EP.VL_DESCONTO,
               IEP.VL_CUSTO_REAL,
               IEP.VL_TOTAL,
               IEP.VL_UNITARIO,
               IEP.VL_DESCONTO              VL_DESCONTO_ITEM,
               IEP.VL_IMPOSTO,
               IEP.VL_PERCENTUAL_DESCONTO,
               IEP.VL_TOTAL_CUSTO_REAL,
               UP.VL_FATOR,
               IEP.QT_ATENDIDA,
               EPP.QT_CONSUMO_ATUAL,
               EPP.QT_CONSUMO_MES,
               IEP.QT_DEVOLVIDA,
               IEP.QT_ENTRADA,
               EPP.QT_ESTOQUE_ATUAL,
               EPP.QT_ESTOQUE_MAXIMO,
               EPP.QT_ESTOQUE_MINIMO,
               EPP.QT_ESTOQUE_VIRTUAL,
               EPP.QT_ESTOQUE_DOADO,
               EPP.QT_ESTOQUE_RESERVADO,
               EPP.QT_ORDEM_DE_COMPRA,
               EPP.QT_PONTO_DE_PEDIDO,
               EPP.QT_SOLICITACAO_DE_COMPRA,
               UP.SN_ATIVO,
               UP.TP_RELATORIOS,
               EPP.TP_CLASSIFICACAO_ABC,
               IRF.CD_REG_FAT,
               IRF.CD_PRO_FAT               CDPROFAT,
               IRF.HR_LANCAMENTO,
               IRF.QT_LANCAMENTO,
               IRF.VL_UNITARIO              VLR_UNIT_FAT,
               IRF.VL_TOTAL_CONTA
        
          FROM DBAMV.ENT_PRO EP
         INNER JOIN DBAMV.ITENT_PRO IEP
            ON IEP.CD_ENT_PRO = EP.CD_ENT_PRO
          LEFT OUTER JOIN DBAMV.UNI_PRO UP
            ON UP.CD_UNI_PRO = IEP.CD_UNI_PRO
          LEFT OUTER JOIN DBAMV.EST_PRO EPP
            ON EPP.CD_PRODUTO = IEP.CD_PRODUTO
           AND EPP.CD_ESTOQUE = 4
         INNER JOIN DBAMV.PRODUTO P
            ON P.CD_PRODUTO = IEP.CD_PRODUTO
         INNER JOIN DBAMV.ESPECIE ES
            ON ES.CD_ESPECIE = P.CD_ESPECIE
         INNER JOIN DBAMV.CLASSE CL
            ON CL.CD_ESPECIE = ES.CD_ESPECIE
           AND CL.CD_CLASSE = P.CD_CLASSE
         INNER JOIN DBAMV.SUB_CLAS SC
            ON SC.CD_CLASSE = CL.CD_CLASSE
           AND ES.CD_ESPECIE = CL.CD_ESPECIE
           AND SC.CD_SUB_CLA = P.CD_SUB_CLA
           AND SC.CD_CLASSE = P.CD_CLASSE
           AND SC.CD_ESPECIE = P.CD_ESPECIE
          LEFT OUTER JOIN DBAMV.REG_FAT RF
            ON RF.CD_ATENDIMENTO = EP.CD_ATENDIMENTO
          LEFT OUTER JOIN DBAMV.ITREG_FAT IRF
            ON IRF.CD_PRO_FAT = P.CD_PRO_FAT
           AND IRF.CD_REG_FAT = RF.CD_REG_FAT
         WHERE EP.CD_ESTOQUE IN
               (SELECT E.CD_ESTOQUE
                  FROM DBAMV.ESTOQUE E
                 WHERE E.TP_ESTOQUE = 'D'
                   AND E.CD_MULTI_EMPRESA = 1)
           AND EP.DT_ENTRADA BETWEEN '01/10/2024' AND '30/10/2024'
