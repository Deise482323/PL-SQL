

SELECT N1.DT_CIRURGIA,
       N1.CD_AVISO_CIRURGIA,
       DECODE(N1.SITUACAO_CIRURGIA,
              'PO',
              'PENDENTE',
              'PE',
              'PENDENTE',
              'SO',
              'SOLICITADA',
              'AU',
              'AUTORIZADA',
              N1.SITUACAO_CIRURGIA) SITUACAO_CIRURGIA,
       N1.CD_MOT_PENDENCIA,
       N1.DS_MOT_PENDENCIA,
       P.DT_MOVIMENTO,
       
       (CASE
       
         WHEN P.CD_MOTIV_PEND_ATU = 2 AND SYSDATE - P.DT_MOVIMENTO >= 1 AND SYSDATE - P.DT_MOVIMENTO < 2 THEN
          'AMARELO'
         WHEN P.CD_MOTIV_PEND_ATU = 2 AND SYSDATE - P.DT_MOVIMENTO >= 2 THEN
          'VERMELHO'
       
         ELSE
          ''
       
       END) PENDENTE
  FROM ENKYO.TB_CIR_PENDENTES_NAC N1
  JOIN DBAMV.GUIA G
    ON G.CD_AVISO_CIRURGIA = N1.CD_AVISO_CIRURGIA
  JOIN DBAMV.LOG_MOT_PEND P
    ON P.CD_GUIA = G.CD_GUIA

 WHERE N1.SN_PROCPA = 'N'
   AND N1.SITUACAO_CIRURGIA <> 'PO'
   AND N1.CD_MOT_PENDENCIA IS NOT NULL
   AND N1.CD_MOT_PENDENCIA = #CDMOTPENDENCIA#
 ORDER BY 1
   
   ------------------------
   
   
   
   
   SELECT P.DT_MOVIMENTO,
   P.CD_MOTIV_PEND_ATU,
   ( CASE 
   
       WHEN P.CD_MOTIV_PEND_ATU = 2 AND SYSDATE - P.DT_MOVIMENTO >= 1 AND P.DT_MOVIMENTO <2
         THEN 'AMARELO' 
      WHEN P.CD_MOTIV_PEND_ATU = 2 AND SYSDATE - P.DT_MOVIMENTO >= 2
         THEN 'VERMELHO'
          
           ELSE ''
             
             END
         )  FROM DBAMV.LOG_MOT_PEND P
         
         WHERE P.DT_MOVIMENTO >= '11/04/2024'
         
         
         ---------------------------------------
         
         select N1.DT_CIRURGIA,
       N1.CD_AVISO_CIRURGIA,
       DECODE(N1.SITUACAO_CIRURGIA, 'PO','PENDENTE','PE','PENDENTE','SO','SOLICITADA', 'AU', 'AUTORIZADA',N1.SITUACAO_CIRURGIA) SITUACAO_CIRURGIA,
       N1.CD_MOT_PENDENCIA,
       N1.DS_MOT_PENDENCIA
       
  from enkyo.TB_CIR_PENDENTES_NAC n1
 WHERE N1.SN_PROCPA = 'N'
   AND N1.SITUACAO_CIRURGIA <> 'PO'
   --AND N1.CD_MOT_PENDENCIA IS NOT NULL
   AND N1.CD_MOT_PENDENCIA = #CDMOTPENDENCIA#
   ORDER BY 1
------------------------------------------------------
SELECT N1.DT_CIRURGIA,
       N1.CD_AVISO_CIRURGIA,
       DECODE(N1.SITUACAO_CIRURGIA,
              'PO',
              'PENDENTE',
              'PE',
              'PENDENTE',
              'SO',
              'SOLICITADA',
              'AU',
              'AUTORIZADA',
              N1.SITUACAO_CIRURGIA) SITUACAO_CIRURGIA,
       N1.CD_MOT_PENDENCIA,
       N1.DS_MOT_PENDENCIA,
       P.DT_MOVIMENTO,
       
       (CASE
       
         WHEN P.CD_MOTIV_PEND_ATU = 2 AND SYSDATE - P.DT_MOVIMENTO < 2 THEN
          'AMARELO'
         WHEN P.CD_MOTIV_PEND_ATU = 2 AND SYSDATE - P.DT_MOVIMENTO >= 2 THEN
          'VERMELHO'
       
         ELSE
          ''
       
       END) PENDENTE
  FROM ENKYO.TB_CIR_PENDENTES_NAC N1
  JOIN DBAMV.GUIA G
    ON G.CD_AVISO_CIRURGIA = N1.CD_AVISO_CIRURGIA
  JOIN DBAMV.LOG_MOT_PEND P
    ON P.CD_GUIA = G.CD_GUIA

 WHERE N1.SN_PROCPA = 'N'
   AND N1.SITUACAO_CIRURGIA <> 'PO'
   AND N1.CD_MOT_PENDENCIA IS NOT NULL
   AND N1.CD_MOT_PENDENCIA = #CDMOTPENDENCIA#
 ORDER BY 1
 -----------------------------------
 
 SELECT 
    P.DT_MOVIMENTO,
    P.CD_MOTIV_PEND_ATU,
    CASE
        WHEN P.CD_MOTIV_PEND_ATU = 2 AND TRUNC(SYSDATE) - P.DT_MOVIMENTO >= 1 AND TRUNC(SYSDATE) - P.DT_MOVIMENTO < 2 THEN 'AMARELO'
        WHEN P.CD_MOTIV_PEND_ATU = 2 AND TRUNC(SYSDATE) - P.DT_MOVIMENTO >= 2 THEN 'VERMELHO'
        ELSE ''
    END AS COR_STATUS
FROM 
    DBAMV.LOG_MOT_PEND P
WHERE 
    P.DT_MOVIMENTO >= TO_DATE('11/04/2024', 'DD/MM/YYYY');

       
