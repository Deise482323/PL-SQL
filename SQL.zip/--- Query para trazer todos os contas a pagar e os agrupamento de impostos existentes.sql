--- QUERY PARA TRAZER TODOS OS CONTAS A PAGAR E OS AGRUPAMENTO DE IMPOSTOS EXISTENTES ( SOLICITA��O LUIZ / MARCIA ) PARA DISPONIBILIZAR PARA AUDITORIA

SELECT CD_CON_PAG,
       
       CD_PROCESSO,
       
       DS_PROCESSO,
       
       CD_MULTI_EMPRESA,
       
       CD_FORNECEDOR,
       
       DS_FORNECEDOR,
       
       NR_CGC_CPF,
       
       CD_REDUZIDO,
       
       DS_CONTA,
       
       DS_OBSERVACAO,
       
       DT_IMPORTACAO_MGES,
       
       DT_EXP_ARQ_LOTE,
       
       DS_LOTE_REMESSA,
       
       TO_DATE(DT_EMISSAO, 'dd/mm/RRRR') DT_EMISSAO,
       
       DT_LANCAMENTO,
       
       DT_VENCIMENTO,
       
       --       DT_PREVISTA_PAG,
       
       DT_PAGAMENTO,
       
       NR_DOCUMENTO,
       
       VL_BRUTO_CONTA,
       
       VL_DUPLICATA,
       
       --       CP_CD_ACRESCIMO,
       
       --       CP_VL_ACRESCIMO,
       
       --       CP_CD_DESCONTO,
       
       --       CP_VL_DESCONTO,
       
       --       VL_ACRESCDESC,
       
       --       CD_ACRESCIMO,
       
       --       CD_DESCONTO,
       
       VL_ACRESCIMO,
       
       VL_DESCONTO,
       
       CD_ACRESC_DESC_FIN,
       
       DS_DESC_ACRES,
       
       NVL(VL_PAGO, 0) VL_PAGO,
       
       LOTE_PGTO_REMESSA,
       
       TP_PAGAMENTO,
       
       DS_TP_PAG,
       
       DS_PAGCON_PAG,
       
       CD_SETOR,
       
       NM_SETOR,
       
       CD_REDUZIDO_COMPART,
       
       DS_CONTA_COMPART,
       
       VL_RATEIO,
       
       BORDERO,
       
       AGENCIA,
       
       CONTA_CORRENTE,
       
       BANCO,
       
       CD_USUARIO,
       
       CD_LOTE_PGTO,
       
       DS_LOTE_PGTO,
       
       VLR_INSS,
       
       VLR_IRRF,
       
       VLR_ISS,
       
       VLR_PCC,
       
       SUM(NVL(VLR_INSS, 0) + NVL(VLR_IRRF, 0) + NVL(VLR_ISS, 0) +
           NVL(VLR_PCC, 0)) VLR_TOT_IMPOSTO

  FROM (SELECT C.CD_CON_PAG, --IT.CD_ITCON_PAG, PP.CD_PAGCON_PAG,
               
               C.CD_PROCESSO,
               
               PR.DS_PROCESSO,
               
               C.CD_MULTI_EMPRESA,
               
               C.CD_FORNECEDOR,
               
               C.DS_FORNECEDOR,
               
               C.CD_REDUZIDO,
               
               PC.DS_CONTA,
               
               C.DS_OBSERVACAO,
               
               (CASE
               
                 WHEN F.TP_FORNECEDOR = 'J' THEN
                 
                  SUBSTR(LPAD(F.NR_CGC_CPF, 14, 0), 1, 2) || '.' ||
                 
                  LPAD(SUBSTR(LPAD(F.NR_CGC_CPF, 14, 0), -12, 3), 3, 0) || '.' ||
                 
                  LPAD(SUBSTR(F.NR_CGC_CPF, -9, 3), 3, 0) || '/' ||
                 
                  LPAD(SUBSTR(F.NR_CGC_CPF, -6, 4), 4, 0) || '-' ||
                 
                  LPAD(SUBSTR(F.NR_CGC_CPF, -2, 2), 2, 0)
               
                 ELSE
                 
                  SUBSTR(LPAD(F.NR_CGC_CPF, 11, 0), 1, 3) || '.' ||
                 
                  LPAD(SUBSTR(F.NR_CGC_CPF, -8, 3), 3, 0) || '.' ||
                 
                  LPAD(SUBSTR(F.NR_CGC_CPF, -5, 3), 3, 0) || '-' ||
                 
                  LPAD(SUBSTR(F.NR_CGC_CPF, -2, 2), 2, 0)
               
               END) NR_CGC_CPF,
               
               C.DT_IMPORTACAO_MGES,
               
               LP.DT_LOTE_PGTO DT_EXP_ARQ_LOTE,
               
               LR.DS_LOTE_REMESSA,
               
               RCP.CD_SETOR,
               
               S.NM_SETOR,
               
               RCP.CD_REDUZIDO CD_REDUZIDO_COMPART,
               
               PCC.DS_CONTA DS_CONTA_COMPART,
               
               RCP.VL_RATEIO,
               
               C.DT_EMISSAO,
               
               C.DT_LANCAMENTO,
               
               --       IT.DT_VENCIMENTO,
               
               (SELECT MIN(IT1.DT_VENCIMENTO)
                  FROM CON_PAG C1
                
                 INNER JOIN ITCON_PAG IT1
                    ON IT1.CD_CON_PAG = C1.CD_CON_PAG
                
                 WHERE {V_VAR} 
AND C1.CD_CON_PAG = C.CD_CON_PAG) DT_VENCIMENTO,
               
               --       IT.DT_PREVISTA_PAG,
               
               TO_DATE(PP.DT_PAGAMENTO, 'DD/MM/RRRR') DT_PAGAMENTO,
               
               C.NR_DOCUMENTO,
               
               C.VL_BRUTO_CONTA,
               
               IT.VL_DUPLICATA,
               
               --       C.CD_ACRESCIMO CP_CD_ACRESCIMO,
               
               --       C.VL_ACRESCIMO CP_VL_ACRESCIMO,
               
               --       PDA.VL_DESC_ACRES VL_ACRESCDESC,
               
               --       PP.CD_ACRESCIMO,
               
               --     C.VL_ACRESCIMO,
               
               --     C.CD_DESCONTO CP_CD_DESCONTO,
               
               --     C.VL_DESCONTO CP_VL_DESCONTO,
               
               --       PP.CD_DESCONTO,
               
               PP.VL_ACRESCIMO,
               
               PP.VL_DESCONTO,
               
               PDA.CD_DESC_ACRES CD_ACRESC_DESC_FIN,
               
               DA.DS_DESC_ACRES,
               
               PP.VL_PAGO,
               
               LPIP.CD_LOTE_PGTO LOTE_PGTO_REMESSA,
               
               PP.TP_PAGAMENTO,
               
               DECODE(PP.TP_PAGAMENTO,
                      '1',
                      'Border� Boleto',
                      '2',
                      'Border� DOC',
                      '3',
                      'Cheque',
                      '4',
                      'Dinheiro',
                      '5',
                      'D�bito C/C',
                      '6',
                      'Presta��o',
                      '8',
                      'TED',
                      '7',
                      'Devolu��o',
                      'B',
                      'Baixa Cont�bil',
                      'Q',
                      'Quitado com Desconto') DS_TP_PAG,
               
               PP.DS_PAGCON_PAG,
               
               PP.CD_BORDERO BORDERO,
               
               CC.CD_AGENCIA AGENCIA,
               
               CC.NR_CONTA CONTA_CORRENTE,
               
               B.NM_BANCO BANCO,
               
               --PP.CD_CON_COR,
               
               --CC.DS_CON_COR,
               
               LP.CD_USUARIO,
               
               LP.CD_LOTE_PGTO,
               
               LP.DS_LOTE_PGTO
               
              ,
               NVL((SELECT SUM(IRT.VL_RETENCAO)
                   
                     FROM DBAMV.CON_PAG CPP
                   
                    INNER JOIN DBAMV.ITRETENCAO_TRIBUTO IRT
                       ON IRT.CD_CON_PAG = CPP.CD_CON_PAG
                      AND CPP.VL_BRUTO_CONTA = IRT.VL_REMUNERACAO
                   
                    INNER JOIN DBAMV.RETENCAO_TRIBUTO RT
                       ON RT.CD_RETENCAO_TRIBUTO = IRT.CD_RETENCAO_TRIBUTO
                   
                    INNER JOIN DBAMV.TIP_DETALHE TD
                       ON TD.CD_DETALHAMENTO = RT.CD_DETALHAMENTO
                   
                    WHERE {V_VAR} 
AND CPP.DT_LANCAMENTO > = '01/01/2012'
                         
                         --AND CPP.TP_VENCIMENTO = 'P'
                         
                         --AND CPP.CD_MULTI_EMPRESA = 1
                         
                      AND TD.CD_DETALHAMENTO IN (19, 4, 16, 1, 42) --- INSS
                         
                      AND CPP.CD_CON_PAG = IRT.CD_CON_PAG
                      AND CPP.CD_CON_PAG = C.CD_CON_PAG --IN ( 480153)
                   
                   ),
                   0) VLR_INSS
               
              ,
               NVL((SELECT SUM(IRT.VL_RETENCAO)
                   
                     FROM DBAMV.CON_PAG CPP
                   
                    INNER JOIN DBAMV.ITRETENCAO_TRIBUTO IRT
                       ON IRT.CD_CON_PAG = CPP.CD_CON_PAG
                      AND CPP.VL_BRUTO_CONTA = IRT.VL_REMUNERACAO
                   
                    INNER JOIN DBAMV.RETENCAO_TRIBUTO RT
                       ON RT.CD_RETENCAO_TRIBUTO = IRT.CD_RETENCAO_TRIBUTO
                   
                    INNER JOIN DBAMV.TIP_DETALHE TD
                       ON TD.CD_DETALHAMENTO = RT.CD_DETALHAMENTO
                   
                    INNER JOIN DBAMV.TIP_DETCON_PAG TDCP
                       ON TDCP.CD_CON_PAG_PAI = CPP.CD_CON_PAG
                         
                      AND TDCP.CD_DETALHAMENTO IN (24, 5, 15, 2, 17) --- IRRF
                         
                      AND TD.SN_ISS_GRU_FAT <> 'N'
                   
                    WHERE {V_VAR} 
AND CPP.DT_LANCAMENTO > = '01/01/2012'
                         
                         --AND CPP.TP_VENCIMENTO = 'P'
                         
                         --AND CPP.CD_MULTI_EMPRESA = 1
                         
                      AND TD.CD_DETALHAMENTO IN (24, 5, 15, 2, 17) --- IRRF
                         
                      AND CPP.CD_CON_PAG = IRT.CD_CON_PAG
                      AND CPP.CD_CON_PAG = C.CD_CON_PAG --IN ( 480153)
                   
                   ),
                   0) VLR_IRRF
               
              ,
               NVL((SELECT SUM(IRT.VL_RETENCAO)
                   
                     FROM DBAMV.CON_PAG CPP
                   
                    INNER JOIN DBAMV.ITRETENCAO_TRIBUTO IRT
                       ON IRT.CD_CON_PAG = CPP.CD_CON_PAG
                      AND CPP.VL_BRUTO_CONTA = IRT.VL_REMUNERACAO
                   
                    INNER JOIN DBAMV.RETENCAO_TRIBUTO RT
                       ON RT.CD_RETENCAO_TRIBUTO = IRT.CD_RETENCAO_TRIBUTO
                   
                    INNER JOIN DBAMV.TIP_DETALHE TD
                       ON TD.CD_DETALHAMENTO = RT.CD_DETALHAMENTO
                   
                    WHERE {V_VAR} 
AND CPP.DT_LANCAMENTO > = '01/01/2012'
                         
                         --AND CPP.TP_VENCIMENTO = 'P'
                         
                         --AND CPP.CD_MULTI_EMPRESA = 1
                         
                      AND TD.CD_DETALHAMENTO IN (11,
                                                 20,
                                                 34,
                                                 38,
                                                 39,
                                                 25,
                                                 43,
                                                 40,
                                                 41,
                                                 23,
                                                 29,
                                                 33,
                                                 12,
                                                 37,
                                                 47,
                                                 46,
                                                 44,
                                                 3) --- ISS
                         
                      AND CPP.CD_CON_PAG = IRT.CD_CON_PAG
                      AND CPP.CD_CON_PAG = C.CD_CON_PAG --IN ( 480153)
                   
                   ),
                   0) VLR_ISS
               
              ,
               NVL((SELECT SUM(IRT.VL_RETENCAO)
                   
                     FROM DBAMV.CON_PAG CPP
                   
                    INNER JOIN DBAMV.ITRETENCAO_TRIBUTO IRT
                       ON IRT.CD_CON_PAG = CPP.CD_CON_PAG
                      AND CPP.VL_BRUTO_CONTA = IRT.VL_REMUNERACAO
                   
                    INNER JOIN DBAMV.RETENCAO_TRIBUTO RT
                       ON RT.CD_RETENCAO_TRIBUTO = IRT.CD_RETENCAO_TRIBUTO
                   
                    INNER JOIN DBAMV.TIP_DETALHE TD
                       ON TD.CD_DETALHAMENTO = RT.CD_DETALHAMENTO
                   
                    WHERE {V_VAR} 
AND CPP.DT_LANCAMENTO > = '01/01/2012'
                         
                         --AND CPP.TP_VENCIMENTO = 'P'
                         
                         --AND CPP.CD_MULTI_EMPRESA = 1
                         
                      AND TD.CD_DETALHAMENTO IN (7, 8, 6, 14, 35, 36, 45) --- PCC
                         
                      AND CPP.CD_CON_PAG = IRT.CD_CON_PAG
                      AND CPP.CD_CON_PAG = C.CD_CON_PAG --IN ( 480153)
                   
                   ),
                   0) VLR_PCC
        
          FROM CON_PAG C
        
         INNER JOIN ITCON_PAG IT
            ON IT.CD_CON_PAG = C.CD_CON_PAG
        
         INNER JOIN DBAMV.PROCESSO PR
            ON PR.CD_PROCESSO = C.CD_PROCESSO
        
          LEFT JOIN PAGCON_PAG PP
            ON PP.CD_ITCON_PAG = IT.CD_ITCON_PAG
        
          LEFT JOIN CON_COR CC
            ON CC.CD_CON_COR = PP.CD_CON_COR
        
          LEFT JOIN BANCO B
            ON B.CD_BANCO = CC.CD_BANCO
        
          LEFT JOIN LOTE_PGTO_ITCON_PAG LPIP
            ON LPIP.CD_ITCON_PAG = IT.CD_ITCON_PAG
        
          LEFT JOIN LOTE_PGTO LP
            ON LP.CD_LOTE_PGTO = LPIP.CD_LOTE_PGTO
        
          LEFT JOIN FORNECEDOR F
            ON F.CD_FORNECEDOR = C.CD_FORNECEDOR
        
          LEFT JOIN DBAMV.PLANO_CONTAS PC
            ON PC.CD_REDUZIDO = C.CD_REDUZIDO
        
          LEFT JOIN RATCON_PAG RCP
            ON RCP.CD_CON_PAG = C.CD_CON_PAG
        
        --LEFT JOIN DBAMV.FORN_CONTA FC ON FC.CD_FORNECEDOR = F.CD_FORNECEDOR AND FC.TP_CONTA NOT IN ('DS','AD') AND FC.CD_MULTI_EMPRESA = C.CD_MULTI_EMPRESA
        
          LEFT JOIN DBAMV.PLANO_CONTAS PCC
            ON PCC.CD_REDUZIDO = RCP.CD_REDUZIDO
        
          LEFT JOIN LOTE_REM_ITCON_PAG L
            ON L.CD_ITCON_PAG = IT.CD_ITCON_PAG
        
          LEFT JOIN LOTE_REMESSA LR
            ON LR.CD_LOTE_REMESSA = L.CD_LOTE_REMESSA
        
          LEFT JOIN EXP_ARQUIVO_REMESSA EAR
            ON EAR.CD_EXP_ARQUIVO_REMESSA = LR.CD_EXP_ARQUIVO_REMESSA
        
          LEFT JOIN PAG_DESC_ACRES PDA
            ON PDA.CD_PAGCON_PAG = PP.CD_PAGCON_PAG
        
          LEFT JOIN DBAMV.DESCONTOS_ACRESCIMOS DA
            ON DA.CD_DESC_ACRES = PDA.CD_DESC_ACRES
        
          LEFT JOIN DBAMV.SETOR S
            ON S.CD_SETOR = RCP.CD_SETOR
        
        ) Q

WHERE {V_VAR}
AND TO_DATE(Q.DT_PAGAMENTO, 'DD/MM/RRRR') BETWEEN  TO_DATE(@P_DT_PAGAMENTO_INI, 'DD/MM/RRRR') AND TO_DATE(@P_DT_PAGAMENTO_FIM, 'DD/MM/RRRR')
AND (TRIM('{V_EMPRESA_AUX}') IS NULL OR '{V_EMPRESA_AUX}' = '0' OR Q.CD_MULTI_EMPRESA IN ({V_EMPRESA_AUX}))
AND (TRIM('{V_PROCESSO_AUX}') IS NULL OR '{V_PROCESSO_AUX}' = '0' OR Q.CD_PROCESSO IN ({V_PROCESSO_AUX}))
AND (TRIM('{V_CONTAS_AUX}') IS NULL OR '{V_CONTAS_AUX}' = '0' OR Q.CD_REDUZIDO IN ({V_CONTAS_AUX}))

 GROUP BY CD_CON_PAG,
          
          CD_PROCESSO,
          
          DS_PROCESSO,
          
          CD_MULTI_EMPRESA,
          
          CD_FORNECEDOR,
          
          DS_FORNECEDOR,
          
          NR_CGC_CPF,
          
          CD_REDUZIDO,
          
          DS_CONTA,
          
          DS_OBSERVACAO,
          
          DT_IMPORTACAO_MGES,
          
          DT_EXP_ARQ_LOTE,
          
          DS_LOTE_REMESSA,
          
          --CD_REDUZIDO,
          
          DT_EMISSAO,
          
          DT_LANCAMENTO,
          
          DT_VENCIMENTO,
          
          --DT_VENCIMENTO,
          
          --DT_PREVISTA_PAG,
          
          DT_PAGAMENTO,
          
          NR_DOCUMENTO,
          
          VL_BRUTO_CONTA,
          
          VL_DUPLICATA,
          
          --CP_CD_ACRESCIMO,
          
          --CP_VL_ACRESCIMO,
          
          --CP_CD_DESCONTO,
          
          --CP_VL_DESCONTO,
          
          --VL_ACRESCDESC,
          
          --CD_ACRESCIMO,
          
          --CD_DESCONTO,
          
          VL_ACRESCIMO,
          
          VL_DESCONTO,
          
          CD_ACRESC_DESC_FIN,
          
          DS_DESC_ACRES,
          
          VL_PAGO,
          
          LOTE_PGTO_REMESSA,
          
          TP_PAGAMENTO,
          
          DS_TP_PAG,
          
          DS_PAGCON_PAG,
          
          CD_SETOR,
          
          NM_SETOR,
          
          CD_REDUZIDO_COMPART,
          
          DS_CONTA_COMPART,
          
          VL_RATEIO,
          
          BORDERO,
          
          AGENCIA,
          
          CONTA_CORRENTE,
          
          BANCO,
          
          CD_USUARIO,
          
          CD_LOTE_PGTO,
          
          DS_LOTE_PGTO,
          
          VLR_INSS,
          
          VLR_IRRF,
          
          VLR_ISS,
          
          VLR_PCC

 ORDER BY 2, 1 ASC
