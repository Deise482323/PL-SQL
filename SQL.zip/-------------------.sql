SELECT TO_CHAR(AT1.DT_ATENDIMENTO, 'MM/RRRR') COMPETENCIA,
       TO_CHAR(AT1.DT_ATENDIMENTO, 'MM') MES,
       TO_CHAR(AT1.DT_ATENDIMENTO, 'RRRR') ANO,
       OA.DS_ORI_ATE ORIGEM,
       AT1.CD_ATENDIMENTO ATENDIMENTO,
       AT1.DT_ATENDIMENTO,
       AT1.CD_PACIENTE PRONTUARIO,
       PAC.NM_PACIENTE PACIENTE,
       TRUNC(STP.DH_PROCESSO) DT_TOTEM,
       TO_CHAR(STP.DH_PROCESSO, 'HH24:MI:SS') HORA_TOTEM,
       TRUNC(STP3.DH_PROCESSO) DT_INIC_ATEND,
       TO_CHAR(STP3.DH_PROCESSO, 'HH24:MI:SS') HORA_INIC_ATEND,
       nvl(round((((STP3.DH_PROCESSO - stp.dh_processo) * 86400 / 3600) * 60),
                 0),
           '00') TOTEM_INICIO_ATENDIMENTO,
       CASE
         WHEN STP4.DH_PROCESSO IS NULL THEN
          AT1.DT_ATENDIMENTO
         ELSE
          TRUNC(STP4.DH_PROCESSO)
       END DT_FINAL_ATEND,
       CASE
         WHEN STP4.DH_PROCESSO IS NULL THEN
          TO_CHAR(AT1.HR_ATENDIMENTO, 'HH24:MI:SS')
         ELSE
          TO_CHAR(STP4.DH_PROCESSO, 'HH24:MI:SS')
       END HORA_FINAL_ATEND,
       nvl(round((((STP4.DH_PROCESSO - stp3.dh_processo) * 86400 / 3600) * 60),
                 0),
           '00') INICIO_ATEND_FINAL_ATEND,
       TRUNC(CA.DT_INICIO) DT_INICIO_ATEND_MEDICO,
       TO_CHAR(CA.DT_INICIO, 'HH24:MI:SS') HORA_INICIO_ATEND_MEDICO,
       (trunc(round(((to_number(to_date(SUBSTR(TO_CHAR(ca.dt_inicio,
                                                       'DD/MM/RRRR'),
                                               1,
                                               10) ||
                                        SUBSTR(TO_CHAR(ca.dt_inicio,
                                                       'HH24:mi'),
                                               1,
                                               5),
                                        'DD/MM/RRRR HH24:MI') -
                                (CASE
                                   WHEN STP4.DH_PROCESSO IS NULL THEN
                                    to_date(SUBSTR(TO_CHAR(AT1.DT_ATENDIMENTO, 'DD/MM/RRRR'), 1, 10) ||
                                            SUBSTR(TO_CHAR(AT1.HR_ATENDIMENTO, 'HH24:mi'), 1, 5),
                                            'DD/MM/RRRR HH24:MI')
                                   ELSE
                                    to_date(SUBSTR(TO_CHAR(STP4.DH_PROCESSO, 'DD/MM/RRRR'), 1, 10) ||
                                            SUBSTR(TO_CHAR(STP4.DH_PROCESSO, 'HH24:mi'), 1, 5),
                                            'DD/MM/RRRR HH24:MI')
                                 END))) * 1440) / 60,
                    2),
              0) --) ,2), 0) / count(*),2), 0)  --Soma das horas inteiras
       || ':' || lpad(round(MOD((to_number(to_date(SUBSTR(TO_CHAR(ca.dt_inicio,
                                                                   'DD/MM/RRRR'),
                                                           1,
                                                           10) ||
                                                    SUBSTR(TO_CHAR(ca.dt_inicio,
                                                                   'HH24:mi'),
                                                           1,
                                                           5),
                                                    'DD/MM/RRRR HH24:MI') -
                                            (CASE
                                               WHEN STP4.DH_PROCESSO IS NULL THEN
                                                to_date(SUBSTR(TO_CHAR(AT1.DT_ATENDIMENTO, 'DD/MM/RRRR'), 1, 10) ||
                                                        SUBSTR(TO_CHAR(AT1.HR_ATENDIMENTO, 'HH24:mi'), 1, 5),
                                                        'DD/MM/RRRR HH24:MI')
                                               ELSE
                                                to_date(SUBSTR(TO_CHAR(STP4.DH_PROCESSO, 'DD/MM/RRRR'), 1, 10) ||
                                                        SUBSTR(TO_CHAR(STP4.DH_PROCESSO, 'HH24:mi'), 1, 5),
                                                        'DD/MM/RRRR HH24:MI')
                                             END)) * 1440) --/ count(*)
                                ,
                                 60)),
                       2,
                       '0') --- soma dos minutos
       ) FIM_ATEND_INIC_MED_HH_MM,
       AT1.DT_ALTA_MEDICA,
       AT1.DT_ALTA,
       ta.ds_senha,
       case
         when substr(ta.ds_senha, 1, 2) = 'PC' THEN
          'PREFERENCIAL'
         WHEN ta.ds_senha is null then
          'SEM SENHA'
         ELSE
          'NORMAL'
       END SENHA,
       
       at1.NM_USUARIO,
       iac.hr_agenda,
       pre.nm_prestador
  FROM ATENDIME AT1
 INNER JOIN PACIENTE PAC
    ON PAC.CD_PACIENTE = AT1.CD_PACIENTE
 inner join ORI_ATE OA
    ON AT1.CD_ORI_ATE = OA.CD_ORI_ATE
  LEFT JOIN SACR_TEMPO_PROCESSO STP
    ON STP.CD_ATENDIMENTO = AT1.CD_ATENDIMENTO
   and stp.Cd_Tipo_Tempo_Processo = 1
  LEFT JOIN SACR_TEMPO_PROCESSO STP3
    ON STP3.CD_ATENDIMENTO = AT1.CD_ATENDIMENTO
   AND STP3.CD_TIPO_TEMPO_PROCESSO = 21 --- ATENDIMENTO ADMINISTRATIVO IN�CIO
  LEFT JOIN SACR_TEMPO_PROCESSO STP4
    ON STP4.CD_ATENDIMENTO = AT1.CD_ATENDIMENTO
   AND STP4.CD_TIPO_TEMPO_PROCESSO = 22 --- ATENDIMENTO ADMINISTRATIVO FINAL
  LEFT join casos_atd ca
    on at1.CD_ATENDIMENTO = ca.cd_atendimento --- INICIO ATENDIMENTO MEDICO ---
  LEFT JOIN dbamv.triagem_atendimento ta
    ON at1.cd_Atendimento = ta.cd_atendimento
  LEFT JOIN DBAMV.IT_AGENDA_CENTRAL IAC ---qtde registro 2.182
    ON IAC.CD_ATENDIMENTO = AT1.CD_ATENDIMENTO
   AND IAC.Cd_It_Agenda_Pai IS NULL
  LEFT JOIN DBAMV.PRESTADOR PRE
    ON PRE.CD_PRESTADOR = AT1.CD_PRESTADOR
 inner join DBAMV.ESPECIALID ESP
    ON ESP.CD_ESPECIALID = AT1.CD_ESPECIALID
 where TO_CHAR(AT1.DT_ATENDIMENTO, 'MM/RRRR') = '{COMPETENCIA}'
   AND AT1.TP_ATENDIMENTO IN ('A', 'E')
   AND AT1.CD_MULTI_EMPRESA = 1
   AND AT1.CD_ORI_ATE in ({CD_ORI_ATE_AUX})
   AND ESP.CD_ESPECIALID IN ({ESPECIALID_AUX})
   and ((ca.cd_casos_atd in
        (select min(caa.cd_casos_atd)
            from dbamv.casos_atd caa
           where caa.cd_atendimento = at1.CD_ATENDIMENTO)) or
        ca.cd_casos_atd is null)
