SELECT TO_CHAR(AT1.DT_ATENDIMENTO, 'MM/RRRR') COMPETENCIA,
       TO_CHAR(AT1.DT_ATENDIMENTO, 'MM') MES,
       TO_CHAR(AT1.DT_ATENDIMENTO, 'RRRR') ANO,
       OA.DS_ORI_ATE ORIGEM,
       AT1.CD_ATENDIMENTO ATENDIMENTO,
       AT1.DT_ATENDIMENTO,
       AT1.CD_PACIENTE PRONTUARIO,
       PAC.NM_PACIENTE PACIENTE,
       TRUNC(STP.DH_PROCESSO) DT_TOTEM,
       TO_CHAR(STP.DH_PROCESSO, 'HH24:MI:SS') HORA_TOTEM,
       TRUNC(STP3.DH_PROCESSO) DT_INIC_ATEND,
       TO_CHAR(STP3.DH_PROCESSO, 'HH24:MI:SS') HORA_INIC_ATEND,
       NVL(ROUND((((STP3.DH_PROCESSO - STP.DH_PROCESSO) * 86400 / 3600) * 60),
                 0),
           '00') TOTEM_INICIO_ATENDIMENTO,
       CASE
         WHEN STP4.DH_PROCESSO IS NULL THEN
          AT1.DT_ATENDIMENTO
         ELSE
          TRUNC(STP4.DH_PROCESSO)
       END DT_FINAL_ATEND,
       CASE
         WHEN STP4.DH_PROCESSO IS NULL THEN
          TO_CHAR(AT1.HR_ATENDIMENTO, 'HH24:MI:SS')
         ELSE
          TO_CHAR(STP4.DH_PROCESSO, 'HH24:MI:SS')
       END HORA_FINAL_ATEND,
       NVL(ROUND((((STP4.DH_PROCESSO - STP3.DH_PROCESSO) * 86400 / 3600) * 60),
                 0),
           '00') INICIO_ATEND_FINAL_ATEND,
       TRUNC(CA.DT_INICIO) DT_INICIO_ATEND_MEDICO,
       TO_CHAR(CA.DT_INICIO, 'HH24:MI:SS') HORA_INICIO_ATEND_MEDICO,
       (TRUNC(ROUND(((TO_NUMBER(TO_DATE(SUBSTR(TO_CHAR(CA.DT_INICIO,
                                                       'DD/MM/RRRR'),
                                               1,
                                               10) ||
                                        SUBSTR(TO_CHAR(CA.DT_INICIO,
                                                       'HH24:mi'),
                                               1,
                                               5),
                                        'DD/MM/RRRR HH24:MI') -
                                (CASE
                                   WHEN STP4.DH_PROCESSO IS NULL THEN
                                    TO_DATE(SUBSTR(TO_CHAR(AT1.DT_ATENDIMENTO, 'DD/MM/RRRR'), 1, 10) ||
                                            SUBSTR(TO_CHAR(AT1.HR_ATENDIMENTO, 'HH24:mi'), 1, 5),
                                            'DD/MM/RRRR HH24:MI')
                                   ELSE
                                    TO_DATE(SUBSTR(TO_CHAR(STP4.DH_PROCESSO, 'DD/MM/RRRR'), 1, 10) ||
                                            SUBSTR(TO_CHAR(STP4.DH_PROCESSO, 'HH24:mi'), 1, 5),
                                            'DD/MM/RRRR HH24:MI')
                                 END))) * 1440) / 60,
                    2),
              0) --) ,2), 0) / COUNT(*),2), 0)  --SOMA DAS HORAS INTEIRAS
       || ':' || LPAD(ROUND(MOD((TO_NUMBER(TO_DATE(SUBSTR(TO_CHAR(CA.DT_INICIO,
                                                                   'DD/MM/RRRR'),
                                                           1,
                                                           10) ||
                                                    SUBSTR(TO_CHAR(CA.DT_INICIO,
                                                                   'HH24:mi'),
                                                           1,
                                                           5),
                                                    'DD/MM/RRRR HH24:MI') -
                                            (CASE
                                               WHEN STP4.DH_PROCESSO IS NULL THEN
                                                TO_DATE(SUBSTR(TO_CHAR(AT1.DT_ATENDIMENTO, 'DD/MM/RRRR'), 1, 10) ||
                                                        SUBSTR(TO_CHAR(AT1.HR_ATENDIMENTO, 'HH24:mi'), 1, 5),
                                                        'DD/MM/RRRR HH24:MI')
                                               ELSE
                                                TO_DATE(SUBSTR(TO_CHAR(STP4.DH_PROCESSO, 'DD/MM/RRRR'), 1, 10) ||
                                                        SUBSTR(TO_CHAR(STP4.DH_PROCESSO, 'HH24:mi'), 1, 5),
                                                        'DD/MM/RRRR HH24:MI')
                                             END)) * 1440) --/ COUNT(*)
                                ,
                                 60)),
                       2,
                       '0') --- SOMA DOS MINUTOS
       ) FIM_ATEND_INIC_MED_HH_MM,
       AT1.DT_ALTA_MEDICA,
       AT1.DT_ALTA,
       TA.DS_SENHA,
       CASE
         WHEN SUBSTR(TA.DS_SENHA, 1, 2) = 'PC' THEN
          'PREFERENCIAL'
         WHEN TA.DS_SENHA IS NULL THEN
          'SEM SENHA'
         ELSE
          'NORMAL'
       END SENHA,
       
       U.NM_USUARIO,
       IAC.HR_AGENDA,
       PRE.NM_PRESTADOR,
       C.NM_CONVENIO
       
  FROM ATENDIME AT1
  INNER JOIN CONVENIO C ON C.CD_CONVENIO = AT1.CD_CONVENIO
 INNER JOIN PACIENTE PAC
    ON PAC.CD_PACIENTE = AT1.CD_PACIENTE
 INNER JOIN ORI_ATE OA
    ON AT1.CD_ORI_ATE = OA.CD_ORI_ATE
  LEFT JOIN SACR_TEMPO_PROCESSO STP
    ON STP.CD_ATENDIMENTO = AT1.CD_ATENDIMENTO
   AND STP.CD_TIPO_TEMPO_PROCESSO = 1
  LEFT JOIN SACR_TEMPO_PROCESSO STP3
    ON STP3.CD_ATENDIMENTO = AT1.CD_ATENDIMENTO
   AND STP3.CD_TIPO_TEMPO_PROCESSO = 21 --- ATENDIMENTO ADMINISTRATIVO IN�CIO
  LEFT JOIN SACR_TEMPO_PROCESSO STP4
    ON STP4.CD_ATENDIMENTO = AT1.CD_ATENDIMENTO
   AND STP4.CD_TIPO_TEMPO_PROCESSO = 22 --- ATENDIMENTO ADMINISTRATIVO FINAL
  LEFT JOIN CASOS_ATD CA
    ON AT1.CD_ATENDIMENTO = CA.CD_ATENDIMENTO --- INICIO ATENDIMENTO MEDICO ---
  LEFT JOIN DBAMV.TRIAGEM_ATENDIMENTO TA
    ON AT1.CD_ATENDIMENTO = TA.CD_ATENDIMENTO
  LEFT JOIN DBAMV.IT_AGENDA_CENTRAL IAC ---QTDE REGISTRO 2.182
    ON IAC.CD_ATENDIMENTO = AT1.CD_ATENDIMENTO
   AND IAC.CD_IT_AGENDA_PAI IS NULL
  LEFT JOIN DBAMV.PRESTADOR PRE
    ON PRE.CD_PRESTADOR = AT1.CD_PRESTADOR
 LEFT JOIN USUARIOS U
    ON U.CD_USUARIO = AT1.NM_USUARIO
 LEFT JOIN DBAMV.ESPECIALID ESP
    ON ESP.CD_ESPECIALID = AT1.CD_ESPECIALID
 WHERE TO_CHAR(AT1.DT_ATENDIMENTO, 'MM/RRRR') = '06/2025'
   AND AT1.TP_ATENDIMENTO IN ('E')
   --AND AT1.CD_MULTI_EMPRESA IN (1,16)

AND AT1.CD_ORI_ATE IN (34, 16)
/*AND AT1.CD_CONVENIO IN ({V_CONV_AUX})
AND ((CA.CD_CASOS_ATD IN (SELECT MIN(CAA.CD_CASOS_ATD) FROM DBAMV.CASOS_ATD CAAS
           WHERE CAA.CD_ATENDIMENTO = AT1.CD_ATENDIMENTO)) OR CA.CD_CASOS_ATD IS NULL)
AND (TRIM({CD_ATENDIMENTO}) IS NULL OR {CD_ATENDIMENTO} = 0 OR AT1.CD_ATENDIMENTO IN ({CD_ATENDIMENTO}))
   AND (TRIM({CD_PACIENTE}) IS NULL OR {CD_PACIENTE} = 0 OR AT1.CD_PACIENTE = ({CD_PACIENTE}))*/
   
