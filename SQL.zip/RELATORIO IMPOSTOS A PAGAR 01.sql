select tdp.cd_con_pag_pai,
       tdp.cd_con_pag_filho,
       tdp.cd_detalhamento,
       td.ds_detalhamento,
       icp.dt_vencimento,
       cp.dt_emissao,
       cp.ds_con_pag,
      (select  distinct f1.nr_cgc_cpf from con_pag cp1, tip_detcon_pag tdp1, fornecedor f1
where  cp1.cd_con_pag = tdp1.cd_con_pag_pai
       and cp1.cd_fornecedor = f1.cd_fornecedor
       and cp1.cd_con_pag = tdp.cd_con_pag_pai) cnpj,
       cp.nr_documento,
       tdp.vl_detalhamento,
       pc.cd_con_cor,
       cc.ds_con_cor
from   
       dbamv.con_pag cp,
       dbamv.itcon_pag icp,
       dbamv.pagcon_pag pc,
       dbamv.con_cor cc,
       dbamv.tip_detcon_pag tdp,
       dbamv.TIP_DETALHE td
where  
       cp.cd_con_pag = icp.cd_con_pag 
       and icp.cd_itcon_pag = pc.cd_itcon_pag
       and cc.cd_con_cor = pc.cd_con_cor
       and cp.cd_con_pag = tdp.cd_con_pag_pai
       and tdp.cd_detalhamento = td.cd_detalhamento
       and icp.dt_vencimento between '01/01/2024' and '29/02/2024'
       and tdp.cd_con_pag_filho in (1195870,1195869)
