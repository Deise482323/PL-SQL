SELECT * FROM dbamv.caught_errors  ORDER BY dt DESC

--ALTER TRIGGER dbamv.catch_errors ENABLE;

--TRIGGER dbamv.catch_errors
 
