select ate.cd_paciente,PLA.DT_PEDIDO, RE.*
  from ped_lab pla
  join itPed_Lab ipl
    on ipl.cd_ped_lab = pla.cd_ped_lab
  join exa_lab el
    on el.cd_exa_lab = ipl.cd_exa_lab
  join atendime ate
    on ate.cd_atendimento = pla.cd_atendimento
  join res_exa re
    on re.cd_ped_lab = pla.cd_ped_lab
   and re.cd_exa_lab = el.cd_exa_lab
 where pla.dt_pedido >= '01/07/2024'
   and pla.cd_multi_empresa = 2

   AND EL.CD_EXA_LAB = 34 -- IN (404, 573, 671, 762, 755, 1547, 716, 437, 26,1270,1271, 652, 1528,677, 34, 962 )
  -- AND RE.NM_CAMPO LIKE '%HDL%'
   AND ATE.CD_ORI_ATE = 7
 -- and  ATE.CD_PACIENTE = 1983975;
  
 /* SELECT * FROM CULTURA C
  WHERE C.CD_PED_LAB = 2359571*/
