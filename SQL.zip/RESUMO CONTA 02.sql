--HNB_NOVO_RESUMO

SELECT G.CONTA,
       G.CD_CON_REC,
       G.SITUACAO,
       G.CD_ATENDIMENTO,
       G.CD_PACIENTE,
       G.NM_PACIENTE,
       G.DT_NASCIMENTO,
       G.DT_ATENDIMENTO,
       G.DT_ALTA,
       G.SEXO,
       G.GRUPO,
       G.DS_GRU_FAT,
       G.VL_PREVISTO,
       G.VL_ADIANTAMENTO,
       G.VL_DESCONTO,
       G.VL_RECEBIDO,
       G.VL_POR_GRUPO,
       (NVL(G.VL_POR_GRUPO, 0) - NVL(G.VL_ADIANTAMENTO, 0) -
       NVL(G.VL_DESCONTO, 0) - NVL(G.VL_RECEBIDO, 0)) SALDO

  FROM (SELECT IRF.CD_REG_FAT CONTA,
               CR.CD_CON_REC,
               DECODE(RF.SN_FECHADA, 'N', 'ABERTA', 'S', 'FECHADA') SITUACAO,
               RF.CD_ATENDIMENTO,
               A.CD_PACIENTE,
               P.NM_PACIENTE,
               TO_DATE(P.DT_NASCIMENTO, 'DD/MM/RRRR') DT_NASCIMENTO,
               A.DT_ATENDIMENTO DT_ATENDIMENTO,
               A.DT_ALTA DT_ALTA,
               DECODE(P.TP_SEXO,
                      'F',
                      'FEMININO',
                      'M',
                      'MASCULINO',
                      'G',
                      'IGNORADO',
                      'I',
                      'INDEFINIDO') SEXO,
               IRF.CD_GRU_FAT GRUPO,
               GF.DS_GRU_FAT,
               
               (SELECT DISTINCT (NVL(ICR.VL_DUPLICATA, 0))
                  FROM RECCON_REC RCR
                 INNER JOIN ITCON_REC ICR
                    ON ICR.CD_ITCON_REC = RCR.CD_ITCON_REC
                 INNER JOIN CON_REC CR
                    ON CR.CD_REG_FAT = RF.CD_REG_FAT
                   AND CR.CD_CON_REC = ICR.CD_CON_REC
                 WHERE RCR.CD_CONTRATO_ADIANT IS NOT NULL) VL_PREVISTO,
               
               (SELECT DISTINCT SUM(NVL(RCR.VL_RECEBIDO, 0))
                  FROM RECCON_REC RCR
                 INNER JOIN ITCON_REC ICR
                    ON ICR.CD_ITCON_REC = RCR.CD_ITCON_REC
                 INNER JOIN CON_REC CR
                    ON CR.CD_REG_FAT = RF.CD_REG_FAT
                   AND CR.CD_CON_REC = ICR.CD_CON_REC
                 WHERE RCR.CD_CONTRATO_ADIANT IS NOT NULL) VL_ADIANTAMENTO,
               
               (SELECT DISTINCT SUM(NVL(RCR.VL_DESCONTO, 0))
                  FROM RECCON_REC RCR
                 INNER JOIN ITCON_REC ICR
                    ON ICR.CD_ITCON_REC = RCR.CD_ITCON_REC
                 INNER JOIN CON_REC CR
                    ON CR.CD_REG_FAT = RF.CD_REG_FAT
                   AND CR.CD_CON_REC = ICR.CD_CON_REC) VL_DESCONTO,
               
               NVL(CASE
                     WHEN (SELECT SUM(RCR.VL_RECEBIDO)
                             FROM ITCON_REC ICR
                            INNER JOIN CON_REC CR
                               ON CR.CD_CON_REC = ICR.CD_CON_REC
                            INNER JOIN RECCON_REC RCR
                               ON RCR.CD_ITCON_REC = ICR.CD_ITCON_REC
                            INNER JOIN REG_FAT RF
                               ON RF.CD_REG_FAT = CR.CD_REG_FAT
                            INNER JOIN ITCON_REC ICR2
                               ON ICR2.CD_CON_REC_AGRUP = ICR.CD_CON_REC_AGRUP
                            WHERE RF.CD_ATENDIMENTO = 11602379 --{V_ATENDIMENTO}
                                 --AND {V_VAR} 
                              AND CR.CD_CON_REC_RENEGOCIADO IS NULL) <> 0 THEN
                      0
                     ELSE
                      (SELECT SUM(RCR.VL_RECEBIDO)
                         FROM ITCON_REC ICR
                        INNER JOIN CON_REC CR
                           ON CR.CD_CON_REC = ICR.CD_CON_REC
                        INNER JOIN RECCON_REC RCR
                           ON RCR.CD_ITCON_REC = ICR.CD_ITCON_REC
                        INNER JOIN REG_FAT RF
                           ON RF.CD_REG_FAT = CR.CD_REG_FAT
                        WHERE RF.CD_ATENDIMENTO = 11602379 --{V_ATENDIMENTO}
                             --AND {V_VAR} 
                          AND CR.CD_CON_REC_RENEGOCIADO IS NULL)
                   END,
                   0) VL_RECEBIDO,
               SUM(IRF.VL_TOTAL_CONTA) VL_POR_GRUPO
        
          FROM ITREG_FAT IRF
         INNER JOIN REG_FAT RF
            ON RF.CD_REG_FAT = IRF.CD_REG_FAT
          JOIN CON_REC CR
            ON CR.CD_REG_FAT = RF.CD_REG_FAT
         INNER JOIN ATENDIME A
            ON A.CD_ATENDIMENTO = RF.CD_ATENDIMENTO
         INNER JOIN PACIENTE P
            ON P.CD_PACIENTE = A.CD_PACIENTE
         INNER JOIN GRU_FAT GF
            ON GF.CD_GRU_FAT = IRF.CD_GRU_FAT
         WHERE IRF.CD_GRU_FAT = GF.CD_GRU_FAT
           AND RF.CD_ATENDIMENTO = 11602379 --{V_ATENDIMENTO}
        --AND {V_VAR} 
        --AND IRF.SN_PERTENCE_PACOTE = 'N'
        
         GROUP BY IRF.CD_REG_FAT,
                  RF.CD_REG_FAT,
                  RF.SN_FECHADA,
                  CR.CD_CON_REC,
                  A.CD_PACIENTE,
                  P.NM_PACIENTE,
                  P.DT_NASCIMENTO,
                  A.DT_ATENDIMENTO,
                  A.DT_ALTA,
                  RF.CD_ATENDIMENTO,
                  P.TP_SEXO,
                  IRF.CD_GRU_FAT,
                  IRF.VL_ACRESCIMO,
                  IRF.VL_DESCONTO,
                  GF.DS_GRU_FAT
        
        UNION
        
        SELECT IRA.CD_REG_AMB CONTA,
               CR.CD_CON_REC,
               DECODE(RA.SN_FECHADA, 'N', 'ABERTA', 'S', 'FECHADA') SITUACAO,
               IRA.CD_ATENDIMENTO,
               A.CD_PACIENTE,
               P.NM_PACIENTE,
               TO_DATE(P.DT_NASCIMENTO, 'DD/MM/RRRR') DT_NASCIMENTO,
               A.DT_ATENDIMENTO DT_ATENDIMENTO,
               A.DT_ALTA DT_ALTA,
               DECODE(P.TP_SEXO,
                      'F',
                      'FEMININO',
                      'M',
                      'MASCULINO',
                      'G',
                      'IGNORADO',
                      'I',
                      'INDEFINIDO') SEXO,
               IRA.CD_GRU_FAT GRUPO,
               GF.DS_GRU_FAT,
               
               (SELECT DISTINCT (NVL(ICR.VL_DUPLICATA, 0))
                  FROM RECCON_REC RCR
                 INNER JOIN ITCON_REC ICR
                    ON ICR.CD_ITCON_REC = RCR.CD_ITCON_REC
                 INNER JOIN CON_REC CR
                    ON CR.CD_REG_AMB = RA.CD_REG_AMB
                   AND CR.CD_CON_REC = ICR.CD_CON_REC
                 WHERE RCR.CD_CONTRATO_ADIANT IS NOT NULL) VL_PREVISTO,
               
               (SELECT DISTINCT SUM(NVL(RCR.VL_RECEBIDO, 0))
                  FROM RECCON_REC RCR
                 INNER JOIN ITCON_REC ICR
                    ON ICR.CD_ITCON_REC = RCR.CD_ITCON_REC
                 INNER JOIN CON_REC CR
                    ON CR.CD_REG_AMB = RA.CD_REG_AMB
                   AND CR.CD_CON_REC = ICR.CD_CON_REC
                 WHERE RCR.CD_CONTRATO_ADIANT IS NOT NULL) VL_ADIANTAMENTO,
               
               (SELECT DISTINCT SUM(NVL(RCR.VL_DESCONTO, 0))
                  FROM RECCON_REC RCR
                 INNER JOIN ITCON_REC ICR
                    ON ICR.CD_ITCON_REC = RCR.CD_ITCON_REC
                 INNER JOIN CON_REC CR
                    ON CR.CD_REG_AMB = RA.CD_REG_AMB
                   AND CR.CD_CON_REC = ICR.CD_CON_REC) VL_DESCONTO,
               
               NVL(CASE
                     WHEN (SELECT SUM(RCR.VL_RECEBIDO)
                             FROM ITCON_REC ICR
                            INNER JOIN CON_REC CR
                               ON CR.CD_CON_REC = ICR.CD_CON_REC
                            INNER JOIN RECCON_REC RCR
                               ON RCR.CD_ITCON_REC = ICR.CD_ITCON_REC
                            INNER JOIN REG_AMB RA
                               ON RA.CD_REG_AMB = CR.CD_REG_AMB
                            INNER JOIN ITCON_REC ICR2
                               ON ICR2.CD_CON_REC_AGRUP = ICR.CD_CON_REC_AGRUP
                            WHERE IRA.CD_ATENDIMENTO = 11602379 --{V_ATENDIMENTO}
                                 --AND {V_VAR} 
                              AND CR.CD_CON_REC_RENEGOCIADO IS NULL) <> 0 THEN
                      0
                     ELSE
                      (SELECT SUM(RCR.VL_RECEBIDO)
                         FROM ITCON_REC ICR
                        INNER JOIN CON_REC CR
                           ON CR.CD_CON_REC = ICR.CD_CON_REC
                        INNER JOIN RECCON_REC RCR
                           ON RCR.CD_ITCON_REC = ICR.CD_ITCON_REC
                        INNER JOIN REG_AMB RA
                           ON RA.CD_REG_AMB = CR.CD_REG_AMB
                        WHERE IRA.CD_ATENDIMENTO = 11602379 --{V_ATENDIMENTO}
                             --AND {V_VAR} 
                          AND CR.CD_CON_REC_RENEGOCIADO IS NULL)
                   END,
                   0) VL_RECEBIDO,
               
               SUM(IRA.VL_TOTAL_CONTA) VL_POR_GRUPO
        
          FROM ITREG_AMB IRA
         INNER JOIN REG_AMB RA
            ON RA.CD_REG_AMB = IRA.CD_REG_AMB
          JOIN CON_REC CR
            ON CR.CD_REG_AMB = RA.CD_REG_AMB
         INNER JOIN ATENDIME A
            ON A.CD_ATENDIMENTO = IRA.CD_ATENDIMENTO
         INNER JOIN PACIENTE P
            ON P.CD_PACIENTE = A.CD_PACIENTE
         INNER JOIN GRU_FAT GF
            ON GF.CD_GRU_FAT = IRA.CD_GRU_FAT
         WHERE IRA.CD_ATENDIMENTO = 11602379 --{V_ATENDIMENTO}
        --AND {V_VAR} 
        --AND IRA.SN_PERTENCE_PACOTE = 'N'
         GROUP BY IRA.CD_REG_AMB,
                  RA.CD_REG_AMB,
                  RA.SN_FECHADA,
                  A.CD_PACIENTE,
                  P.NM_PACIENTE,
                  P.DT_NASCIMENTO,
                  CR.CD_CON_REC,
                  A.DT_ATENDIMENTO,
                  A.DT_ALTA,
                  IRA.CD_ATENDIMENTO,
                  P.TP_SEXO,
                  IRA.CD_GRU_FAT,
                  IRA.VL_ACRESCIMO,
                  IRA.VL_DESCONTO,
                  GF.DS_GRU_FAT) G
