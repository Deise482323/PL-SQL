SELECT *
  FROM ITORD_PRO
 WHERE CD_ORD_COM IN
       (SELECT CD_ORD_COM FROM ORD_COM WHERE CD_ORD_COM = 418323)
------------------------------------------------------------------
  SELECT * FROM ENT_PRO WHERE CD_ORD_COM = 418323
