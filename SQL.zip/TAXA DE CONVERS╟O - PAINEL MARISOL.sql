SELECT '<b><span style="color: #001A70; font-family: Arial Black;">UNIDADE</span></b>' CL1,
       '<b><span style="color: #001A70; font-family: Arial Black;">QTD_ATENDIMENTOS</span></b>' CL2,
       '<b><span style="color: #001A70; font-family: Arial Black;">QTD_INTERNA��ES</span></b>' CL3,
       '<b><span style="color: #001A70; font-family: Arial Black;">TAXA</span></b>' CL4
  FROM DUAL
-----------------(PA INFANTIL)-----------------------------
UNION ALL

SELECT '<b><span style="color: #00B388;  font-family: Arial Black;">PA INFANTIL</span></b>' AS DESCRICAO,
       
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR((SELECT COUNT(ATE.CD_ATENDIMENTO)
                 FROM ATENDIME ATE
                WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                  AND ATE.CD_ORI_ATE IN (14)
                  AND ATE.CD_MULTI_EMPRESA = 1
                  AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1)) ||
       '</span></b>' AS QTD_PA,
       
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR((SELECT COUNT(ATE.CD_ATENDIMENTO)
                 FROM ATENDIME ATE
                WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                  AND ATE.CD_ORI_ATE IN (64)
                  AND ATE.CD_MULTI_EMPRESA = 1
                  AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1)) ||
       '</span></b>' AS QTD_INTER,
       
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR(ROUND((SELECT COUNT(ATE.CD_ATENDIMENTO)
                        FROM ATENDIME ATE
                       WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                         AND ATE.CD_ORI_ATE IN (64)
                         AND ATE.CD_MULTI_EMPRESA = 1
                         AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1) /
                     NULLIF((SELECT COUNT(ATE.CD_ATENDIMENTO)
                              FROM ATENDIME ATE
                             WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                               AND ATE.CD_ORI_ATE IN (14)
                               AND ATE.CD_MULTI_EMPRESA = 1
                               AND TRUNC(ATE.DT_ATENDIMENTO) =
                                   TRUNC(SYSDATE) - 1),
                            0) * 100,
                     2)) || '</span></b>' AS TAXA

  FROM DUAL
---------------(PA ADULTO)-------------------

UNION ALL

SELECT '<b><span style="color: #00B388; font-family: Arial Black;">PA ADULTO</span></b>' AS DESCRICAO,
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR((SELECT COUNT(ATE.CD_ATENDIMENTO)
                 FROM ATENDIME ATE
                WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                  AND ATE.CD_ORI_ATE IN (13, 66)
                  AND ATE.CD_MULTI_EMPRESA = 1
                  AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1)) ||
       '</span></b>' AS QTD_PA,
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR((SELECT COUNT(ATE.CD_ATENDIMENTO)
                 FROM ATENDIME ATE
                WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                  AND ATE.CD_ORI_ATE IN (37, 50, 63)
                  AND ATE.CD_MULTI_EMPRESA = 1
                  AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1)) ||
       '</span></b>' AS QTD_INTER,
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR(ROUND((SELECT COUNT(ATE.CD_ATENDIMENTO)
                        FROM ATENDIME ATE
                       WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                         AND ATE.CD_ORI_ATE IN (37, 50, 63)
                         AND ATE.CD_MULTI_EMPRESA = 1
                         AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1) /
                     NULLIF((SELECT COUNT(ATE.CD_ATENDIMENTO)
                              FROM ATENDIME ATE
                             WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                               AND ATE.CD_ORI_ATE IN (13, 66)
                               AND ATE.CD_MULTI_EMPRESA = 1
                               AND TRUNC(ATE.DT_ATENDIMENTO) =
                                   TRUNC(SYSDATE) - 1),
                            0) * 100,
                     2)) || '</span></b>' AS TAXA

  FROM DUAL

-------------------(TOTAL GERAL)----------------------------------
UNION ALL

SELECT '<b><span style="color: #00B388; font-family: Arial Black;">TOTAL GERAL</span></b>' AS DESCRICAO,
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR((SELECT COUNT(ATE.CD_ATENDIMENTO)
                 FROM ATENDIME ATE
                WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                  AND ATE.CD_ORI_ATE IN (13, 14, 66)
                  AND ATE.CD_MULTI_EMPRESA = 1
                  AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1)) ||
       '</span></b>' AS QTD_PA,
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR((SELECT COUNT(ATE.CD_ATENDIMENTO)
                 FROM ATENDIME ATE
                WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                  AND ATE.CD_ORI_ATE IN (37, 50, 63, 64)
                  AND ATE.CD_MULTI_EMPRESA = 1
                  AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1)) ||
       '</span></b>' AS QTD_INTER,
       
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR(ROUND((SELECT COUNT(ATE.CD_ATENDIMENTO)
                        FROM ATENDIME ATE
                       WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                         AND ATE.CD_ORI_ATE IN (37, 50, 63, 64)
                         AND ATE.CD_MULTI_EMPRESA = 1
                         AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1) /
                     NULLIF((SELECT COUNT(ATE.CD_ATENDIMENTO)
                              FROM ATENDIME ATE
                             WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                               AND ATE.CD_ORI_ATE IN (13, 14, 66)
                               AND ATE.CD_MULTI_EMPRESA = 1
                               AND TRUNC(ATE.DT_ATENDIMENTO) =
                                   TRUNC(SYSDATE) - 1),
                            0) * 100,
                     2)) || '</span></b>' AS TAXA

  FROM DUAL
-------------------------------(TAXA DAS UTI�S)---------------------------
UNION ALL

SELECT NULL CL1, NULL CL2, NULL CL3, NULL CL4
  FROM DUAL

UNION ALL
SELECT '<b><span style="color: #001A70; font-family: Arial Black;">QTD_INTERNA��ES (PAA X PAP)</span></b>' CL1,
       '<b><span style="color: #001A70; font-family: Arial Black;">UNIDADE</span></b>' CL2,
       '<b><span style="color: #001A70; font-family: Arial Black;">QTD_POR_UNIDADE</span></b>' CL3,
       '<b><span style="color: #001A70; font-family: Arial Black;">TAXA</span></b>' CL4
  FROM DUAL
-------------------------------(UCO)------------------------------------------
UNION ALL

SELECT '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR((SELECT COUNT(ATE.CD_ATENDIMENTO)
                 FROM ATENDIME ATE
                WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                  AND ATE.CD_ORI_ATE IN (37, 50, 63)
                  AND ATE.CD_MULTI_EMPRESA = 1
                  AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1)) ||
       '</span></b>' AS QTDE_INTER,
       '<b><span style="color: #00B388;font-family: Arial Black;">UCO</span></b>' AS DESCRICAO,
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       
       TO_CHAR((SELECT COUNT(MI.CD_ATENDIMENTO)
                 FROM MOV_INT MI
                 JOIN LEITO L
                   ON L.CD_LEITO = MI.CD_LEITO
                 JOIN UNID_INT UI
                   ON UI.CD_UNID_INT = L.CD_UNID_INT
                 JOIN ATENDIME ATE
                   ON ATE.CD_ATENDIMENTO = MI.CD_ATENDIMENTO
                WHERE UPPER(UI.DS_UNID_INT) LIKE '%CORONARIANA%'
                  AND ATE.CD_ATENDIMENTO_PAI IS NULL
                  AND ATE.CD_ORI_ATE IN (37, 50, 63)
                  AND ATE.CD_MULTI_EMPRESA = 1
                  AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1
                  AND MI.CD_MOV_INT =
                      (SELECT MIN(MI2.CD_MOV_INT)
                         FROM MOV_INT MI2
                         JOIN LEITO L2
                           ON L2.CD_LEITO = MI2.CD_LEITO
                        WHERE MI2.CD_ATENDIMENTO = MI.CD_ATENDIMENTO
                          AND L2.SN_EXTRA = 'N'))) || '</span></b>' AS QTD_UNIDADE,
       
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR(ROUND((SELECT COUNT(MI.CD_ATENDIMENTO)
                        FROM MOV_INT MI
                        JOIN LEITO L
                          ON L.CD_LEITO = MI.CD_LEITO
                        JOIN UNID_INT UI
                          ON UI.CD_UNID_INT = L.CD_UNID_INT
                        JOIN ATENDIME ATE
                          ON ATE.CD_ATENDIMENTO = MI.CD_ATENDIMENTO
                       WHERE UPPER(UI.DS_UNID_INT) LIKE '%CORONARIANA%'
                         AND ATE.CD_ATENDIMENTO_PAI IS NULL
                         AND ATE.CD_ORI_ATE IN (37, 50, 63)
                         AND ATE.CD_MULTI_EMPRESA = 1
                         AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1
                         AND MI.CD_MOV_INT =
                             (SELECT MIN(MI2.CD_MOV_INT)
                                FROM MOV_INT MI2
                                JOIN LEITO L2
                                  ON L2.CD_LEITO = MI2.CD_LEITO
                               WHERE MI2.CD_ATENDIMENTO = MI.CD_ATENDIMENTO
                                 AND L2.SN_EXTRA = 'N')) /
                     NULLIF((SELECT COUNT(ATE.CD_ATENDIMENTO)
                              FROM ATENDIME ATE
                             WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                               AND ATE.CD_ORI_ATE IN (37, 50, 63)
                               AND ATE.CD_MULTI_EMPRESA = 1
                               AND TRUNC(ATE.DT_ATENDIMENTO) =
                                   TRUNC(SYSDATE) - 1),
                            0) * 100,
                     2)) || '</span></b>' AS PERCENTUAL
  FROM DUAL
--------------------(UTI 1� / UTI 5)-----------------------------
UNION ALL

SELECT '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR((SELECT COUNT(ATE.CD_ATENDIMENTO)
                 FROM ATENDIME ATE
                WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                  AND ATE.CD_ORI_ATE IN (37, 50, 63)
                  AND ATE.CD_MULTI_EMPRESA = 1
                  AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1)) ||
       '</span></b>' AS QTDE_INTER,
       '<b><span style="color: #00B388;font-family: Arial Black;">UTI 1� / UTI 5�</span></b>' AS DESCRICAO,
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR((SELECT COUNT(MI.CD_ATENDIMENTO)
                 FROM MOV_INT MI
                 JOIN LEITO L
                   ON L.CD_LEITO = MI.CD_LEITO
                 JOIN UNID_INT UI
                   ON UI.CD_UNID_INT = L.CD_UNID_INT
                 JOIN ATENDIME ATE
                   ON ATE.CD_ATENDIMENTO = MI.CD_ATENDIMENTO
                WHERE (UPPER(UI.DS_UNID_INT) LIKE '%UTI%' AND
                      UPPER(UI.DS_UNID_INT) NOT LIKE '%UTI PED%')
                  AND ATE.CD_ATENDIMENTO_PAI IS NULL
                  AND ATE.CD_ORI_ATE IN (37, 50, 63)
                  AND ATE.CD_MULTI_EMPRESA = 1
                  AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1
                  AND MI.CD_MOV_INT =
                      (SELECT MIN(MI2.CD_MOV_INT)
                         FROM MOV_INT MI2
                         JOIN LEITO L2
                           ON L2.CD_LEITO = MI2.CD_LEITO
                        WHERE MI2.CD_ATENDIMENTO = MI.CD_ATENDIMENTO
                          AND L2.SN_EXTRA = 'N'))) || '</span></b>' AS QTD_UNIDADE,
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR(ROUND((SELECT COUNT(MI.CD_ATENDIMENTO)
                        FROM MOV_INT MI
                        JOIN LEITO L
                          ON L.CD_LEITO = MI.CD_LEITO
                        JOIN UNID_INT UI
                          ON UI.CD_UNID_INT = L.CD_UNID_INT
                        JOIN ATENDIME ATE
                          ON ATE.CD_ATENDIMENTO = MI.CD_ATENDIMENTO
                       WHERE (UPPER(UI.DS_UNID_INT) LIKE '%UTI%' AND
                             UPPER(UI.DS_UNID_INT) NOT LIKE '%UTI PED%')
                         AND ATE.CD_ATENDIMENTO_PAI IS NULL
                         AND ATE.CD_ORI_ATE IN (37, 50, 63)
                         AND ATE.CD_MULTI_EMPRESA = 1
                         AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1
                         AND MI.CD_MOV_INT =
                             (SELECT MIN(MI2.CD_MOV_INT)
                                FROM MOV_INT MI2
                                JOIN LEITO L2
                                  ON L2.CD_LEITO = MI2.CD_LEITO
                               WHERE MI2.CD_ATENDIMENTO = MI.CD_ATENDIMENTO
                                 AND L2.SN_EXTRA = 'N')) /
                     NULLIF((SELECT COUNT(ATE.CD_ATENDIMENTO)
                              FROM ATENDIME ATE
                             WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                               AND ATE.CD_ORI_ATE IN (37, 50, 63)
                               AND ATE.CD_MULTI_EMPRESA = 1
                               AND TRUNC(ATE.DT_ATENDIMENTO) =
                                   TRUNC(SYSDATE) - 1),
                            0) * 100,
                     2)) || '</span></b>' AS PERCENTUAL
  FROM DUAL

----------------------------(UTI PED)-------------------------------------------------------------------------------
UNION ALL

SELECT '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR((SELECT COUNT(ATE.CD_ATENDIMENTO)
                 FROM ATENDIME ATE
                WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                  AND ATE.CD_ORI_ATE IN (64)
                  AND ATE.CD_MULTI_EMPRESA = 1
                  AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1)) ||
       '</span></b>' AS QTDE_INTER,
       '<b><span style="color: #00B388;font-family: Arial Black;">UTI PED</span></b>' AS DESCRICAO,
       
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR((SELECT COUNT(MI.CD_ATENDIMENTO)
                 FROM MOV_INT MI
                 JOIN LEITO L
                   ON L.CD_LEITO = MI.CD_LEITO
                 JOIN UNID_INT UI
                   ON UI.CD_UNID_INT = L.CD_UNID_INT
                 JOIN ATENDIME ATE
                   ON ATE.CD_ATENDIMENTO = MI.CD_ATENDIMENTO
                WHERE UPPER(UI.DS_UNID_INT) LIKE '%UTI PED%'
                  AND ATE.CD_ATENDIMENTO_PAI IS NULL
                  AND ATE.CD_ORI_ATE IN (64)
                  AND ATE.CD_MULTI_EMPRESA = 1
                  AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1
                  AND MI.CD_MOV_INT =
                      (SELECT MIN(MI2.CD_MOV_INT)
                         FROM MOV_INT MI2
                         JOIN LEITO L2
                           ON L2.CD_LEITO = MI2.CD_LEITO
                        WHERE MI2.CD_ATENDIMENTO = MI.CD_ATENDIMENTO
                          AND L2.SN_EXTRA = 'N'))) || '</span></b>' AS QTD_UNIDADE,
       
       '<b><span style="color: #00B388; font-family: Arial Black;">' ||
       TO_CHAR(ROUND((SELECT COUNT(MI.CD_ATENDIMENTO)
                        FROM MOV_INT MI
                        JOIN LEITO L
                          ON L.CD_LEITO = MI.CD_LEITO
                        JOIN UNID_INT UI
                          ON UI.CD_UNID_INT = L.CD_UNID_INT
                        JOIN ATENDIME ATE
                          ON ATE.CD_ATENDIMENTO = MI.CD_ATENDIMENTO
                       WHERE UPPER(UI.DS_UNID_INT) LIKE '%UTI PED%'
                         AND ATE.CD_ATENDIMENTO_PAI IS NULL
                         AND ATE.CD_ORI_ATE IN (64)
                         AND ATE.CD_MULTI_EMPRESA = 1
                         AND TRUNC(ATE.DT_ATENDIMENTO) = TRUNC(SYSDATE) - 1
                         AND MI.CD_MOV_INT =
                             (SELECT MIN(MI2.CD_MOV_INT)
                                FROM MOV_INT MI2
                                JOIN LEITO L2
                                  ON L2.CD_LEITO = MI2.CD_LEITO
                               WHERE MI2.CD_ATENDIMENTO = MI.CD_ATENDIMENTO
                                 AND L2.SN_EXTRA = 'N')) /
                     NULLIF((SELECT COUNT(ATE.CD_ATENDIMENTO)
                              FROM ATENDIME ATE
                             WHERE ATE.CD_ATENDIMENTO_PAI IS NULL
                               AND ATE.CD_ORI_ATE IN (64)
                               AND ATE.CD_MULTI_EMPRESA = 1
                               AND TRUNC(ATE.DT_ATENDIMENTO) =
                                   TRUNC(SYSDATE) - 1),
                            0) * 100,
                     2)) || '</span></b>' AS PERCENTUAL
  FROM DUAL
