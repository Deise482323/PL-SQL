select /*'      
    <style type="text/css">
          P {font-size: 150pt}
          A {font-size: 20pt}
    </style>
    <table width=1420 
      <tr>
         <td ALIGN=MIDDLE height=130 bgcolor="#ffffff">
            <font face="Arial" color=BLUE><b><A>TEMPO ESTIMADO PARA ATENDIMENTO M�DICO</A></b></font>
         </td>
      </tr>
      <tr>
         <td ALIGN=MIDDLE height=500 bgcolor="#66ff66">
            <font face="Arial" color=white><P>' ||*/
       
       (select trunc(((sum(tat.tempo_atend_medico) / count(*))) * 24) -- hora
               || ':' || lpad(replace(trunc(mod(((sum(tat.tempo_atend_medico) /
                                                count(*))) * 1440,
                                                60)),
                                      '-',
                                      ''),
                              2,
                              '00') tt_tempo_formatado
          from (select rownum, tat.*
                  from (select DT_ATENDIMENTO,
                               DH_ATENDIMENTO,
                               CD_ATENDIMENTo,
                               nm_paciente,
                               dh_retiada_Senha,
                               dh_atend_medico,
                               tempo_atendimento tempo_atend_medico,
                               CD_ORI_ATE,
                               trunc(tempo_atendimento * 24) -- hora
                               || ':' || lpad(replace(trunc(mod(tempo_atendimento * 1440,
                                                                60)),
                                                      '-',
                                                      ''),
                                              2,
                                              '00') tempo_atend_medico_formatado
                          from (select at.DT_ATENDIMENTO,
                                       at.DT_ATENDIMENTO +
                                       (at.HR_ATENDIMENTO -
                                       trunc(at.HR_ATENDIMENTO)) DH_ATENDIMENTO,
                                       at.CD_ATENDIMENTo,
                                       pc.nm_paciente,
                                       sh.dh_processo dh_retiada_Senha,
                                       case
                                         when nvl(ch.dh_processo,
                                                  nvl(rd.dt_registro,
                                                      to_date('31/12/2075',
                                                              'DD/MM/RRRR'))) >
                                              pre.dh_processo then
                                          pre.dh_processo
                                         else
                                          nvl(ch.dh_processo,
                                              nvl(rd.dt_registro, pre.dh_processo))
                                       end dh_atend_medico,
                                       case
                                         when nvl(ch.dh_processo,
                                                  nvl(rd.dt_registro,
                                                      to_date('31/12/2075',
                                                              'DD/MM/RRRR'))) >
                                              pre.dh_processo then
                                          pre.dh_processo
                                         else
                                          nvl(ch.dh_processo,
                                              nvl(rd.dt_registro, pre.dh_processo))
                                       end - sh.dh_processo tempo_atendimento,
                                       at.CD_ORI_ATE
                                  from dbamv.atendime at
                                 inner join dbamv.paciente pc
                                    on at.CD_PACIENTE = pc.cd_paciente
                                 inner join dbamv.TRIAGEM_ATENDIMENTO ta
                                    on ta.cd_atendimento = at.CD_ATENDIMENTO
                                   and ta.cd_fila_senha = 10 AND TA.CD_COR_REFERENCIA IN(4,12) -------
                                 inner join dbamv.sacr_tempo_processo sh
                                    on sh.cd_atendimento = at.CD_ATENDIMENTO
                                   and sh.cd_tipo_tempo_processo = 1 -- cadastro no totem
                                  left outer join dbamv.sacr_tempo_processo ch
                                    on ch.CD_ATENDIMENTO = at.CD_ATENDIMENTO
                                   and ch.cd_tipo_tempo_processo = 30 -- tempo de chamada m�dica
                                  left outer join dbamv.sacr_tempo_processo pre
                                    on pre.CD_ATENDIMENTO = at.CD_ATENDIMENTO
                                   and pre.cd_tipo_tempo_processo = 31 -- tempo preenchimento prescri��o
                                  left outer join (select *
                                                    from (select dc.cd_atendimento,
                                                                 min(dc.dh_criacao) dt_registro
                                                            from pw_documento_clinico dc
                                                            join prestador prt
                                                              on prt.cd_prestador =
                                                                 dc.cd_prestador
                                                           where dc.dh_referencia between
                                                                 (sysdate - 2) and
                                                                 sysdate
                                                             and prt.cd_tip_presta = 8
                                                           group by cd_atendimento)) rd
                                    on rd.cd_atendimento = at.CD_ATENDIMENTO
                                 where at.cd_ori_ate = 13
                                    and AT.DT_ATENDIMENTO between
                                       trunc(sysdate) - 1 and trunc(sysdate)
                                   and nvl(ch.dh_processo,
                                           nvl(rd.dt_registro, pre.dh_processo)) is not null
                                 order by dh_atend_medico desc)) tat) tat
         where rownum <= 30 /*QtdAtendParaMedia#*/ --
         having count(*) > 0)
       
       /*|| '</P></font>
         </td>
      </tr>
     </table>' temp_espera*/
 /* from dual*/
-------------------------------------------
SELECT * FROM  dbamv.TRIAGEM_ATENDIMENTO ta
WHERE  TA.DH_PRE_ATENDIMENTO >= TO_DATE('16/04/2024', 'DD/MM/YYYY')


SELECT * FROM DBAMV.SACR_COR_REFERENCIA
