

SELECT DISTINCT EL.CD_EXA_LAB,
EL.NM_EXA_LAB,
EL.NM_MNEMONICO,
REX.NM_CAMPO FROM DBAMV.EXA_LAB EL
JOIN RES_EXA REX ON REX.CD_EXA_LAB = EL.CD_EXA_LAB
WHERE EL.NM_MNEMONICO = 'UI' /*IN ('GLI','TRI','COL','TGO','TGP','CR','UR','PSATL','HMG','HMG','HMG','AUR','AFP','AMI',
                           'BTF','CA','CAI','CLF','HDL','DHL','FERR','FAL','P','GGT','HBGLI','MG','K','PTF','NA',
                           'B12','LDL','VLDL','PPF','SO','ABORH','HMG','VHS','HGH','E2','FSH','BHCG','INSU','LH',
                           'TESTO','TSH','T4L','T3','TESTOL','IGF1','TRAB','VITD25OH','AHBCG','ANTIHBS','HVAG','HVAM',
                           'HBSAG','CEA','HBEAG','LATEX','PCR','VDRL','AHBCM','CA199','CA125','HCV','CA153','HIV',
                           'PSATL','UI','PCRU')*/

/*val_exa os campos da versao

versao vinculo dos exames*/
