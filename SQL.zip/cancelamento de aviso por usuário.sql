select 
ac.cd_aviso_cirurgia,
ac.ds_obs_aviso,
ac.dt_aviso_cirurgia,
C.CD_CONVENIO,
CO.NM_CONVENIO,
MC.DS_MOT_CANC,
AC.dt_cancelamento,
ac.cd_usuario_cancel
from aviso_cirurgia ac
JOIN CIRURGIA_AVISO C ON C.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
JOIN CONVENIO CO ON CO.CD_CONVENIO = C.CD_CONVENIO
inner join  mot_canc mc on mc.cd_mot_canc = ac.cd_mot_canc
where tp_situacao = 'C' 
and ac.cd_cen_cir in (1,9)
AND C.SN_PRINCIPAL = 'S'
AND AC.DS_OBS_AVISO LIKE '%PROCPA%'
and ac.dt_cancelamento between @P_DATA_INI and @P_DATA_FIM
AND AC.CD_USUARIO_CANCEL in ({USUARIOS_AUX})
and mc.cd_mot_canc in ({DESC_MOT_AUX})
and {V_VAR}


Select * from aviso_cirurgia
