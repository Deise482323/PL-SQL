SELECT *
  FROM HNB_SERVICO_ENVIO_EMAIL M
 WHERE M.CD_SERVICO_ENVIO_EMAIL = 682687
-----------------------------------------------------------------------------
  SELECT *
          FROM SERVICO_ENVIO_EMAIL E
         WHERE E.DS_DESTINATARIO = 'lrlrgvasconcellos@gmail.com'
           AND E.DS_EMAIL LIKE '%Data:%14/03/2024%'
-----------------------------------------------------------------------------
        
          SELECT DISTINCT IA.HR_AGENDA,
                          IA.NM_PACIENTE,
                          IA.DS_EMAIL,
                          IA.CD_ITEM_AGENDAMENTO,
                          A.DS_ITEM_AGENDAMENTO,
                          IA.CD_PACIENTE
                  FROM IT_AGENDA_CENTRAL IA
                  JOIN ITEM_AGENDAMENTO A
                    ON A.CD_ITEM_AGENDAMENTO = IA.CD_ITEM_AGENDAMENTO
                 WHERE IA.CD_PACIENTE IN (1111597)
                   AND IA.HR_AGENDA > '01/01/2024'
                 ORDER BY IA.HR_AGENDA, IA.NM_PACIENTE
