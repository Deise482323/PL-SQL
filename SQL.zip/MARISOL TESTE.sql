SELECT UNIDADE, "% OCUPA��O" indicador, ORDEM
  FROM (
        SELECT '<b>TAXA DE OCUPA��O' || ' ' || TRUNC(SYSDATE) || '</b>' UNIDADE,
                NULL,
                NULL,
                NULL,
                ' ' "% OCUPA��O",
                NULL,
                1 ORDEM
          FROM DUAL --ok
        
        UNION ALL
        
        SELECT '- PEDIATRIA' UNIDADE,
                SUM(PACDIA) QTD,
                SUM(QUINZE) "de 15 a 30 dias",
                SUM(TRINTA) " + 30",
                to_char(ROUND(SUM(PACDIA) / SUM(LEITO) * 100, 0) || '%') "% OCUPA��O",
                SUM(LEITO) LEITO,
                3 ORDEM
          FROM (SELECT COUNT(CD_ATENDIMENTO) "PACDIA",
                        SUM(QUINZE) QUINZE,
                        SUM(TRINTA) TRINTA,
                        null,
                        null leito
                   FROM ( -----------------------------OCUPA��O
                         SELECT DS_UNID_INT,
                                 CD_ATENDIMENTO,
                                 CASE
                                   WHEN QTD_DIAS >= 15 AND QTD_DIAS < 30 THEN
                                    1
                                 END "QUINZE",
                                 CASE
                                   WHEN QTD_DIAS >= 30 THEN
                                    1
                                 END "TRINTA"
                           FROM (SELECT DS_UNID_INT,
                                         CD_ATENDIMENTO,
                                         TRUNC(SYSDATE) - DT_ATENDIMENTO QTD_DIAS
                                    FROM ATENDIME, LEITO, UNID_INT
                                   WHERE TP_ATENDIMENTO = 'I'
                                     AND CD_ATENDIMENTO_PAI IS NULL
                                     AND DT_ALTA IS NULL
                                     AND CD_MULTI_EMPRESA = 1
                                     AND ATENDIME.CD_LEITO = LEITO.CD_LEITO
                                     AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
                                                                                                            --AND LEITO.SN_EXTRA = 'N'--NOVO
                                                                                                           -- AND LEITO.CD_TIP_ACOM IN (3,19)
                                     AND LEITO.CD_UNID_INT in (12,52)--ok)) 
-------------------------------FIM OCUPACAO
                 union all
---------------------------QUANTIDADE DE LEITOS ATIVOS
                 SELECT null, null, null, null, COUNT(1) QTD
                   FROM LEITO, UNID_INT
                  WHERE LEITO.TP_SITUACAO = 'A'
                    AND LEITO.SN_EXTRA = 'N'
                    AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
                    AND LEITO.CD_UNID_INT IN
                        (SELECT CD_UNID_INT
                           FROM UNID_INT
                          WHERE CD_SETOR IN
                                (SELECT CD_SETOR
                                   FROM SETOR
                                  WHERE CD_MULTI_EMPRESA = 1))
                                                                                                              --AND LEITO.CD_TIP_ACOM IN (3,19)
                    AND LEITO.CD_UNID_INT in (12,52) --ok
                 
                                                                                                           --3, GERAL 1 ANDAR 14 CORONARIANA,15 GERAL 5 ANDAR ,42 UTI NEO
-------------------------FIM LEITOS ATIVOS        
                 
                 )
        
        union all
        
        SELECT '- SEM PEDIATRIA' UNIDADE,
                SUM(PACDIA) QTD,
                SUM(QUINZE) "de 15 a 30 dias",
                SUM(TRINTA) " + 30",
                to_char(ROUND(SUM(PACDIA) / SUM(LEITO) * 100, 0) || '%') "% OCUPA��O",
                SUM(LEITO) LEITO,
                2 ORDEM
          FROM (SELECT COUNT(CD_ATENDIMENTO) "PACDIA",
                        SUM(QUINZE) QUINZE,
                        SUM(TRINTA) TRINTA,
                        null,
                        null leito
                   FROM ( -----------------------------OCUPA��O
                         SELECT DS_UNID_INT,
                                 CD_ATENDIMENTO,
                                 CASE
                                   WHEN QTD_DIAS >= 15 AND QTD_DIAS < 30 THEN
                                    1
                                 END "QUINZE",
                                 CASE
                                   WHEN QTD_DIAS >= 30 THEN
                                    1
                                 END "TRINTA"
                           FROM (SELECT DS_UNID_INT,
                                         CD_ATENDIMENTO,
                                         TRUNC(SYSDATE) - DT_ATENDIMENTO QTD_DIAS
                                    FROM ATENDIME, LEITO, UNID_INT
                                   WHERE TP_ATENDIMENTO = 'I'
                                     AND CD_ATENDIMENTO_PAI IS NULL
                                     AND DT_ALTA IS NULL
                                     AND CD_MULTI_EMPRESA = 1
                                     AND ATENDIME.CD_LEITO = LEITO.CD_LEITO
                                     AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
                                                                                                         --AND LEITO.SN_EXTRA = 'N'--NOVO
                                                                                                 --AND LEITO.CD_TIP_ACOM IN (3,19)
                                     AND LEITO.CD_UNID_INT NOT in (12,52))--ok ) 
-------------------------------FIM OCUPACAO
                 union all
---------------------------QUANTIDADE DE LEITOS ATIVOS
                 SELECT null, null, null, null, COUNT(1) QTD
                   FROM LEITO, UNID_INT
                  WHERE LEITO.TP_SITUACAO = 'A'
                    AND LEITO.SN_EXTRA = 'N'
                    AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
                    AND LEITO.CD_UNID_INT IN
                        (SELECT CD_UNID_INT
                           FROM UNID_INT
                          WHERE CD_SETOR IN
                                (SELECT CD_SETOR
                                   FROM SETOR
                                  WHERE CD_MULTI_EMPRESA = 1))
                                                                                                   -- AND LEITO.CD_TIP_ACOM IN (3,19)
                    AND LEITO.CD_UNID_INT NOT in (12,52) --ok
                                                                                      --3, GERAL 1 ANDAR 14 CORONARIANA,15 GERAL 5 ANDAR ,42 UTI NEO
-------------------------FIM LEITOS ATIVOS        
                 
                 )
      --#############################################################################  
        union all
        
--------------OCUPACAO UTI
        SELECT '- ' ||
                
                CASE
                  WHEN DS_UNID_INT = 'UTI GERAL 1 ANDAR' THEN
                   'UTI 1�'
                  WHEN DS_UNID_INT = 'UTI GERAL 5 ANDAR' THEN
                   'UTI 5�'
                    WHEN DS_UNID_INT = 'UTI PEDIATRICA' THEN
                           '4� ANDAR HNB'
                                                                                                 /*  WHEN DS_UNID_INT = 'UTI CORONARIANA' THEN
                                                                                                 'UCO'
                                                                                              WHEN DS_UNID_INT = 'UTI NEONATAL' THEN
                                                                                              'UTI NEO'*/
                   
                END UNIDADE,
                SUM(PACDIA) QTD,
                SUM(QUINZE) "de 15 a 30 dias",
                SUM(TRINTA) " + 30",
                to_char(ROUND(SUM(PACDIA) / SUM(LEITO) * 100, 0) || '%') "% OCUPA��O",
                SUM(LEITO) LEITO,
                CASE
                  WHEN DS_UNID_INT = 'UTI GERAL 1 ANDAR' THEN
                   4
                  WHEN DS_UNID_INT = 'UTI GERAL 5 ANDAR' THEN
                   5
                    WHEN DS_UNID_INT = 'UTI PEDIATRICA' THEN
                    6
                                                                           /* WHEN DS_UNID_INT = 'UTI CORONARIANA' THEN
                                                                                      6
                                                                             WHEN DS_UNID_INT = 'UTI NEONATAL' THEN
                                                                                       7*/
                END ORDEM
          FROM (SELECT DS_UNID_INT,
                        COUNT(CD_ATENDIMENTO) "PACDIA",
                        SUM(QUINZE) QUINZE,
                        SUM(TRINTA) TRINTA,
                        null,
                        null leito
                   FROM ( -----------------------------OCUPA��O
                         SELECT DS_UNID_INT,
                                 CD_ATENDIMENTO,
                                 CASE
                                   WHEN QTD_DIAS >= 15 AND QTD_DIAS < 30 THEN
                                    1
                                 END "QUINZE",
                                 CASE
                                   WHEN QTD_DIAS >= 30 THEN
                                    1
                                 END "TRINTA"
                           FROM (SELECT DS_UNID_INT,
                                         CD_ATENDIMENTO,
                                         TRUNC(SYSDATE) - DT_ATENDIMENTO QTD_DIAS
                                    FROM ATENDIME, LEITO, UNID_INT
                                   WHERE TP_ATENDIMENTO = 'I'
                                                                                     --AND CD_ATENDIMENTO_PAI IS NULL
                                     AND DT_ALTA IS NULL
                                     AND CD_MULTI_EMPRESA = 1
                                     AND ATENDIME.CD_LEITO = LEITO.CD_LEITO
                                     AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
                                                                                         --AND LEITO.SN_EXTRA = 'N'--NOVO
                                                                                        --AND LEITO.CD_TIP_ACOM IN (3,19)
                                     AND LEITO.CD_UNID_INT in (3,15,52)))-- ok -- 52 NOVA UNIDADE DE INTERNA��O PEDIATRICA 
                  GROUP BY DS_UNID_INT 
------------------------------FIM OCUPACAO
--#############################################################
                 union all
---------------------------QUANTIDADE DE LEITOS ATIVOS
                 SELECT DS_UNID_INT, null, null, null, null, COUNT(1) QTD
                   FROM LEITO, UNID_INT
                  WHERE LEITO.TP_SITUACAO = 'A'
                    AND LEITO.SN_EXTRA = 'N'
                    AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
                    AND LEITO.CD_UNID_INT IN
                        (SELECT CD_UNID_INT
                           FROM UNID_INT
                          WHERE CD_SETOR IN
                                (SELECT CD_SETOR
                                   FROM SETOR
                                  WHERE CD_MULTI_EMPRESA = 1))
                                                              -- AND LEITO.CD_TIP_ACOM IN (3,19)
                    AND LEITO.CD_UNID_INT in (3,15,52) -- 52 NOVA UNIDADE DE INTERNA��O PEDIATRICA 
                   GROUP BY DS_UNID_INT -- ok
                                                           --3, GERAL 1 ANDAR 14 CORONARIANA,15 GERAL 5 ANDAR ,42 UTI NEO
-------------------------FIM LEITOS ATIVOS        
              )   
                 
         GROUP BY DS_UNID_INT
        
--------------FIM OCUPACAO UTI      
        union all
        
        SELECT '<b>INTERNA��ES' || ' ' ||
                TO_CHAR(TRUNC(SYSDATE) - 1, 'DD/MM/YYYY') || '</b>' UNIDADE,
                NULL,
                NULL,
                NULL,
                ' ' "% OCUPA��O",
                NULL,
                8 ORDEM
          FROM DUAL --ok
        
        /*UNION ALL
        --------------Interna��es dia anterior
        select '- VIA PAA',
                null,
                null,
                null,
                to_char(count(cd_atendimento)),
                null,
                9 ORDEM
          from atendime, ori_ate
         where dt_atendimento = trunc(sysdate) - 1
           and tp_atendimento = 'I'
           and atendime.cd_multi_empresa = 1
           and atendime.CD_ORI_ATE = ori_ate.CD_ORI_ATE
           and atendime.CD_ATENDIMENTO_PAI is null
           and ATENDIME.cd_ori_ate in (42, 63, 50)
        
        --------------FIM Interna��es dia anterior*/
        
        UNION ALL
        --------------Interna��es dia anterior
        select '- VIA PAP',
                null,
                null,
                null,
                to_char(count(cd_atendimento)),
                null,
                10 ORDEM
          from atendime, ori_ate
         where dt_atendimento = trunc(sysdate) - 1
           and tp_atendimento = 'I'
           and atendime.cd_multi_empresa = 1
           and atendime.CD_ORI_ATE = ori_ate.CD_ORI_ATE
           and atendime.CD_ATENDIMENTO_PAI is null
           and ATENDIME.cd_ori_ate in (64) -- ok
        
       /* UNION ALL
        --------------Interna��es dia anterior
        select '- VIA PAP - COVID',
                null,
                null,
                null,
                to_char(count(cd_atendimento)),
                null,
                11 ORDEM
          from atendime, ori_ate
         where dt_atendimento = trunc(sysdate) - 1
           and tp_atendimento = 'I'
           and atendime.cd_multi_empresa = 1
           and atendime.CD_ORI_ATE = ori_ate.CD_ORI_ATE
           and atendime.CD_ATENDIMENTO_PAI is null
           and ATENDIME.cd_ori_ate in (61)
        --------------FIM Interna��es dia anterior*/
        
       /* UNION ALL
        
        select '- VIA PAA - COVID',
                null,
                null,
                null,
                to_char(count(cd_atendimento)),
                null,
                12 ORDEM
          from atendime, ori_ate
         where dt_atendimento = trunc(sysdate) - 1
           and tp_atendimento = 'I'
           and atendime.cd_multi_empresa = 1
           and atendime.CD_ORI_ATE = ori_ate.CD_ORI_ATE
           and atendime.CD_ATENDIMENTO_PAI is null
           and ATENDIME.cd_ori_ate in (62)
        
        --------------FIM Interna��es dia anterior*/
        
        UNION ALL
        --------------Interna��es dia anterior
        select '- TRAUMA',
                null,
                null,
                null,
                to_char(count(cd_atendimento)),
                null,
                13 ORDEM
          from atendime, ori_ate
         where dt_atendimento = trunc(sysdate) - 1
           and tp_atendimento = 'I'
           and atendime.cd_multi_empresa = 1
           and atendime.CD_ORI_ATE = ori_ate.CD_ORI_ATE
           and atendime.CD_ATENDIMENTO_PAI is null
           and ATENDIME.cd_ori_ate in (37)
         group by ds_ori_ate  -- ok
        --------------FIM Interna��es dia anterior
        
        UNION ALL
        --------------Interna��es dia anterior SEM PA
        select '- ELETIVA' DS_ORI_ATE,
                null,
                null,
                null,
                to_char(count(cd_atendimento)),
                null,
                14 ORDEM
          from atendime, ori_ate
         where dt_atendimento = trunc(sysdate) - 1
           and tp_atendimento = 'I'
           and atendime.cd_multi_empresa = 1
           and atendime.CD_ORI_ATE = ori_ate.CD_ORI_ATE
           and atendime.CD_ATENDIMENTO_PAI is null
           and ORI_ATE.cd_ori_ate in (39, 36) --ok        
        --------------FIM Interna��es dia anterior
        UNION ALL
        --------------Altas dia anterior
        select '- ALTAS' TIPO,
                null,
                null,
                null,
                to_char(count(cd_atendimento)),
                null,
                15 ORDEM
          from atendime, ori_ate
         where dt_alta = trunc(sysdate) - 1
           and tp_atendimento = 'I'
           and atendime.cd_multi_empresa = 1
           and atendime.CD_ORI_ATE = ori_ate.CD_ORI_ATE
           and atendime.CD_LEITO not in
               (select cd_leito
                  from leito
                 where cd_unid_int in (20, 16, 17,52))  -- 52 NOVA UNIDADE DE INTERNA��O PEDIATRICA 
           AND ATENDIME.CD_LEITO NOT IN
               (SELECT CD_LEITO FROM LEITO WHERE LEITO.SN_EXTRA = 'S') --ok
        
        --------------FIM Altas Interna��es dia anterior
        
        UNION ALL
        
        SELECT '<b>MAPA CIR�RGICO' || ' ' || TRUNC(SYSDATE) || '</b>' UNIDADE,
                NULL,
                NULL,
                NULL,
                ' ' "% OCUPA��O",
                NULL,
                16 ORDEM
          FROM DUAL --ok
        
        UNION ALL
        -------MAPA CIRURGICO
        SELECT '- ' ||
                
                CASE
                  WHEN CEN_CIR.DS_CEN_CIR = 'CENTRO CIRURGICO - HNB' THEN
                   'C.C'
                  WHEN CEN_CIR.DS_CEN_CIR = 'CENTRO OBSTETRICO' THEN
                   'C.O'
                  WHEN CEN_CIR.DS_CEN_CIR = 'HEMODINAMICA' THEN
                   'HEMO'
                END
                
               ,
                NULL,
                NULL,
                NULL,
                to_char(COUNT(AVISO_CIRURGIA.CD_AVISO_CIRURGIA)),
                NULL,
                
                CASE
                  WHEN CEN_CIR.DS_CEN_CIR = 'CENTRO CIRURGICO - HNB' THEN
                   17
                  WHEN CEN_CIR.DS_CEN_CIR = 'CENTRO OBSTETRICO' THEN
                   18
                  WHEN CEN_CIR.DS_CEN_CIR = 'HEMODINAMICA' THEN
                   19
                END ORDEM
        
          FROM AVISO_CIRURGIA, CEN_CIR, AGE_CIR
         WHERE TRUNC(DT_INICIO_AGE_CIR) = TRUNC(SYSDATE)
           AND AVISO_CIRURGIA.CD_CEN_CIR = CEN_CIR.CD_CEN_CIR
           AND AGE_CIR.CD_AVISO_CIRURGIA = AVISO_CIRURGIA.CD_AVISO_CIRURGIA
           AND AVISO_CIRURGIA.CD_CEN_CIR IN (1, 7, 3)
           AND AVISO_CIRURGIA.TP_SITUACAO <> 'C'
         GROUP BY CEN_CIR.DS_CEN_CIR --ok
        -------FIM MAPA CIRURGICO
        UNION ALL
        
        SELECT '<b>RESERVAS UTI </b>' UNIDADE,
                NULL,
                NULL,
                NULL,
                ' ' "% OCUPA��O",
                NULL,
                20 ORDEM
          FROM DUAL --ok
        
        UNION ALL
        
        -------RESERVA UTI
        
        SELECT UNIDADE,
                QTD,
                "de 15 a 30 dias",
                " + 30",
                "% OCUPA��O",
                LEITO,
                ORDEM
          FROM (SELECT '- ' || CASE
                          WHEN DS_UNID_INT = 'UTI GERAL 1 ANDAR' THEN
                           'UTI 1�'
                          WHEN DS_UNID_INT = 'UTI GERAL 5 ANDAR' THEN
                           'UTI 5�'
                           WHEN DS_UNID_INT = 'UTI PEDIATRICA' THEN
                           '4� ANDAR HNB'
                            /* WHEN DS_UNID_INT = 'UTI CORONARIANA' THEN
                           'UCO'
                          WHEN DS_UNID_INT = 'UTI NEONATAL' THEN
                           'UTI NEO'*/
                        END UNIDADE,
                        NULL QTD,
                        NULL "de 15 a 30 dias",
                        NULL " + 30",
                        to_char(COUNT(CD_AVISO_CIRURGIA)) "% OCUPA��O",
                        NULL LEITO,
                        21 ORDEM,
                        (SELECT DECODE(LT1.CD_UNID_INT,
                                       15,
                                       'UTI 5�',
                                       3,
                                       'UTI 1�',
                                       50,
                                       'UTI PEDIATRICA', 
                                       NULL)
                           FROM ATENDIME AT1, LEITO LT1
                          WHERE AT1.CD_LEITO = LT1.CD_LEITO
                            AND AT1.CD_ATENDIMENTO =
                                AVISO_CIRURGIA.CD_ATENDIMENTO
                            AND LT1.CD_UNID_INT IN (3,15,50)) LEITO_OCUP
                   FROM AVISO_CIRURGIA, CEN_CIR, UNID_INT
                  WHERE TRUNC(DT_PREV_INTER) = TRUNC(SYSDATE)
                    AND AVISO_CIRURGIA.CD_CEN_CIR = CEN_CIR.CD_CEN_CIR
                    AND AVISO_CIRURGIA.CD_UNID_INT = UNID_INT.CD_UNID_INT
                    AND SN_UTI = 'S'
                    AND CEN_CIR.CD_CEN_CIR IN (1, 7, 3)
                  GROUP BY '- ' || CASE
                             WHEN DS_UNID_INT = 'UTI GERAL 1 ANDAR' THEN
                              'UTI 1�'
                             WHEN DS_UNID_INT = 'UTI GERAL 5 ANDAR' THEN
                              'UTI 5�'
                              WHEN DS_UNID_INT = 'UTI PEDIATRICA' THEN
                           '4� ANDAR HNB'
                            /* WHEN DS_UNID_INT = 'UTI CORONARIANA' THEN
                              'UCO'
                             WHEN DS_UNID_INT = 'UTI NEONATAL' THEN
                              'UTI NEO'*/
                           END)
         WHERE LEITO_OCUP IS NULL --ok
        
        --------FIM RESERVA UTI
        UNION ALL
        SELECT '<b>LEITOS VAGOS UTI</b>' UNIDADE,
                NULL,
                NULL,
                NULL,
                ' ' "% OCUPA��O",
                NULL,
                22 ORDEM
          FROM DUAL --ok
        UNION ALL
        -------LEITOS VAGOS UTI
        SELECT '- ' || CASE
                  WHEN DS_UNID_INT = 'UTI GERAL 1 ANDAR' THEN
                   'UTI 1�'
                  WHEN DS_UNID_INT = 'UTI GERAL 5 ANDAR' THEN
                   'UTI 5�'
                     WHEN DS_UNID_INT = 'UTI PEDIATRICA' THEN
                           '4� ANDAR HNB'
                 /* WHEN DS_UNID_INT = 'UTI CORONARIANA' THEN
                   'UCO'
                  WHEN DS_UNID_INT = 'UTI NEONATAL' THEN
                   'UTI NEO'*/
                END UNIDADE,
                null,
                null,
                null,
                to_char(COUNT(1)),
                NULL QTD,
                
                CASE
                  WHEN DS_UNID_INT = 'UTI GERAL 1 ANDAR' THEN
                   23
                  WHEN DS_UNID_INT = 'UTI GERAL 5 ANDAR' THEN
                   24
                  WHEN DS_UNID_INT = 'UTI PEDIATRICA' THEN
                   25
                 /* WHEN DS_UNID_INT = 'UTI CORONARIANA' THEN
                   25
                  WHEN DS_UNID_INT = 'UTI NEONATAL' THEN
                   26*/
                END ORDEM
        
          FROM LEITO, UNID_INT
         WHERE LEITO.TP_SITUACAO = 'A'
           AND LEITO.SN_EXTRA = 'N'
           AND LEITO.CD_UNID_INT = UNID_INT.CD_UNID_INT
           AND LEITO.CD_UNID_INT IN
               (SELECT CD_UNID_INT
                  FROM UNID_INT
                 WHERE CD_SETOR IN
                       (SELECT CD_SETOR FROM SETOR WHERE CD_MULTI_EMPRESA = 1))
              -- AND LEITO.CD_TIP_ACOM IN (3,19)
           AND LEITO.CD_UNID_INT in (3, 15, 50)
           AND TP_OCUPACAO = 'V'
         GROUP BY DS_UNID_INT --ok --3, GERAL 1 ANDAR 14 CORONARIANA,15 GERAL 5 ANDAR ,42 UTI NEO
        
        union all
        
        SELECT '<b>PRONTO ATENDIMENTO' || ' ' ||
                TO_CHAR(TRUNC(SYSDATE) - 1, 'DD/MM/YYYY') || '</b>' UNIDADE,
                NULL,
                NULL,
                NULL,
                ' ' "% OCUPA��O",
                NULL,
                27 ORDEM
          FROM DUAL --ok
        
        UNION ALL
        
        select '- PAA' TIPO,
                null,
                null,
                null,
                to_char(count(cd_atendimento)),
                null,
                28 ORDEM
          from atendime, ori_ate
         where trunc(dt_atendimento) = trunc(sysdate) - 1
           and tp_atendimento = 'U'
           and atendime.cd_multi_empresa = 1
           and atendime.CD_ORI_ATE = ori_ate.CD_ORI_ATE
           and atendime.cd_ori_ate in (47) --ok
        
        /*UNION ALL
        
        select '- PAP' TIPO,
                null,
                null,
                null,
                to_char(count(cd_atendimento)),
                null,
                29 ORDEM
          from atendime, ori_ate
         where trunc(dt_atendimento) = trunc(sysdate) - 1
           and tp_atendimento = 'U'
           and atendime.cd_multi_empresa = 1
           and atendime.CD_ORI_ATE = ori_ate.CD_ORI_ATE
           and atendime.cd_ori_ate in (14)*/
        
        UNION ALL
        
        select '- PACOV' TIPO,
                null,
                null,
                null,
                to_char(count(cd_atendimento)),
                null,
                30 ORDEM
          from atendime, ori_ate
         where trunc(dt_atendimento) = trunc(sysdate) - 1
           and tp_atendimento = 'U'
           and atendime.cd_multi_empresa = 1
           and atendime.CD_ORI_ATE = ori_ate.CD_ORI_ATE
           and atendime.cd_ori_ate in (66)--ok        
        --)
        )
 ORDER BY ORDEM
