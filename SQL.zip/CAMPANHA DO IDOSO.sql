SELECT DISTINCT PAC.DS_TRABALHO CONTRATANTE,
                PAC.NM_PACIENTE NOME,
                PAC.CD_PACIENTE SAME,
                PAC.EMAIL EMAIL,
                TO_DATE(PAC.DT_NASCIMENTO, 'DD/MM/RRRR') DT_NASC,
                ATE.CD_ATENDIMENTO,
                ATE.DT_ATENDIMENTO,
                TO_NUMBER(FNC_HNB_OBTER_IDADE(PAC.DT_NASCIMENTO,
                                              PLA.DT_PEDIDO)) IDADE,
                (SELECT DISTINCT S.NM_SEXO
                   FROM DBAMV.TIPO_SEXO S
                  WHERE S.TP_SEXO = PAC.TP_SEXO) GENERO,
                TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATE.CD_ATENDIMENTO,
                                                          421,
                                                          'U')) IMC,
                TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATE.CD_ATENDIMENTO,
                                                          4,
                                                          'U')) PAS,
                TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATE.CD_ATENDIMENTO,
                                                          5,
                                                          'U')) PAD,
                TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATE.CD_ATENDIMENTO,
                                                          21,
                                                          'U')) PESO,
                TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATE.CD_ATENDIMENTO,
                                                          22,
                                                          'U')) ALTURA,
                TO_NUMBER(DBAMV.FNC_HNB_OBTER_SINAL_VITAL(ATE.CD_ATENDIMENTO,
                                                          621,
                                                          'U')) CIRCU_ABDOMINAL,
                TO_NUMBER(REPLACE((SELECT DISTINCT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'GLI'
                                     AND UPPER(REX.NM_CAMPO) = 'GLICOSE'),
                                  '.',
                                  ',')) GLICOSE,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'TRI'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('TRIGLIC�RIDES', 'TRIGLICERIDES')),
                                  '.',
                                  ',')) TRIGLICERIDES,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'COL'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'COLESTEROL TOTAL'),
                                  '.',
                                  ',')) COLESTEROL_TOTAL,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'TGO'
                                     AND UPPER(REX.NM_CAMPO) = 'AST (TGO)'),
                                  '.',
                                  ',')) TGO,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'TGP'
                    AND UPPER(REX.NM_CAMPO) = 'ALT (TGP)') TGP,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'CR'
                    AND UPPER(REX.NM_CAMPO) = 'CREATININA') CREATININA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UR'
                                     AND UPPER(REX.NM_CAMPO) = 'UR�IA'),
                                  '.',
                                  ',')) UREIA,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'PSATL'
                    AND UPPER(REX.NM_CAMPO) = 'PSA TOTAL') PSA_TOTAL,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'PSATL'
                    AND UPPER(REX.NM_CAMPO) = 'PSA LIVRE/TOTAL') PSA_LIVRE_TOTAL,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'PSATL'
                    AND UPPER(REX.NM_CAMPO) = 'PSA LIVRE') PSA_LIVREL,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'HMG'
                    AND UPPER(REX.NM_CAMPO) = 'PLAQUETAS') PLAQUETAS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) = 'BAS�FILOS'),
                                  '.',
                                  ',')) BASOFILOS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) = 'LEUC�CITOS'),
                                  '.',
                                  ',')) LEUCOCITOS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'ERITR�CITOS'),
                                  '.',
                                  ',')) ERITROCITOS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('HEMAT�CRITO', 'HEMATOCRITO')),
                                  '.',
                                  ',')) HEMATOCRITO,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'HEMOGLOBINA'),
                                  '.',
                                  ',')) HEMOGLOBINA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) =
                                         'HEMOGLOBINA CORPUSCULAR M�DIA'),
                                  '.',
                                  ',')) HEMO_CORP_MEDIA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('MON�CITOS', 'MONOCITOS')),
                                  '.',
                                  ',')) MONOCITOS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('NEUTR�FILOS', 'NEUTROFILOS')),
                                  '.',
                                  ',')) NEUTROFILOS,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'HMG'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('VOLUME PLAQUET�RIO M�DIO',
                                          'VOLUME PLAQUETARIO MEDIO')),
                                  '.',
                                  ',')) VOL_PLAQ_MEDIO,
                
                REPLACE((SELECT REX.DS_RESULTADO
                          FROM DBAMV.ITPED_LAB IPLA
                          JOIN DBAMV.EXA_LAB EL
                            ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                          JOIN RES_EXA REX
                            ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                         WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                           AND EL.NM_MNEMONICO = 'HBGLI'
                           AND UPPER(REX.NM_CAMPO) = 'HEMOGLOBINA GLICADA'),
                        '.',
                        ',') HEMOGLOBINA_GLICADA,
                --
                REPLACE((SELECT REX.DS_RESULTADO
                          FROM DBAMV.ITPED_LAB IPLA
                          JOIN DBAMV.EXA_LAB EL
                            ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                          JOIN RES_EXA REX
                            ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                         WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                           AND EL.NM_MNEMONICO = 'HDL'
                           AND UPPER(REX.NM_CAMPO) = 'HDL-COLESTEROL'),
                        '.',
                        ',') HDL_COLESTEROL,
                
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'UI'
                    AND UPPER(REX.NM_CAMPO) IN ('ASPECTO', 'ASPECTO, URINA')) ASPECTO,
                
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'UI'
                    AND UPPER(REX.NM_CAMPO) = 'CILINDROS, URINA') CILINDROS_URINA,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'UI'
                    AND UPPER(REX.NM_CAMPO) = 'COR, URINA') COR_URINA,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'UI'
                    AND UPPER(REX.NM_CAMPO) IN
                        ('CORPOS CET�NICOS, URINA',
                         'CORPOS CETONICOS, URINA')) CORPOS_CETON_URINA,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'UI'
                    AND UPPER(REX.NM_CAMPO) IN
                        ('ERITR�CITOS QUANTITATIVO, URINA',
                         'ERITROCITOS QUANTITATIVO, URINA')) ERITR_QUANT_URINA,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'UI'
                    AND UPPER(REX.NM_CAMPO) = 'GLICOSE, URINA ISOLADA') GLI_URI_ISOLADA,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'UI'
                    AND UPPER(REX.NM_CAMPO) IN
                        ('LEUC�CITOS QUANTITATIVO, URINA',
                         'LEUCOCITOS QUANTITATIVO, URINA')) LEUCO_QT_URINA,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'UI'
                    AND UPPER(REX.NM_CAMPO) = 'NITRITO, URINA') NITRITO_URINA,
                TO_NUMBER(REPLACE((SELECT REX.DS_RESULTADO
                                    FROM DBAMV.ITPED_LAB IPLA
                                    JOIN DBAMV.EXA_LAB EL
                                      ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                                    JOIN RES_EXA REX
                                      ON REX.CD_ITPED_LAB =
                                         IPLA.CD_ITPED_LAB
                                   WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                                     AND EL.NM_MNEMONICO = 'UI'
                                     AND UPPER(REX.NM_CAMPO) IN
                                         ('PH, URINA', 'PH')),
                                  '.',
                                  ',')) PH_URINA,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'UI'
                    AND UPPER(REX.NM_CAMPO) IN
                        ('PROTE�NAS, URINA ISOLADA',
                         'PROTEINAS, URINA ISOLADA',
                         'PROTE�NAS')) PROT_URINA_ISOLADA,
                (SELECT REX.DS_RESULTADO
                   FROM DBAMV.ITPED_LAB IPLA
                   JOIN DBAMV.EXA_LAB EL
                     ON EL.CD_EXA_LAB = IPLA.CD_EXA_LAB
                   JOIN RES_EXA REX
                     ON REX.CD_ITPED_LAB = IPLA.CD_ITPED_LAB
                  WHERE IPLA.CD_PED_LAB = PLA.CD_PED_LAB
                    AND EL.NM_MNEMONICO = 'UI'
                    AND UPPER(REX.NM_CAMPO) IN
                        ('UROBILINOG�NIO, URINA', 'UROBILINOGENIO, URINA')) UROBILI_URINA

  FROM DBAMV.ATENDIME ATE
  JOIN DBAMV.PACIENTE PAC
    ON PAC.CD_PACIENTE = ATE.CD_PACIENTE
  JOIN DBAMV.PED_LAB PLA
    ON PLA.CD_ATENDIMENTO = ATE.CD_ATENDIMENTO
 WHERE ATE.CD_CONVENIO = 117
   AND ATE.DT_ATENDIMENTO BETWEEN '14/06/2025' AND '15/06/2025'
 ORDER BY PAC.NM_PACIENTE
