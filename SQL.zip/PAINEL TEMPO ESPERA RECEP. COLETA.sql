SELECT (SELECT COUNT(TA1.CD_TRIAGEM_ATENDIMENTO)
          FROM TRIAGEM_ATENDIMENTO TA1
         WHERE TO_DATE(TA1.DH_PRE_ATENDIMENTO, 'DD/MM/RRRR') >=
               TO_DATE(SYSDATE, 'DD/MM/RRRR')
           AND TA1.DH_REMOVIDO IS NULL
           AND TA1.CD_ATENDIMENTO IS NULL
           AND TA1.CD_FILA_SENHA = 110 --
           AND NOT EXISTS
         (SELECT 1
                  FROM SACR_TEMPO_PROCESSO TP
                 WHERE TP.CD_TRIAGEM_ATENDIMENTO = TA1.CD_TRIAGEM_ATENDIMENTO
                   AND TP.CD_TIPO_TEMPO_PROCESSO = 21)) QTDE_PENDENTE,
       NVL(to_number(trunc(MEDIA * 24)),0) hora,
       NVL(TO_NUMBER(replace(trunc(mod(MEDIA * 1440, 60)), '-', '')),0) MINUTOS,
       trunc(MEDIA * 24) -- hora
       || ':' ||
       lpad(replace(trunc(mod(MEDIA * 1440, 60)), '-', ''), 2, '00') TEMPO_MEDIO
     --  #FILA_TOTEM# FILA_SENHA
       

  FROM (SELECT SUM(DIF_TEMPO) / COUNT(CD_TRIAGEM_ATENDIMENTO) MEDIA
          FROM (SELECT CD_TRIAGEM_ATENDIMENTO,
                       INI_ATEND_ADM - DH_TOTEM DIF_TEMPO
                  FROM (SELECT TA.CD_TRIAGEM_ATENDIMENTO,
                               TA.DH_PRE_ATENDIMENTO DH_TOTEM,
                               (SELECT TP2.DH_PROCESSO
                                  FROM SACR_TEMPO_PROCESSO TP2
                                 WHERE TP2.CD_TRIAGEM_ATENDIMENTO =
                                       TA.CD_TRIAGEM_ATENDIMENTO
                                   AND TP2.CD_TIPO_TEMPO_PROCESSO = 21) INI_ATEND_ADM
                              /* TO_DATE(TO_CHAR(ATE.DT_ATENDIMENTO,
                                               'DD/MM/RRRR') ||
                                       TO_CHAR(ATE.HR_ATENDIMENTO,
                                               'HH24:MI:SS'),
                                       'DD/MM/RRRR HH24:MI:SS') FIM_ATEND_ADM*/
                          FROM TRIAGEM_ATENDIMENTO TA
                          LEFT JOIN ATENDIME ATE
                            ON ATE.CD_ATENDIMENTO = TA.CD_ATENDIMENTO
                         WHERE TO_DATE(TA.DH_PRE_ATENDIMENTO, 'DD/MM/RRRR') >=
                               TO_DATE(SYSDATE, 'DD/MM/RRRR')
                           AND TA.DH_REMOVIDO IS NULL
                           AND TA.CD_FILA_SENHA = 110)--
                 WHERE FIM_ATEND_ADM BETWEEN SYSDATE - (MEDIA / 1440) AND
                       SYSDATE))
