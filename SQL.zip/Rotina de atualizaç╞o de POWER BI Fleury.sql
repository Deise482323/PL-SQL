-- 1. Inser��o dos dados da planilha
-- Copiar os dados da planilha fornecida pelo Fleury para a tabela ENKYO.TB_AUX_EXAMES_FLEURY.

SELECT * FROM ENKYO.TB_AUX_EXAMES_FLEURY WHERE DS_LOCAL = '0' FOR UPDATE;
-- Observa��o: O comando FOR UPDATE bloqueia as linhas selecionadas para prevenir mudan�as concorrentes.

-- 2. Atualiza��o de valores inv�lidos (caractere "-") para NULL
-- Substituir o caractere "-" por NULL em colunas onde valores n�o podem ser vazios ou incorretos, como datas ou c�digos, para evitar erros ou conflitos no tratamento posterior.

UPDATE ENKYO.TB_AUX_EXAMES_FLEURY
   SET DS_LOCAL = NULL
 WHERE DS_LOCAL LIKE '-';

UPDATE ENKYO.TB_AUX_EXAMES_FLEURY SET FICHA = NULL WHERE FICHA LIKE '-';

UPDATE ENKYO.TB_AUX_EXAMES_FLEURY
   SET DT_RECEB_AMOSTRA = NULL
 WHERE DT_RECEB_AMOSTRA LIKE '-';

UPDATE ENKYO.TB_AUX_EXAMES_FLEURY
   SET DT_LAUDO = NULL
 WHERE DT_LAUDO LIKE '-';

UPDATE ENKYO.TB_AUX_EXAMES_FLEURY
   SET CD_EXA_EXTERNO = NULL
 WHERE CD_EXA_EXTERNO LIKE '-';

-- 3. Verifica��o de registros duplicados
-- Garantir que n�o haja duplica��o de dados ap�s a inser��o, o que pode causar inconsist�ncias e problemas em consultas futuras.

SELECT EF.DS_LOCAL,
       EF.FICHA,
       EF.DT_RECEB_AMOSTRA,
       EF.DT_LAUDO,
       EF.CD_EXA_EXTERNO
  FROM ENKYO.TB_AUX_EXAMES_FLEURY EF
 GROUP BY EF.DS_LOCAL,
          EF.FICHA,
          EF.DT_RECEB_AMOSTRA,
          EF.DT_LAUDO,
          EF.CD_EXA_EXTERNO
HAVING COUNT(*) > 1;

-- Explica��o: O HAVING COUNT(*) > 1 identifica grupos de registros que aparecem mais de uma vez.

-- 4. Remo��o de registros duplicados
-- Deletar as duplicatas, mantendo apenas uma inst�ncia de cada conjunto de dados.

DELETE FROM ENKYO.TB_AUX_EXAMES_FLEURY EF
 WHERE ROWID IN (SELECT ROWID
                   FROM (SELECT ROWID,
                                ROW_NUMBER() OVER(PARTITION BY EF.DS_LOCAL, EF.FICHA, EF.DT_RECEB_AMOSTRA, EF.DT_LAUDO, EF.CD_EXA_EXTERNO ORDER BY ROWID) AS rnum
                           FROM ENKYO.TB_AUX_EXAMES_FLEURY EF)
                  WHERE rnum > 1);

-- Explica��o: O ROW_NUMBER() atribui um n�mero a cada linha dentro de um grupo de duplicatas. O rnum > 1 identifica as duplicatas (linhas extras) e as remove.

-- 5. Valida��o final
-- Ap�s as atualiza��es e exclus�es, uma consulta final � recomendada para garantir que os dados estejam corretos e sem duplicidades.
