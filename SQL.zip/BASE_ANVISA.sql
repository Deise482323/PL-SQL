SELECT *
  FROM (SELECT A.CD_ATENDIMENTO AS ATENDIMENTO,
               A.CD_PACIENTE    AS SAME,
               A.DT_ATENDIMENTO AS DT_INI_INT,
               a.dt_alta        AS DT_ALTA,
               -- Calcula n�mero de dias de interna��o
               A.DT_ALTA - A.DT_ATENDIMENTO AS DIAS_INTERNACAO,
               -- Extrai o m�s/ano para amostragem mensal
               TO_CHAR(A.DT_ATENDIMENTO, 'MM/YYYY') AS MES_ANO,
               -- Usa ROW_NUMBER para limitar a 30 registros por m�s
               ROW_NUMBER() OVER(PARTITION BY TO_CHAR(A.DT_ATENDIMENTO, 'MM/YYYY') ORDER BY A.DT_ATENDIMENTO) AS SEQ_ATE_MES
          FROM ATENDIME A
          JOIN AVISO_CIRURGIA AC
            ON AC.CD_ATENDIMENTO = A.CD_ATENDIMENTO
         WHERE A.DT_ATENDIMENTO BETWEEN TO_DATE('01/01/2024', 'DD/MM/YYYY') AND
               TO_DATE('31/12/2024', 'DD/MM/YYYY')
           AND A.TP_ATENDIMENTO = 'I' -- Interna��o
           AND AC.CD_CEN_CIR <> 7
           AND A.CD_MULTI_EMPRESA = 1
           AND A.DT_ALTA IS NOT NULL
           AND (A.DT_ALTA - A.DT_ATENDIMENTO) >= 2 -- Pelo menos 2 dias de interna��o
        ) SUB
 WHERE SEQ_ATE_MES <= 30
 ORDER BY MES_ANO, SEQ_ATE_MES;
