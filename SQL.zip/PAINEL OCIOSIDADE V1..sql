SELECT MEDICO,
       ESPECIALIDADE,
       ITEM_AGENDAMENTO,
       TOTAL_HRS_TRAB,
       HR_INICIO,
       HR_FIM,
       HR_AGENDA,
       QT_FALTAS,
       TO_CHAR(TRUNC(HRS_FALTA_NORMAL / 60)) || ':' ||
       LPAD(TRUNC(MOD(HRS_FALTA_NORMAL, 60)), 2, '0') || ':00' AS HRS_FALTA_NORMAL
     
FROM (
    SELECT DISTINCT AC.CD_PRESTADOR || ' - ' || P.NM_PRESTADOR AS MEDICO,
    
                    EP.DS_ESPECIALID AS ESPECIALIDADE,
                    
                    IA.CD_ITEM_AGENDAMENTO || ' - ' || IA.DS_ITEM_AGENDAMENTO AS ITEM_AGENDAMENTO,
                    
              
    LPAD(FLOOR((ESC.HR_FIM - ESC.HR_INICIO) * 24), 2, '0') || ':' ||
    LPAD(FLOOR(MOD((ESC.HR_FIM - ESC.HR_INICIO) * 24 * 60, 60)), 2, '0') || ':' ||
    LPAD(FLOOR(MOD((ESC.HR_FIM - ESC.HR_INICIO) * 24 * 60 * 60, 60)), 2, '0') AS TOTAL_HRS_TRAB
,
                    
                    
                    ESC.HR_INICIO,
                    ESC.HR_FIM,
                    IAC.HR_AGENDA,
                    
                    -- Calculo para contar os pacientes faltantes
                    (SELECT COUNT(*)
                     FROM DBAMV.IT_AGENDA_CENTRAL IAC_FALTA
                     WHERE IAC_FALTA.CD_AGENDA_CENTRAL = AC.CD_AGENDA_CENTRAL
                       AND IAC_FALTA.CD_ATENDIMENTO IS NULL
                       AND IAC_FALTA.SN_ENCAIXE = 'N'
                       AND SYSDATE > IAC_FALTA.HR_AGENDA) AS QT_FALTAS,
                    
                    -- calculo de total de minutos de faltas
                    (SELECT SUM(NVL(AC_FALTA.QT_TEMPO_MEDIO, 0))
                     FROM DBAMV.IT_AGENDA_CENTRAL IAC_FALTA
                     JOIN DBAMV.AGENDA_CENTRAL AC_FALTA
                         ON AC_FALTA.CD_AGENDA_CENTRAL = IAC_FALTA.CD_AGENDA_CENTRAL
                     WHERE IAC_FALTA.CD_AGENDA_CENTRAL = AC.CD_AGENDA_CENTRAL
                       AND IAC_FALTA.CD_ATENDIMENTO IS NULL
                       AND IAC_FALTA.SN_ENCAIXE = 'N'
                       AND SYSDATE > IAC_FALTA.HR_AGENDA) AS HRS_FALTA_NORMAL,
                       
                    EXTRACT(MONTH FROM IAC.HR_AGENDA) AS MES,
                    EXTRACT(YEAR FROM IAC.HR_AGENDA) AS ANO
                    
    FROM DBAMV.AGENDA_CENTRAL AC
    JOIN DBAMV.IT_AGENDA_CENTRAL IAC
        ON AC.CD_AGENDA_CENTRAL = IAC.CD_AGENDA_CENTRAL
    JOIN PRESTADOR P
        ON P.CD_PRESTADOR = AC.CD_PRESTADOR
    JOIN DBAMV.ESCALA_CENTRAL ESC
        ON ESC.CD_ESCALA_CENTRAL = AC.CD_ESCALA_CENTRAL
    JOIN ESP_MED E
        ON E.CD_PRESTADOR = AC.CD_PRESTADOR
       AND E.SN_ESPECIAL_PRINCIPAL = 'S'
    JOIN ESPECIALID EP
        ON EP.CD_ESPECIALID = E.CD_ESPECIALID
    INNER JOIN DBAMV.ITEM_AGENDAMENTO IA
        ON IA.CD_ITEM_AGENDAMENTO = IAC.CD_ITEM_AGENDAMENTO
       AND IA.TP_ITEM = 'A'
    WHERE IAC.HR_AGENDA BETWEEN TO_DATE('01/02/2025', 'DD/MM/RRRR') AND
           TO_DATE('04/02/2025', 'DD/MM/RRRR')
       AND AC.CD_PRESTADOR = 249
       AND AC.TP_AGENDA = 'A'
    GROUP BY AC.CD_PRESTADOR,
             EP.DS_ESPECIALID,
             IA.CD_ITEM_AGENDAMENTO,
             ESC.HR_INICIO,
             ESC.HR_FIM,
             P.NM_PRESTADOR,
             IAC.HR_AGENDA,
             IA.DS_ITEM_AGENDAMENTO,
             AC.CD_AGENDA_CENTRAL
)
