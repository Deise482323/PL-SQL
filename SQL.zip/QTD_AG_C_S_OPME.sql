SELECT G1.TP_GUIA AS TIPO, SUM(G1.AVISO) AS QTD
-----------------SEM OPME-----------------------------------------
  FROM (SELECT 'SEM OPME' AS TP_GUIA,
               COUNT(DISTINCT AC.CD_AVISO_CIRURGIA) AS AVISO
          FROM GUIA G
         INNER JOIN AVISO_CIRURGIA AC
            ON G.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
         INNER JOIN USUARIOS U
            ON U.CD_USUARIO = AC.CD_USUARIO
         INNER JOIN CONVENIO C
            ON C.CD_CONVENIO = G.CD_CONVENIO
         INNER JOIN CIRURGIA_AVISO CA
            ON CA.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
          LEFT JOIN PRO_FAT PF ---
            ON PF.CD_PRO_FAT = C.CD_PRO_FAT
         INNER JOIN PRESTADOR_AVISO PA
            ON PA.CD_AVISO_CIRURGIA = CA.CD_AVISO_CIRURGIA
           AND PA.CD_CIRURGIA = CA.CD_CIRURGIA
           AND PA.CD_CIRURGIA_AVISO = CA.CD_CIRURGIA_AVISO
        
         WHERE TO_DATE(AC.DT_AVISO_CIRURGIA, 'DD/MM/RRRR') BETWEEN
               TO_DATE(@P_DATA_INI, 'DD/MM/RRRR') AND
               TO_DATE(@P_DATA_FIM, 'DD/MM/RRRR')
           AND AC.TP_SITUACAO = 'G'
           AND G.CD_AVISO_CIRURGIA IS NOT NULL
           AND PA.CD_ATI_MED = 01
           AND CA.SN_PRINCIPAL = 'S'
           AND AC.CD_CEN_CIR IN (1, 9)
           AND G.TP_GUIA in ('I', 'P')
           AND NOT EXISTS
         (SELECT 1
                  FROM GUIA G2
                 WHERE G2.CD_AVISO_CIRURGIA = G.CD_AVISO_CIRURGIA
                   AND G2.TP_GUIA = 'O')
           AND CA.CD_CONVENIO IN ({CONVENIO_AUX})
           AND PF.CD_GRU_PRO IN ({ESPECIALIDADE_AUX})
           AND PA.CD_PRESTADOR IN ({PRESTADOR_AUX})
           AND U.CD_USUARIO IN ({USUARIOS_AUX})
           AND {V_VAR}
         GROUP BY G.CD_AVISO_CIRURGIA
        -----------------COM OPME------------------------------------------------------------         
        UNION ALL
        SELECT 'COM OPME' AS TP_GUIA,
               COUNT(DISTINCT AC.CD_AVISO_CIRURGIA) AS AVISO
          FROM GUIA G
         INNER JOIN AVISO_CIRURGIA AC
            ON G.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
         INNER JOIN USUARIOS U
            ON U.CD_USUARIO = AC.CD_USUARIO
         INNER JOIN CONVENIO C
            ON C.CD_CONVENIO = G.CD_CONVENIO
         INNER JOIN CIRURGIA_AVISO CA
            ON CA.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
          LEFT JOIN PRO_FAT PF ---
            ON PF.CD_PRO_FAT = C.CD_PRO_FAT
         INNER JOIN PRESTADOR_AVISO PA
            ON PA.CD_AVISO_CIRURGIA = CA.CD_AVISO_CIRURGIA
           AND PA.CD_CIRURGIA = CA.CD_CIRURGIA
           AND PA.CD_CIRURGIA_AVISO = CA.CD_CIRURGIA_AVISO
        
         WHERE TO_DATE(AC.DT_AVISO_CIRURGIA, 'DD/MM/RRRR') BETWEEN
               TO_DATE(@P_DATA_INI, 'DD/MM/RRRR') AND
               TO_DATE(@P_DATA_FIM, 'DD/MM/RRRR')
           AND G.TP_GUIA = 'O'
           AND AC.TP_SITUACAO = 'G'
           AND G.CD_AVISO_CIRURGIA IS NOT NULL
           AND PA.CD_ATI_MED = 01
           AND CA.SN_PRINCIPAL = 'S'
           AND AC.CD_CEN_CIR IN (1, 9)
           AND G.CD_GUIA = (SELECT MIN(G3.CD_GUIA)
                              FROM GUIA G3
                             WHERE G3.CD_AVISO_CIRURGIA = G.CD_AVISO_CIRURGIA
                               AND G3.TP_GUIA = G.TP_GUIA)
           AND CA.CD_CONVENIO IN ({CONVENIO_AUX})
           AND PF.CD_GRU_PRO IN ({ESPECIALIDADE_AUX})
           AND PA.CD_PRESTADOR IN ({PRESTADOR_AUX})
           AND U.CD_USUARIO IN ({USUARIOS_AUX})
           AND {V_VAR}
         GROUP BY G.CD_AVISO_CIRURGIA
        --------------TOTAL GERAL----------------------------------------
        UNION ALL
        SELECT 'TOTAL GERAL' AS TP_GUIA,
               COUNT(DISTINCT AC.CD_AVISO_CIRURGIA) AS AVISO
          FROM GUIA G
         INNER JOIN AVISO_CIRURGIA AC
            ON G.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
         INNER JOIN USUARIOS U
            ON U.CD_USUARIO = AC.CD_USUARIO
         INNER JOIN CONVENIO C
            ON C.CD_CONVENIO = G.CD_CONVENIO
         INNER JOIN CIRURGIA_AVISO CA
            ON CA.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
          LEFT JOIN PRO_FAT PF ---
            ON PF.CD_PRO_FAT = C.CD_PRO_FAT
         INNER JOIN PRESTADOR_AVISO PA
            ON PA.CD_AVISO_CIRURGIA = CA.CD_AVISO_CIRURGIA
           AND PA.CD_CIRURGIA = CA.CD_CIRURGIA
           AND PA.CD_CIRURGIA_AVISO = CA.CD_CIRURGIA_AVISO
        
         WHERE TO_DATE(AC.DT_AVISO_CIRURGIA, 'DD/MM/RRRR') BETWEEN
               TO_DATE(@P_DATA_INI, 'DD/MM/RRRR') AND
               TO_DATE(@P_DATA_FIM, 'DD/MM/RRRR')
           AND G.CD_AVISO_CIRURGIA IS NOT NULL
           AND G.TP_GUIA IN ('I', 'P', 'O')
           AND AC.TP_SITUACAO = 'G'
           AND PA.CD_ATI_MED = 01
           AND CA.SN_PRINCIPAL = 'S'
           AND AC.CD_CEN_CIR IN (1, 9)
           AND CA.CD_CONVENIO IN ({CONVENIO_AUX})
           AND PF.CD_GRU_PRO IN ({ESPECIALIDADE_AUX})
           AND PA.CD_PRESTADOR IN ({PRESTADOR_AUX})
           AND U.CD_USUARIO IN ({USUARIOS_AUX})
           AND {V_VAR}
         GROUP BY G.CD_AVISO_CIRURGIA
        
        ) G1
 GROUP BY G1.TP_GUIA
