SELECT DISTINCT E.CD_EXA_LAB,
                E.NM_CAMPO,
                MAX(E.DS_RESULTADO),
                EL.NM_MNEMONICO
  FROM RES_EXA E
  JOIN DBAMV.EXA_LAB EL
    ON EL.CD_EXA_LAB = E.CD_EXA_LAB
 WHERE -- E.CD_EXA_LAB = 1547 --IN (404, 573, 671, 762, 755, 1547, 716, 437, 26,1270,1271, 652, 1528,677, 34, 962 )
 E.NM_CAMPO LIKE '%N�O-HDL�COLESTEROL, SORO%'

 GROUP BY E.CD_EXA_LAB, E.NM_CAMPO, EL.NM_MNEMONICO
 
 ORDER BY E.CD_EXA_LAB
---------------------------------------------------------------- 
 SELECT * FROM EXA_LAB E
WHERE E.NM_MNEMONICO = 'VITD25OH'

-- IN ('B12','VDRL','HEPB','AVHAT','HBSAG','HMG', 'GLI', 'HDL', 'UI','VITD25OH', 'HVAM', 'HVAG', 'AHBCG', 'ANTIHBS', 'HCV', 'ABORH', 'PPF' )
---------------------------------------------------------
 SELECT * FROM EXA_LAB E
WHERE E.NM_MNEMONICO IN ('HMG')
