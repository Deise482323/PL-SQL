SELECT DISTINCT
       --modulo,
       tela,
       cd_papel,
       ds_papel,
       cd_usuario,
       nm_usuario
 
  FROM
  ( 
    SELECT 
           nm_sistema Modulo
          ,cd_modulo Tela
          ,cd_usuario
          ,nm_usuario
          ,nvl(cd_papel,0) cd_papel
          ,ds_papel
    FROM
    (
      SELECT
             sistema.nm_sistema,
             modulos.cd_modulo,
             modulos.nm_modulo,
             usuarios.cd_usuario,
             usuarios.nm_usuario,
             tp_modulo,
             0 cd_papel,
             NULL ds_papel
      FROM  
             dbasgu.sistema,
             dbasgu.modulos,
             dbasgu.usuarios,
             dbasgu.mod_sis,
             dbasgu.aut_mod
      WHERE
                 sistema.cd_sistema = mod_sis.cd_sistema
             AND modulos.cd_modulo = mod_sis.cd_modulo
             AND modulos.cd_modulo = aut_mod.cd_modulo
             AND usuarios.cd_usuario = aut_mod.cd_usuario
             AND usuarios.sn_ativo = 'S'
      GROUP BY
             nm_sistema,
             modulos.cd_modulo,
             nm_modulo,
             usuarios.cd_usuario,
             nm_usuario,
             tp_modulo
      UNION
      SELECT
             sistema.nm_sistema,
             modulos.cd_modulo,
             modulos.nm_modulo,
             usuarios.cd_usuario,
             usuarios.nm_usuario,
             tp_modulo,
             papel.cd_papel,
             papel.ds_papel
      FROM
             dbasgu.sistema,
             dbasgu.mod_sis,
             dbasgu.modulos,
             dbasgu.usuarios,
             dbasgu.papel_mod,
             dbasgu.papel,
             dbasgu.papel_usuarios p_usu
      WHERE
                 sistema.cd_sistema = mod_sis.cd_sistema
             AND mod_sis.cd_modulo  = modulos.cd_modulo
             AND modulos.cd_modulo  = papel_mod.cd_modulo
             AND papel_mod.cd_papel = p_usu.cd_papel
             AND papel_mod.cd_papel = papel.cd_papel
             AND p_usu.cd_usuario   = usuarios.cd_usuario
             AND usuarios.sn_ativo  = 'S'
      GROUP BY
             nm_sistema,
             modulos.cd_modulo,
             nm_modulo,
             usuarios.cd_usuario,
             nm_usuario,
             tp_modulo,
             papel.cd_papel,
             papel.ds_papel
      ORDER BY
             1 ASC,
             2 ASC,
             3 ASC,
             6 ASC,
             4 ASC,
             5 ASC,
             nm_sistema,
             nm_modulo,
             nm_usuario,
             tp_modulo
                ))
  WHERE
             --Cd_usuario in ('KLEBERGS')
             tela IN('m_config_perfil_usuario') --IN ('M_TUSS_FFCV')--'M_REMESSA','M_LAN_HOS','M_LAN_AMB_PARTICULAR','M_GERA_REMESSA_AMB')
              --AND  MODULO LIKE 'PORT%'
                       --AND cd_papel IN (0)
                       AND CD_USUARIO IN(SELECT CD_ID_USUARIO FROM USUARIO_MULTI_EMPRESA WHERE CD_MULTI_EMPRESA = 3)
                 ORDER BY
                       --cd_papel ASC,
                       --modulo, tela
                       cd_usuario,
                       tela
