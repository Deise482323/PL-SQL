SELECT VC.DS_ESPECIALID,
       VC.QTD,
       VC.TOTAL_GERAL,
       ROUND(VC.QTD * 100 / VC.TOTAL_GERAL, 2) AS MEDIA
  FROM (SELECT V.DS_ESPECIALID,
               COUNT(V.CD_AVISO_CIRURGIA) AS QTD,
               TOTAL_GERAL.TOTAL AS TOTAL_GERAL
          FROM (SELECT G.CD_AVISO_CIRURGIA, CA.CD_ESPECIALID, E.DS_ESPECIALID
                  FROM GUIA G
                 INNER JOIN AVISO_CIRURGIA AC
                    ON G.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
                 INNER JOIN CIRURGIA_AVISO CA
                    ON CA.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
                   AND CA.SN_PRINCIPAL = 'S'
                 INNER JOIN ESPECIALID E
                    ON E.CD_ESPECIALID = CA.CD_ESPECIALID
                 INNER JOIN USUARIOS U
                    ON U.CD_USUARIO = AC.CD_USUARIO
                 INNER JOIN CONVENIO C
                    ON C.CD_CONVENIO = G.CD_CONVENIO
                 WHERE G.CD_AVISO_CIRURGIA IS NOT NULL
                   AND AC.TP_SITUACAO = 'R'
                   AND TO_DATE(AC.DT_REALIZACAO, 'DD/MM/RRRR') BETWEEN
                       TO_DATE(P_DATA_INI, 'DD/MM/RRRR') AND
                       TO_DATE(P_DATA_FIM, 'DD/MM/RRRR')
                   AND AC.CD_CEN_CIR IN (1, 9)
                   AND AC.TP_CIRURGIAS = 'E'
                   AND AC.DS_OBS_AVISO NOT LIKE '%PROCPA%'
                   AND G.CD_GUIA =
                       (SELECT MIN(G3.CD_GUIA)
                          FROM GUIA G3
                         WHERE G3.CD_AVISO_CIRURGIA = G.CD_AVISO_CIRURGIA
                           AND G3.TP_GUIA = G.TP_GUIA)
                   AND U.CD_USUARIO IN ({USUARIOS_AUX})) V
         CROSS JOIN (SELECT COUNT(*) AS TOTAL
                      FROM (SELECT G.CD_AVISO_CIRURGIA
                              FROM GUIA G
                             INNER JOIN AVISO_CIRURGIA AC
                                ON G.CD_AVISO_CIRURGIA = AC.CD_AVISO_CIRURGIA
                             INNER JOIN CIRURGIA_AVISO CA
                                ON CA.CD_AVISO_CIRURGIA =
                                   AC.CD_AVISO_CIRURGIA
                               AND CA.SN_PRINCIPAL = 'S'
                             INNER JOIN ESPECIALID E
                                ON E.CD_ESPECIALID = CA.CD_ESPECIALID
                             INNER JOIN USUARIOS U
                                ON U.CD_USUARIO = AC.CD_USUARIO
                             INNER JOIN CONVENIO C
                                ON C.CD_CONVENIO = G.CD_CONVENIO
                             WHERE G.CD_AVISO_CIRURGIA IS NOT NULL
                               AND AC.TP_SITUACAO = 'R'
                               AND TO_DATE(AC.DT_REALIZACAO, 'DD/MM/RRRR') BETWEEN
                                   TO_DATE(P_DATA_INI, 'DD/MM/RRRR') AND
                                   TO_DATE(P_DATA_FIM, 'DD/MM/RRRR')
                               AND AC.CD_CEN_CIR IN (1, 9)
                               AND AC.TP_CIRURGIAS = 'E'
                               AND AC.DS_OBS_AVISO NOT LIKE '%PROCPA%'
                               AND G.CD_GUIA =
                                   (SELECT MIN(G3.CD_GUIA)
                                      FROM GUIA G3
                                     WHERE G3.CD_AVISO_CIRURGIA =
                                           G.CD_AVISO_CIRURGIA
                                       AND G3.TP_GUIA = G.TP_GUIA)
                               AND U.CD_USUARIO IN ({USUARIOS_AUX}))) TOTAL_GERAL
         GROUP BY V.DS_ESPECIALID, TOTAL_GERAL.TOTAL) VC
