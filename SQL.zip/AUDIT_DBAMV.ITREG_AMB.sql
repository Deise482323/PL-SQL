SELECT *
  FROM AUDIT_DBAMV.ITREG_FAT IRA
 WHERE IRA.CD_REG_FAT = 325498
   AND IRA.AUDIT_TP_ACAO <> 'E'
   AND IRA.CD_GRU_FAT = 9
-------------------------------------------------
SELECT * FROM ITREG_FAT
------------------------------------------------

SELECT * FROM ATENDIME B
WHERE B.CD_ATENDIMENTO = 10738026 -- 42  1 
---
SELECT * FROM ITREG_AMB B WHERE B.CD_ATENDIMENTO = 10738026 
UPDATE  ITREG_AMB B SET B.CD_CONVENIO = 42 WHERE B.CD_ATENDIMENTO = 10738026 

------------------------------------------------
SELECT B.* FROM REG_AMB B
WHERE B.CD_REG_AMB = 9693302 

--------------------------------------
SELECT * FROM AUDIT_DBAMV.ITREG_AMB R
WHERE R.CD_ATENDIMENTO = 10738026 

