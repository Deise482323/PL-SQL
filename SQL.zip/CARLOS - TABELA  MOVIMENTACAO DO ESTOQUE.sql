-----( CRIACAO DAS TABELAS TEMPORARIOS COM MOVIMENTACOES ( ENTRADAS E SAIDAS ) DE PRODUTOS NA FARMACIA )----------
/*

TP_MVTO_ESTOQUE
B = TOMBAMENTO
E = EMPRESTIMO
R = MOV. ENTRE EMPRESAS
S = SAIDA SETOR
P = PACIENTE
X = BAIXA DE PRODUTO
C = DEVOLUCAO DE PACIENTE
D = DEVOLUCAO DE SETOR
T = TRANSF ENTRE ESTOQUES
*/



----------------( TABELA TEMPORARIA MOVIMENTACAO DO ESTOQUE )------------------
-----RODADO EM : DATA - TEMPO EXECUCAO - REGISTROS
--   16/03/2018 10.25 --  2.229.424 
--   30/10/2018 14.00 -- 16.374.451  --- TIME 40:00
--   18/06/2019 16:00 -- TIME : 3:43  ( Inserido dados de 01/11/2018 a 31/05/2019 ). Total = 12.035.351


       
-----drop table  ----------- dbamv.TMP_MOVIMENTO_ESTOQUE --( USAR INSERT )


SELECT TO_CHAR(ME.DT_MVTO_ESTOQUE,'YYYYMM') ANOMES,
COUNT(*) QTDE
FROM DBAMV.TMP_MOVIMENTO_ESTOQUE ME 
WHERE  TO_CHAR(ME.DT_MVTO_ESTOQUE,'YYYY') = '2024'
GROUP BY to_char(ME.DT_MVTO_ESTOQUE,'YYYYMM') 
order by 1 desc

TMP_MOVIMENTO_ESTOQUE
TMP_PRODUTO_SALDO_MENSAL



---------( VERIFICAR MESES FECHADOS )----------

Select * from dbamv.fechamento_do_mes  fm 
where fm.cd_multi_empresa = 1 and fm.dt_competencia >= '01/08/2024'
order by fm.dt_competencia

-- Acrescentar no script o periodo que desejar dar carga.

-------------------------------------------------------------------------------------------------------------------------------------------------
---- CREATE TABLE DBAMV.TMP_MOVIMENTO_ESTOQUE AS 
---- ATUALIZADO EM 15/02/2023 / 14/06/2023 / 14/09/2023 /  29/01/2024  / 04/04/2024
-------------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO DBAMV.TMP_MOVIMENTO_ESTOQUE
       (CD_MVTO_ESTOQUE,TP_MVTO_ESTOQUE,DESC_MVTO_ESTOQUE,CD_ESTOQUE,DT_MVTO_ESTOQUE,
       CD_ATENDIMENTO,CD_UNID_INT,CD_SETOR,CD_PRESTADOR,CD_ESTOQUE_DESTINO,
       CD_MOT_DEV,CD_SOLSAI_PRO,CD_AVISO_CIRURGIA,CD_ENT_PRO,CD_USUARIO,CD_MULTI_EMPRESA,
       TP_RETROATIVO,CD_ITMVTO_ESTOQUE,CD_PRODUTO,CD_UNI_PRO,QT_MOVIMENTACAO,CD_FORNECEDOR,
       CD_LOTE,DT_VALIDADE,NR_DOCUMENTO,DH_MVTO_ESTOQUE,CD_ITSOLSAI_PRO,
       TP_ESTOQUE,QT_KIT,TP_ORCAMENTO,SN_FATURA,DT_GRAVACAO,DS_ESTOQUE,
       SN_IMPRIME_DIRETO,CD_REDUZIDO_DEBITO,CD_REDUZIDO_CREDITO,CD_SUB_CLA,
       CD_CLASSE,CD_ESPECIE,DS_PRODUTO,DT_CADASTRO,TP_ATIVO,DT_ULTIMA_ENTRADA,
       SN_CONTROLE_VALIDADE,SN_PADRONIZADO,SN_PSCOTROPICO,HR_ULTIMA_ENTRADA,SN_MEDICAMENTO,
       CD_TIP_ATIV,SN_IMPRIME_ETIQUETA,SN_LOTE,CD_PRO_FAT,VL_FATOR_PRO_FAT,CD_DCB,CD_UNIDADE,
       DS_UNIDADE,VL_FATOR,TP_RELATORIOS,VL_CUSTO_MEDIO,CD_UNIDADERF1,DS_UNIDADERF1,VL_FATORRF1,
       TP_RELATORIOSRF1,CSTMEDIORF1,VL_ULTIMA_ENTRADA,CD_ULTIMO_FORNECEDOR,QT_ULTIMA_ENTRADA,
       DS_PRODUTO_RESUMIDO,VL_ULTIMA_CUSTO_REAL,SN_CONSIGNADO,CD_FORNECEDOR_PRINCIPAL,VL_ULTIMA_COMPRA_IPI,
       TP_HORAS_ESTERELIZAR,CD_USUARIO_INC,DT_INC_USUARIO,CD_USUARIO_ALT,DT_ALT_USUARIO )

Select 
    IME.CD_MVTO_ESTOQUE,  
    ME.TP_MVTO_ESTOQUE,  

    decode(ME.TP_MVTO_ESTOQUE,'B' ,'TOMBAMENTO','E','EMPRESTIMO','R','MOV. ENTRE EMPRESAS','S','SAIDA SETOR','P' ,'PACIENTE','X','BAIXA DE PRODUTO','C','DEVOLUCAO DE PACIENTE',
                                   'D','DEVOLUCAO DE SETOR','T','TRANSF ENTRE ESTOQUES') DESC_MVTO_ESTOQUE,       
                  
    me.CD_ESTOQUE,
    DT_MVTO_ESTOQUE,
    CD_ATENDIMENTO,
    CD_UNID_INT,
    me.CD_SETOR,
    CD_PRESTADOR,
    CD_ESTOQUE_DESTINO,
    CD_MOT_DEV,
    CD_SOLSAI_PRO,
    CD_AVISO_CIRURGIA,
    CD_ENT_PRO,
    CD_USUARIO,
    me.CD_MULTI_EMPRESA,
    TP_RETROATIVO,
    CD_ITMVTO_ESTOQUE,
    ime.CD_PRODUTO,
    ime.CD_UNI_PRO,
    QT_MOVIMENTACAO,
    
    IME.CD_FORNECEDOR,
--    IME.CD_LOTE,
    substr(IME.CD_LOTE,1,20) cd_lote,
    IME.DT_VALIDADE,
    SUBSTR(ME.NR_DOCUMENTO,1,15)  NR_DOCUMENTO,
    DH_MVTO_ESTOQUE,
    CD_ITSOLSAI_PRO,
    e.TP_ESTOQUE,
    QT_KIT,
    TP_ORCAMENTO,
    SN_FATURA,
    DT_GRAVACAO,
    DS_ESTOQUE,
    SN_IMPRIME_DIRETO,
    CD_REDUZIDO_DEBITO,
    CD_REDUZIDO_CREDITO,
    CD_SUB_CLA,
    CD_CLASSE,
    CD_ESPECIE,
    DS_PRODUTO,
    DT_CADASTRO,
    TP_ATIVO,
    DT_ULTIMA_ENTRADA,
    SN_CONTROLE_VALIDADE,
    SN_PADRONIZADO,
    SN_PSCOTROPICO,

    HR_ULTIMA_ENTRADA,
    SN_MEDICAMENTO,
    CD_TIP_ATIV,
    SN_IMPRIME_ETIQUETA,
    SN_LOTE,
    pr.CD_PRO_FAT,
    VL_FATOR_PRO_FAT,
    CD_DCB,

    UP.CD_UNIDADE,
    UP.DS_UNIDADE,
    UP.VL_FATOR,
    UP.TP_RELATORIOS,
    VL_CUSTO_MEDIO,

    UP1.CD_UNIDADE CD_UNIDADERF1,
    UP1.DS_UNIDADE DS_UNIDADERF1,
    UP1.VL_FATOR VL_FATORRF1,
    UP1.TP_RELATORIOS TP_RELATORIOSRF1,
    (VL_ULTIMA_ENTRADA * up1.vl_fator) CSTMEDIORF1,
  
    VL_ULTIMA_ENTRADA,
    CD_ULTIMO_FORNECEDOR,
    QT_ULTIMA_ENTRADA,
    DS_PRODUTO_RESUMIDO,
    VL_ULTIMA_CUSTO_REAL,
    SN_CONSIGNADO,
    CD_FORNECEDOR_PRINCIPAL,
    VL_ULTIMA_COMPRA_IPI,
    TP_HORAS_ESTERELIZAR,
    CD_USUARIO_INC,
    DT_INC_USUARIO,
    CD_USUARIO_ALT,
    DT_ALT_USUARIO

--select count(*)
fRom dbamv.mvto_estoque me
inner join dbamv.itmvto_estoque ime on ime.cd_mvto_estoque = me.cd_mvto_estoque
inner join dbamv.estoque e on e.cd_estoque = me.cd_estoque
inner join dbamv.produto pr on pr.cd_produto = ime.cd_produto
inner join dbamv.uni_pro up on up.cd_produto = pr.cd_produto and up.tp_relatorios = 'R' AND UP.SN_ATIVO = 'S'
LEFT OUTER join dbamv.uni_pro up1 on up1.cd_produto = pr.cd_produto and up1.tp_relatorios = '1' AND UP1.SN_ATIVO = 'S'
where me.dt_mvto_estoque between '01/08/2024' and '31/08/2024'
--AND  ME.cd_estoque IN (4,5,6,7,8,2,9)
--AND E.TP_ESTOQUE = 'D'
AND ME.CD_MULTI_EMPRESA  = 1
--and IME.cd_produto = 115493 and ME.tp_mvto_estoque = 'S' AND IME.CD_MVTO_ESTOQUE = 12332452





SELECT TO_CHAR(E.DT_MVTO_ESTOQUE,'YYYYMM') ANOMES,
       COUNT(*) QDE
FROM DBAMV.TMP_MOVIMENTO_ESTOQUE E 
where TO_CHAR(E.DT_MVTO_ESTOQUE,'YYYY') = '2024'
GROUP BY TO_CHAR(E.DT_MVTO_ESTOQUE,'YYYYMM') 
ORDER BY 1 


*/



-----------( PESQUISA SALDO FINAL DE CADA PRODUTO NO ESTOQUE )-------


SELECT * FROM DBAMV.TMP_PRODUTO_SALDOMENSAL C WHERE C.CD_ANO >= 2021
and c.cd_produto = 63579
order by cd_ano,cd_mes


------------------------------------- drop table dbamv.TMP_PRODUTO_SALDOMENSAL

------------------ CREATE TABLE DBAMV.TMP_PRODUTO_SALDOMENSAL AS



SELECT cd_ano,cd_mes, count(*) qtde
FROM DBAMV.TMP_PRODUTO_SALDOMENSAL C 
where c.cd_ano in ( '2024')
group by cd_ano,cd_mes
order by 1,2 

--- ATUALIZADO EM 14/06/2023 - Dados MAI/2023 
--- ATUALIZADO EM 14/09/2023 - Dados AGO/2023 

---- INSERT PARA ATUALIZAR A BASE TMP_PRODUTO_SALDOMENSAL COM O MES QUE DESEJAR ATUALIZAR.

INSERT INTO DBAMV.TMP_PRODUTO_SALDOMENSAL
       (CD_PRODUTO,CD_ESTOQUE,CD_ANO,CD_MES,QT_ESTOQUE_INICIAL,VL_ESTOQUE_INICIAL,
       QT_ESTOQUE_FINAL,VL_ESTOQUE_FINAL,QT_ENTRADA,VL_ENTRADA,QT_SAIDA_SETOR,VL_SAIDA_SETOR,
       QT_SAIDA_PACIENTE,VL_SAIDA_PACIENTE,QT_DEVOLUCAO_SETOR,VL_DEVOLUCAO_SETOR,QT_DEVOLUCAO_PACIENTE,
       VL_DEVOLUCAO_PACIENTE,SN_IMPORTADO_MGES_FCCT)

select CD_PRODUTO,  
       CD_ESTOQUE,
       CD_ANO,
       CD_MES,
       QT_ESTOQUE_INICIAL,
       VL_ESTOQUE_INICIAL,
       QT_ESTOQUE_FINAL,
       VL_ESTOQUE_FINAL,
       QT_ENTRADA,  
       VL_ENTRADA,
       QT_SAIDA_SETOR,
          VL_SAIDA_SETOR,
                    QT_SAIDA_PACIENTE,
                      VL_SAIDA_PACIENTE,
                        QT_DEVOLUCAO_SETOR,
                          VL_DEVOLUCAO_SETOR,
                            QT_DEVOLUCAO_PACIENTE,
                              VL_DEVOLUCAO_PACIENTE,
                                SN_IMPORTADO_MGES_FCCT
FROM DBAMV.C_CONEST C WHERE C.CD_ANO = 2024 and c.cd_mes in (08)


--- ATUALIZADO DIA 30/04/2020   MES = 04
--- ATUALIZADO DIA 22/06/2020   MES = 05
--- ATUALIZADO DIA 23/11/2020   MES = 08,09,10
--- ATUALIZADO DIA 04/01/2023   MES = 12  
--- ATUALIZADO DIA 01/02/2023   MES = 01  


SELECT C.CD_ANO ,C.CD_MES , COUNT(*) QTDE
        FROM DBAMV.TMP_PRODUTO_SALDOMENSAL C WHERE C.CD_ANO = 2023
GROUP BY C.CD_ANO ,C.CD_MES
ORDER BY 2 DESC

--- 


SELECT C.CD_MES,  COUNT(*) QTDE FROM DBAMV.C_CONEST C WHERE C.CD_ANO = 2022
-- and c.cd_mes in (7)
GROUP BY C.CD_MES
 
-------------------------------------------------------------------------------------

-----------( TABELA ENTRADA DE PRODUTO NO ESTOQUE )------------------


SELECT to_char(epe.dt_entrada,'yyyymm') anomes,count(*) qtde
FROM DBAMV.TMP_ENTRADA_PRODUTO_ESTOQUE EPE 
WHERE to_char(epe.dt_entrada,'yyyy') = '2024'
group by to_char(epe.dt_entrada,'yyyymm') 
order by 1


--------------------------------------------------------------
-----------( TMP_ENTRADA_PRODUTO_ESTOQUE )-------------------


-- SCRIPT PARA ENVIO FERNANDO
SELECT * FROM DBAMV.TMP_ENTRADA_PRODUTO_ESTOQUE EPE WHERE EPE.DT_ENTRADA BETWEEN '28/02/2023' AND '28/02/2023'
order by epe.dt_entrada

-- dELETe FROM DBAMV.TMP_ENTRADA_PRODUTO_ESTOQUE EPE WHERE EPE.DT_ENTRADA BETWEEN '01/01/2024' AND '29/02/2024' --8.815


-------- DATA ATUALIZACAO : 08/05/2023 / 14/06/2023 / 17/08/2023 / 29/01/2024 ( Ate dez/2023)  --- 04/04/2024 

SELECT to_char(epe.dt_entrada,'yyyy/mm') anomes,
       count(*) FROM DBAMV.TMP_ENTRADA_PRODUTO_ESTOQUE EPE WHERE EPE.DT_ENTRADA BETWEEN '01/12/2023' AND '30/04/2024'
       group by  to_char(epe.dt_entrada,'yyyy/mm') 
order by  to_char(epe.dt_entrada,'yyyy/mm')
-- drop table dbamv.tmp_entrada_produto_estoque




-------------------------------------------------------------------------------------------------------------------------------------------------
--- CREATE TABLE TMP_ENTRADA_PRODUTO_ESTOQUE AS
---- ATUALIZADO EM 15/02/2023 / 06/03/2023 / 10/04/2023 / 14/06/2023 / 09/08/2023  / 14/09/2023 /  29/01/2024  / 04/04/2024 / 16/05/2024
-------------------------------------------------------------------------------------------------------------------------------------------------


INSERT INTO DBAMV.TMP_ENTRADA_PRODUTO_ESTOQUE
       (CD_ATENDIMENTO,
       CD_CUSTO_MEDIO,
       CD_ENT_PRO,
       CD_ESTOQUE,
       DT_ENTRADA,
       CD_FORNECEDOR,
       NR_DOCUMENTO,
       CD_CON_PAG,
       CD_ITENT_PRO,
       CD_ORD_COM,
       CD_PRODUTO,
       DS_PRODUTO,
       ds_especie,
       ds_classe,
       ds_sub_cla,
       cd_pro_fat,
       CD_TIP_ENT,
       CD_TIP_DOC,
       CD_UNI_PRO,
       CD_UNIDADE,
       DT_GRAVACAO,
       DT_EMISSAO,
       DS_UNIDADE,
       VL_TOTAL_ENTRADA,
       VL_DESCONTO,
       VL_CUSTO_REAL,
       VL_TOTAL,
       VL_UNITARIO,
       VL_DESCONTO_ITEM,
       VL_IMPOSTO,
       VL_PERCENTUAL_DESCONTO,
       VL_TOTAL_CUSTO_REAL,
       VL_FATOR,
       QT_ATENDIDA,
       QT_CONSUMO_ATUAL,
       QT_CONSUMO_MES,
       QT_DEVOLVIDA,
       QT_ENTRADA,
       QT_ESTOQUE_ATUAL,
       QT_ESTOQUE_MAXIMO,
       QT_ESTOQUE_MINIMO,
       QT_ESTOQUE_VIRTUAL,
       QT_ESTOQUE_DOADO,
       QT_ESTOQUE_RESERVADO,
       QT_ORDEM_DE_COMPRA,
       QT_PONTO_DE_PEDIDO,
       QT_SOLICITACAO_DE_COMPRA,
       SN_ATIVO,
       TP_RELATORIOS,
       TP_CLASSIFICACAO_ABC,
       CD_REG_FAT,
       CDPROFAT,
       HR_LANCAMENTO,
       QT_LANCAMENTO,
       VLR_UNIT_FAT,
       VL_TOTAL_CONTA
)
       
SELECT 
       IEP.CD_ATENDIMENTO,
       IEP.CD_CUSTO_MEDIO,
       EP.CD_ENT_PRO,
       EP.CD_ESTOQUE,
       EP.DT_ENTRADA,
       EP.CD_FORNECEDOR,
       EP.NR_DOCUMENTO,
       EP.CD_CON_PAG,
       IEP.CD_ITENT_PRO,
       EP.CD_ORD_COM,
       IEP.CD_PRODUTO,
       P.DS_PRODUTO,
       es.ds_especie,
       cl.ds_classe,
       sc.ds_sub_cla,
       p.cd_pro_fat,
       EP.CD_TIP_ENT,
       EP.CD_TIP_DOC,
       IEP.CD_UNI_PRO,
       UP.CD_UNIDADE,
       IEP.DT_GRAVACAO,
       EP.DT_EMISSAO,
       UP.DS_UNIDADE,
       EP.VL_TOTAL VL_TOTAL_ENTRADA,
       EP.VL_DESCONTO,
       IEP.VL_CUSTO_REAL,
       IEP.VL_TOTAL,
       IEP.VL_UNITARIO,
       IEP.VL_DESCONTO VL_DESCONTO_ITEM,
       IEP.VL_IMPOSTO,
       IEP.VL_PERCENTUAL_DESCONTO,
       IEP.VL_TOTAL_CUSTO_REAL,
       UP.VL_FATOR,
       IEP.QT_ATENDIDA,
       EPP.QT_CONSUMO_ATUAL,
       EPP.QT_CONSUMO_MES,
       IEP.QT_DEVOLVIDA,
       IEP.QT_ENTRADA,
       EPP.QT_ESTOQUE_ATUAL,
       EPP.QT_ESTOQUE_MAXIMO,
       EPP.QT_ESTOQUE_MINIMO,
       EPP.QT_ESTOQUE_VIRTUAL,
       EPP.QT_ESTOQUE_DOADO,
       EPP.QT_ESTOQUE_RESERVADO,
       EPP.QT_ORDEM_DE_COMPRA,
       EPP.QT_PONTO_DE_PEDIDO,
       EPP.QT_SOLICITACAO_DE_COMPRA,
       UP.SN_ATIVO,
       UP.TP_RELATORIOS,
       EPP.TP_CLASSIFICACAO_ABC,
       IRF.CD_REG_FAT,
       IRF.CD_PRO_FAT CDPROFAT,
       IRF.HR_LANCAMENTO,
       IRF.QT_LANCAMENTO,
       IRF.VL_UNITARIO VLR_UNIT_FAT,
       IRF.VL_TOTAL_CONTA

FROM DBAMV.ENT_PRO EP 
INNER JOIN DBAMV.ITENT_PRO IEP ON IEP.CD_ENT_PRO = EP.CD_ENT_PRO
LEFT OUTER JOIN DBAMV.UNI_PRO UP ON UP.CD_UNI_PRO = IEP.CD_UNI_PRO
LEFT OUTER JOIN DBAMV.EST_PRO EPP ON EPP.CD_PRODUTO = IEP.CD_PRODUTO AND EPP.CD_ESTOQUE = 4
inner join dbamv.produto p on p.cd_produto = iep.cd_produto
inner join dbamv.especie es on es.cd_especie = p.cd_especie
inner join dbamv.classe cl on cl.cd_especie = es.cd_especie and cl.cd_classe = p.cd_classe
inner join dbamv.sub_clas sc on sc.cd_classe = cl.cd_classe and es.cd_especie = cl.cd_especie 
and sc.cd_sub_cla = p.cd_sub_cla and sc.cd_classe = p.cd_classe and sc.cd_especie = p.cd_especie
LEFT OUTER JOIN DBAMV.REG_FAT RF ON RF.CD_ATENDIMENTO = EP.CD_ATENDIMENTO
LEFT OUTER JOIN DBAMV.ITREG_FAT IRF ON IRF.CD_PRO_FAT = P.CD_PRO_FAT AND IRF.CD_REG_FAT = RF.CD_REG_FAT
WHERE eP.cd_estoque IN (select E.CD_ESTOQUE from dbamv.estoque e WHERE E.tp_estoque = 'D' AND E.CD_MULTI_EMPRESA = 1)
AND EP.DT_ENTRADA  between '01/08/2024' and '31/08/2024'
--AND IRF.QT_LANCAMENTO > 999999


----------------------------------------------------------------------
                        -- SCRIPT PARA ENVIO FERNANDO
----------------------------------------------------------------------
--- Tabela : TMP_MOVIMENTO_ESTOQUE

select 
     CD_MVTO_ESTOQUE || '|' ||TP_MVTO_ESTOQUE || '|' ||DESC_MVTO_ESTOQUE || '|' ||CD_ESTOQUE || '|' ||DT_MVTO_ESTOQUE || '|' ||CD_ATENDIMENTO || '|' ||CD_UNID_INT || '|' ||CD_SETOR || '|' ||CD_PRESTADOR || '|' ||CD_ESTOQUE_DESTINO || '|' ||CD_MOT_DEV || '|' ||CD_SOLSAI_PRO || '|' ||CD_AVISO_CIRURGIA || '|' ||CD_ENT_PRO || '|' ||CD_USUARIO || '|' ||CD_MULTI_EMPRESA || '|' ||TP_RETROATIVO || '|' ||CD_ITMVTO_ESTOQUE || '|' ||CD_PRODUTO || '|' ||CD_UNI_PRO || '|' ||QT_MOVIMENTACAO || '|' ||CD_FORNECEDOR || '|' ||CD_LOTE || '|' ||DT_VALIDADE || '|' ||NR_DOCUMENTO || '|' ||DH_MVTO_ESTOQUE || '|' ||CD_ITSOLSAI_PRO || '|' ||TP_ESTOQUE || '|' ||QT_KIT || '|' ||TP_ORCAMENTO || '|' ||SN_FATURA || '|' ||DT_GRAVACAO || '|' ||DS_ESTOQUE || '|' ||SN_IMPRIME_DIRETO || '|' ||CD_REDUZIDO_DEBITO || '|' ||CD_REDUZIDO_CREDITO || '|' ||CD_SUB_CLA || '|' ||CD_CLASSE || '|' ||CD_ESPECIE || '|' ||DS_PRODUTO || '|' ||DT_CADASTRO || '|' ||TP_ATIVO || '|' ||DT_ULTIMA_ENTRADA || '|' ||SN_CONTROLE_VALIDADE || '|' ||SN_PADRONIZADO || '|' ||SN_PSCOTROPICO || '|' ||HR_ULTIMA_ENTRADA || '|' ||SN_MEDICAMENTO || '|' ||CD_TIP_ATIV || '|' ||SN_IMPRIME_ETIQUETA || '|' ||SN_LOTE || '|' ||CD_PRO_FAT || '|' ||VL_FATOR_PRO_FAT || '|' ||CD_DCB || '|' ||CD_UNIDADE || '|' ||DS_UNIDADE || '|' ||VL_FATOR || '|' ||TP_RELATORIOS || '|' ||VL_CUSTO_MEDIO || '|' ||CD_UNIDADERF1 || '|' ||DS_UNIDADERF1 || '|' ||VL_FATORRF1 || '|' ||TP_RELATORIOSRF1 || '|' ||CSTMEDIORF1 || '|' ||VL_ULTIMA_ENTRADA || '|' ||CD_ULTIMO_FORNECEDOR || '|' ||QT_ULTIMA_ENTRADA || '|' ||DS_PRODUTO_RESUMIDO || '|' ||VL_ULTIMA_CUSTO_REAL || '|' ||SN_CONSIGNADO || '|' ||CD_FORNECEDOR_PRINCIPAL || '|' ||VL_ULTIMA_COMPRA_IPI || '|' ||TP_HORAS_ESTERELIZAR || '|' ||CD_USUARIO_INC || '|' ||DT_INC_USUARIO || '|' ||CD_USUARIO_ALT || '|' ||DT_ALT_USUARIO
from dbamv.tmp_movimento_estoque tme where tme.dt_mvto_estoque between '01/02/2024' and '01/05/2024'
ORDER BY tme.CD_MVTO_ESTOQUE


--- Tabela : TMP_ENTRADA_PRODUTO_ESTOQUE

SELECT 
      CD_ATENDIMENTO || '|' ||CD_CUSTO_MEDIO || '|' ||CD_ENT_PRO || '|' ||CD_ESTOQUE || '|' ||DT_ENTRADA || '|' ||CD_FORNECEDOR || '|' ||NR_DOCUMENTO || '|' ||CD_CON_PAG || '|' ||CD_ITENT_PRO || '|' ||CD_ORD_COM || '|' ||CD_PRODUTO || '|' ||DS_PRODUTO || '|' ||DS_ESPECIE || '|' ||DS_CLASSE || '|' ||DS_SUB_CLA || '|' ||CD_PRO_FAT || '|' ||CD_TIP_ENT || '|' ||CD_TIP_DOC || '|' ||CD_UNI_PRO || '|' ||CD_UNIDADE || '|' ||DT_GRAVACAO || '|' ||DT_EMISSAO || '|' ||DS_UNIDADE || '|' ||VL_TOTAL_ENTRADA || '|' ||VL_DESCONTO || '|' ||VL_CUSTO_REAL || '|' ||VL_TOTAL || '|' ||VL_UNITARIO || '|' ||VL_DESCONTO_ITEM || '|' ||VL_IMPOSTO || '|' ||VL_PERCENTUAL_DESCONTO || '|' ||VL_TOTAL_CUSTO_REAL || '|' ||VL_FATOR || '|' ||QT_ATENDIDA || '|' ||QT_CONSUMO_ATUAL || '|' ||QT_CONSUMO_MES || '|' ||QT_DEVOLVIDA || '|' ||QT_ENTRADA || '|' ||QT_ESTOQUE_ATUAL || '|' ||QT_ESTOQUE_MAXIMO || '|' ||QT_ESTOQUE_MINIMO || '|' ||QT_ESTOQUE_VIRTUAL || '|' ||QT_ESTOQUE_DOADO || '|' ||QT_ESTOQUE_RESERVADO || '|' ||QT_ORDEM_DE_COMPRA || '|' ||QT_PONTO_DE_PEDIDO || '|' ||QT_SOLICITACAO_DE_COMPRA || '|' ||SN_ATIVO || '|' ||TP_RELATORIOS || '|' ||TP_CLASSIFICACAO_ABC || '|' ||CD_REG_FAT || '|' ||CDPROFAT || '|' ||HR_LANCAMENTO || '|' ||QT_LANCAMENTO || '|' ||VLR_UNIT_FAT || '|' ||VL_TOTAL_CONTA
 FROM DBAMV.TMP_ENTRADA_PRODUTO_ESTOQUE EPE WHERE EPE.DT_ENTRADA BETWEEN '01/04/2024' AND '30/04/2024'



----------------------------------------------------------------------------------


-- delete from dbamv.tmp_movimento_estoque tme where tme.dt_mvto_estoque between '01/11/2023' and '31/12/2023'

-- select * from dbamv.estoque e WHERE E.tp_estoque = 'D' AND E.CD_MULTI_EMPRESA = 1 


SELECT PR.CD_PRODUTO,
       PR.DS_PRODUTO,
       PR.CD_ESPECIE,
       ES.DS_ESPECIE,
       PR.CD_CLASSE,
       CL.DS_CLASSE,
       PR.CD_SUB_CLA,
       SC.DS_SUB_CLA,
       PR.DT_ULTIMA_ENTRADA,
       PR.VL_ULTIMA_ENTRADA,
       PR.VL_CUSTO_MEDIO
       fROM DBAMV.PRODUTO PR
inner join dbamv.especie es on es.cd_especie = pR.cd_especie
inner join dbamv.classe cl on cl.cd_especie = es.cd_especie and cl.cd_classe = pR.cd_classe
inner join dbamv.sub_clas sc on sc.cd_classe = cl.cd_classe and es.cd_especie = cl.cd_especie 
and sc.cd_sub_cla = pR.cd_sub_cla and sc.cd_classe = pR.cd_classe and sc.cd_especie = pR.cd_especie

select pf.cd_pro_fat,
       pf.ds_pro_fat,
       gf.cd_gru_fat,
       gf.ds_gru_fat,
       gp.cd_gru_pro,
       gp.ds_gru_pro
       from dbamv.pro_fat pf  -- 36.933
inner join dbamv.gru_pro gp on gp.cd_gru_pro = pf.cd_gru_pro
inner join dbamv.gru_fat gf on gf.cd_gru_fat = gp.cd_gru_fat 



-----------( TABELA PAGAMENTO DE NOTA )------------------
-- drop table dbamv.TMP_PAGAMENTO_PRODUTO
-- SELECT count(*) FROM DBAMV.TMP_PAGAMENTO_PRODUTO --- 54.741

SELECT * FROM DBAMV.TMP_PAGAMENTO_PRODUTO TPP WHERE TPP.DT_EMISSAO BETWEEN '01/01/2026' AND '20/02/2026'
-----------------------------------------------------------------------------------------------------------------
UPDATE DBAMV.TMP_PAGAMENTO_PRODUTO
SET DT_VENCIMENTO = TRUNC(DT_VENCIMENTO),
    DT_LANCAMENTO = TRUNC(DT_LANCAMENTO),
    DT_EMISSAO    = TRUNC(DT_EMISSAO),
    DT_QUITACAO   = TRUNC(DT_QUITACAO);
    ------------------------------------
    SELECT COUNT(*) AS QTDE_COM_HORA
FROM DBAMV.TMP_PAGAMENTO_PRODUTO
WHERE DT_VENCIMENTO <> TRUNC(DT_VENCIMENTO)
   OR DT_LANCAMENTO <> TRUNC(DT_LANCAMENTO)
   OR DT_EMISSAO <> TRUNC(DT_EMISSAO)
   OR DT_QUITACAO <> TRUNC(DT_QUITACAO);
-----------------------------------------------------------------------------------------------------
CREATE TABLE dbamv.TMP_PAGAMENTO_PRODUTO 
AS

SELECT 
       CP.CD_CON_PAG,
       CP.NR_DOCUMENTO,
       CP.DT_LANCAMENTO,
       CP.DT_EMISSAO,
       CP.SN_CONTABILIZA,
       CP.DS_CON_PAG,
       CP.CD_FORNECEDOR,
       CP.CD_ESTOQUE,
       ICP.NR_PARCELA,
       ICP.DT_VENCIMENTO,
       ICP.VL_DUPLICATA,
       ICP.DT_QUITACAO,
       ICP.VL_MOEDA
 
       FROM DBAMV.CON_PAG CP
       INNER JOIN DBAMV.ITCON_PAG ICP ON ICP.CD_CON_PAG = CP.CD_CON_PAG
       INNER JOIN DBAMV.ENT_PRO EP ON EP.CD_CON_PAG = ICP.CD_CON_PAG
WHERE eP.cd_estoque IN (2,3,4,5,9,36,1,35,40,71)
AND EP.DT_ENTRADA  between '01/01/2022' and '31/12/2022'
group by        CP.CD_CON_PAG,
       CP.NR_DOCUMENTO,
       CP.DT_LANCAMENTO,
       CP.DT_EMISSAO,
       CP.SN_CONTABILIZA,
       CP.DS_CON_PAG,
       CP.CD_FORNECEDOR,
       CP.CD_ESTOQUE,
       ICP.NR_PARCELA,
       ICP.DT_VENCIMENTO,
       ICP.VL_DUPLICATA,
       ICP.DT_QUITACAO,
       ICP.VL_MOEDA
       
--====INSERT===========----

INSERT INTO DBAMV.TMP_PAGAMENTO_PRODUTO (
       CD_CON_PAG,
       NR_DOCUMENTO,
       DT_LANCAMENTO,
       DT_EMISSAO,
       SN_CONTABILIZA,
       DS_CON_PAG,
       CD_FORNECEDOR,
       CD_ESTOQUE,
       NR_PARCELA,
       DT_VENCIMENTO,
       VL_DUPLICATA,
       DT_QUITACAO,
       VL_MOEDA
)
SELECT 
       CP.CD_CON_PAG,
       CP.NR_DOCUMENTO,
       CAST(TRUNC(CP.DT_LANCAMENTO)  AS DATE),
       CAST(TRUNC(CP.DT_EMISSAO)     AS DATE),
       CP.SN_CONTABILIZA,
       CP.DS_CON_PAG,
       CP.CD_FORNECEDOR,
       CP.CD_ESTOQUE,
       ICP.NR_PARCELA,
       CAST(TRUNC(ICP.DT_VENCIMENTO) AS DATE),
       ICP.VL_DUPLICATA,
       CAST(TRUNC(ICP.DT_QUITACAO)   AS DATE),
       ICP.VL_MOEDA
FROM DBAMV.CON_PAG CP
INNER JOIN DBAMV.ITCON_PAG ICP 
       ON ICP.CD_CON_PAG = CP.CD_CON_PAG
INNER JOIN DBAMV.ENT_PRO EP 
       ON EP.CD_CON_PAG = ICP.CD_CON_PAG
WHERE EP.CD_ESTOQUE IN (2,3,4,5,9,36,1,35,40,71)
AND TRUNC(EP.DT_ENTRADA) BETWEEN DATE '2022-01-01'
                             AND DATE '2026-02-20';



---
-----------( TABELA NONTAS FISCAIS ) ---------------


--****** CRIADO NOVA VIEW PARA PEGAR NOTA FISCAL QUE JA EM COM VALOR RECEBIDO E GLOSADO **** ( MAIS A BAIXO ).

-- SELECT count(*) FROM DBAMV.TMP_NOTAS_FISCAIS   --- 30.488
-- drop table DBAMV.TMP_NOTAS_FISCAIS
-- SELECT * FROM DBAMV.TMP_NOTAS_FISCAIS TCR WHERE TCR.DT_EMISSAO BETWEEN '01/01/2015' AND '31/01/2015'
 

--CREATE TABLE DBAMV.TMP_NOTAS_FISCAIS  
--AS

SELECT NF.CD_NOTA_FISCAL,
       NF.NR_ID_NOTA_FISCAL RPS,
       TO_CHAR(NF.DT_EMISSAO,'YYYYMM') ANOMES,
       NF.DT_EMISSAO,
       NF.CD_ATENDIMENTO,
       NF.CD_REG_FAT,
       NF.CD_REG_AMB,
       NF.CD_CONVENIO,
       NF.CD_REMESSA,
       NF.NM_CLIENTE,
       NF.NR_CGC_CPF,
       NF.VL_TOTAL_NOTA,
       NF.CD_STATUS,
       NF.VL_ACRESCIMO_NOTA,
       NF.VL_DESCONTO_NOTA,
       NF.NR_NOTA_FISCAL_NFE,
       NF.HR_EMISSAO_NFE,
       NF.CD_VERIFICACAO_NFE,
       ICR.DT_PREVISTA_RECEBIMENTO,
       ICR.DT_VENCIMENTO--,
--       ICR.VL_DUPLICATA,
--       ICR.TP_QUITACAO
FROM DBAMV.NOTA_FISCAL NF
LEFT OUTER JOIN DBAMV.CON_REC CR ON NF.CD_NOTA_FISCAL = CR.CD_NOTA_FISCAL
left outer JOIN DBAMV.ITCON_REC ICR ON ICR.CD_CON_REC = CR.CD_CON_REC 
--left outer JOIN DBAMV.FORNECEDOR F ON F.CD_FORNECEDOR = CR.CD_FORNECEDOR
WHERE Cr.DT_EMISSAO BETWEEN '01/01/2016' AND '31/12/2016'
AND nf.cd_multi_empresa = 1
AND NF.CD_STATUS <> 'C'


---------------------------( NOTA FISCAL X RECEBIMENTO X GLOSADO )-------------------
----NOVA ROTINA

-- SELECT count(*) FROM DBAMV.TMP_NOTAS_FISCAIS   --- 30.542  -- 34.256
-- drop table DBAMV.TMP_NOTAS_FISCAIS
-- SELECT * FROM DBAMV.TMP_NOTAS_FISCAIS TCR -- WHERE TCR.DT_EMISSAO BETWEEN '01/01/2015' AND '31/01/2015'
-- tempo : 05:20

CREATE TABLE DBAMV.TMP_NOTAS_FISCAIS  AS

select cd_nota_fiscal,
       nr_id_nota_fiscal,
       to_char(dt_emissao,'yyyy/mm') anomesemissao,
       dt_emissao,
       dt_vencimento,
       cd_convenio,
       cd_fornecedor,
       nm_fantasia,
       sum(vlr_faturado) vlr_faturado,
       sum(vlr_recebido) vlr_recebido,
       dt_recebimento,
       sum(vlr_glosa_inicial) vlr_glosa_inicial,
       sum(vlr_recurso_glosa) vlr_recurso_glosa,
       sum(vlr_recebido_glosa) vlr_recebido_glosa,
       tp_quitacao
from (

select 'INTERNOS' TP_ATENDIMENTO,
       nf.cd_nota_fiscal,
       a.nr_id_nota_fiscal,
       a.dt_vencimento,
       a.dt_emissao,
       rf.cd_convenio,
       a.cd_fornecedor,
       a.nm_fantasia,
       sum(a.vl_faturado) vlr_faturado,
       sum(a.vl_recebido) vlr_recebido,
       a.dt_recebimento,
       sum(a.vl_glosa_inic) vlr_glosa_inicial,
       sum(a.vl_recurso_glosa) vlr_recurso_glosa,
       sum(a.vl_recebido_glosa) vlr_recebido_glosa,
       icr.tp_quitacao
from dbamv.vdic_hnb_visao_cliente_analit a 
inner join dbamv.reg_fat rf on rf.cd_reg_fat = a.cd_reg_fat 
inner join dbamv.nota_fiscal nf on nf.nr_id_nota_fiscal = a.nr_id_nota_fiscal
inner join dbamv.con_rec cr on cr.cd_nota_fiscal = nf.cd_nota_fiscal
inner  join dbamv.itcon_rec icr on icr.cd_con_rec = cr.cd_con_rec
where nf.tp_pessoa_rps <> 'F' 
AND NF.CD_MULTI_EMPRESA = 1
AND a.dt_emissao between '01/01/2016' and '31/12/2016'
--a.nr_id_nota_fiscal = 610020
group by nf.cd_nota_fiscal,
      a.nr_id_nota_fiscal,
       a.dt_vencimento,
       a.dt_emissao,
       rf.cd_convenio,
       a.cd_fornecedor,
       a.nm_fantasia,
--      icr.vl_duplicata,
--       icr.vl_soma_recebido,
       a.dt_recebimento,
       icr.tp_quitacao
       
       
       
UNION ALL     

select 'AMBEXTPS' TP_ATENDIMENTO,
       nf.cd_nota_fiscal,
       a.nr_id_nota_fiscal,
       a.dt_vencimento,
       a.dt_emissao,
       ra.cd_convenio,
       a.cd_fornecedor,
       a.nm_fantasia,
       sum(a.vl_faturado) vlr_faturado,
       sum(a.vl_recebido) vlr_recebido,
        a.dt_recebimento,
       sum(a.vl_glosa_inic) vlr_glosa_inicial,
       sum(a.vl_recurso_glosa) vlr_recurso_glosa,
       sum(a.vl_recebido_glosa) vlr_recebido_glosa,
       icr.tp_quitacao
from dbamv.vdic_hnb_visao_cliente_analit a 
inner join dbamv.reg_amb ra on ra.cd_reg_amb = a.cd_reg_amb 
inner join dbamv.nota_fiscal nf on nf.nr_id_nota_fiscal = a.nr_id_nota_fiscal
inner join dbamv.con_rec cr on cr.cd_nota_fiscal = nf.cd_nota_fiscal
inner  join dbamv.itcon_rec icr on icr.cd_con_rec = cr.cd_con_rec
where nf.tp_pessoa_rps <> 'F' 
AND NF.CD_MULTI_EMPRESA = 1
AND a.dt_emissao between  '01/01/2016' and '31/12/2016'
--a.nr_id_nota_fiscal = 610020
group by nf.cd_nota_fiscal,
      a.nr_id_nota_fiscal,
       a.dt_vencimento,
       a.dt_emissao,
       ra.cd_convenio,
       a.cd_fornecedor,
       a.nm_fantasia,
--       icr.vl_duplicata,
--       icr.vl_soma_recebido,
       a.dt_recebimento,
       icr.tp_quitacao
       
       
       
union all


select  'INTERNOS' TP_ATENDIMENTO,
        nf.cd_nota_fiscal,
        a.nr_id_nota_fiscal,
       a.dt_vencimento,
       a.dt_emissao,
       rf.cd_convenio,
       a.cd_fornecedor,
       a.nm_fantasia,
       ICR.VL_DUPLICATA,
       ICR.VL_SOMA_RECEBIDO,
       icr.dt_prevista_recebimento, 
       ICR.VL_GLOSA,
       ICR.VL_RECURSO,
       ICR.VL_RECURSO,
       icr.tp_quitacao
from dbamv.vdic_hnb_visao_cliente_analit a 
inner join dbamv.reg_fat rf on rf.cd_reg_fat= a.cd_reg_fat
inner join dbamv.nota_fiscal nf on nf.nr_id_nota_fiscal = a.nr_id_nota_fiscal
inner join dbamv.con_rec cr on cr.cd_nota_fiscal = nf.cd_nota_fiscal
inner  join dbamv.itcon_rec icr on icr.cd_con_rec = cr.cd_con_rec
where nf.tp_pessoa_rps = 'F' 
AND NF.CD_MULTI_EMPRESA = 1
and  a.dt_emissao between '01/01/2016' and '31/12/2016'
--a.nr_id_nota_fiscal = 610020
group by nf.cd_nota_fiscal,
      a.nr_id_nota_fiscal,
       a.dt_vencimento,
       a.dt_emissao,
       rf.cd_convenio,
       a.cd_fornecedor,
       a.nm_fantasia,
       a.nm_fantasia,
       ICR.VL_DUPLICATA,
       ICR.VL_SOMA_RECEBIDO,
       icr.dt_prevista_recebimento,
       ICR.VL_GLOSA,
       ICR.VL_RECURSO,
       ICR.VL_RECURSO,
       icr.tp_quitacao

       
union all
      


select  'AMBEXTPS' TP_ATENDIMENTO,
        nf.cd_nota_fiscal,
        a.nr_id_nota_fiscal,
       a.dt_vencimento,
       a.dt_emissao,
       ra.cd_convenio,
       a.cd_fornecedor,
       a.nm_fantasia,
       ICR.VL_DUPLICATA,
       ICR.VL_SOMA_RECEBIDO,
       icr.dt_prevista_recebimento,
       ICR.VL_GLOSA,
       ICR.VL_RECURSO,
       ICR.VL_RECURSO,
       icr.tp_quitacao
from dbamv.vdic_hnb_visao_cliente_analit a 
inner join dbamv.reg_amb ra on ra.cd_reg_amb= a.cd_reg_amb
inner join dbamv.nota_fiscal nf on nf.nr_id_nota_fiscal = a.nr_id_nota_fiscal
inner join dbamv.con_rec cr on cr.cd_nota_fiscal = nf.cd_nota_fiscal
inner  join dbamv.itcon_rec icr on icr.cd_con_rec = cr.cd_con_rec
where nf.tp_pessoa_rps = 'F' 
AND NF.CD_MULTI_EMPRESA = 1
and  a.dt_emissao between  '01/01/2016' and '31/12/2016'
--a.nr_id_nota_fiscal = 610020
group by nf.cd_nota_fiscal,
      a.nr_id_nota_fiscal,
       a.dt_vencimento,
       a.dt_emissao,
       ra.cd_convenio,
       a.cd_fornecedor,
       a.nm_fantasia,
       a.nm_fantasia,
       ICR.VL_DUPLICATA,
       ICR.VL_SOMA_RECEBIDO,
       icr.dt_prevista_recebimento,
       ICR.VL_GLOSA,
       ICR.VL_RECURSO,
       ICR.VL_RECURSO,
       icr.tp_quitacao

)group by cd_nota_fiscal,
       nr_id_nota_fiscal,
       dt_emissao,
       to_char(dt_emissao,'yyyy/mm'),
       dt_vencimento,
       cd_convenio,
       cd_fornecedor,
       nm_fantasia,
       dt_recebimento,
       tp_quitacao

 

/*
itcon_rec   tp_quitacao 
V previsto
C comprometido
P parcialmente quitado
Q quitado
L cancelado
R protestado
G quitado com glosa
*/
     

SELECT * FROM DBAMV.NOTA_FISCAL NF WHERE NF.CD_NOTA_FISCAL in (386200, 380000)

-------------------( LISTAGEM DO RAZAO )-------------------------------------------------------------------

--Somatorio dos lotes 

SELECT  CD_LOTE
        ,sum(VLR_CREDITO) VLR_CREDITO
        ,SUM(VLR_DEBITO) VLR_DEBITO
FROM (

---  Quebra por LOTES

SELECT l.cd_lote
       ,l.ds_lote
       ,l.dt_inicial_lcto
       ,l.dt_final_lcto
       ,l.vl_lote
       ,l.sn_importado

       ,LC.CD_LCTO_CONTABIL
       ,LC.DT_LCTO  
        
        ,NULL CD_REDUZIDO_CREDITO
        ,NULL CD_CONTABIL_CREDITO
        ,'' DS_CONTA_CREDITO
        ,NULL VLR_CREDITO
                
        ,LC.CD_REDUZIDO_DEBITO  
        ,PCD.CD_CONTABIL CD_CONTABIL_DEBITO
        ,pcd.ds_conta DS_CONTA_DEBITO
        ,LC.VL_LANCADO VLR_DEBITO

        ,LC.CD_HISTORICO_PADRAO 
        ,LC.DS_COMPLEMENTO  
        ,LC.CD_LCTO_MOVIMENTO 
        ,'D' TP_LCTO
        ,LC.VL_MOEDA_LANCADO  
        ,LC.CD_MOEDA  
        ,LC.CD_PROCESSO 
        ,LC.CD_ORIGEM 
        ,LC.CD_MULTI_EMPRESA  
        ,LC.DS_COMPLEMENTO_EXT  
        ,LC.CD_MULTI_EMPRESA_ORIGEM
        
        ,cp.CD_CON_PAG  
        ,cp.CD_FORNECEDOR 
        ,f.NM_FORNECEDOR  
        ,cp.NR_DOCUMENTO  
        ,cp.DT_EMISSAO  
        ,cp.TP_VENCIMENTO 
        ,cp.CD_TIP_DOC  
        ,cp.VL_BRUTO_CONTA  
        ,cp.DS_FORNECEDOR 
/*
        ,icp.DT_VENCIMENTO  
        ,icp.DT_QUITACAO  
        ,icp.TP_QUITACAO
*/

FROM DBAMV.LCTO_CONTABIL LC 
inner join dbamv.plano_contas pcd on pcd.cd_reduzido = lc.cd_reduzido_debito
inner join dbamv.lote l on l.cd_lote = lc.cd_lote

left outer join dbamv.con_pag cp on cp.cd_con_pag = lc.cd_origem and cp.ds_con_pag = lc.ds_complemento
left outer join dbamv.fornecedor f on f.cd_fornecedor = cp.cd_fornecedor

---left outer join dbamv.itcon_pag icp on icp.cd_con_pag = cp.cd_con_pag  --Apresentada diferente valores

WHERE LC.CD_REDUZIDO_DEBITO IS NOT NULL 
-- AND LC.CD_LOTE  = 86728  
--and lc.cd_lcto_movimento = 17011153 
--and lc.cd_lcto_movimento = 15004222
--and lc.cd_lcto_movimento in (20070166,20070724,20070725,20070726,20070727)
--and lc.cd_lcto_movimento in (14685012,15004221,15004222,15004223)
--and lc.cd_lcto_movimento in (16973936)
AND TO_CHAR(LC.DT_LCTO,'YYYY/MM') >= '2017/01' AND TO_CHAR(LC.DT_LCTO,'YYYY/MM') <= '2017/01'
 

UNION ALL

SELECT l.cd_lote
       ,l.ds_lote
       ,l.dt_inicial_lcto
       ,l.dt_final_lcto
       ,l.vl_lote
       ,l.sn_importado
       
       ,CD_LCTO_CONTABIL
        ,LC.DT_LCTO 

        ,LC.CD_REDUZIDO_CREDITO 
        ,pcc.Cd_Contabil CD_CONTABIL_CREDITO
        ,pcc.ds_conta DS_CONTA_CREDITO
        ,LC.VL_LANCADO  VLR_CREDITO
        
        ,NULL CD_REDUZIDO_DEBITO  
        ,NULL CD_CONTABIL_DEBITO
        ,'' DS_CONTA_DEBITO
        ,NULL VLR_DEBITO
        
        ,LC.CD_HISTORICO_PADRAO 
        ,LC.DS_COMPLEMENTO  
        ,LC.CD_LCTO_MOVIMENTO 
        ,'C' TP_LCTO
        ,LC.VL_MOEDA_LANCADO  
        ,LC.CD_MOEDA  
        ,LC.CD_PROCESSO 
        ,LC.CD_ORIGEM 
        ,LC.CD_MULTI_EMPRESA  
        ,LC.DS_COMPLEMENTO_EXT  
        ,LC.CD_MULTI_EMPRESA_ORIGEM
        
        ,cp.CD_CON_PAG  
        ,cp.CD_FORNECEDOR 
        ,f.NM_FORNECEDOR  
        ,cp.NR_DOCUMENTO  
        ,cp.DT_EMISSAO  
        ,cp.TP_VENCIMENTO 
        ,cp.CD_TIP_DOC  
        ,cp.VL_BRUTO_CONTA  
        ,cp.DS_FORNECEDOR 
/*
        ,icp.DT_VENCIMENTO  
        ,icp.DT_QUITACAO  
        ,icp.TP_QUITACAO
*/

FROM DBAMV.LCTO_CONTABIL LC 
inner join dbamv.plano_contas pcC on pcc.cd_reduzido = lc.cd_reduzido_credito 
inner join dbamv.lote l on l.cd_lote = lc.cd_lote

left outer join dbamv.con_pag cp on cp.cd_con_pag = lc.cd_origem and cp.ds_con_pag = lc.ds_complemento
---left outer join dbamv.itcon_pag icp on icp.cd_con_pag = cp.cd_con_pag
left outer join dbamv.fornecedor f on f.cd_fornecedor = cp.cd_fornecedor

WHERE LC.CD_REDUZIDO_CREDITO IS NOT NULL  
--AND LC.CD_LOTE  = 86728 --79880  
--and lc.cd_lcto_movimento = 17011153 
--and lc.cd_lcto_movimento = 15004222
--and lc.cd_lcto_movimento in ( 20070166,20070724,20070725,20070726,20070727)
--and lc.cd_lcto_movimento in (14685012,15004221,15004222,15004223)
AND TO_CHAR(LC.DT_LCTO,'YYYY/MM') >= '2017/01' AND TO_CHAR(LC.DT_LCTO,'YYYY/MM') <= '2017/01'

ORDER BY cd_lote,cd_lcto_movimento,cd_lcto_contabil
---ORDER BY CD_LCTO_MOVIMENTO
  
 ) 
 
 GROUP BY  CD_LOTE
      
select * from dbamv.lcto_contabil lc where lc.cd_lcto_movimento = 15004223
REF. A COMPRA/SERV. CONF. NF GALPAO 01/16 DO SERLE EMPREENDIMENTOS IMOBILIARIOS LTDA
ds_complemento
select * from dbamv.con_pag cp where cp.cd_con_pag = 383926
ds_con_pag
REF. A COMPRA/SERV. CONF. NF GALPAO 01/16 DO SERLE EMPREENDIMENTOS IMOBILIARIOS LTDA
 
 ------------------------------------------
 

select * from dbamv.lcto_contabil lc where lc.cd_lcto_movimento = 16973936
select * From dbamv.processo pro where pro.cd_processo = 15
select * From dbamv.processo pro where pro.cd_processo = 14

select * From dbamv.lcto_contabil_gerencial lcg where lcg.cd_lcto_movimento = 16973936
select * from dbamv.con_pag cp where cp.cd_con_pag = 385422

select rowid,proi.* from dbamv.proibicao proi where proi.cd_pro_fat in ('11010149','11010150') 
and proi.cd_convenio = 3
and proi.cd_con_pla = 0808


select * from dbamv.vdic_hnb_recibo_quitacao rq where rq.CD_CON_REC = 743651


select nf.nr_id_nota_fiscal,nf.nr_nota_fiscal_nfe,nf.cd_nota_fiscal,nf.cd_atendimento
 From dbamv.nota_fiscal nf where nf.nr_id_nota_fiscal in (
731455,
737211,
700838)

select * from dbamv.nota_fiscal nf where nf.nr_id_nota_fiscal = 700403

select mee.cd_multi_empresa,mee.ds_multi_empresa,mee.cd_imun
 From dbamv.multi_empresas mee where mee.cd_multi_empresa in (1,11,2,13)

-------------( TABELA GRUPO NOTAS FISCAIS ) ---------------

 SELECT count(*) FROM DBAMV.TMP_NOTAS_FISCAIS_GRUPO
-- drop table DBAMV.TMP_NOTAS_FISCAIS_GRUPO
-- SELECT * FROM DBAMV.TMP_NOTAS_FISCAIS_GRUPO TCR WHERE TCR.DT_EMISSAO BETWEEN '27/01/2015' AND '27/01/2015'
 

CREATE TABLE DBAMV.TMP_NOTAS_FISCAIS_GRUPO  
AS

SELECT NF.CD_NOTA_FISCAL,
       NF.NR_ID_NOTA_FISCAL RPS,
       TO_CHAR(NF.DT_EMISSAO,'YYYYMM') ANOMES,
       NF.DT_EMISSAO,
       NF.CD_ATENDIMENTO,
       NF.CD_REG_FAT,
       NF.CD_REG_AMB,
       NF.CD_CONVENIO,
       NF.CD_REMESSA,
       NF.NM_CLIENTE,
       NF.NR_CGC_CPF,
       NF.VL_TOTAL_NOTA,
       NF.CD_STATUS,
       NF.VL_ACRESCIMO_NOTA,
       NF.VL_DESCONTO_NOTA,
       NF.NR_NOTA_FISCAL_NFE,
       NF.HR_EMISSAO_NFE,
       NF.CD_VERIFICACAO_NFE,
       ICR.DT_PREVISTA_RECEBIMENTO,
       ICR.DT_VENCIMENTO,
       INF.CD_GRU_FAT,
       INF.VL_GRU_FAT

FROM DBAMV.NOTA_FISCAL NF
INNER JOIN DBAMV.ITNOTA_FISCAL INF ON INF.CD_NOTA_FISCAL = NF.CD_NOTA_FISCAL
LEFT OUTER JOIN DBAMV.CON_REC CR ON NF.CD_NOTA_FISCAL = CR.CD_NOTA_FISCAL
left outer JOIN DBAMV.ITCON_REC ICR ON ICR.CD_CON_REC = CR.CD_CON_REC 
WHERE --Cr.DT_EMISSAO BETWEEN '01/01/2013' AND '30/07/2015'
--and
 nf.cd_multi_empresa = 1
AND NF.CD_STATUS <> 'C'
     
-------- ( TABELA DE NOTAS FICAS POR GRUPO )--------
 SELECT count(*) FROM DBAMV.TMP_NOTAS_FISCAIS_GRUPO
-- drop table DBAMV.TMP_NOTAS_FISCAIS_GRUPO
-- SELECT * FROM DBAMV.TMP_NOTAS_FISCAIS_GRUPO TCR WHERE TCR.DT_EMISSAO BETWEEN '27/01/2015' AND '27/01/2015'
 

CREATE TABLE DBAMV.TMP_NOTAS_FISCAIS_GRUPO  
AS

SELECT NF.CD_NOTA_FISCAL,
       NF.NR_ID_NOTA_FISCAL RPS,
       TO_CHAR(NF.DT_EMISSAO,'YYYYMM') ANOMES,
       NF.DT_EMISSAO,
       NF.CD_ATENDIMENTO,
       NF.CD_REG_FAT,
       NF.CD_REG_AMB,
       NF.CD_CONVENIO,
       IFNF.CD_REMESSA,
       NF.NM_CLIENTE,
       NF.NR_CGC_CPF,
       NF.VL_TOTAL_NOTA,
       NF.CD_STATUS,
       NF.VL_ACRESCIMO_NOTA,
       NF.VL_DESCONTO_NOTA,
       NF.NR_NOTA_FISCAL_NFE,
       NF.HR_EMISSAO_NFE,
       NF.CD_VERIFICACAO_NFE,
       ICR.DT_PREVISTA_RECEBIMENTO,
       ICR.DT_VENCIMENTO,
       INF.CD_GRU_FAT,
       INF.VL_GRU_FAT

FROM DBAMV.NOTA_FISCAL NF
INNER JOIN DBAMV.ITNOTA_FISCAL INF ON INF.CD_NOTA_FISCAL = NF.CD_NOTA_FISCAL
INNER JOIN DBAMV.ITFAT_NOTA_FISCAL IFNF ON IFNF.CD_NOTA_FISCAL = NF.CD_NOTA_FISCAL
LEFT OUTER JOIN DBAMV.CON_REC CR ON NF.CD_NOTA_FISCAL = CR.CD_NOTA_FISCAL
left outer JOIN DBAMV.ITCON_REC ICR ON ICR.CD_CON_REC = CR.CD_CON_REC 
WHERE --Cr.DT_EMISSAO BETWEEN '01/01/2013' AND '30/07/2015'
--and
 nf.cd_multi_empresa = 1
AND NF.CD_STATUS <> 'C'


-------- ( TABELA DE NOTAS FICAS POR ITENS  )--------
 SELECT count(*) FROM DBAMV.TMP_NOTAS_FISCAIS_CONTA  -- ( 4.983.731 Registros)
-- drop table DBAMV.TMP_NOTAS_FISCAIS_ITENS
-- SELECT * FROM DBAMV.TMP_NOTAS_FISCAIS_CONTA TCR WHERE TCR.DT_EMISSAO BETWEEN '27/01/2015' AND '27/01/2015'
 

CREATE TABLE DBAMV.TMP_NOTAS_FISCAIS_CONTA  
AS

SELECT NF.CD_NOTA_FISCAL,
       NF.NR_ID_NOTA_FISCAL RPS,
       TO_CHAR(NF.DT_EMISSAO,'YYYYMM') ANOMES,
       NF.DT_EMISSAO,
       IFNF.CD_ATENDIMENTO,
       IFNF.CD_REG_FAT,
       IFNF.CD_REG_AMB,
       NF.CD_CONVENIO,
       NF.NM_CLIENTE,
       NF.NR_CGC_CPF,
       NF.VL_TOTAL_NOTA,
       NF.CD_STATUS,
       NF.VL_ACRESCIMO_NOTA,
       NF.VL_DESCONTO_NOTA,
       NF.NR_NOTA_FISCAL_NFE,
       NF.HR_EMISSAO_NFE,
       NF.CD_VERIFICACAO_NFE,
       ICR.DT_PREVISTA_RECEBIMENTO,
       ICR.DT_VENCIMENTO,
       GF.CD_GRU_FAT,
       SUM(IFNF.VL_ITFAT_NF) VLR_NF

FROM DBAMV.NOTA_FISCAL NF
INNER JOIN DBAMV.ITFAT_NOTA_FISCAL IFNF ON IFNF.CD_NOTA_FISCAL = NF.CD_NOTA_FISCAL
LEFT OUTER JOIN DBAMV.CON_REC CR ON NF.CD_NOTA_FISCAL = CR.CD_NOTA_FISCAL
INNER JOIN DBAMV.ITREG_FAT IRF ON IRF.CD_REG_FAT = IFNF.CD_REG_FAT AND IRF.CD_LANCAMENTO = IFNF.CD_LANCAMENTO_FAT
INNER JOIN DBAMV.GRU_FAT GF ON GF.CD_GRU_FAT = IRF.CD_GRU_FAT
left outer JOIN DBAMV.ITCON_REC ICR ON ICR.CD_CON_REC = CR.CD_CON_REC 
WHERE Cr.DT_EMISSAO BETWEEN '01/01/2011' AND '06/11/2015' and
 nf.cd_multi_empresa = 1
AND NF.CD_STATUS <> 'C'
--AND NF.CD_CONVENIO = 40 
--AND NF.NR_ID_NOTA_FISCAL = 568421

GROUP BY NF.CD_NOTA_FISCAL,
       NF.NR_ID_NOTA_FISCAL,
       TO_CHAR(NF.DT_EMISSAO,'YYYYMM'),
       NF.DT_EMISSAO,
       IFNF.CD_ATENDIMENTO,
       IFNF.CD_REG_FAT,
       IFNF.CD_REG_AMB,
       NF.CD_CONVENIO,
       NF.NM_CLIENTE,
       NF.NR_CGC_CPF,
       NF.VL_TOTAL_NOTA,
       NF.CD_STATUS,
       NF.VL_ACRESCIMO_NOTA,
       NF.VL_DESCONTO_NOTA,
       NF.NR_NOTA_FISCAL_NFE,
       NF.HR_EMISSAO_NFE,
       NF.CD_VERIFICACAO_NFE,
       ICR.DT_PREVISTA_RECEBIMENTO,
       ICR.DT_VENCIMENTO,
       GF.CD_GRU_FAT

UNION ALL


SELECT NF.CD_NOTA_FISCAL,
       NF.NR_ID_NOTA_FISCAL RPS,
       TO_CHAR(NF.DT_EMISSAO,'YYYYMM') ANOMES,
       NF.DT_EMISSAO,
       IFNF.CD_ATENDIMENTO,
       IFNF.CD_REG_FAT,
       IFNF.CD_REG_AMB,
       NF.CD_CONVENIO,
       NF.NM_CLIENTE,
       NF.NR_CGC_CPF,
       NF.VL_TOTAL_NOTA,
       NF.CD_STATUS,
       NF.VL_ACRESCIMO_NOTA,
       NF.VL_DESCONTO_NOTA,
       NF.NR_NOTA_FISCAL_NFE,
       NF.HR_EMISSAO_NFE,
       NF.CD_VERIFICACAO_NFE,
       ICR.DT_PREVISTA_RECEBIMENTO,
       ICR.DT_VENCIMENTO,
       GF.CD_GRU_FAT,
       SUM(IFNF.VL_ITFAT_NF) VLR_NF

FROM DBAMV.NOTA_FISCAL NF
INNER JOIN DBAMV.ITFAT_NOTA_FISCAL IFNF ON IFNF.CD_NOTA_FISCAL = NF.CD_NOTA_FISCAL
LEFT OUTER JOIN DBAMV.CON_REC CR ON NF.CD_NOTA_FISCAL = CR.CD_NOTA_FISCAL
INNER JOIN DBAMV.ITREG_AMB IRA ON IRA.CD_REG_AMB = IFNF.CD_REG_AMB AND IRA.CD_LANCAMENTO = IFNF.CD_LANCAMENTO_AMB 
INNER JOIN DBAMV.GRU_FAT GF ON GF.CD_GRU_FAT = IRA.CD_GRU_FAT
left outer JOIN DBAMV.ITCON_REC ICR ON ICR.CD_CON_REC = CR.CD_CON_REC 
WHERE Cr.DT_EMISSAO BETWEEN '01/01/2011' AND '06/11/2015' and
 nf.cd_multi_empresa = 1
AND NF.CD_STATUS <> 'C'
--AND NF.CD_CONVENIO = 40 
--AND NF.NR_ID_NOTA_FISCAL = 568421

GROUP BY NF.CD_NOTA_FISCAL,
       NF.NR_ID_NOTA_FISCAL,
       TO_CHAR(NF.DT_EMISSAO,'YYYYMM'),
       NF.DT_EMISSAO,
       IFNF.CD_ATENDIMENTO,
       IFNF.CD_REG_FAT,
       IFNF.CD_REG_AMB,
       NF.CD_CONVENIO,
       NF.NM_CLIENTE,
       NF.NR_CGC_CPF,
       NF.VL_TOTAL_NOTA,
       NF.CD_STATUS,
       NF.VL_ACRESCIMO_NOTA,
       NF.VL_DESCONTO_NOTA,
       NF.NR_NOTA_FISCAL_NFE,
       NF.HR_EMISSAO_NFE,
       NF.CD_VERIFICACAO_NFE,
       ICR.DT_PREVISTA_RECEBIMENTO,
       ICR.DT_VENCIMENTO,
       GF.CD_GRU_FAT


-----================== TABELA DE DOMINIO ======================--------------

---------------( TABELA PROD_FAT )------

SELECT pf.CD_PRO_FAT,
  pf.DS_PRO_FAT,
    pf.DS_UNIDADE,
      pf.TP_SEXO,
        pf.NR_AUXILIAR,
          pf.NR_INCIDENCIAS,
            pf.VL_FILME,
              pf.CD_GRU_PRO,
                pf.CD_POR_ANE,
                  pf.QTD_MAXIMA,
                    pf.SN_PACOTE,
                      pf.SN_ATIVO,
                        pf.SN_OPME,
                        gf.cd_gru_fat,
                        gf.ds_gru_fat,
                        gf.tp_gru_fat,
                        gp.cd_gru_pro,
                        gp.ds_gru_pro,
                        gp.tp_gru_pro

FROM DBAMV.PRO_FAT  pf
inner join dbamv.gru_pro gp on gp.cd_gru_pro = pf.cd_gru_pro  
inner join dbamv.gru_fat gf on gf.cd_gru_fat = gp.cd_gru_fat 
where ds_pro_fat NOT like 'XXX%' 
ORDER BY CD_PRO_FAT


---------------( TABELA CONVENIO  )------
SELECT CNV.CD_CONVENIO,
       CNV.NM_CONVENIO,
       CNV.TP_CONVENIO
FROM DBAMV.CONVENIO CNV 
order by cd_convenio


---------------( TABELA GRU_PRO  )------
SELECT GP.CD_GRU_PRO,
       GP.DS_GRU_PRO,
       GP.TP_GRU_PRO,
       GP.CD_GRU_FAT,
       GP.SN_PROCEDIMENTO_PRINCIPAL
FROM DBAMV.GRU_PRO GP 


---------------( TABELA GRU_FAT  )------
SELECT GF.CD_GRU_FAT,
       GF.DS_GRU_FAT,
       GF.TP_GRU_FAT,
       GF.SN_ATIVO
FROM DBAMV.GRU_FAT GF 



---------------( TABELA SETOR  )------
SELECT S.CD_SETOR,
       S.NM_SETOR,
       S.CD_CEN_CUS,
       S.SN_PODE_SOLICITAR_EXAMES,
       S.SN_ATIVO
FROM DBAMV.SETOR S  
order by s.cd_setor


-----------( TABELA ORIGEM )-------

SELECT CD_ORI_ATE,
       DS_ORI_ATE,
       TP_ORIGEM,
       CD_SETOR,
       SN_ATIVO,
       CD_MULTI_EMPRESA
 FROM DBAMV.ORI_ATE
 order by cd_ori_ate
 
 ---- ( TABELA ESPECIALIDADE _------
 
 SELECT  CD_ESPECIALID,
         DS_ESPECIALID,
          SN_ATIVO,
            CD_CBOS
            FROM DBAMV.ESPECIALID
order by cd_especialid

------ ( TABELA PRESTADORES )-----
SELECT 
       PRE.CD_PRESTADOR ,
       PRE.NM_PRESTADOR ,
       PRE.CD_CONSELHO,
       CO.DS_CONSELHO,
       CO.TP_CONSELHO,
       PRE.DS_CODIGO_CONSELHO,
       PRE.TP_CORPO_CLINICO,
       PRE.TP_VINCULO,
       PRE.SN_ANESTESISTA ,
       PRE.SN_AUXILIAR  ,
       PRE.SN_CIRURGIAO,  
       PRE.SN_OUTROS  ,
       PRE.CD_PRESTADOR_REPASSE 
     FROM DBAMV.PRESTADOR PRE
LEFT OUTER JOIN DBAMV.CONSELHO CO ON CO.CD_CONSELHO = PRE.CD_CONSELHO
order by pre.cd_prestador

------ ( TABELA TIPO ACOMODACAO )-----
   
SELECT 
       CD_TIP_ACOM, 
       DS_TIP_ACOM, 
       SN_ACOMOD_CONTA, 
       TP_ACOMODACAO
FROM DBAMV.TIP_ACOM

------- ( SETORES DE EXAMES )----------

SELECT  
        SE.CD_SET_EXA,  
        SE.NM_SET_EXA ,
        SE.TP_SETOR ,
        SE.CD_SETOR ,
        S.NM_SETOR  ,
        S.CD_MULTI_EMPRESA  ,
        ME.DS_MULTI_EMPRESA
--SELECT *
 FROM DBAMV.SET_EXA SE
INNER JOIN DBAMV.SETOR S ON S.CD_SETOR = SE.CD_SETOR
INNER JOIN DBAMV.MULTI_EMPRESAS ME ON ME.CD_MULTI_EMPRESA = S.CD_MULTI_EMPRESA
order by se.CD_SET_EXA

------- ( CONVENIO X PLANO - CON_PLA )----------

SELECT CPL.CD_CONVENIO,
       CPL.CD_CON_PLA,
       CPL.DS_CON_PLA
FROM DBAMV.CON_PLA CPL 
ORDER BY CPL.CD_CONVENIO,CPL.CD_CON_PLA


----- ( REGRA X ITREGRA )-------

--SELECT R.CD_REGRA,R.DS_REGRA,SN_PAGA_HORARIO_ESPECIAL,TP_ATEND_AMBULATORIAL,TP_ATEND_EXTERNO,TP_ATEND_INTERNACAO,TP_ATEND_URGEME,VL_PERC_CIR_MESMA_VIA,VL_PERC_CIR_VIA_DIFER,TP_ATEND_HOMECARE,DS_BASE_CALCULO
SELECT 
         R.CD_REGRA,R.DS_REGRA,
         IR.CD_TAB_FAT,TF.DS_TAB_FAT,TF.TP_TAB_FAT,IR.CD_GRU_PRO,GP.DS_GRU_PRO,GP.TP_GRU_PRO,IR.VL_PERCETUAL_PAGO
     
         
fROM DBAMV.REGRA R
INNER JOIN DBAMV.ITREGRA IR ON IR.CD_REGRA = R.CD_REGRA
INNER JOIN DBAMV.TAB_FAT TF ON TF.CD_TAB_FAT = IR.CD_TAB_FAT
INNER JOIN DBAMV.GRU_PRO GP ON GP.CD_GRU_PRO = IR.CD_GRU_PRO
--WHERE R.CD_REGRA = 91
ORDER BY R.CD_REGRA

 ------------------( CONVENIO X PLANO X REGRA )----------
 
 SELECT CD_CONVENIO,
        CD_CON_PLA,
        CD_MULTI_EMPRESA,
        SN_ATIVO,
        CD_REGRA,
        --CD_INDICE,
        SN_PERMITE_INTERNACAO,
        SN_PERMITE_URGENCIA,
        SN_PERMITE_AMBULATORIO,
        SN_PERMITE_EXTERNO
   FROM Dbamv.Empresa_Con_Pla
  WHERE CD_MULTI_EMPRESA = 1
  ORDER BY CD_CONVENIO,CD_CON_PLA
