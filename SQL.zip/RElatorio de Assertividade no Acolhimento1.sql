SELECT

 MESANO,
 ORIGEM,
 DOCUMENTO documento,
 '' RESPOSTA_SIM,
 '' PERCENTUAL_SIM,
 RESPOSTA_nao,
 CASE
   WHEN NVL(RESPOSTA_nao, 0) = 0 THEN
    0
   ELSE
    ROUND(NVL(RESPOSTA_nao, 0) * 100 / NVL(TOTAIS, 0), 2)
 END "PERCENTUAL_nao",
 TOTAIS TOTALANAMNESES
  FROM ((SELECT TO_CHAR(RD.DT_REGISTRO, 'MM/RRRR') MESANO,
                OA.DS_ORI_ATE ORIGEM,
                DOC.DS_DOCUMENTO DOCUMENTO,
                COUNT(*) RESPOSTA_nao,
                'NAO' DOCUMENTO_NOVO_PEP_II,
                (select COUNT(*)
                   from registro_documento RD1
                  inner join documento doc1
                     on rd1.cd_documento = doc1.cd_documento
                  INNER JOIN ATENDIME AT
                     ON AT.CD_ATENDIMENTO = RD1.CD_ATENDIMENTO
                  INNER JOIN ORI_ATE OA1
                     ON OA1.CD_ORI_ATE = AT.CD_ORI_ATE
                  WHERE AT.CD_MULTI_EMPRESA = 1
                    AND AT.CD_ATENDIMENTO_PAI IS NULL
                    AND RD1.CD_DOCUMENTO IN (194, 218, 222, 221, 210, 2)
                    AND TO_CHAR(RD1.DT_REGISTRO, 'MM/RRRR') = '{MESANO}'
                    AND OA1.CD_ORI_ATE IN ({ORIGEM_AUX}) ---- PA ADULTO
                    AND DOC1.DS_DOCUMENTO = DOC.DS_DOCUMENTO
                    AND OA1.DS_ORI_ATE = OA.DS_ORI_ATE
                  group by TO_CHAR(RD1.DT_REGISTRO, 'MM/RRRR'),
                           OA1.DS_ORI_ATE,
                           DOC1.DS_DOCUMENTO) TOTAIS
         
           from registro_documento RD
          inner join documento doc
             on rd.cd_documento = doc.cd_documento
          INNER JOIN ATENDIME AT
             ON AT.CD_ATENDIMENTO = RD.CD_ATENDIMENTO
          INNER JOIN REGISTRO_RESPOSTA RR
             ON RR.CD_REGISTRO_DOCUMENTO = RD.CD_REGISTRO_DOCUMENTO
            AND RR.CD_PERGUNTA_DOC IN (36122, 28083) -- ELIMINADA RESPOSTA 28082 = SIM
            AND RR.DS_RESPOSTA LIKE 'checked'
          INNER JOIN ORI_ATE OA
             ON OA.CD_ORI_ATE = AT.CD_ORI_ATE
          WHERE AT.CD_MULTI_EMPRESA = 1
            AND AT.CD_ATENDIMENTO_PAI IS NULL
            AND RD.CD_DOCUMENTO IN (194, 218, 222, 221, 210, 2)
            AND TO_CHAR(RD.DT_REGISTRO, 'MM/RRRR') = '{MESANO}'
            AND OA.CD_ORI_ATE IN ({ORIGEM_AUX})
          group by TO_CHAR(RD.DT_REGISTRO, 'MM/RRRR'),
                   OA.DS_ORI_ATE,
                   DOC.DS_DOCUMENTO)
       
        UNION ALL
       
        (SELECT TO_CHAR(PDC.DH_CRIACAO, 'MM/RRRR') MESANO,
                OA.DS_ORI_ATE ORIGEM,
                ED.DS_DOCUMENTO,
                COUNT(*) RESPOSTA_nao,
                'SIM' DOCUMENTO_NOVO_PEP_II,
                (select COUNT(*)
                   from pw_documento_clinico pdc1
                  inner join pw_editor_clinico pec1
                     on pec1.cd_documento_clinico = pdc1.cd_documento_clinico
                  inner join dbamv.editor_documento ED1
                     on PEC1.CD_DOCUMENTO = ED1.CD_DOCUMENTO
                  INNER JOIN ATENDIME AT
                     ON AT.CD_ATENDIMENTO = PDC1.CD_ATENDIMENTO --RD.CD_ATENDIMENTO
                  INNER JOIN ORI_ATE OA1
                     ON OA1.CD_ORI_ATE = AT.CD_ORI_ATE
                  WHERE AT.CD_MULTI_EMPRESA = 1
                    AND AT.CD_ATENDIMENTO_PAI IS NULL
                    AND PEC1.CD_DOCUMENTO IN (690, 696, 699, 700, 701, 702) --- SUBSTITUIR POR n�s documentos anamneses do PEP II
                       ----                                                           EQUIVALENTES A : (194,218,222,221,210,2)
                    AND TO_CHAR(PDC1.DH_CRIACAO, 'MM/RRRR') = '{MESANO}'
                    AND OA1.CD_ORI_ATE IN ({ORIGEM_AUX}) ---- PA ADULTO
                    AND ED1.DS_DOCUMENTO = ED.DS_DOCUMENTO
                    AND OA1.DS_ORI_ATE = OA.DS_ORI_ATE
                  group by TO_CHAR(PDC1.DH_CRIACAO, 'MM/RRRR'),
                           OA1.DS_ORI_ATE,
                           ED1.DS_DOCUMENTO) TOTAIS
           from pw_documento_clinico pdc
          inner join pw_editor_clinico pec
             on pec.cd_documento_clinico = pdc.cd_documento_clinico
          inner join EDITOR_REGISTRO_CAMPO ERC
             on pec.cd_editor_registro = erc.cd_registro
          INNER JOIN ATENDIME AT
             ON AT.CD_ATENDIMENTO = PDC.CD_ATENDIMENTO --RD.CD_ATENDIMENTO
          INNER JOIN ORI_ATE OA
             ON OA.CD_ORI_ATE = AT.CD_ORI_ATE
          inner join dbamv.editor_documento ED
             on PEC.CD_DOCUMENTO = ED.CD_DOCUMENTO
          inner join dbamv.Editor_Campo EC
             on EC.CD_CAMPO = ERC.CD_CAMPO
          WHERE AT.CD_MULTI_EMPRESA = 1
            AND AT.CD_ATENDIMENTO_PAI IS NULL
            AND PEC.CD_DOCUMENTO IN (690, 696, 699, 700, 701, 702) --- SUBSTITUIR POR n�s documentos anamneses do PEP II
               ----                                                   EQUIVALENTES A : (194,218,222,221,210,2)
            and EC.DS_IDENTIFICADOR IN
                ('CK_N_CONCORD_CLASS_INI_1',
                 'CK_INTENSAFE_NAO_1',
                 'CK_N_CONCORD_CLASS_INI_1',
                 'CK_N_CONCORD_CLASS_INI_1',
                 'CK_ITENSAFER_CONCORD_N_1',
                 'CK_N_CONCORD_CLASS_INI_1')
            AND to_char(erc.lo_valor) = 'true'
            AND TO_CHAR(PDC.DH_CRIACAO, 'MM/RRRR') = '{MESANO}'
            AND OA.CD_ORI_ATE IN ({ORIGEM_AUX}) -- (63)  PARA TESTES
          group by TO_CHAR(PDC.DH_CRIACAO, 'MM/RRRR'),
                   OA.DS_ORI_ATE,
                   ED.DS_DOCUMENTO))

 group by MESANO, ORIGEM, DOCUMENTO, RESPOSTA_nao, TOTAIS
 ORDER BY ORIGEM, DOCUMENTO
