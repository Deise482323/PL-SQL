SELECT SB1.CD_GRU_REP,
       SB1.DS_GRU_REP,
       SB1.cd_prestador,
       SB1.nm_prestador,
       SB1.Cd_Tip_Presta,
       SB1.TIPO_PRESTADOR,
       SB1.ds_repasse,
       SB1.cd_gru_pro,
       SB1.cd_pro_fat,
       SB1.ds_pro_fat,
       SB1.cd_remessa,
       SB1.conta,
       SB1.DS_ORI_ATE,
       SB1.CD_ATENDIMENTO,
       SB1.DT_ATENDIMENTO,
       SB1.nm_paciente,
       SB1.ds_ati_med,
       SB1.nm_convenio,
       TRUNC(SB1.dt_lancamento) DT_LANCAMENTO,
       SB1.qt_lancamento,
       SB1.VL_REPASSE,
       SB1.vl_perc_repasse,
       SB1.vl_base_repassado 
FROM (SELECT Nvl(cd_lancamento_fat, cd_lancamento_amb) CD_LANCAMENTO
          ,gru_rep.cd_prestador CD_GRU_REP
      ,gru_rep.nm_prestador DS_GRU_REP
      ,prestador.cd_prestador CD_PRESTADOR
      ,prestador.NM_PRESTADOR NM_PRESTADOR
      ,prestador.Cd_Tip_Presta
      ,(SELECT TP.NM_TIP_PRESTA FROM TIP_PRESTA TP WHERE TP.CD_TIP_PRESTA = PRESTADOR.CD_TIP_PRESTA) TIPO_PRESTADOR
      ,gru_rep.cd_prestador CD_PRESTADOR_REPASSE
      ,v.cd_repasse CD_REPASSE
      ,v.dt_repasse DT_REPASSE
      ,v.ds_repasse DS_REPASSE
      ,0 VL_TOTAL
      ,v.cd_pro_fat CD_PRO_FAT
      ,Nvl(Nvl(Nvl(Nvl(rp_c.ds_pro_fat, rp_sih.ds_procedimento), rp_sia.ds_procedimento),pro_fat.ds_pro_fat),procedimento_sus.ds_procedimento) DS_PRO_FAT
      ,Nvl(v.cd_reg_fat, v.cd_reg_amb) conta
      ,v.dt_competencia
      ,v.VL_REPASSE VL_REPASSE
      ,v.dt_lancamento DT_LANCAMENTO
      ,v.qt_lancamento QT_LANCAMENTO
      ,Nvl(rp_c.vl_total_conta, rp_sih.vl_total_conta) VL_TOTAL_CONTA
      ,Nvl(Nvl(rp_c.cd_remessa, rp_sih.cd_remessa),rp_sia.cd_fat_sia) CD_REMESSA
      ,convenio.nm_convenio NM_CONVENIO
      ,Nvl(paciente.nm_paciente,rp_sia.nm_paciente) NM_PACIENTE
      ,Nvl(Nvl(Nvl(rp_c.cd_gru_pro,rp_sih.cd_gru_pro),rp_sia.cd_gru_pro),gru_pro.cd_gru_pro) CD_GRU_PRO
      ,Nvl(Nvl(Nvl(rp_c.DS_GRU_PRO,rp_sih.DS_GRU_PRO),rp_sia.DS_GRU_PRO),gru_pro.ds_gru_pro) DS_GRU_PRO
      ,v.tipo_reg TIPO
      ,0 VL_FATURADO
      ,v.CD_CONVENIO CD_CONVENIO
      ,rp_sia.cd_reg_repasse_sia CD_REG_REPASSE_SIA
      ,atendime.cd_especialid CD_ESPECIALID
      ,rp_c.cd_tip_ate CD_TIP_ATE
      ,atendime.cd_ori_ate CD_ORI_ATE
      ,(SELECT OA.DS_ORI_ATE FROM ORI_ATE OA WHERE OA.CD_ORI_ATE = ATENDIME.CD_ORI_ATE) DS_ORI_ATE
      ,rp_sia.sn_medico SN_MEDICO
      ,rp_sia.vl_anestesista VL_ANESTESISTA
      ,rp_sia.vl_outros VL_OUTROS
      ,rp_sia.vl_auxiliar VL_AUXILIAR
      ,rp_sia.vl_geral VL_GERAL
      ,v.vl_base_repassado VL_BASE_REPASSADO
      ,atendime.tp_atendimento TP_ATENDIMENTO
      ,ati_med.ds_ati_med DS_ATI_MED
      ,rp_c.vl_filme VL_FILME
      ,v.cd_atendimento CD_ATENDIMENTO
      ,TO_DATE(TO_CHAR(ATENDIME.DT_ATENDIMENTO, 'DD-MM-YYYY') ||
               TO_CHAR(ATENDIME.HR_ATENDIMENTO, 'HH24:MI:SS'), 'DD-MM-YYYY HH24:MI:SS') DT_ATENDIMENTO
      ,v.vl_perc_repasse VL_PERC_REPASSE
      ,rp_c.qt_ch_unitario QT_CH
      ,Nvl(v.cd_reg_fat, v.cd_reg_amb) NUM_CONTA
      ,v.cd_atendimento NUM_ATEND
      ,Nvl(cd_lancamento_fat, cd_lancamento_amb) CD_LANCA
      ,v.cd_ati_med CD_ATI_MED
      ,rp_c.VL_RECEBIDO VL_RECEBIDO
     ,DECODE(substr(v.tipo_reg,1,3),'REC','G',
                                   'GLO','G',
                                   'MAN','RP',
           'CNV', rp_c.sn_horario_contratado,'N') SN_HORARIO_CONTRATADO
     ,repasse.TP_REPASSE TP_REPASSE
     ,Decode(lr.tp_remessa,'C','*','R','+','') E_CONCILIADO
  FROM dbamv.convenio,
       dbamv.prestador gru_rep,
       dbamv.prestador ,
       dbamv.repasse ,
       dbamv.paciente,
       dbamv.ati_med ,
       dbamv.atendime,
       dbamv.log_repasse lr,
       (SELECT 'CNV_AMB' tipo_reg,
       r.dt_competencia,
       r.dt_repasse,
       r.ds_repasse,
       itr.cd_repasse,
       itr.cd_prestador,
       itr.cd_prestador_repasse,
       itr.cd_reg_fat,
       itr.cd_lancamento_fat,
       itr.cd_reg_amb,
       itr.cd_lancamento_amb,
       itc.vl_base_repassado,
       itr.vl_repasse,
       itc.cd_atendimento,
       reg.cd_convenio,
       to_date(to_char(dt_lancamento, 'yyyymmdd') || ' ' ||
               to_char(hr_lancamento, 'hh24:mi:ss'),
               'yyyymmdd hh24:mi:ss') dt_lancamento,
       itc.cd_pro_fat,
       itc.qt_lancamento,
       itc.cd_ati_med,
       itr.cd_it_repasse,
       to_number(null) cd_it_repasse_sih,
       to_number(null) cd_it_repasse_sia,
       itr.vl_perc_repasse,
       to_number(null) cd_glosas,
       itc.cd_setor_produziu cd_setor
  FROM dbamv.repasse                r,
       dbamv.it_repasse             itr,
       dbamv.itreg_amb              itc,
       dbamv.reg_amb                reg,
       dbamv.multi_empresas_repasse mer
 WHERE r.cd_repasse = itr.cd_repasse
   AND itr.cd_reg_amb = itc.cd_reg_amb
   AND itr.cd_lancamento_amb = itc.cd_lancamento
   AND reg.cd_reg_amb = itc.cd_reg_amb
   AND TO_CHAR(r.dt_competencia, 'MM/RRRR') = '09/2023'
   --AND (itr.cd_prestador = '{vPRESTADOR}' OR '{vPRESTADOR}' IS NULL OR '{vPRESTADOR}' = 0)
   AND (itr.cd_prestador_repasse = 1734)
   AND r.tp_repasse = 'C'
   AND itr.cd_reg_fat is null
   AND mer.cd_multi_empresa_rep = 1 /*dbamv.pkg_mv2000.le_empresa*/
   AND reg.cd_multi_empresa = mer.cd_multi_empresa_fat
UNION ALL
SELECT 'CNV_INT' tipo,
       r.dt_competencia,
       r.dt_repasse,
       r.ds_repasse,
       itr.cd_repasse,
       itr.cd_prestador,
       itr.cd_prestador_repasse,
       itr.cd_reg_fat,
       itr.cd_lancamento_fat,
       itr.cd_reg_amb,
       itr.cd_lancamento_amb,
       itc.vl_base_repassado,
       itr.vl_repasse,
       reg.cd_atendimento,
       reg.cd_convenio,
       to_date(to_char(dt_lancamento, 'yyyymmdd') || ' ' ||
               to_char(hr_lancamento, 'hh24:mi:ss'),
               'yyyymmdd hh24:mi:ss'),
       itc.cd_pro_fat,
       itc.qt_lancamento,
       itc.cd_ati_med,
       itr.cd_it_repasse,
       to_number(null),
       to_number(null),
       itr.vl_perc_repasse,
       to_number(null),
       itc.cd_setor_produziu
  FROM dbamv.repasse                r,
       dbamv.it_repasse             itr,
       dbamv.itreg_fat              itc,
       dbamv.reg_fat                reg,
       dbamv.multi_empresas_repasse mer
 WHERE r.cd_repasse = itr.cd_repasse
   AND itr.cd_reg_fat = itc.cd_reg_fat
   AND itr.cd_lancamento_fat = itc.cd_lancamento
   AND reg.cd_reg_fat = itc.cd_reg_fat
   AND TO_CHAR(r.dt_competencia, 'MM/RRRR') = '09/2023'
   --AND (itr.cd_prestador = '{vPRESTADOR}' OR '{vPRESTADOR}' IS NULL OR '{vPRESTADOR}' = 0)
   AND (itr.cd_prestador_repasse = 1734)
   AND r.tp_repasse = 'C'
   AND itr.cd_reg_amb is null
   AND mer.cd_multi_empresa_rep = 1 /*dbamv.pkg_mv2000.le_empresa*/
   AND reg.cd_multi_empresa = mer.cd_multi_empresa_fat
   and not exists (select 'X'
          from dbamv.itlan_med
         where cd_reg_fat = itc.cd_reg_fat
           and cd_lancamento = itc.cd_lancamento)
UNION ALL
SELECT 'CNV_EQP' tipo,
       r.dt_competencia,
       r.dt_repasse,
       r.ds_repasse,
       itr.cd_repasse,
       itr.cd_prestador,
       itr.cd_prestador_repasse,
       itr.cd_reg_fat,
       itr.cd_lancamento_fat,
       itr.cd_reg_amb,
       itr.cd_lancamento_amb,
       itl.vl_base_repassado,
       itr.vl_repasse,
       reg.cd_atendimento,
       reg.cd_convenio,
       to_date(to_char(dt_lancamento, 'yyyymmdd') || ' ' ||
               to_char(hr_lancamento, 'hh24:mi:ss'),
               'yyyymmdd hh24:mi:ss'),
       itc.cd_pro_fat,
       itc.qt_lancamento,
       itl.cd_ati_med,
       itr.cd_it_repasse,
       to_number(null),
       to_number(null),
       itr.vl_perc_repasse,
       to_number(null),
       itc.cd_setor_produziu
  FROM dbamv.repasse                r,
       dbamv.it_repasse             itr,
       dbamv.itreg_fat              itc,
       dbamv.itlan_med              itl,
       dbamv.reg_fat                reg,
       dbamv.multi_empresas_repasse mer
 WHERE r.cd_repasse = itr.cd_repasse
   AND itr.cd_reg_fat = itc.cd_reg_fat
   AND itr.cd_lancamento_fat = itc.cd_lancamento
   AND itc.cd_reg_fat = itl.cd_reg_fat
   AND itc.cd_lancamento = itl.cd_lancamento
   AND itr.cd_ati_med = itl.cd_ati_med
   AND reg.cd_reg_fat = itc.cd_reg_fat
   AND itr.cd_reg_amb is null
   AND TO_CHAR(r.dt_competencia, 'MM/RRRR') = '09/2023'
   --AND (itr.cd_prestador = '{vPRESTADOR}' OR '{vPRESTADOR}' IS NULL OR '{vPRESTADOR}' = 0)
   AND (itr.cd_prestador_repasse = 1734)
   AND r.tp_repasse = 'C'
   AND mer.cd_multi_empresa_rep = 1 /*dbamv.pkg_mv2000.le_empresa*/
   AND reg.cd_multi_empresa = mer.cd_multi_empresa_fat
UNION ALL
SELECT 'SUS_AMB' tipo,
       r.dt_competencia,
       r.dt_repasse,
       r.ds_repasse,
       itr.cd_repasse,
       itr.cd_prestador,
       itr.cd_prestador_repasse,
       TO_NUMBER(null),
       TO_NUMBER(null),
       eve.cd_eventos,
       TO_NUMBER(null),
       eve.vl_base_repassado,
       itr.vl_repasse,
       eve.cd_atendimento,
       eve.cd_convenio,
       eve.dt_eve_siasus,
       eve.cd_procedimento,
       eve.qt_lancada,
       TO_CHAR(null),
       to_number(null),
       to_number(null),
       itr.cd_it_repasse_sia,
       itr.vl_perc_repasse,
       to_number(null),
       eve.cd_setor_produziu
  FROM dbamv.repasse                r,
       dbamv.it_repasse_sia         itr,
       dbamv.eve_siasus             eve,
       dbamv.multi_empresas_repasse mer
 WHERE r.cd_repasse = itr.cd_repasse
   AND itr.cd_eventos = eve.cd_eventos
   AND TO_CHAR(r.dt_competencia, 'MM/RRRR') = '09/2023'
   --AND (itr.cd_prestador = '{vPRESTADOR}' OR '{vPRESTADOR}' IS NULL OR '{vPRESTADOR}' = 0)
   AND (itr.cd_prestador_repasse = 1734)
   AND r.tp_repasse = 'A'
   AND mer.cd_multi_empresa_rep = 1 /*dbamv.pkg_mv2000.le_empresa*/
   AND eve.cd_multi_empresa = mer.cd_multi_empresa_fat
UNION ALL
SELECT 'SUS_INT' tipo,
       r.dt_competencia,
       r.dt_repasse,
       r.ds_repasse,
       itr.cd_repasse,
       itr.cd_prestador,
       itr.cd_prestador_repasse,
       itr.cd_reg_fat,
       itr.cd_lancamento,
       TO_NUMBER(null),
       TO_NUMBER(null),
       itc.vl_base_repassado,
       itr.vl_repasse,
       reg.cd_atendimento,
       reg.cd_convenio,
       to_date(to_char(dt_lancamento, 'yyyymmdd') || ' ' ||
               to_char(hr_lancamento, 'hh24:mi:ss'),
               'yyyymmdd hh24:mi:ss'),
       itc.cd_procedimento,
       itc.qt_lancamento,
       itc.cd_ati_med,
       to_number(null),
       itr.cd_it_repasse_sih,
       to_number(null),
       itr.vl_perc_repasse,
       to_number(null),
       itc.cd_setor_produziu
  FROM dbamv.repasse                r,
       dbamv.it_repasse_sih         itr,
       dbamv.itreg_fat              itc,
       dbamv.reg_fat                reg,
       dbamv.multi_empresas_repasse mer
 WHERE r.cd_repasse = itr.cd_repasse
   AND itr.cd_reg_fat = itc.cd_reg_fat
   AND itr.cd_lancamento = itc.cd_lancamento
   AND reg.cd_reg_fat = itc.cd_reg_fat
   AND TO_CHAR(r.dt_competencia, 'MM/RRRR') = '09/2023'
   --AND (itr.cd_prestador = '{vPRESTADOR}' OR '{vPRESTADOR}' IS NULL OR '{vPRESTADOR}' = 0)
   AND (itr.cd_prestador_repasse = 1734)
   AND r.tp_repasse = 'I'
   AND mer.cd_multi_empresa_rep = 1 /*dbamv.pkg_mv2000.le_empresa*/
   AND reg.cd_multi_empresa = mer.cd_multi_empresa_fat
   AND not exists (select cd_reg_fat, cd_lancamento
          from dbamv.itlan_med
         where cd_reg_fat = itc.cd_reg_fat
           and cd_lancamento = itc.cd_lancamento)
UNION ALL
SELECT 'SUS_EQP' tipo,
       r.dt_competencia,
       r.dt_repasse,
       r.ds_repasse,
       itr.cd_repasse,
       itr.cd_prestador,
       itr.cd_prestador_repasse,
       itr.cd_reg_fat,
       itr.cd_lancamento,
       TO_NUMBER(null),
       TO_NUMBER(null),
       itl.vl_base_repassado,
       itr.vl_repasse,
       reg.cd_atendimento,
       reg.cd_convenio,
       to_date(to_char(dt_lancamento, 'yyyymmdd') || ' ' ||
               to_char(hr_lancamento, 'hh24:mi:ss'),
               'yyyymmdd hh24:mi:ss'),
       itc.cd_procedimento,
       itc.qt_lancamento,
       itl.cd_ati_med,
       to_number(null),
       itr.cd_it_repasse_sih,
       to_number(null),
       itr.vl_perc_repasse,
       to_number(null),
       itc.cd_setor_produziu
  FROM dbamv.repasse                r,
       dbamv.it_repasse_sih         itr,
       dbamv.itreg_fat              itc,
       dbamv.itlan_med              itl,
       dbamv.reg_fat                reg,
       dbamv.multi_empresas_repasse mer
 WHERE r.cd_repasse = itr.cd_repasse
   AND itr.cd_reg_fat = itc.cd_reg_fat
   AND itr.cd_lancamento = itc.cd_lancamento
   AND itc.cd_reg_fat = itl.cd_reg_fat
   AND itc.cd_lancamento = itl.cd_lancamento
   AND itr.cd_ati_med = itl.cd_ati_med
   AND reg.cd_reg_fat = itc.cd_reg_fat
   AND TO_CHAR(r.dt_competencia, 'MM/RRRR') = '09/2023'
   --AND (itr.cd_prestador = '{vPRESTADOR}' OR '{vPRESTADOR}' IS NULL OR '{vPRESTADOR}' = 0)
   AND (itr.cd_prestador_repasse = 1734)
   AND r.tp_repasse = 'I'
   AND mer.cd_multi_empresa_rep = 1 /*dbamv.pkg_mv2000.le_empresa*/
   AND reg.cd_multi_empresa = mer.cd_multi_empresa_fat
UNION ALL
SELECT 'GLO_INT' tipo,
       r.dt_competencia,
       r.dt_repasse,
       r.ds_repasse,
       itr.cd_repasse,
       itr.cd_prestador,
       itr.cd_prestador_repasse,
       g.cd_reg_fat,
       g.cd_lancamento_fat,
       g.cd_reg_amb,
       g.cd_lancamento_amb,
       g.vl_glosa * (-1),
       itr.vl_glosa * (-1),
       reg.cd_atendimento,
       reg.cd_convenio,
       to_date(to_char(dt_lancamento, 'yyyymmdd') || ' ' ||
               to_char(hr_lancamento, 'hh24:mi:ss'),
               'yyyymmdd hh24:mi:ss'),
       itc.cd_pro_fat,
       itc.qt_lancamento,
       itc.cd_ati_med,
       itr.cd_it_repasse,
       to_number(null),
       to_number(null),
       itr.vl_perc_repasse,
       g.cd_glosas,
       itc.cd_setor_produziu
  FROM dbamv.repasse                r,
       dbamv.it_repasse             itr,
       dbamv.itreg_fat              itc,
       dbamv.glosas                 g,
       dbamv.reg_fat                reg,
       dbamv.multi_empresas_repasse mer
 WHERE r.cd_repasse = itr.cd_repasse
   AND g.cd_glosas = itr.cd_glosas
   AND g.cd_reg_fat = itc.cd_reg_fat
   AND g.cd_lancamento_fat = itc.cd_lancamento
   AND reg.cd_reg_fat = itc.cd_reg_fat
   AND g.cd_reg_amb IS NULL
   AND TO_CHAR(r.dt_competencia, 'MM/RRRR') = '09/2023'
   --AND (itr.cd_prestador = '{vPRESTADOR}' OR '{vPRESTADOR}' IS NULL OR '{vPRESTADOR}' = 0)
   AND (itr.cd_prestador_repasse = 1734)
   AND r.tp_repasse = 'G'
   AND mer.cd_multi_empresa_rep = 1 /*dbamv.pkg_mv2000.le_empresa*/
   AND reg.cd_multi_empresa = mer.cd_multi_empresa_fat
   and not exists (select 'X'
          from dbamv.itlan_med
         where cd_reg_fat = itc.cd_reg_fat
           and cd_lancamento = itc.cd_lancamento)
UNION ALL
/*inicio em manutencao*/
SELECT 'GLO_INT' tipo,
       r.dt_competencia,
       r.dt_repasse,
       r.ds_repasse,
       itr.cd_repasse,
       itr.cd_prestador,
       itr.cd_prestador_repasse,
       g.cd_reg_fat,
       g.cd_lancamento_fat,
       g.cd_reg_amb,
       g.cd_lancamento_amb,
       g.vl_glosa * (-1),
       itr.vl_glosa * (-1),
       reg.cd_atendimento,
       reg.cd_convenio,
       to_date(to_char(dt_lancamento, 'yyyymmdd') || ' ' ||
               to_char(hr_lancamento, 'hh24:mi:ss'),
               'yyyymmdd hh24:mi:ss'),
       itc.cd_pro_fat,
       itc.qt_lancamento,
       itl.cd_ati_med,
       itr.cd_it_repasse,
       to_number(null),
       to_number(null),
       itr.vl_perc_repasse,
       g.cd_glosas,
       itc.cd_setor_produziu
  FROM dbamv.repasse                r,
       dbamv.it_repasse             itr,
       dbamv.itreg_fat              itc,
       dbamv.itlan_med              itl,
       dbamv.glosas                 g,
       dbamv.reg_fat                reg,
       dbamv.multi_empresas_repasse mer
 WHERE r.cd_repasse = itr.cd_repasse
   AND g.cd_glosas = itr.cd_glosas
   AND g.cd_reg_fat = itc.cd_reg_fat
   AND g.cd_lancamento_fat = itc.cd_lancamento
   AND reg.cd_reg_fat = itc.cd_reg_fat
   AND itc.cd_reg_fat = itl.cd_reg_fat
   AND itc.cd_lancamento = itl.cd_lancamento
   AND g.cd_ati_med = itl.cd_ati_med(+)
   AND g.cd_reg_amb IS NULL
   AND TO_CHAR(r.dt_competencia, 'MM/RRRR') = '09/2023'
   --AND (itr.cd_prestador = '{vPRESTADOR}' OR '{vPRESTADOR}' IS NULL OR '{vPRESTADOR}' = 0)
   AND (itr.cd_prestador_repasse = 1734)
   AND r.tp_repasse = 'G'
   AND mer.cd_multi_empresa_rep = 1 /*dbamv.pkg_mv2000.le_empresa*/
   AND reg.cd_multi_empresa = mer.cd_multi_empresa_fat
UNION ALL
/*fim*/
SELECT 'GLO_AMB' tipo,
       r.dt_competencia,
       r.dt_repasse,
       r.ds_repasse,
       itr.cd_repasse,
       itr.cd_prestador,
       itr.cd_prestador_repasse,
       g.cd_reg_fat,
       g.cd_lancamento_fat,
       g.cd_reg_amb,
       g.cd_lancamento_amb,
       g.vl_glosa * (-1),
       itr.vl_glosa * (-1),
       itc.cd_atendimento,
       reg.cd_convenio,
       to_date(to_char(dt_lancamento, 'yyyymmdd') || ' ' ||
               to_char(hr_lancamento, 'hh24:mi:ss'),
               'yyyymmdd hh24:mi:ss'),
       itc.cd_pro_fat,
       itc.qt_lancamento,
       itc.cd_ati_med,
       itr.cd_it_repasse,
       to_number(null),
       to_number(null),
       itr.vl_perc_repasse,
       g.cd_glosas,
       itc.cd_setor_produziu
  FROM dbamv.repasse                r,
       dbamv.it_repasse             itr,
       dbamv.itreg_amb              itc,
       dbamv.glosas                 g,
       dbamv.reg_amb                reg,
       dbamv.multi_empresas_repasse mer
 WHERE r.cd_repasse = itr.cd_repasse
   AND g.cd_glosas = itr.cd_glosas
   AND g.cd_reg_amb = itc.cd_reg_amb
   AND g.cd_lancamento_amb = itc.cd_lancamento
   AND reg.cd_reg_amb = itc.cd_reg_amb
   AND g.cd_reg_fat IS NULL
   AND TO_CHAR(r.dt_competencia, 'MM/RRRR') = '09/2023'
   --AND (itr.cd_prestador = '{vPRESTADOR}' OR '{vPRESTADOR}' IS NULL OR '{vPRESTADOR}' = 0)
   AND (itr.cd_prestador_repasse = 1734)
   AND r.tp_repasse = 'G'
   AND mer.cd_multi_empresa_rep = 1 /*dbamv.pkg_mv2000.le_empresa*/
   AND reg.cd_multi_empresa = mer.cd_multi_empresa_fat
UNION ALL
SELECT 'REC_INT' tipo,
       r.dt_competencia,
       r.dt_repasse,
       r.ds_repasse,
       itr.cd_repasse,
       itr.cd_prestador,
       itr.cd_prestador_repasse,
       g.cd_reg_fat,
       g.cd_lancamento_fat,
       g.cd_reg_amb,
       g.cd_lancamento_amb,
       g.vl_recebido,
       itr.vl_repasse,
       reg.cd_atendimento,
       reg.cd_convenio,
       to_date(to_char(dt_lancamento, 'yyyymmdd') || ' ' ||
               to_char(hr_lancamento, 'hh24:mi:ss'),
               'yyyymmdd hh24:mi:ss'),
       itc.cd_pro_fat,
       itc.qt_lancamento,
       itc.cd_ati_med,
       itr.cd_it_repasse,
       to_number(null),
       to_number(null),
       itr.vl_perc_repasse,
       g.cd_glosas,
       itc.cd_setor_produziu
  FROM dbamv.repasse                r,
       dbamv.it_repasse             itr,
       dbamv.itreg_fat              itc,
       dbamv.glosas                 g,
       dbamv.reg_fat                reg,
       dbamv.multi_empresas_repasse mer
 WHERE r.cd_repasse = itr.cd_repasse
   AND g.cd_glosas = itr.cd_glosas
   AND g.cd_reg_fat = itc.cd_reg_fat
   AND g.cd_lancamento_fat = itc.cd_lancamento
   AND reg.cd_reg_fat = itc.cd_reg_fat
   AND g.cd_reg_amb IS NULL
   AND TO_CHAR(r.dt_competencia, 'MM/RRRR') = '09/2023'
   --AND (itr.cd_prestador = '{vPRESTADOR}' OR '{vPRESTADOR}' IS NULL OR '{vPRESTADOR}' = 0)
   AND (itr.cd_prestador_repasse = 1734)
   AND r.tp_repasse = 'R'
   AND mer.cd_multi_empresa_rep = 1 /*dbamv.pkg_mv2000.le_empresa*/
   AND reg.cd_multi_empresa = mer.cd_multi_empresa_fat
UNION ALL
SELECT 'REC_AMB' tipo,
       r.dt_competencia,
       r.dt_repasse,
       r.ds_repasse,
       itr.cd_repasse,
       itr.cd_prestador,
       itr.cd_prestador_repasse,
       g.cd_reg_fat,
       g.cd_lancamento_fat,
       g.cd_reg_amb,
       g.cd_lancamento_amb,
       g.vl_recebido,
       itr.vl_repasse,
       itc.cd_atendimento,
       reg.cd_convenio,
       to_date(to_char(dt_lancamento, 'yyyymmdd') || ' ' ||
               to_char(hr_lancamento, 'hh24:mi:ss'),
               'yyyymmdd hh24:mi:ss'),
       itc.cd_pro_fat,
       itc.qt_lancamento,
       itc.cd_ati_med,
       itr.cd_it_repasse,
       to_number(null),
       to_number(null),
       itr.vl_perc_repasse,
       g.cd_glosas,
       itc.cd_setor_produziu
  FROM dbamv.repasse                r,
       dbamv.it_repasse             itr,
       dbamv.itreg_amb              itc,
       dbamv.glosas                 g,
       dbamv.reg_amb                reg,
       dbamv.multi_empresas_repasse mer
 WHERE r.cd_repasse = itr.cd_repasse
   AND g.cd_glosas = itr.cd_glosas
   AND g.cd_reg_amb = itc.cd_reg_amb
   AND g.cd_lancamento_amb = itc.cd_lancamento
   AND reg.cd_reg_amb = itc.cd_reg_amb
   AND g.cd_reg_fat IS NULL
   AND TO_CHAR(r.dt_competencia, 'MM/RRRR') = '09/2023'
   --AND (itr.cd_prestador = '{vPRESTADOR}' OR '{vPRESTADOR}' IS NULL OR '{vPRESTADOR}' = 0)
   AND (itr.cd_prestador_repasse = 1734)
   AND r.tp_repasse = 'R'
   AND mer.cd_multi_empresa_rep = 1 /*dbamv.pkg_mv2000.le_empresa*/
   AND reg.cd_multi_empresa = mer.cd_multi_empresa_fat
UNION ALL
SELECT 'MANUAL' tipo,
       r.dt_competencia,
       r.dt_repasse,
       r.ds_repasse,
       itr.cd_repasse,
       itr.cd_prestador,
       itr.cd_prestador_repasse,
       TO_NUMBER(null),
       TO_NUMBER(null),
       TO_NUMBER(null),
       TO_NUMBER(null),
       itr.vl_faturado,
       (Nvl(itr.vl_repasse, 0) - Nvl(itr.vl_desconto, 0)) vl_repasse,
       TO_NUMBER(null),
       TO_NUMBER(null),
       r.dt_repasse,
       TO_CHAR(null),
       TO_NUMBER(null),
       TO_CHAR(null),
       to_number(null),
       to_number(null),
       to_number(null),
       to_number(null),
       to_number(null),
       itr.cd_setor
  FROM dbamv.repasse                r,
       dbamv.repasse_prestador      itr,
       dbamv.multi_empresas_repasse mer
 WHERE r.cd_repasse = itr.cd_repasse
   AND TO_CHAR(r.dt_competencia, 'MM/RRRR') = '09/2023'
   --AND (itr.cd_prestador = '{vPRESTADOR}' OR '{vPRESTADOR}' IS NULL OR '{vPRESTADOR}' = 0)
   AND (itr.cd_prestador_repasse = 1734)
   AND r.tp_repasse in ('M', 'E', 'N', 'F', 'P', 'U', 'S', 'L')
   AND mer.cd_multi_empresa_rep = 1 /*dbamv.pkg_mv2000.le_empresa*/
   AND r.cd_multi_empresa = mer.cd_multi_empresa_fat) v,
       (SELECT *
          FROM dbamv.repasse_consolidado
         WHERE cd_it_repasse IS NOT NULL) rp_c,
       (SELECT *
          FROM dbamv.repasse_consolidado
         WHERE cd_it_repasse_sih IS NOT NULL) rp_sih,
       (SELECT *
          FROM dbamv.repasse_consolidado
         WHERE cd_it_repasse_sia IS NOT NULL) rp_sia,
       dbamv.pro_fat,
       dbamv.procedimento_sus,
       DBAMV.gru_pro
 WHERE v.cd_convenio = convenio.cd_convenio(+)
   AND v.cd_prestador_repasse = gru_rep.cd_prestador
   AND v.cd_prestador = prestador.cd_prestador
   AND v.cd_repasse = repasse.cd_repasse
   AND v.cd_atendimento = atendime.cd_atendimento(+)
   AND atendime.cd_paciente = paciente.cd_paciente(+)
   AND v.cd_ati_med = ati_med.cd_ati_med(+)
   AND rp_c.cd_it_repasse(+) = v.cd_it_repasse
   AND rp_sih.cd_it_repasse_sih(+) = v.cd_it_repasse_sih
   AND rp_sia.cd_it_repasse_sia(+) = v.cd_it_repasse_sia
   AND v.cd_pro_fat = pro_fat.cd_pro_fat(+)
   AND Nvl(pro_fat.cd_gru_pro, procedimento_sus.cd_grupo_procedimento) = gru_pro.cd_gru_pro (+)
   AND v.cd_pro_fat = procedimento_sus.cd_procedimento(+)
   AND repasse.cd_repasse = lr.cd_repasse) SB1
   --and (repasse.Tp_Repasse = '{vTPREPASSE}' OR '{vTPREPASSE}' = 'TD' OR LTRIM('{vTPREPASSE}') IS NULL)
   --and (convenio.cd_convenio = '{vCONVENIO}' OR LTRIM('{vCONVENIO}') IS NULL)
   --and (atendime.cd_ori_ate = '{vORIATE}' OR LTRIM('{vORIATE}') IS NULL OR '{vORIATE}' = '0')) SB1
   
--  order by SB1.DS_GRU_REP,SB1.nm_prestador, SB1.cd_gru_pro, SB1.cd_pro_fat, SB1.nm_paciente
