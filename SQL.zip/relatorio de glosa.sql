-- QUERY COMPLETA AJUSTADA COM FORMATA��O E PADRONIZA��O

SELECT *
  FROM (
    -- BLOCO 1 - FATURAMENTO HOSPITALAR
    SELECT DISTINCT
           prestador.cd_prestador_repasse         AS cd_gru_rep,
           (SELECT nm_prestador
              FROM dbamv.prestador p
             WHERE p.cd_prestador = prestador.cd_prestador_repasse) AS ds_gru_rep,
           prestador.cd_prestador,
           prestador.nm_prestador,
           repasse.dt_repasse,
           repasse.ds_repasse,
           pro_fat.cd_pro_fat,
           pro_fat.ds_pro_fat,
           reg_fat.cd_reg_fat                    AS conta,
           (it_repasse.vl_glosa * -1)            AS l_repasse,
           itreg_fat.dt_lancamento,
           glosas.qt_glosa                       AS qt_lancamento,
           (glosas.vl_glosa * -1)                AS vl_total_conta,
           convenio.nm_convenio,
           paciente.nm_paciente,
           gru_pro.cd_gru_pro,
           gru_pro.ds_gru_pro,
           ati_med.ds_ati_med,
           atendime.cd_atendimento,
           it_repasse.vl_perc_repasse,
           repasse.dt_competencia,
           'G'                                   AS sn_horario_contratado,
           motivo_glosa.ds_motivo_glosa
      FROM dbamv.repasse
     JOIN dbamv.it_repasse     ON it_repasse.cd_repasse = repasse.cd_repasse
     JOIN dbamv.glosas         ON it_repasse.cd_glosas = glosas.cd_glosas
     JOIN dbamv.prestador      ON glosas.cd_prestador = prestador.cd_prestador
     JOIN dbamv.prestador gru_rep ON it_repasse.cd_prestador_repasse = gru_rep.cd_prestador
     JOIN dbamv.pro_fat        ON glosas.cd_pro_fat = pro_fat.cd_pro_fat
     JOIN dbamv.gru_pro        ON pro_fat.cd_gru_pro = gru_pro.cd_gru_pro
     JOIN dbamv.reg_fat        ON glosas.cd_reg_fat = reg_fat.cd_reg_fat
     JOIN dbamv.convenio       ON reg_fat.cd_convenio = convenio.cd_convenio
     JOIN dbamv.atendime       ON reg_fat.cd_atendimento = atendime.cd_atendimento
     JOIN dbamv.paciente       ON atendime.cd_paciente = paciente.cd_paciente
     JOIN dbamv.itreg_fat      ON reg_fat.cd_reg_fat = itreg_fat.cd_reg_fat
                               AND glosas.cd_pro_fat = itreg_fat.cd_pro_fat
     LEFT JOIN dbamv.ati_med   ON glosas.cd_ati_med = ati_med.cd_ati_med
     JOIN dbamv.motivo_glosa   ON glosas.cd_motivo_glosa = motivo_glosa.cd_motivo_glosa
     WHERE atendime.cd_multi_empresa = '1'
       AND repasse.cd_multi_empresa = '1'
       AND it_repasse.sn_virtual = 'N'
       AND NVL(glosas.vl_recebido, 0) = 0
       AND itreg_fat.cd_lancamento = (
           SELECT MIN(it.cd_lancamento)
             FROM dbamv.itreg_fat it
            WHERE it.cd_reg_fat = reg_fat.cd_reg_fat
              AND it.cd_pro_fat = glosas.cd_pro_fat
       )
       AND prestador.cd_prestador <> 2705
       AND prestador.cd_prestador = 37 
      -- AND prestador.cd_prestador_repasse = 83525
       AND TO_CHAR(repasse.dt_competencia, 'MM/YYYY') = '05/2025'
       AND repasse.dt_repasse IS NOT NULL

    UNION ALL

    -- BLOCO 2 - AMBULATORIAL SEM DATA DE RECEBIMENTO
    SELECT DISTINCT
           prestador.cd_prestador_repasse        AS cd_gru_rep,
           (SELECT nm_prestador
              FROM dbamv.prestador p
             WHERE p.cd_prestador = prestador.cd_prestador_repasse) AS ds_gru_rep,
           prestador.cd_prestador,
           prestador.nm_prestador,
           repasse.dt_repasse,
           repasse.ds_repasse,
           pro_fat.cd_pro_fat,
           pro_fat.ds_pro_fat,
           reg_amb.cd_reg_amb                    AS conta,
           (it_repasse.vl_glosa * -1)            AS vl_repasse,
           atendime.dt_atendimento               AS dt_lancamento,
           glosas.qt_glosa,
           (glosas.vl_glosa * -1)                AS vl_total_conta,
           convenio.nm_convenio,
           paciente.nm_paciente,
           gru_pro.cd_gru_pro,
           gru_pro.ds_gru_pro,
           ''                                    AS ds_ati_med,
           atendime.cd_atendimento,
           it_repasse.vl_perc_repasse,
           repasse.dt_competencia,
           'G'                                   AS sn_horario_contratado,
           motivo_glosa.ds_motivo_glosa
      FROM dbamv.repasse
     JOIN dbamv.it_repasse     ON it_repasse.cd_repasse = repasse.cd_repasse
     JOIN dbamv.glosas         ON it_repasse.cd_glosas = glosas.cd_glosas
     JOIN dbamv.prestador      ON glosas.cd_prestador = prestador.cd_prestador
     JOIN dbamv.prestador gru_rep ON it_repasse.cd_prestador_repasse = gru_rep.cd_prestador
     JOIN dbamv.pro_fat        ON glosas.cd_pro_fat = pro_fat.cd_pro_fat
     JOIN dbamv.gru_pro        ON pro_fat.cd_gru_pro = gru_pro.cd_gru_pro
     JOIN dbamv.reg_amb        ON glosas.cd_reg_amb = reg_amb.cd_reg_amb
     JOIN dbamv.convenio       ON reg_amb.cd_convenio = convenio.cd_convenio
     JOIN dbamv.atendime       ON glosas.cd_atendimento = atendime.cd_atendimento
     JOIN dbamv.paciente       ON atendime.cd_paciente = paciente.cd_paciente
     JOIN dbamv.motivo_glosa   ON glosas.cd_motivo_glosa = motivo_glosa.cd_motivo_glosa
     WHERE atendime.cd_multi_empresa = '1'
       AND repasse.cd_multi_empresa = '1'
       AND it_repasse.sn_virtual = 'N'
       AND NVL(glosas.vl_recebido, 0) = 0
       AND prestador.cd_prestador <> 2705
       AND prestador.cd_prestador = 37 
      -- AND prestador.cd_prestador_repasse = 83525
       AND TO_CHAR(repasse.dt_competencia, 'MM/YYYY') = '05/2025'
       AND repasse.dt_repasse IS NOT NULL

    UNION ALL

    -- BLOCO 3 - HOSPITALAR COM RECURSO REPASSADO (VL_RECEBIDO)
    SELECT DISTINCT
           prestador.cd_prestador_repasse        AS cd_gru_rep,
           (SELECT nm_prestador
              FROM dbamv.prestador p
             WHERE p.cd_prestador = prestador.cd_prestador_repasse) AS ds_gru_rep,
           prestador.cd_prestador,
           prestador.nm_prestador,
           repasse.dt_repasse,
           repasse.ds_repasse,
           pro_fat.cd_pro_fat,
           pro_fat.ds_pro_fat,
           reg_fat.cd_reg_fat                    AS conta,
           glosas.vl_recurso_repassado           AS vl_repasse,
           glosas.dt_recebido                    AS dt_lancamento,
           glosas.qt_glosa,
           glosas.vl_recebido                    AS vl_total_conta,
           convenio.nm_convenio,
           paciente.nm_paciente,
           gru_pro.cd_gru_pro,
           gru_pro.ds_gru_pro,
           ati_med.ds_ati_med,
           atendime.cd_atendimento,
           it_repasse.vl_perc_repasse,
           repasse.dt_competencia,
           'G'                                   AS sn_horario_contratado,
           motivo_glosa.ds_motivo_glosa
      FROM dbamv.repasse
     JOIN dbamv.it_repasse     ON it_repasse.cd_repasse = repasse.cd_repasse
     JOIN dbamv.glosas         ON it_repasse.cd_glosas = glosas.cd_glosas
     JOIN dbamv.prestador      ON glosas.cd_prestador = prestador.cd_prestador
     JOIN dbamv.prestador gru_rep ON it_repasse.cd_prestador_repasse = gru_rep.cd_prestador
     JOIN dbamv.pro_fat        ON glosas.cd_pro_fat = pro_fat.cd_pro_fat
     JOIN dbamv.gru_pro        ON pro_fat.cd_gru_pro = gru_pro.cd_gru_pro
     JOIN dbamv.reg_fat        ON glosas.cd_reg_fat = reg_fat.cd_reg_fat
     JOIN dbamv.convenio       ON reg_fat.cd_convenio = convenio.cd_convenio
     JOIN dbamv.atendime       ON reg_fat.cd_atendimento = atendime.cd_atendimento
     JOIN dbamv.paciente       ON atendime.cd_paciente = paciente.cd_paciente
     LEFT JOIN dbamv.ati_med   ON glosas.cd_ati_med = ati_med.cd_ati_med
     JOIN dbamv.motivo_glosa   ON glosas.cd_motivo_glosa = motivo_glosa.cd_motivo_glosa
     WHERE atendime.cd_multi_empresa = '1'
       AND repasse.cd_multi_empresa = '1'
       AND repasse.tp_repasse = 'R'
       AND prestador.cd_prestador <> 2705
       AND prestador.cd_prestador = 37 
      -- AND prestador.cd_prestador_repasse = 83525
       AND TO_CHAR(repasse.dt_competencia, 'MM/YYYY') = '05/2025'
       AND repasse.dt_repasse IS NOT NULL

    UNION ALL

    -- BLOCO 4 - AMBULATORIAL COM RECURSO REPASSADO
    SELECT DISTINCT
           prestador.cd_prestador_repasse        AS cd_gru_rep,
           (SELECT nm_prestador
              FROM dbamv.prestador p
             WHERE p.cd_prestador = prestador.cd_prestador_repasse) AS ds_gru_rep,
           prestador.cd_prestador,
           prestador.nm_prestador,
           repasse.dt_repasse,
           repasse.ds_repasse,
           pro_fat.cd_pro_fat,
           pro_fat.ds_pro_fat,
           reg_amb.cd_reg_amb                    AS conta,
           glosas.vl_recurso_repassado           AS vl_repasse,
           atendime.dt_atendimento               AS dt_lancamento,
           glosas.qt_glosa,
           glosas.vl_recebido                    AS vl_total_conta,
           convenio.nm_convenio,
           paciente.nm_paciente,
           gru_pro.cd_gru_pro,
           gru_pro.ds_gru_pro,
           ''                                    AS ds_ati_med,
           atendime.cd_atendimento,
           it_repasse.vl_perc_repasse,
           repasse.dt_competencia,
           'G'                                   AS sn_horario_contratado,
           motivo_glosa.ds_motivo_glosa
      FROM dbamv.repasse
     JOIN dbamv.it_repasse     ON it_repasse.cd_repasse = repasse.cd_repasse
     JOIN dbamv.glosas         ON it_repasse.cd_glosas = glosas.cd_glosas
     JOIN dbamv.prestador      ON glosas.cd_prestador = prestador.cd_prestador
     JOIN dbamv.prestador gru_rep ON it_repasse.cd_prestador_repasse = gru_rep.cd_prestador
     JOIN dbamv.pro_fat        ON glosas.cd_pro_fat = pro_fat.cd_pro_fat
     JOIN dbamv.gru_pro        ON pro_fat.cd_gru_pro = gru_pro.cd_gru_pro
     JOIN dbamv.reg_amb        ON glosas.cd_reg_amb = reg_amb.cd_reg_amb
     JOIN dbamv.convenio       ON reg_amb.cd_convenio = convenio.cd_convenio
     JOIN dbamv.atendime       ON glosas.cd_atendimento = atendime.cd_atendimento
     JOIN dbamv.paciente       ON atendime.cd_paciente = paciente.cd_paciente
     JOIN dbamv.motivo_glosa   ON glosas.cd_motivo_glosa = motivo_glosa.cd_motivo_glosa
     WHERE atendime.cd_multi_empresa = '1'
       AND repasse.cd_multi_empresa = '1'
       AND repasse.tp_repasse = 'R'
       AND prestador.cd_prestador <> 2705
       AND prestador.cd_prestador = 37 
      -- AND prestador.cd_prestador_repasse = 83525
       AND TO_CHAR(repasse.dt_competencia, 'MM/YYYY') = '05/2025'
       AND repasse.dt_repasse IS NOT NULL
  )
