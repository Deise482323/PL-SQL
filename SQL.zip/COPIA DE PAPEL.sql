BEGIN
  FOR MD IN (SELECT 342 CD_PAPEL,
                    M.CD_MODULO,
                    M.SN_CONSULTAR,
                    M.SN_ALTERAR,
                    M.SN_EXCLUIR,
                    M.SN_INCLUIR
               FROM DBASGU.PAPEL_MOD M
             
              WHERE M.CD_PAPEL = 9
                AND M.CD_MODULO <> 'M_TRAPRO'
                AND NOT EXISTS(SELECT * FROM DBASGU.PAPEL_MOD M1 WHERE M1.CD_PAPEL = 342 AND M1.CD_MODULO = M.CD_MODULO  )) LOOP
    INSERT INTO DBASGU.PAPEL_MOD
      (CD_PAPEL,
       CD_MODULO,
       SN_CONSULTAR,
       SN_ALTERAR,
       SN_EXCLUIR,
       SN_INCLUIR)
    VALUES
      (MD.CD_PAPEL,
       MD.CD_MODULO,
       MD.SN_CONSULTAR,
       MD.SN_ALTERAR,
       MD.SN_EXCLUIR,
       MD.SN_INCLUIR);
       
       END LOOP ;
       
       END;

SELECT * FROM DBASGU.PAPEL_MOD M
WHERE M.CD_PAPEL = 338
