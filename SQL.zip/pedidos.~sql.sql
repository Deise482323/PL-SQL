SELECT

 sla.cd_ped_lab,
 sla.dt_pedido,
 sla.cd_atendimento,
 sla.cd_setor,
 sla.nm_setor,
 sla.tp_solicitacao,
 sla.nm_exa_lab,
 sla.cd_amostra,
 sla.hr_ped_lab,
 sla.dt_impressao_amostra,
 sla.dataimpressaoetiqueta,
 sla.dt_coleta,
 sla.dt_confirma_lab,
 sla.dt_assinado
 
,
 to_char(soma_sub_data(sla.hr_ped_lab, sla.dataimpressaoetiqueta, '-'),
         'HH24:MI') temp_pedLab_impAmostra,
 to_char(soma_sub_data(sla.dataimpressaoetiqueta, sla.dt_coleta, '-'),
         'HH24:MI') temp_impAmostra_coleta,
 to_char(soma_sub_data(sla.dt_coleta, sla.dt_confirma_lab, '-'), 'HH24:MI') temp_coleta_ConfLab,
 to_char(soma_sub_data(sla.dt_confirma_lab, sla.dt_assinado, '-'),
         'HH24:MI') temp_ConfLab_Ass,
 to_char(soma_sub_data(sla.hr_ped_lab, sla.dt_assinado, '-'), 'HH24:MI') temp_fim
 
,
 sla.cod_unid,
 sla.nr_controle,
 sla.nm_mnemonico,
 sla.cd_codigo_externo

  FROM (
        
        select pl.cd_ped_lab,
                pl.dt_pedido,
                pl.cd_atendimento,
                pl.cd_setor,
                s.nm_setor,
                pl.tp_solicitacao,
                ex.nm_exa_lab,
                a.cd_amostra,
                to_date(to_char(pl.dt_pedido, 'DD/MM/RRRR') ||
                        to_char(pl.hr_ped_lab, 'HH24:MI'),
                        'DD/MM/RRRR HH24:MI') hr_ped_lab,
                to_date(ax.dataimpressaoetiqueta, 'DD/MM/RRRR HH24:MI') dt_impressao_amostra,
                ax.dataimpressaoetiqueta
                --,to_date(a.dt_coleta, 'DD/MM/RRRR HH24:MI') dt_coleta
               ,
                a.dt_coleta
                
               ,
                (select min(to_date(axf.dt_receb_amostra, 'DD/MM/RRRR HH24:MI'))
                   from enkyo.tb_aux_exames_fleury axf
                  where axf.ficha = substr(a.cd_amostra, 1, 10)
                    and axf.cd_exa_externo = ex.cd_codigo_externo
                 
                 ) dt_confirma_lab
                
               ,
                (select min(to_date(axf.dt_laudo, 'DD/MM/RRRR HH24:MI'))
                   from enkyo.tb_aux_exames_fleury axf
                  where axf.ficha = substr(a.cd_amostra, 1, 10)
                    and axf.cd_exa_externo = ex.cd_codigo_externo
                 
                 ) dt_assinado
                
                /*,to_char(soma_sub_data(pl.hr_ped_lab, ax.dataimpressaoetiqueta,'-'),'HH24:MI') temp_pedLab_impAmostra
                ,to_char(soma_sub_data(ax.dataimpressaoetiqueta, a.dt_coleta,'-'),'HH24:MI') temp_impAmostra_coleta
                ,to_char(soma_sub_data(a.dt_coleta, a.dt_confirma_lab,'-'),'HH24:MI') temp_coleta_ConfLab
                ,to_char(soma_sub_data(a.dt_confirma_lab, it.dt_assinado,'-'),'HH24:MI') temp_ConfLab_Ass
                ,to_char(soma_sub_data(pl.hr_ped_lab, it.dt_assinado,'-'),'HH24:MI') temp_fim*/
                
               ,
                case
                  when substr(a.cd_amostra, 1, 3) in
                       ('417', '683', '684', '685') then
                   substr(a.cd_amostra, 1, 3)
                  else
                   ''
                end Cod_Unid,
                pl.nr_controle,
                ex.nm_mnemonico,
                ex.cd_codigo_externo
        
          from dbamv.ped_lab pl
         inner join dbamv.itped_lab it
            on it.cd_ped_lab = pl.cd_ped_lab
         inner join dbamv.amostra_exa_lab axl
            on axl.cd_itped_lab = it.cd_itped_lab
         inner join dbamv.amostra a
            on a.cd_amostra = axl.cd_amostra
         inner join dbamv.setor s
            on s.cd_setor = pl.cd_setor
         inner join dbamv.exa_lab ex
            on ex.cd_exa_lab = it.cd_exa_lab
         inner join dbamv.amostra_externo ax
            on ax.codigoamostra = a.cd_amostra
        
       /*  where {V_VAR}
         where to_date(pl.dt_pedido, 'DD/MM/RRRR') between @P_DATA_INI and
               @P_DATA_FIM
           and s.cd_setor in ({V_SETOR_AUX})*/
        
         group by pl.cd_ped_lab,
                   pl.dt_pedido,
                   pl.cd_atendimento,
                   pl.cd_setor,
                   s.nm_setor,
                   pl.tp_solicitacao,
                   ex.nm_exa_lab,
                   ex.cd_exa_lab,
                   a.cd_amostra,
                   to_date(to_char(pl.dt_pedido, 'DD/MM/RRRR') ||
                           to_char(pl.hr_ped_lab, 'HH24:MI'),
                           'DD/MM/RRRR HH24:MI')
                   --,to_date(ax.dataimpressaoetiqueta, 'DD/MM/RRRR HH24:MI')
                  ,
                   ax.dataimpressaoetiqueta
                   --,to_dat(a.dt_coleta, 'DD/MM/RRRR HH24:MI') 
                  ,
                   a.dt_coleta,
                   to_date(a.dt_confirma_lab, 'DD/MM/RRRR HH24:MI'),
                   to_date(it.dt_assinado, 'DD/MM/RRRR HH24:MI')
                   
                   /*    ,to_char(soma_sub_data(pl.hr_ped_lab, ax.dataimpressaoetiqueta,'-'),'HH24:MI')
                   ,to_char(soma_sub_data(ax.dataimpressaoetiqueta, a.dt_coleta,'-'),'HH24:MI') 
                   ,to_char(soma_sub_data(a.dt_coleta, a.dt_confirma_lab,'-'),'HH24:MI') 
                   ,to_char(soma_sub_data(a.dt_confirma_lab, it.dt_assinado,'-'),'HH24:MI') 
                   ,to_char(soma_sub_data(pl.hr_ped_lab, it.dt_assinado,'-'),'HH24:MI')*/,
                   case
                     when substr(a.cd_amostra, 1, 3) in
                          ('417', '683', '684', '685') then
                      substr(a.cd_amostra, 1, 3)
                     else
                      ''
                   end,
                   pl.nr_controle,
                   ex.nm_mnemonico,
                   ex.cd_codigo_externo
        
        ) SLA
        
        WHERE SLA.CD_PED_LAB = 2342200
