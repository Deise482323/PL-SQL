SELECT * FROM dbamv.mot_bai
