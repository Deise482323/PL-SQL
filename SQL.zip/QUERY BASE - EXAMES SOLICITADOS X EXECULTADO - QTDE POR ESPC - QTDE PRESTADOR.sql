SELECT 
    ATE.CD_ORI_ATE, 
    OA.DS_ORI_ATE, 
    EL.CD_EXA_LAB, 
    EL.NM_EXA_LAB, 
    EM.DS_ESPECIALID, 
    P.NM_PRESTADOR,
    COUNT(IPL.CD_EXA_LAB) AS QTD_SOLICITADO,
    SUM(
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM dbamv.amostra_exa_lab ael
                INNER JOIN amostra am ON am.cd_amostra = ael.cd_amostra
                WHERE ael.cd_itped_lab = IPL.cd_itped_lab
                  AND am.dt_coleta IS NOT NULL
            ) 
            OR EXISTS (
                SELECT 1
                FROM DBAMV.RES_EXA RE
                WHERE RE.CD_ITPED_LAB = IPL.cd_itped_lab
                  AND RE.CD_PED_LAB = PL.CD_PED_LAB
            )
            OR EXISTS (
                SELECT 1
                FROM dbamv.cultura c
                WHERE c.cd_ped_lab = IPL.cd_ped_lab
                  AND c.cd_exa_lab = IPL.cd_exa_lab
                  AND c.cd_itped_lab = IPL.cd_itped_lab
            )
            THEN 1
            ELSE 0
        END
    ) AS QTD_EXECUTADO
FROM 
    ITPED_LAB IPL
INNER JOIN 
    PED_LAB PL ON PL.CD_PED_LAB = IPL.CD_PED_LAB
INNER JOIN 
    ATENDIME ATE ON ATE.CD_ATENDIMENTO = PL.CD_ATENDIMENTO
INNER JOIN 
    EXA_LAB EL ON EL.CD_EXA_LAB = IPL.CD_EXA_LAB
INNER JOIN 
    ORI_ATE OA ON OA.CD_ORI_ATE = ATE.CD_ORI_ATE
INNER JOIN 
    ESP_MED EM ON EM.CD_ESPECIALID = ATE.CD_ESPECIALID
INNER JOIN 
    PRESTADOR P ON P.CD_PRESTADOR = ATE.CD_PRESTADOR
WHERE 
   PL.DT_PEDIDO BETWEEN TO_DATE('01/01/2023', 'DD/MM/YYYY') AND TO_DATE('30/06/2024', 'DD/MM/YYYY')
    AND OA.CD_ORI_ATE = 35
GROUP BY 
    ATE.CD_ORI_ATE, 
    OA.DS_ORI_ATE, 
    EL.CD_EXA_LAB, 
    EL.NM_EXA_LAB, 
    EM.DS_ESPECIALID, 
    P.NM_PRESTADOR;
